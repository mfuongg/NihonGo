import '../models/reading_material.dart';

class ReadingMaterialData {
  static List<ReadingMaterial> _loadedMaterials = <ReadingMaterial>[];
  static List<CultureTopic> _loadedCultureTopics = <CultureTopic>[];

  static void setLoadedMaterials(List<ReadingMaterial> materials) {
    _loadedMaterials = List<ReadingMaterial>.unmodifiable(materials);
  }

  static void setLoadedCultureTopics(List<CultureTopic> topics) {
    _loadedCultureTopics = List<CultureTopic>.unmodifiable(topics);
  }

  static List<ReadingMaterial> getAllMaterials() => _loadedMaterials;
  static List<CultureTopic> getAllCultureTopics() => _loadedCultureTopics;
}

List<ReadingMaterial> buildReadingMaterials() {
  return ReadingMaterialData.getAllMaterials();
}

List<CultureTopic> buildCultureTopics() {
  return ReadingMaterialData.getAllCultureTopics();
}
