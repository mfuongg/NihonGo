import '../models/grammar.dart';

class GrammarData {
  static const List<String> levels = ['N5', 'N4', 'N3', 'N2', 'N1'];
  static List<GrammarLesson> _loadedLessons = <GrammarLesson>[];

  static void setLoadedLessons(List<GrammarLesson> lessons) {
    _loadedLessons = List<GrammarLesson>.unmodifiable(lessons);
  }

  static List<GrammarLesson> getAllLessons() => _loadedLessons;

  static List<GrammarLesson> getLessonsByLevel(String level) {
    return _loadedLessons.where((g) => g.jlptLevel == level).toList();
  }
}
