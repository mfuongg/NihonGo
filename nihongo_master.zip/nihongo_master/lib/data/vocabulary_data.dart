import '../models/vocabulary.dart';

class VocabularyData {
  static List<VocabularyWord> _loadedWords = <VocabularyWord>[];

  static void setLoadedWords(List<VocabularyWord> words) {
    _loadedWords = List<VocabularyWord>.unmodifiable(words);
  }

  static List<VocabularyWord> getAllWords() {
    return _loadedWords;
  }

  static List<VocabularyWord> getWordsByLevel(String level) {
    return _loadedWords.where((w) => w.jlptLevel == level).toList();
  }

  static List<VocabularyWord> search(String query) {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const <VocabularyWord>[];
    final q = trimmed.toLowerCase();
    return _loadedWords.where((w) {
      return w.japanese.contains(trimmed) ||
          w.hiragana.contains(trimmed) ||
          w.romaji.toLowerCase().contains(q) ||
          w.vietnamese.toLowerCase().contains(q) ||
          w.english.toLowerCase().contains(q);
    }).toList();
  }
}
