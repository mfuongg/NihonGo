import '../models/quiz.dart';

class JLPTTestData {
  static List<JLPTTest> _loadedTests = <JLPTTest>[];

  static void setLoadedTests(List<JLPTTest> tests) {
    _loadedTests = List<JLPTTest>.unmodifiable(tests);
  }

  static void upsertTest(JLPTTest test) {
    final next = <JLPTTest>[
      test,
      ..._loadedTests.where((t) => t.id != test.id),
    ];
    _loadedTests = List<JLPTTest>.unmodifiable(next);
  }

  static List<JLPTTest> getAllTests() => _loadedTests;

  static List<JLPTTest> getTestsByLevel(String level) {
    return _loadedTests.where((t) => t.level == level).toList();
  }
}
