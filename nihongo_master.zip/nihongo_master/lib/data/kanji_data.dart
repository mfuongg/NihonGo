import '../models/kanji.dart';
import '../models/vocabulary.dart';
import 'vocabulary_data.dart';

class KanjiData {
  static const List<String> _levels = ['N5', 'N4', 'N3', 'N2', 'N1'];
  static List<KanjiItem> _loadedKanji = <KanjiItem>[];

  static void setLoadedKanji(List<KanjiItem> items) {
    _loadedKanji = List<KanjiItem>.unmodifiable(items);
  }

  static List<KanjiItem> getAllKanji() {
    if (_loadedKanji.isNotEmpty) {
      return _loadedKanji;
    }
    return _levels.expand((level) => getKanjiByLevel(level)).toList();
  }

  static List<KanjiItem> getKanjiByLevel(String level) {
    return _loadedKanji.where((k) => k.jlptLevel == level).toList();
  }

  static List<VocabularyWord> getPracticeWordsByLevel(
    String level, {
    int limit = 24,
  }) {
    final levelKanjiChars =
        getKanjiByLevel(level).map((k) => k.kanji).toSet();
    final levelWords = VocabularyData.getWordsByLevel(level);
    if (levelWords.isEmpty) {
      return const <VocabularyWord>[];
    }

    if (levelKanjiChars.isNotEmpty) {
      final matching = levelWords.where((w) {
        for (var i = 0; i < w.japanese.length; i++) {
          if (levelKanjiChars.contains(w.japanese[i])) {
            return true;
          }
        }
        return false;
      }).toList();
      if (matching.isNotEmpty) {
        return matching.take(limit).toList();
      }
    }
    return levelWords.take(limit).toList();
  }

  static List<KanjiItem> search(String query) {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return getAllKanji();

    return getAllKanji().where((k) {
      return k.kanji.contains(query.trim()) ||
          k.onyomi.toLowerCase().contains(normalized) ||
          k.kunyomi.toLowerCase().contains(normalized) ||
          k.vietnamese.toLowerCase().contains(normalized) ||
          k.english.toLowerCase().contains(normalized) ||
          k.exampleWords.any((w) => w.toLowerCase().contains(normalized)) ||
          k.exampleMeanings.any((m) => m.toLowerCase().contains(normalized));
    }).toList();
  }
}
