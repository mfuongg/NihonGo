import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../data/grammar_data.dart';
import '../data/jlpt_test_data.dart';
import '../data/kanji_data.dart';
import '../data/reading_material_data.dart';
import '../data/vocabulary_data.dart';
import '../models/grammar.dart';
import '../models/quiz.dart';
import '../models/vocabulary.dart';
import '../utils/content_fallback.dart';
import 'local_database_service.dart';

enum TutorMeaningStatus {
  available,
  partialEnglishOnly,
  missingAll,
}

enum TutorRetrievalStatus {
  success,
  successPartialMeaning,
  successNoMeaning,
  noMatch,
  databaseError,
  invalidQuery,
}

class TutorRetrievedItem {
  final String? itemId;
  final String category;
  final String titleJp;
  final String reading;
  final String hiragana;
  final String romaji;
  final String meaningVi;
  final String rawMeaningVi;
  final String meaningEn;
  final String level;
  final String detail;

  const TutorRetrievedItem({
    this.itemId,
    required this.category,
    required this.titleJp,
    required this.reading,
    this.hiragana = '',
    this.romaji = '',
    required this.meaningVi,
    this.rawMeaningVi = '',
    this.meaningEn = '',
    required this.level,
    this.detail = '',
  });

  String? get cleanedMeaningVi => ContentFallback.cleanText(rawMeaningVi);

  String? get cleanedMeaningEn => ContentFallback.cleanText(meaningEn);

  bool get hasMeaningVi => cleanedMeaningVi != null;

  bool get hasMeaningEn => cleanedMeaningEn != null;

  TutorMeaningStatus get meaningStatus {
    if (hasMeaningVi) return TutorMeaningStatus.available;
    if (hasMeaningEn) return TutorMeaningStatus.partialEnglishOnly;
    return TutorMeaningStatus.missingAll;
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        if (itemId != null) 'itemId': itemId,
        'category': category,
        'titleJp': titleJp,
        'reading': reading,
        'hiragana': hiragana,
        'romaji': romaji,
        'meaningVi': meaningVi,
        'rawMeaningVi': rawMeaningVi,
        'meaningEn': meaningEn,
        'level': level,
        'detail': detail,
      };

  factory TutorRetrievedItem.fromJson(Map<String, dynamic> map) {
    final rawVi = ContentFallback.cleanText(map['rawMeaningVi']?.toString());
    final rawEn = ContentFallback.cleanText(map['meaningEn']?.toString());
    final fallbackVi = ContentFallback.cleanText(map['meaningVi']?.toString());
    return TutorRetrievedItem(
      itemId: ContentFallback.cleanText(map['itemId']?.toString()),
      category: map['category']?.toString() ?? 'Từ vựng',
      titleJp: map['titleJp']?.toString() ?? '',
      reading: map['reading']?.toString() ?? '',
      hiragana: map['hiragana']?.toString() ?? '',
      romaji: map['romaji']?.toString() ?? '',
      meaningVi: rawVi ?? rawEn ?? fallbackVi ?? '',
      rawMeaningVi: rawVi ?? '',
      meaningEn: rawEn ?? '',
      level: map['level']?.toString() ?? 'N5',
      detail: map['detail']?.toString() ?? '',
    );
  }
}

class QuangThuongTutorResponse {
  final String query;
  final String level;
  final List<TutorRetrievedItem> retrievedSqliteItems;
  final String sqliteSummaryAnswer;
  final String? aiGeneratedExplanation;
  final bool isAiOnline;
  final bool isDatabaseError;
  final String? errorMessage;
  final String suggestedPracticeRoute;

  const QuangThuongTutorResponse({
    required this.query,
    required this.level,
    required this.retrievedSqliteItems,
    required this.sqliteSummaryAnswer,
    this.aiGeneratedExplanation,
    required this.isAiOnline,
    this.isDatabaseError = false,
    this.errorMessage,
    this.suggestedPracticeRoute = 'vocab',
  });

  bool get isRetrievalSuccess =>
      retrievedSqliteItems.isNotEmpty && !isDatabaseError;

  TutorMeaningStatus? get primaryMeaningStatus =>
      retrievedSqliteItems.isEmpty
          ? null
          : retrievedSqliteItems.first.meaningStatus;

  static bool hasValidQueryCharacters(String text) {
    return RegExp(
      r'[a-zA-Z0-9\u00C0-\u1EF9\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]',
    ).hasMatch(text);
  }

  TutorRetrievalStatus get retrievalStatus {
    if (query.trim().isEmpty || !hasValidQueryCharacters(query)) {
      return TutorRetrievalStatus.invalidQuery;
    }
    if (isDatabaseError) return TutorRetrievalStatus.databaseError;
    if (retrievedSqliteItems.isEmpty) return TutorRetrievalStatus.noMatch;
    return switch (retrievedSqliteItems.first.meaningStatus) {
      TutorMeaningStatus.available => TutorRetrievalStatus.success,
      TutorMeaningStatus.partialEnglishOnly =>
        TutorRetrievalStatus.successPartialMeaning,
      TutorMeaningStatus.missingAll => TutorRetrievalStatus.successNoMeaning,
    };
  }
}

class GeminiHttpResponse {
  final int statusCode;
  final String body;

  const GeminiHttpResponse({
    required this.statusCode,
    required this.body,
  });
}

typedef GeminiHttpPostHandler = Future<GeminiHttpResponse> Function(
  Uri uri,
  Map<String, String> headers,
  String body,
);

class GeminiRagContext {
  final String level;
  final List<VocabularyWord> vocabularies;
  final List<GrammarLesson> grammarPoints;

  const GeminiRagContext({
    required this.level,
    required this.vocabularies,
    required this.grammarPoints,
  });
}

class GeminiExamGenerationResult {
  final JLPTTest test;
  final bool isAiGenerated;
  final bool isFallback;
  final String sourceId;
  final String statusMessage;
  final GeminiRagContext ragContext;

  const GeminiExamGenerationResult({
    required this.test,
    required this.isAiGenerated,
    required this.isFallback,
    required this.sourceId,
    required this.statusMessage,
    required this.ragContext,
  });
}

/// Real AI Exam Generation Service using RAG (Retrieval-Augmented Generation)
/// over the verified local SQLite JLPT dataset (`verified_v2`).
///
/// Security & Integrity Guarantees:
/// 1. NEVER hardcodes any API key in client source code or web bundles.
///    Supports Backend Proxy (`--dart-define=GEMINI_PROXY_URL=...`) or
///    environment-injected key (`--dart-define=GEMINI_API_KEY=...`).
/// 2. Checks model endpoint availability across current stable Flash models
///    with automatic fallback if an endpoint returns 404/deprecated.
/// 3. Strictly separates AI-generated exams (`is_ai_generated = 1`, `src_gemini_rag`)
///    from offline SQLite fallback exams (`is_ai_generated = 0`, `src_sqlite_backup`).
class GeminiExamService {
  GeminiExamService._internal();
  static final GeminiExamService instance = GeminiExamService._internal();

  static const String _envProxyUrl = String.fromEnvironment(
    'GEMINI_PROXY_URL',
    defaultValue: '',
  );
  static const String _envApiKey = String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: '',
  );
  static const String _envModel = String.fromEnvironment(
    'GEMINI_MODEL',
    defaultValue: 'gemini-3.5-flash-lite',
  );

  static const List<String> candidateModels = <String>[
    'gemini-3.5-flash-lite',
    'gemini-2.5-flash',
    'gemini-2.0-flash',
  ];

  static const Duration requestTimeout = Duration(seconds: 15);

  GeminiHttpPostHandler? _httpPostOverride;
  String? _apiKeyOverride;
  String? _proxyUrlOverride;

  @visibleForTesting
  void configureForTesting({
    GeminiHttpPostHandler? httpPostOverride,
    String? apiKeyOverride,
    String? proxyUrlOverride,
  }) {
    _httpPostOverride = httpPostOverride;
    _apiKeyOverride = apiKeyOverride;
    _proxyUrlOverride = proxyUrlOverride;
  }

  /// Step 1 of RAG: Retrieve 5–10 random vocabulary words and 2–3 grammar points
  /// for the target JLPT [level] from verified local datasets / SQLite.
  Future<GeminiRagContext> retrieveRagContext(
    String level, {
    int vocabCount = 6,
    int grammarCount = 3,
    Random? random,
  }) async {
    final rng = random ?? Random();
    final normalizedLevel = level.trim().toUpperCase();

    var allVocab = VocabularyData.getWordsByLevel(normalizedLevel);
    if (allVocab.isEmpty && !kIsWeb) {
      try {
        final cached = await LocalDatabaseService.instance.getCachedVocabulary();
        allVocab = cached
            .where((w) => w.jlptLevel.toUpperCase() == normalizedLevel)
            .toList();
      } catch (_) {}
    }

    var allGrammar = GrammarData.getLessonsByLevel(normalizedLevel);
    if (allGrammar.isEmpty && !kIsWeb) {
      try {
        final dbGrammar =
            await LocalDatabaseService.instance.getGrammarLessonsFromDb();
        allGrammar = dbGrammar
            .where((g) => g.jlptLevel.toUpperCase() == normalizedLevel)
            .toList();
      } catch (_) {}
    }

    final vocabPool = List<VocabularyWord>.from(allVocab)..shuffle(rng);
    final grammarPool = List<GrammarLesson>.from(allGrammar)..shuffle(rng);

    final selectedVocab = vocabPool.take(vocabCount.clamp(5, 10)).toList();
    final selectedGrammar = grammarPool.take(grammarCount.clamp(2, 3)).toList();

    return GeminiRagContext(
      level: normalizedLevel,
      vocabularies: selectedVocab,
      grammarPoints: selectedGrammar,
    );
  }

  /// Step 2 of RAG: Augment retrieved vocabulary & grammar into a strict JSON prompt.
  String buildRagPrompt(GeminiRagContext context) {
    final vocabLines = context.vocabularies.map((v) {
      final meaning = v.vietnamese.trim().isNotEmpty ? v.vietnamese : v.english;
      return '- ${v.japanese} (${v.hiragana}): $meaning';
    }).join('\n');

    final grammarLines = context.grammarPoints.map((g) {
      final title = (g.titleVi ?? '').trim().isNotEmpty ? g.titleVi! : g.title;
      return '- ${g.pattern}: $title';
    }).join('\n');

    return '''
Bạn là chuyên gia khảo thí JLPT cấp độ ${context.level}.
Hãy sử dụng BẮT BUỘC các từ vựng và mẫu ngữ pháp đã truy xuất từ kho dữ liệu chuẩn dưới đây để biên soạn 1 đoạn văn đọc hiểu ngắn bằng tiếng Nhật (phù hợp trình độ ${context.level}) và ĐÚNG 5 câu hỏi trắc nghiệm (4 lựa chọn A, B, C, D).

[TỪ VỰNG TRUY XUẤT (RAG VOCABULARY - ${context.level})]
$vocabLines

[NGỮ PHÁP TRUY XUẤT (RAG GRAMMAR - ${context.level})]
$grammarLines

YÊU CẦU ĐẦU RA:
Chỉ trả về DUY NHẤT một chuỗi JSON hợp lệ (không bọc trong markdown ```json) theo đúng cấu trúc:
{
  "title": "Đề thi AI RAG JLPT ${context.level} - Đọc hiểu & Ngữ cảnh",
  "reading_passage": "Đoạn văn tiếng Nhật ngắn sử dụng từ vựng và ngữ pháp trên (kèm bản dịch tiếng Việt ngắn gọn bên dưới)",
  "questions": [
    {
      "question_jp": "Câu hỏi tiếng Nhật có chứa từ vựng/ngữ pháp hoặc hỏi về đoạn văn",
      "question_vi": "Yêu cầu câu hỏi bằng tiếng Việt",
      "options": ["Lựa chọn A", "Lựa chọn B", "Lựa chọn C", "Lựa chọn D"],
      "correct_index": 0,
      "explanation": "Giải thích chi tiết bằng tiếng Việt vì sao đáp án đúng",
      "type": "reading"
    }
  ]
}
''';
  }

  /// Step 3 of RAG: Call Gemini endpoint (or Backend Proxy), parse JSON into `JLPTTest`,
  /// persist to SQLite (`is_ai_generated = 1`, `src_gemini_rag`), or gracefully fallback
  /// to local SQLite verified questions (`is_ai_generated = 0`, `src_sqlite_backup`).
  Future<GeminiExamGenerationResult> generateExam({
    required String level,
    bool persistToSqlite = true,
  }) async {
    final normalizedLevel = level.trim().toUpperCase();
    final ragContext = await retrieveRagContext(normalizedLevel);
    final prompt = buildRagPrompt(ragContext);

    final effectiveProxyUrl = (_proxyUrlOverride ?? _envProxyUrl).trim();
    final effectiveApiKey = (_apiKeyOverride ?? _envApiKey).trim();

    if (effectiveProxyUrl.isEmpty && effectiveApiKey.isEmpty) {
      return _buildAndPersistFallbackExam(
        ragContext: ragContext,
        reason:
            'Đang sử dụng đề dự phòng do sự cố kết nối AI (chưa cấu hình endpoint/proxy).',
        persistToSqlite: persistToSqlite,
      );
    }

    final modelsToTry = <String>{
      _envModel.trim().isEmpty ? candidateModels.first : _envModel.trim(),
      ...candidateModels,
    }.toList();

    String lastErrorReason = 'Đang sử dụng đề dự phòng do sự cố kết nối AI.';

    for (final modelName in modelsToTry) {
      try {
        final uri = effectiveProxyUrl.isNotEmpty
            ? Uri.parse(effectiveProxyUrl)
            : Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$effectiveApiKey',
              );

        final requestBody = jsonEncode(<String, Object?>{
          'model': modelName,
          'contents': <Map<String, Object?>>[
            <String, Object?>{
              'role': 'user',
              'parts': <Map<String, Object?>>[
                <String, Object?>{'text': prompt},
              ],
            },
          ],
          'generationConfig': <String, Object?>{
            'temperature': 0.4,
            'responseMimeType': 'application/json',
          },
        });

        final response = await _postJson(
          uri,
          const <String, String>{'Content-Type': 'application/json'},
          requestBody,
        ).timeout(requestTimeout);

        if (response.statusCode == 404) {
          // Model endpoint deprecated or not found -> try next candidate Flash model
          lastErrorReason =
              'Endpoint model $modelName không khả dụng (HTTP 404).';
          continue;
        }

        if (response.statusCode == 429) {
          lastErrorReason =
              'Đang sử dụng đề dự phòng do sự cố kết nối AI (hết hạn mức quota HTTP 429).';
          break;
        }

        if (response.statusCode < 200 || response.statusCode >= 300) {
          lastErrorReason =
              'Đang sử dụng đề dự phòng do sự cố kết nối AI (HTTP ${response.statusCode}).';
          break;
        }

        final parsedTest = _parseGeminiResponseToTest(
          rawResponseBody: response.body,
          level: normalizedLevel,
        );
        if (parsedTest != null && parsedTest.questions.length >= 5) {
          if (persistToSqlite) {
            await LocalDatabaseService.instance.saveGeneratedExamToDb(parsedTest);
          }
          JLPTTestData.upsertTest(parsedTest);
          return GeminiExamGenerationResult(
            test: parsedTest,
            isAiGenerated: true,
            isFallback: false,
            sourceId: 'src_gemini_rag',
            statusMessage:
                'Đã sinh đề thi tự động bằng AI (Gemini RAG Engine) thành công.',
            ragContext: ragContext,
          );
        } else {
          lastErrorReason =
              'Đang sử dụng đề dự phòng do dữ liệu phản hồi AI không đúng định dạng.';
          break;
        }
      } on TimeoutException {
        lastErrorReason =
            'Đang sử dụng đề dự phòng do sự cố kết nối AI (quá thời gian chờ 15s).';
        break;
      } catch (_) {
        lastErrorReason =
            'Đang sử dụng đề dự phòng do sự cố kết nối AI.';
        break;
      }
    }

    return _buildAndPersistFallbackExam(
      ragContext: ragContext,
      reason: lastErrorReason,
      persistToSqlite: persistToSqlite,
    );
  }

  Future<GeminiHttpResponse> _postJson(
    Uri uri,
    Map<String, String> headers,
    String body,
  ) async {
    final override = _httpPostOverride;
    if (override != null) {
      return override(uri, headers, body);
    }

    final client = HttpClient();
    client.connectionTimeout = requestTimeout;
    try {
      final request = await client.postUrl(uri);
      headers.forEach(request.headers.set);
      final encoded = utf8.encode(body);
      request.contentLength = encoded.length;
      request.add(encoded);
      final response = await request.close();
      final responseBody = await response.transform(utf8.decoder).join();
      return GeminiHttpResponse(
        statusCode: response.statusCode,
        body: responseBody,
      );
    } finally {
      client.close(force: true);
    }
  }

  JLPTTest? _parseGeminiResponseToTest({
    required String rawResponseBody,
    required String level,
  }) {
    try {
      final outer = jsonDecode(rawResponseBody);
      Map<String, dynamic>? payload;

      if (outer is Map<String, dynamic>) {
        if (outer.containsKey('questions') && outer['questions'] is List) {
          payload = outer;
        } else if (outer['candidates'] is List &&
            (outer['candidates'] as List).isNotEmpty) {
          final firstCandidate = (outer['candidates'] as List).first;
          final parts = firstCandidate['content']?['parts'];
          if (parts is List && parts.isNotEmpty) {
            final rawText = (parts.first['text']?.toString() ?? '').trim();
            final cleanedText = _stripMarkdownJsonFence(rawText);
            final inner = jsonDecode(cleanedText);
            if (inner is Map<String, dynamic>) {
              payload = inner;
            }
          }
        }
      }

      if (payload == null) return null;
      final rawQuestions = payload['questions'];
      if (rawQuestions is! List || rawQuestions.isEmpty) return null;

      final stamp = DateTime.now().millisecondsSinceEpoch;
      final examId = 'exam_ai_rag_${level}_$stamp';
      final readingPassage = payload['reading_passage']?.toString().trim();
      final title = (payload['title']?.toString().trim().isNotEmpty ?? false)
          ? payload['title'].toString().trim()
          : 'Đề thi AI RAG JLPT $level (Đọc hiểu & Ngữ cảnh)';

      final quizQuestions = <QuizQuestion>[];
      for (var i = 0; i < rawQuestions.length && i < 5; i++) {
        final item = rawQuestions[i];
        if (item is! Map) continue;
        final qJp = item['question_jp']?.toString().trim() ?? '';
        final qVi = item['question_vi']?.toString().trim() ??
            'Chọn đáp án đúng nhất cho câu hỏi cấp độ $level:';
        final rawOpts = item['options'];
        if (rawOpts is! List || rawOpts.length < 4) continue;
        final options =
            rawOpts.take(4).map((e) => e.toString().trim()).toList();
        final correctIdxRaw = item['correct_index'];
        final correctIdx = (correctIdxRaw is int)
            ? correctIdxRaw.clamp(0, 3)
            : (int.tryParse(correctIdxRaw?.toString() ?? '0') ?? 0).clamp(0, 3);
        final explanation = item['explanation']?.toString().trim() ??
            'Giải thích từ mô hình AI RAG cấp độ $level.';
        final rawType = item['type']?.toString().toLowerCase() ?? 'reading';
        final qType = switch (rawType) {
          'grammar' => QuestionType.grammar,
          'vocab' || 'vocabulary' => QuestionType.vocabularyMeaning,
          _ => QuestionType.reading,
        };

        quizQuestions.add(
          QuizQuestion(
            id: '${examId}_q_${i + 1}',
            question: qVi,
            questionJp: qJp,
            options: options,
            correctIndex: correctIdx,
            explanation: explanation,
            jlptLevel: level,
            type: qType,
          ),
        );
      }

      if (quizQuestions.length < 5) return null;

      return JLPTTest(
        id: examId,
        level: level,
        title: title,
        timeMinutes: 15,
        questions: quizQuestions,
        isAiGenerated: true,
        isFallback: false,
        sourceId: 'src_gemini_rag',
        readingPassage: readingPassage,
      );
    } catch (_) {
      return null;
    }
  }

  String _stripMarkdownJsonFence(String text) {
    var cleaned = text.trim();
    if (cleaned.startsWith('```json')) {
      cleaned = cleaned.substring(7).trim();
    } else if (cleaned.startsWith('```')) {
      cleaned = cleaned.substring(3).trim();
    }
    if (cleaned.endsWith('```')) {
      cleaned = cleaned.substring(0, cleaned.length - 3).trim();
    }
    return cleaned;
  }

  Future<GeminiExamGenerationResult> _buildAndPersistFallbackExam({
    required GeminiRagContext ragContext,
    required String reason,
    required bool persistToSqlite,
  }) async {
    final level = ragContext.level;
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final examId = 'exam_sqlite_fallback_${level}_$stamp';

    final existingLevelTests = JLPTTestData.getTestsByLevel(level)
        .where((t) => !t.isAiGenerated && !t.isFallback)
        .toList();

    final fallbackQuestions = <QuizQuestion>[];

    if (existingLevelTests.isNotEmpty) {
      final pool = <QuizQuestion>[
        for (final t in existingLevelTests) ...t.questions,
      ];
      for (var i = 0; i < pool.length && fallbackQuestions.length < 5; i++) {
        final q = pool[i];
        fallbackQuestions.add(
          QuizQuestion(
            id: '${examId}_q_${fallbackQuestions.length + 1}',
            question: q.question,
            questionJp: q.questionJp,
            options: q.options,
            correctIndex: q.correctIndex,
            explanation: q.explanation,
            jlptLevel: level,
            type: q.type,
          ),
        );
      }
    }

    // Supplement with verified vocabulary/grammar questions from RAG context if needed
    final vocabList = ragContext.vocabularies;
    for (var i = 0;
        i < vocabList.length && fallbackQuestions.length < 5;
        i++) {
      final target = vocabList[i];
      final targetMeaning = target.vietnamese.trim().isNotEmpty
          ? target.vietnamese
          : target.english;
      final distractors = <String>[
        for (final other in vocabList)
          if (other.id != target.id)
            (other.vietnamese.trim().isNotEmpty
                ? other.vietnamese
                : other.english),
        'thời tiết buổi sáng',
        'kế hoạch học tập',
        'nhà ga trung tâm',
      ].where((s) => s.trim().isNotEmpty && s != targetMeaning).toSet().take(3).toList();

      while (distractors.length < 3) {
        distractors.add('Đáp án nhiễu ${distractors.length + 1}');
      }

      final options = <String>[targetMeaning, ...distractors.take(3)];
      fallbackQuestions.add(
        QuizQuestion(
          id: '${examId}_q_${fallbackQuestions.length + 1}',
          question:
              'Chọn nghĩa tiếng Việt chính xác của từ vựng cấp độ $level sau (SQLite Fallback):',
          questionJp: '${target.japanese}（${target.hiragana}）',
          options: options,
          correctIndex: 0,
          explanation:
              'Từ "${target.japanese}" (${target.hiragana}) trong kho dữ liệu chuẩn SQLite có nghĩa là "$targetMeaning".',
          jlptLevel: level,
          type: QuestionType.vocabularyMeaning,
        ),
      );
    }

    while (fallbackQuestions.length < 5) {
      final idx = fallbackQuestions.length + 1;
      fallbackQuestions.add(
        QuizQuestion(
          id: '${examId}_q_$idx',
          question: 'Câu hỏi ôn tập dự phòng cấp độ $level số $idx (SQLite Fallback):',
          questionJp: '日本語の$levelレベルの練習問題（第$idx問）',
          options: const <String>[
            'Đáp án chuẩn từ SQLite A',
            'Phương án B',
            'Phương án C',
            'Phương án D',
          ],
          correctIndex: 0,
          explanation: 'Câu hỏi trích xuất từ bộ dữ liệu dự phòng cục bộ SQLite.',
          jlptLevel: level,
          type: QuestionType.vocabularyMeaning,
        ),
      );
    }

    final fallbackPassage = ragContext.vocabularies.isNotEmpty
        ? '【Bài đọc mẫu ngoại tuyến - $level】\n'
            'Từ vựng trọng tâm: ${ragContext.vocabularies.take(5).map((v) => "${v.japanese} (${v.hiragana})").join("、")}。\n'
            'Ngữ pháp trọng tâm: ${ragContext.grammarPoints.map((g) => g.pattern).join(" / ")}。'
        : null;

    final fallbackTest = JLPTTest(
      id: examId,
      level: level,
      title: 'Đề thi mẫu ngoại tuyến JLPT $level (SQLite Fallback)',
      timeMinutes: 15,
      questions: fallbackQuestions.take(5).toList(),
      isAiGenerated: false,
      isFallback: true,
      sourceId: 'src_sqlite_backup',
      readingPassage: fallbackPassage,
    );

    if (persistToSqlite) {
      await LocalDatabaseService.instance.saveGeneratedExamToDb(fallbackTest);
    }
    JLPTTestData.upsertTest(fallbackTest);

    return GeminiExamGenerationResult(
      test: fallbackTest,
      isAiGenerated: false,
      isFallback: true,
      sourceId: 'src_sqlite_backup',
      statusMessage: reason,
      ragContext: ragContext,
    );
  }

  static const Set<String> _viAndEnStopWords = <String>{
    'quàng', 'thượng', 'hoàng', 'ơi', 'trẫm', 'con', 'sen', 'cho', 'hỏi',
    'giải', 'thích', 'là', 'gì', 'nghĩa', 'của', 'từ', 'vựng', 'kanji',
    'chữ', 'hán', 'ngữ', 'pháp', 'cấu', 'trúc', 'ví', 'dụ', 'câu', 'cấp',
    'độ', 'jlpt', 'n5', 'n4', 'n3', 'n2', 'n1', 'học', 'ôn', 'tập', 'luyện',
    'viết', 'đọc', 'nghe', 'phát', 'âm', 'như', 'thế', 'nào', 'với', 'trong',
    'tiếng', 'nhật', 'mẫu', 'bài', 'cần', 'gợi', 'ý', 'giúp', 'mình', 'tôi',
    'cách', 'dùng', 'phân', 'biệt', 'và', 'hay', 'hoặc', 'có', 'bao', 'nhiêu',
    'nét', 'chủ', 'đề', 'hiểu', 'phù', 'hợp', 'tra', 'cứu', 'về', 'đi',
    'what', 'does', 'mean', 'meaning', 'of', 'in', 'japanese', 'is', 'the',
    'how', 'to', 'say', 'word', 'vocabulary', 'tell', 'me', 'about', 'please',
  };

  static const Set<String> _jpMetaWords = <String>{
    '日本語',
    '意味',
    '言葉',
    '単語',
    '漢字',
    '文法',
    '例文',
    '質問',
    '問題',
    '読み方',
    '読み',
    '何',
    'なに',
    'なん',
    'どういう',
    '教えて',
    'ください',
    'ですか',
    'ますか',
  };

  static const List<String> _jpQuestionBoilerplate = <String>[
    'はどういう意味ですか',
    'ってどういう意味ですか',
    'とはどういう意味ですか',
    'はどういう意味なの',
    'はどういう意味',
    'ってどういう意味',
    'とはどういう意味',
    'の意味を教えてください',
    'の意味を教えて',
    'の意味は何ですか',
    'の意味なんですか',
    'の意味ですか',
    'の意味は',
    'の意味',
    'とは何ですか',
    'とはなんですか',
    'とはなに',
    'ってなんですか',
    'って何ですか',
    'ってなに',
    'を教えてください',
    'を教えて',
    'について教えてください',
    'について教えて',
    'はどう読みますか',
    'の読み方は何ですか',
    'の読み方を教えて',
    'の読み方は',
    'の読み方',
    'は日本語で何と言いますか',
    'は日本語で何ですか',
    '日本語の',
    '日本語で',
    'ですか',
    'ますか',
    'ください',
    '教えて',
    'どういう',
  ];

  static bool _containsJapaneseScript(String text) {
    return RegExp(r'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]').hasMatch(text);
  }

  static bool _isJapaneseCharOnly(String text) {
    return RegExp(r'^[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fffー]+$')
        .hasMatch(text);
  }

  /// Normalizes a natural Japanese/Vietnamese/English question and extracts
  /// prioritized candidate keywords without losing Kanji, Hiragana, Katakana,
  /// or internal spaces in multi-word Latin/Vietnamese phrases.
  @visibleForTesting
  List<String> extractQueryCandidates(String query) {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const <String>[];

    final candidates = <String>[];
    final seenLower = <String>{};

    void addCandidate(String raw) {
      final cleaned = raw
          .trim()
          .replaceAll(
            RegExp(
              r'^[？?！!。、，,・：:；;〜~「」『』【】〈〉《》“”"\x27（）()\[\]{}•—\-]+|[？?！!。、，,・：:；;〜~「」『』【】〈〉《》“”"\x27（）()\[\]{}•—\-]+$',
            ),
            '',
          )
          .trim();
      if (cleaned.isEmpty) return;
      final key = cleaned.toLowerCase();
      if (_viAndEnStopWords.contains(key)) return;
      if (seenLower.add(key)) {
        candidates.add(cleaned);
      }
    }

    // 1. Extract quoted/bracketed candidates first (highest priority, e.g. 「学校」 -> 学校)
    final quoteRegex = RegExp(
      r'「([^」]+)」|『([^』]+)』|【([^】]+)】|〈([^〉]+)〉|《([^》]+)》|“([^”]+)”|"([^"]+)"|\x27([^\x27]+)\x27|（([^）]+)）|\(([^)]+)\)',
    );
    final quotedSet = <String>{};
    for (final match in quoteRegex.allMatches(trimmed)) {
      for (var g = 1; g <= match.groupCount; g++) {
        final groupVal = match.group(g)?.trim();
        if (groupVal != null && groupVal.isNotEmpty) {
          addCandidate(groupVal);
          quotedSet.add(groupVal);
        }
      }
    }

    // If the entire query is a single Japanese word (even a meta-word like 意味 or 日本語), keep it
    final strippedPunctWhole = trimmed
        .replaceAll(
          RegExp(r'[？?！!。、，,・：:；;〜~「」『』【】〈〉《》“”"\x27（）()\[\]{}•—\-]'),
          '',
        )
        .trim();
    if (strippedPunctWhole.isNotEmpty &&
        _isJapaneseCharOnly(strippedPunctWhole) &&
        strippedPunctWhole.runes.length <= 6 &&
        !_jpQuestionBoilerplate.any(
          (p) => strippedPunctWhole.length > p.length && strippedPunctWhole.contains(p),
        )) {
      if (!_jpQuestionBoilerplate.contains(strippedPunctWhole)) {
        addCandidate(strippedPunctWhole);
      }
    }

    // 2. Strip bracketed segments and Japanese question boilerplate to isolate unquoted Japanese target terms
    var jpWorking = trimmed.replaceAll(quoteRegex, ' ');
    for (final pattern in _jpQuestionBoilerplate) {
      jpWorking = jpWorking.replaceAll(pattern, ' ');
    }
    jpWorking = jpWorking.replaceAll(
      RegExp(r'[？?！!。、，,・：:；;〜~「」『』【】〈〉《》“”"\x27（）()\[\]{}•—\-]'),
      ' ',
    );

    final lowerQuery = trimmed.toLowerCase();
    final preserveParticles = lowerQuery.contains('trợ từ') ||
        lowerQuery.contains('ngữ pháp') ||
        lowerQuery.contains('phân biệt') ||
        lowerQuery.contains('助詞') ||
        lowerQuery.contains('文法');

    // Extract contiguous Kanji compounds (e.g. 学校, 先生, 約束, 日)
    for (final m
        in RegExp(r'[\u3400-\u4dbf\u4e00-\u9fff]+').allMatches(jpWorking)) {
      final kanjiRun = m.group(0)!.trim();
      if (kanjiRun.isEmpty) continue;
      if (_jpMetaWords.contains(kanjiRun) &&
          !quotedSet.contains(kanjiRun) &&
          strippedPunctWhole != kanjiRun) {
        continue;
      }
      addCandidate(kanjiRun);
    }

    // Extract contiguous Katakana words (e.g. スラックス, フォーム)
    for (final m in RegExp(r'[\u30a0-\u30ffー]{2,}').allMatches(jpWorking)) {
      final kataRun = m.group(0)!.trim();
      if (kataRun.isNotEmpty) {
        addCandidate(kataRun);
      }
    }

    // Split Japanese segments on structural particles to extract Kanji+Hiragana or pure Hiragana words (e.g. がっこう)
    final jpSegments = jpWorking
        .split(RegExp(r'\s+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty && _containsJapaneseScript(s));

    for (final seg in jpSegments) {
      if (preserveParticles &&
          seg.runes.length == 1 &&
          RegExp(r'^[\u3040-\u309f]$').hasMatch(seg)) {
        addCandidate(seg);
        continue;
      }
      // Split by particles when connecting clauses/nouns
      final parts = seg.split(
        RegExp(r'(?:とは|って|から|まで|より|の|は|が|を|に|で|と|や|へ|も|か|ね|よ)+'),
      );
      for (final part in parts) {
        final cleanPart = part.trim();
        if (cleanPart.isEmpty) continue;
        if (_jpMetaWords.contains(cleanPart) &&
            !quotedSet.contains(cleanPart) &&
            strippedPunctWhole != cleanPart) {
          continue;
        }
        if (_isJapaneseCharOnly(cleanPart)) {
          // Avoid adding single stray Hiragana boilerplate characters unless preserveParticles is true
          if (cleanPart.runes.length == 1 &&
              RegExp(r'^[\u3040-\u309f]$').hasMatch(cleanPart) &&
              !preserveParticles &&
              strippedPunctWhole != cleanPart) {
            continue;
          }
          addCandidate(cleanPart);
        }
      }
    }

    // 3. Extract Latin / Romaji / Vietnamese / English keywords and multi-word phrases
    final nonJpWorking = trimmed
        .replaceAll(quoteRegex, ' ')
        .replaceAll(RegExp(r'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fffー]+'), ' ')
        .replaceAll(RegExp(r'[？?！!。、，,・：:；;〜~「」『』【】〈〉《》“”"\x27（）()\[\]{}•—\-]'), ' ');

    final latinTokens = nonJpWorking
        .toLowerCase()
        .split(RegExp(r'\s+'))
        .map((t) => t.trim())
        .where((t) => t.isNotEmpty && !_viAndEnStopWords.contains(t))
        .toList();

    if (latinTokens.length >= 2 && latinTokens.length <= 4) {
      // Preserve multi-word Vietnamese/English phrase (e.g. "trường học", "giáo viên") before individual words
      addCandidate(latinTokens.join(' '));
    }
    for (final tok in latinTokens) {
      addCandidate(tok);
    }

    return candidates;
  }

  static bool _matchesExactMeaningSense(String rawField, String lowerCandidate) {
    final cleanedField = ContentFallback.cleanText(rawField);
    if (cleanedField == null || lowerCandidate.isEmpty) return false;
    final cleaned = cleanedField.toLowerCase();
    if (cleaned == lowerCandidate) return true;
    final senses = cleaned
        .split(RegExp(r'[;,/•|]+'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty);
    return senses.any((s) => s == lowerCandidate);
  }

  static bool _containsMeaningWord(String rawField, String lowerCandidate) {
    final cleanedField = ContentFallback.cleanText(rawField);
    if (cleanedField == null || lowerCandidate.length < 3) return false;
    final cleaned = cleanedField.toLowerCase();
    if (_matchesExactMeaningSense(cleaned, lowerCandidate)) return true;
    final pattern = RegExp(
      '(^|[^a-zA-Z0-9\\u00C0-\\u1EF9])${RegExp.escape(lowerCandidate)}([^a-zA-Z0-9\\u00C0-\\u1EF9]|\$)',
      caseSensitive: false,
    );
    return pattern.hasMatch(cleaned);
  }

  /// Resolves a verified internal Vietnamese meaning strictly by exact record [rawId]
  /// from loaded verified vocabulary data. Never guesses or matches by English/Kanji.
  static String? _lookupVerifiedVietnameseById(String rawId) {
    final cleanId = ContentFallback.cleanText(rawId);
    if (cleanId == null) return null;
    for (final v in VocabularyData.getAllWords()) {
      if (v.id == cleanId) {
        final vi = ContentFallback.cleanText(v.vietnamese);
        if (vi != null) return vi;
      }
    }
    return null;
  }

  static TutorRetrievedItem _vocabToRetrievedItem(VocabularyWord w) {
    final cleanVi = ContentFallback.cleanText(w.vietnamese) ??
        _lookupVerifiedVietnameseById(w.id);
    final cleanEn = ContentFallback.cleanText(w.english);
    final exSentence = w.exampleSentences.isNotEmpty
        ? w.exampleSentences.first.trim()
        : '';
    final exMeaning = w.exampleTranslations.isNotEmpty
        ? (ContentFallback.cleanText(w.exampleTranslations.first) ?? '')
        : '';
    final exLine = exSentence.isNotEmpty
        ? 'Câu mẫu: $exSentence${exMeaning.isNotEmpty ? " — $exMeaning" : ""}'
        : (w.category.trim().isNotEmpty ? 'Chủ đề: ${w.category}' : '');
    final readingStr = w.romaji.trim().isNotEmpty
        ? '${w.hiragana} (${w.romaji})'
        : w.hiragana;

    return TutorRetrievedItem(
      itemId: ContentFallback.cleanText(w.id),
      category: 'Từ vựng',
      titleJp: w.japanese,
      reading: readingStr,
      hiragana: w.hiragana.trim(),
      romaji: w.romaji.trim(),
      meaningVi: cleanVi ?? cleanEn ?? '',
      rawMeaningVi: cleanVi ?? '',
      meaningEn: cleanEn ?? '',
      level: w.jlptLevel,
      detail: exLine,
    );
  }

  /// Truy xuất các bản ghi liên quan từ SQLite / kho dữ liệu chuẩn (`verified_v2`)
  /// dựa trên câu hỏi của người học và cấp độ JLPT hiện tại.
  /// Không bao giờ gửi toàn bộ database hay dữ liệu cá nhân.
  Future<List<TutorRetrievedItem>> retrieveTutorSqliteItems({
    required String query,
    required String level,
    int maxItems = 6,
  }) async {
    final normalizedQuery = query.trim();
    if (normalizedQuery.isEmpty || maxItems <= 0) {
      return const <TutorRetrievedItem>[];
    }
    final lowerQuery = normalizedQuery.toLowerCase();

    String targetLevel = level.trim().toUpperCase();
    if (!const <String>['N5', 'N4', 'N3', 'N2', 'N1'].contains(targetLevel)) {
      targetLevel = 'N5';
    }
    String? explicitLevelInQuery;
    for (final lv in const <String>['N5', 'N4', 'N3', 'N2', 'N1']) {
      if (RegExp('\\b${lv.toLowerCase()}\\b').hasMatch(lowerQuery)) {
        targetLevel = lv;
        explicitLevelInQuery = lv;
        break;
      }
    }

    final candidates = extractQueryCandidates(normalizedQuery);

    final wantsKanji = lowerQuery.contains('kanji') ||
        lowerQuery.contains('chữ hán') ||
        lowerQuery.contains('số nét') ||
        lowerQuery.contains('bao nhiêu nét') ||
        normalizedQuery.contains('漢字');
    final wantsGrammar = lowerQuery.contains('ngữ pháp') ||
        lowerQuery.contains('cấu trúc') ||
        lowerQuery.contains('trợ từ') ||
        lowerQuery.contains('mẫu câu') ||
        normalizedQuery.contains('文法');
    final wantsReading = lowerQuery.contains('bài đọc') ||
        lowerQuery.contains('đoạn văn') ||
        lowerQuery.contains('đọc hiểu') ||
        normalizedQuery.contains('読解');
    final wantsVocab = lowerQuery.contains('từ vựng') ||
        lowerQuery.contains('từ mới') ||
        normalizedQuery.contains('意味') ||
        normalizedQuery.contains('単語');

    if (candidates.isNotEmpty) {
      final scoredItems = <({TutorRetrievedItem item, int score})>[];
      final seenKeys = <String>{};

      void addScored(TutorRetrievedItem item, int score) {
        final key = '${item.category}::${item.titleJp}::${item.level}';
        if (seenKeys.add(key)) {
          scoredItems.add((item: item, score: score));
        }
      }

      void searchCandidatesInPool({
        required bool strictLevel,
        required bool exactOnly,
      }) {
        // Evaluate each candidate in extracted priority order
        for (var cIdx = 0; cIdx < candidates.length; cIdx++) {
          final cand = candidates[cIdx];
          final lowerCand = cand.toLowerCase();
          final isJpCand = _containsJapaneseScript(cand);

          // 1. Vocabulary search (Priority 1: exact expression; Priority 2: reading / meaning / substring)
          if (!wantsKanji && !wantsGrammar && !wantsReading) {
            try {
              final vocabPool = strictLevel
                  ? VocabularyData.getWordsByLevel(targetLevel)
                  : VocabularyData.getAllWords();
              for (final w in vocabPool) {
                if (w.japanese == cand) {
                  // Priority 1 — Exact Japanese term
                  addScored(_vocabToRetrievedItem(w), 100 + cIdx);
                } else if (w.hiragana == cand) {
                  // Priority 2a — Exact Hiragana reading
                  addScored(_vocabToRetrievedItem(w), 150 + cIdx);
                } else if (!isJpCand && w.romaji.toLowerCase() == lowerCand) {
                  // Priority 2a — Exact Romaji reading
                  addScored(_vocabToRetrievedItem(w), 160 + cIdx);
                } else if (!isJpCand &&
                    (_matchesExactMeaningSense(w.vietnamese, lowerCand) ||
                        _matchesExactMeaningSense(w.english, lowerCand))) {
                  // Priority 2a — Exact Vietnamese or English meaning sense
                  addScored(_vocabToRetrievedItem(w), 170 + cIdx);
                } else if (!exactOnly) {
                  if (isJpCand) {
                    // Priority 2b — Japanese text/reading substring (never match Japanese query on meaning fields)
                    if (cand.runes.length >= 2 &&
                        (w.japanese.contains(cand) ||
                            w.hiragana.contains(cand))) {
                      addScored(_vocabToRetrievedItem(w), 300 + cIdx);
                    }
                  } else {
                    if (w.category.trim().toLowerCase() == lowerCand) {
                      addScored(_vocabToRetrievedItem(w), 280 + cIdx);
                    } else if (lowerCand.length >= 3 &&
                        (_containsMeaningWord(w.vietnamese, lowerCand) ||
                            _containsMeaningWord(w.english, lowerCand))) {
                      addScored(_vocabToRetrievedItem(w), 320 + cIdx);
                    }
                  }
                }
              }
            } catch (_) {}
          }

          // 2. Kanji search
          if (!wantsGrammar && !wantsReading) {
            try {
              final kanjiPool = strictLevel
                  ? KanjiData.getKanjiByLevel(targetLevel)
                  : KanjiData.getAllKanji();
              for (final k in kanjiPool) {
                final cleanVi = ContentFallback.cleanText(k.vietnamese);
                final cleanEn = ContentFallback.cleanText(k.english);
                final kanjiItem = TutorRetrievedItem(
                  itemId: ContentFallback.cleanText(k.id),
                  category: 'Kanji',
                  titleJp: k.kanji,
                  reading: '${k.kunyomi} • ${k.onyomi}'.trim(),
                  meaningVi: cleanVi ?? cleanEn ?? '',
                  rawMeaningVi: cleanVi ?? '',
                  meaningEn: cleanEn ?? '',
                  level: k.jlptLevel,
                  detail:
                      'Số nét: ${k.strokeCount}${k.exampleWords.isNotEmpty ? " • Ví dụ: ${k.exampleWords.take(2).join(", ")}" : ""}',
                );

                if (k.kanji == cand) {
                  // Exact single-character Kanji match
                  final baseScore = wantsKanji ? 90 : 120;
                  addScored(kanjiItem, baseScore + cIdx);
                } else if (!exactOnly && !wantsVocab) {
                  if (isJpCand) {
                    if (cand.runes.length >= 2 &&
                        (k.kunyomi.contains(cand) ||
                            k.onyomi.contains(cand) ||
                            k.exampleWords.any((ew) => ew == cand))) {
                      addScored(kanjiItem, 330 + cIdx);
                    }
                  } else if (lowerCand.length >= 3 &&
                      (_containsMeaningWord(k.vietnamese, lowerCand) ||
                          _containsMeaningWord(k.english, lowerCand))) {
                    addScored(kanjiItem, 340 + cIdx);
                  }
                }
              }
            } catch (_) {}
          }

          // 3. Grammar search
          if (!wantsKanji && !wantsReading) {
            try {
              final grammarPool = strictLevel
                  ? GrammarData.getLessonsByLevel(targetLevel)
                  : GrammarData.getAllLessons();
              for (final g in grammarPool) {
                final cleanVi = ContentFallback.cleanText(g.titleVi);
                final cleanEn = ContentFallback.cleanText(g.titleEn) ??
                    ContentFallback.cleanText(g.title);
                final titleDisplay = cleanVi ?? cleanEn ?? g.pattern;
                final expVi = ContentFallback.cleanText(g.explanationVi) ??
                    ContentFallback.cleanText(g.explanation) ??
                    '';
                final exLine = g.examples.isNotEmpty
                    ? 'Ví dụ: ${g.examples.first.japanese} (${g.examples.first.displayTranslation(language: "vi")})'
                    : expVi;
                final grammarItem = TutorRetrievedItem(
                  itemId: ContentFallback.cleanText(g.id),
                  category: 'Ngữ pháp',
                  titleJp: g.pattern,
                  reading: g.formation ?? g.pattern,
                  meaningVi: titleDisplay,
                  rawMeaningVi: cleanVi ?? '',
                  meaningEn: cleanEn ?? '',
                  level: g.jlptLevel,
                  detail: exLine,
                );

                if (g.pattern == cand) {
                  final baseScore = wantsGrammar ? 90 : 130;
                  addScored(grammarItem, baseScore + cIdx);
                } else if (!exactOnly && (!wantsVocab || wantsGrammar)) {
                  if (isJpCand) {
                    if ((cand.runes.length >= 2 || wantsGrammar) &&
                        (g.pattern.contains(cand) ||
                            titleDisplay.contains(cand) ||
                            g.title.contains(cand))) {
                      addScored(
                        grammarItem,
                        (wantsGrammar ? 180 : 350) + cIdx,
                      );
                    }
                  } else if (lowerCand.length >= 2 &&
                      (titleDisplay.toLowerCase().contains(lowerCand) ||
                          g.title.toLowerCase().contains(lowerCand) ||
                          expVi.toLowerCase().contains(lowerCand))) {
                    addScored(
                      grammarItem,
                      (wantsGrammar ? 190 : 360) + cIdx,
                    );
                  }
                }
              }
            } catch (_) {}
          }

          // 4. Reading Materials search
          if (!exactOnly &&
              (wantsReading || (!wantsKanji && !wantsGrammar && !wantsVocab))) {
            try {
              for (final r in ReadingMaterialData.getAllMaterials()) {
                if (strictLevel && r.level.toUpperCase() != targetLevel) {
                  continue;
                }
                final cleanVi = ContentFallback.cleanText(r.titleVi);
                final cleanEn = ContentFallback.cleanText(r.titleEn) ??
                    ContentFallback.cleanText(r.title);
                final tVi = cleanVi ?? cleanEn ?? r.japaneseTitle;
                final readingItem = TutorRetrievedItem(
                  itemId: ContentFallback.cleanText(r.id),
                  category: 'Đọc hiểu',
                  titleJp: r.japaneseTitle,
                  reading: r.titleFurigana ?? '',
                  meaningVi: tVi,
                  rawMeaningVi: cleanVi ?? '',
                  meaningEn: cleanEn ?? '',
                  level: r.level,
                  detail: r.preview,
                );
                if (isJpCand) {
                  if (r.japaneseTitle == cand ||
                      (cand.runes.length >= 2 &&
                          r.japaneseTitle.contains(cand))) {
                    addScored(readingItem, 370 + cIdx);
                  }
                } else if (lowerCand.length >= 3 &&
                    (tVi.toLowerCase().contains(lowerCand) ||
                        r.summary.toLowerCase().contains(lowerCand))) {
                  addScored(readingItem, 380 + cIdx);
                }
              }
            } catch (_) {}
          }
        }
      }

      // Step 1: Search strictly within targetLevel (N5, etc.)
      searchCandidatesInPool(strictLevel: true, exactOnly: false);

      // Step 2: If no match in targetLevel and user did not lock a level in query,
      // check other levels for exact matches first (preserving their actual JLPT level).
      if (scoredItems.isEmpty && explicitLevelInQuery == null) {
        searchCandidatesInPool(strictLevel: false, exactOnly: true);
        if (scoredItems.isEmpty) {
          searchCandidatesInPool(strictLevel: false, exactOnly: false);
        }
      }

      // Step 3: Direct SQLite table query when in-memory VocabularyData is empty
      if (scoredItems.isEmpty &&
          VocabularyData.getAllWords().isEmpty &&
          !kIsWeb &&
          !wantsKanji &&
          !wantsGrammar &&
          !wantsReading) {
        try {
          final dbWords =
              await LocalDatabaseService.instance.searchVocabulariesInSqlite(
            candidates: candidates,
            targetLevel: targetLevel,
            allowCrossLevelFallback: explicitLevelInQuery == null,
            limit: maxItems,
          );
          for (var i = 0; i < dbWords.length; i++) {
            addScored(_vocabToRetrievedItem(dbWords[i]), 100 + i);
          }
        } catch (_) {}
      }

      if (scoredItems.isEmpty) {
        return const <TutorRetrievedItem>[];
      }

      scoredItems.sort((a, b) => a.score.compareTo(b.score));

      // If we have high-confidence exact/reading/meaning matches (score < 250),
      // filter out low-confidence substring noise (score >= 300) so exact queries stay focused.
      final hasExactMatch = scoredItems.any((e) => e.score < 250);
      final filtered = hasExactMatch
          ? scoredItems.where((e) => e.score < 300).toList()
          : scoredItems;

      return filtered.take(maxItems).map((e) => e.item).toList();
    }

    // 5. General level/category overview queries (candidates.isEmpty, e.g. "Giải thích ngữ pháp N5", "Tra cứu Kanji N4", "Gợi ý bài đọc hiểu")
    if (VocabularyData.getAllWords().isEmpty && !kIsWeb) {
      try {
        await LocalDatabaseService.instance
            .ensureVerifiedDatasetImportedAndLoaded();
      } catch (_) {}
    }
    final results = <TutorRetrievedItem>[];
    try {
      if (wantsKanji) {
        for (final k in KanjiData.getKanjiByLevel(targetLevel).take(maxItems)) {
          final cleanVi = ContentFallback.cleanText(k.vietnamese);
          final cleanEn = ContentFallback.cleanText(k.english);
          results.add(
            TutorRetrievedItem(
              itemId: ContentFallback.cleanText(k.id),
              category: 'Kanji',
              titleJp: k.kanji,
              reading: '${k.kunyomi} • ${k.onyomi}'.trim(),
              meaningVi: cleanVi ?? cleanEn ?? '',
              rawMeaningVi: cleanVi ?? '',
              meaningEn: cleanEn ?? '',
              level: k.jlptLevel,
              detail: 'Số nét: ${k.strokeCount}',
            ),
          );
        }
      } else if (wantsGrammar) {
        for (final g
            in GrammarData.getLessonsByLevel(targetLevel).take(maxItems)) {
          final cleanVi = ContentFallback.cleanText(g.titleVi);
          final cleanEn = ContentFallback.cleanText(g.titleEn) ??
              ContentFallback.cleanText(g.title);
          results.add(
            TutorRetrievedItem(
              itemId: ContentFallback.cleanText(g.id),
              category: 'Ngữ pháp',
              titleJp: g.pattern,
              reading: g.formation ?? g.pattern,
              meaningVi: cleanVi ?? cleanEn ?? g.pattern,
              rawMeaningVi: cleanVi ?? '',
              meaningEn: cleanEn ?? '',
              level: g.jlptLevel,
              detail: ContentFallback.cleanText(g.explanationVi) ??
                  ContentFallback.cleanText(g.explanation) ??
                  '',
            ),
          );
        }
      } else if (wantsReading) {
        for (final r in ReadingMaterialData.getAllMaterials()) {
          if (results.length >= maxItems) break;
          if (r.level.toUpperCase() == targetLevel) {
            final cleanVi = ContentFallback.cleanText(r.titleVi);
            final cleanEn = ContentFallback.cleanText(r.titleEn) ??
                ContentFallback.cleanText(r.title);
            results.add(
              TutorRetrievedItem(
                itemId: ContentFallback.cleanText(r.id),
                category: 'Đọc hiểu',
                titleJp: r.japaneseTitle,
                reading: r.titleFurigana ?? '',
                meaningVi: cleanVi ?? cleanEn ?? r.japaneseTitle,
                rawMeaningVi: cleanVi ?? '',
                meaningEn: cleanEn ?? '',
                level: r.level,
                detail: r.preview,
              ),
            );
          }
        }
      } else if (wantsVocab || explicitLevelInQuery != null) {
        for (final w
            in VocabularyData.getWordsByLevel(targetLevel).take(maxItems)) {
          results.add(_vocabToRetrievedItem(w));
        }
      }
    } catch (_) {}

    return results.take(maxItems).toList();
  }

  /// Hỏi Gia sư Quàng Thượng:
  /// - Truy xuất dữ liệu liên quan từ SQLite (`retrievedSqliteItems`)
  /// - Tổng hợp tóm tắt dữ liệu chuẩn từ SQLite (`sqliteSummaryAnswer`)
  /// - Gọi Gemini để sinh lời giảng chi tiết bằng giọng văn Quàng Thượng thân thiện
  /// - Tách biệt rõ dữ liệu truy xuất từ SQLite với nội dung do AI sinh thêm.
  Future<QuangThuongTutorResponse> askQuangThuongTutor({
    required String query,
    required String level,
    int learnedVocabCount = 0,
    int learnedKanjiCount = 0,
  }) async {
    final cleanedQuery = query.trim();
    final normalizedLevel = level.trim().toUpperCase();
    if (cleanedQuery.isEmpty ||
        !QuangThuongTutorResponse.hasValidQueryCharacters(cleanedQuery)) {
      return QuangThuongTutorResponse(
        query: cleanedQuery,
        level: normalizedLevel,
        retrievedSqliteItems: const <TutorRetrievedItem>[],
        sqliteSummaryAnswer:
            'Con sen hãy nhập câu hỏi tiếng Nhật, Hiragana, Romaji hoặc nghĩa tiếng Việt để Trẫm tra cứu nhé!',
        aiGeneratedExplanation: null,
        isAiOnline: false,
        errorMessage: cleanedQuery.isEmpty
            ? 'Câu hỏi rỗng. Vui lòng nhập nội dung cần tra cứu.'
            : 'Câu hỏi không hợp lệ. Vui lòng nhập chữ cái hoặc từ vựng cần tra cứu.',
        suggestedPracticeRoute: 'vocab',
      );
    }

    List<TutorRetrievedItem> retrievedItems;
    try {
      retrievedItems = await retrieveTutorSqliteItems(
        query: cleanedQuery,
        level: normalizedLevel,
        maxItems: 5,
      );
    } catch (e) {
      return QuangThuongTutorResponse(
        query: cleanedQuery,
        level: normalizedLevel,
        retrievedSqliteItems: const <TutorRetrievedItem>[],
        sqliteSummaryAnswer:
            'Không thể truy xuất dữ liệu SQLite cho câu hỏi "$cleanedQuery".',
        aiGeneratedExplanation: null,
        isAiOnline: false,
        isDatabaseError: true,
        errorMessage: 'Lỗi truy xuất cơ sở dữ liệu SQLite: $e',
        suggestedPracticeRoute: 'vocab',
      );
    }

    final suggestedRoute = _inferSuggestedRoute(cleanedQuery, retrievedItems);
    final sqliteSummary = _buildSqliteSummaryAnswer(
      query: cleanedQuery,
      level: normalizedLevel,
      items: retrievedItems,
    );

    final effectiveProxyUrl = (_proxyUrlOverride ?? _envProxyUrl).trim();
    final effectiveApiKey = (_apiKeyOverride ?? _envApiKey).trim();

    if (effectiveProxyUrl.isEmpty && effectiveApiKey.isEmpty) {
      return QuangThuongTutorResponse(
        query: cleanedQuery,
        level: normalizedLevel,
        retrievedSqliteItems: retrievedItems,
        sqliteSummaryAnswer: sqliteSummary,
        aiGeneratedExplanation: null,
        isAiOnline: false,
        // Do not show a fallback error when SQLite retrieval succeeded;
        // SQLite answers directly without requiring Gemini API.
        errorMessage: null,
        suggestedPracticeRoute: suggestedRoute,
      );
    }

    final ragBlock = retrievedItems.isEmpty
        ? 'Không tìm thấy mục khớp trực tiếp; dùng kiến thức chuẩn JLPT $normalizedLevel.'
        : retrievedItems
            .map(
              (item) =>
                  '- [${item.category} ${item.level}] ${item.titleJp} (${item.reading}): ${item.meaningVi}. ${item.detail}',
            )
            .join('\n');

    final tutorPrompt = '''
Bạn là "Gia sư Quàng Thượng" — chú mèo hoàng gia thông thái, dễ thương và tận tâm dạy tiếng Nhật trong ứng dụng Nihongo Master.
Xưng hô: "Trẫm" (hoặc "Quàng Thượng") và gọi người học là "con sen" một cách vui vẻ, lịch sự, khích lệ.
Trình độ hiện tại của người học: JLPT $normalizedLevel (Đã học $learnedVocabCount từ vựng, $learnedKanjiCount Kanji).

[DỮ LIỆU CHUẨN TRUY XUẤT TỪ SQLITE]
$ragBlock

[CÂU HỎI CỦA NGƯỜI HỌC]
"$cleanedQuery"

YÊU CẦU TRẢ LỜI:
1. Giải thích ngắn gọn, rõ ràng bằng tiếng Việt dựa sát vào [DỮ LIỆU CHUẨN TRUY XUẤT TỪ SQLITE] ở trên.
2. Cho 1-2 ví dụ câu tiếng Nhật có kèm cách đọc Hiragana và dịch nghĩa tiếng Việt.
3. Gợi ý bài luyện tập tiếp theo phù hợp trình độ $normalizedLevel.
''';

    final modelsToTry = <String>{
      _envModel.trim().isEmpty ? candidateModels.first : _envModel.trim(),
      ...candidateModels,
    }.toList();

    String lastError =
        'Kết nối Gemini bị gián đoạn. Bạn có thể bấm "Gửi lại" hoặc xem dữ liệu chuẩn từ SQLite bên trên.';

    for (final modelName in modelsToTry) {
      try {
        final uri = effectiveProxyUrl.isNotEmpty
            ? Uri.parse(effectiveProxyUrl)
            : Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$effectiveApiKey',
              );

        final requestBody = jsonEncode(<String, Object?>{
          'model': modelName,
          'contents': <Map<String, Object?>>[
            <String, Object?>{
              'role': 'user',
              'parts': <Map<String, Object?>>[
                <String, Object?>{'text': tutorPrompt},
              ],
            },
          ],
          'generationConfig': <String, Object?>{
            'temperature': 0.4,
          },
        });

        final response = await _postJson(
          uri,
          const <String, String>{
            'Content-Type': 'application/json; charset=utf-8',
          },
          requestBody,
        ).timeout(requestTimeout);

        if (response.statusCode == 404) {
          lastError =
              'Endpoint model Gemini ($modelName) không khả dụng (HTTP 404). Hãy kiểm tra cấu hình model hoặc bấm "Gửi lại".';
          continue;
        }
        if (response.statusCode == 401 || response.statusCode == 403) {
          lastError =
              'Lỗi xác thực Gemini API (HTTP ${response.statusCode}): API key không hợp lệ hoặc không có quyền truy cập.';
          break;
        }
        if (response.statusCode == 429) {
          lastError =
              'Hệ thống Gemini đang quá tải hạn mức (HTTP 429). Vui lòng thử lại sau ít phút.';
          break;
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          lastError =
              'Máy chủ AI trả về mã lỗi HTTP ${response.statusCode}. Hãy bấm "Gửi lại" để thử lại.';
          break;
        }

        final aiText = _extractPlainTextFromGeminiResponse(response.body);
        if (aiText != null && aiText.trim().isNotEmpty) {
          return QuangThuongTutorResponse(
            query: cleanedQuery,
            level: normalizedLevel,
            retrievedSqliteItems: retrievedItems,
            sqliteSummaryAnswer: sqliteSummary,
            aiGeneratedExplanation: aiText.trim(),
            isAiOnline: true,
            errorMessage: null,
            suggestedPracticeRoute: suggestedRoute,
          );
        }
      } on TimeoutException {
        lastError =
            'Yêu cầu tới Gemini bị quá thời gian chờ (Timeout). Hãy bấm "Gửi lại".';
        break;
      } catch (_) {
        lastError =
            'Không thể kết nối mạng tới Gemini. Đang hiển thị dữ liệu tra cứu trực tiếp từ SQLite.';
        break;
      }
    }

    return QuangThuongTutorResponse(
      query: cleanedQuery,
      level: normalizedLevel,
      retrievedSqliteItems: retrievedItems,
      sqliteSummaryAnswer: sqliteSummary,
      aiGeneratedExplanation: null,
      isAiOnline: false,
      errorMessage: lastError,
      suggestedPracticeRoute: suggestedRoute,
    );
  }

  String _inferSuggestedRoute(
    String query,
    List<TutorRetrievedItem> retrieved,
  ) {
    final lq = query.toLowerCase();
    if (lq.contains('viết') || lq.contains('nét')) return 'writing';
    if (lq.contains('phát âm') || lq.contains('đọc') || lq.contains('nghe')) {
      return 'pronunciation';
    }
    if (retrieved.isNotEmpty) {
      final firstCat = retrieved.first.category;
      if (firstCat == 'Từ vựng') return 'vocab';
      if (firstCat == 'Kanji') return 'kanji';
      if (firstCat == 'Ngữ pháp') return 'grammar';
    }
    if (lq.contains('kanji') ||
        lq.contains('hán') ||
        retrieved.any((e) => e.category == 'Kanji')) {
      return 'kanji';
    }
    if (lq.contains('ngữ pháp') ||
        lq.contains('cấu trúc') ||
        retrieved.any((e) => e.category == 'Ngữ pháp')) {
      return 'grammar';
    }
    return 'vocab';
  }

  String _buildSqliteSummaryAnswer({
    required String query,
    required String level,
    required List<TutorRetrievedItem> items,
  }) {
    if (items.isEmpty) {
      return 'Không tìm thấy dữ liệu khớp trong kho SQLite (cấp $level) cho câu hỏi "$query". Con sen hãy thử nhập từ tiếng Nhật, Hiragana, Romaji hoặc nghĩa khác nhé!';
    }

    final primary = items.first;
    final buffer = StringBuffer();

    final displayReading = ContentFallback.cleanText(primary.hiragana) ??
        ContentFallback.cleanText(primary.reading) ??
        '';
    if (displayReading.isNotEmpty && displayReading != primary.titleJp) {
      buffer.writeln('${primary.titleJp}（$displayReading）');
    } else {
      buffer.writeln(primary.titleJp);
    }

    final cleanRomaji = ContentFallback.cleanText(primary.romaji);
    if (cleanRomaji != null) {
      buffer.writeln('Romaji: $cleanRomaji');
    }

    final cleanVi = primary.cleanedMeaningVi;
    final cleanEn = primary.cleanedMeaningEn;

    switch (primary.meaningStatus) {
      case TutorMeaningStatus.available:
        buffer.writeln('Nghĩa tiếng Việt: $cleanVi');
        if (cleanEn != null) {
          buffer.writeln('Nghĩa tiếng Anh: $cleanEn');
        }
      case TutorMeaningStatus.partialEnglishOnly:
        buffer.writeln('Nghĩa tiếng Anh: $cleanEn');
        buffer.writeln(
          'Nghĩa tiếng Việt: Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.',
        );
      case TutorMeaningStatus.missingAll:
        buffer.writeln(
          'Nghĩa: Bản ghi trong bộ dữ liệu hiện chưa có thông tin nghĩa tiếng Việt và tiếng Anh.',
        );
    }

    final levelNote = primary.level.toUpperCase() != level.toUpperCase()
        ? '${primary.level} (khác cấp $level đang chọn)'
        : primary.level;
    buffer.writeln('Cấp độ JLPT: $levelNote • Phân loại: ${primary.category}');
    if (primary.detail.trim().isNotEmpty) {
      buffer.writeln(primary.detail.trim());
    }
    buffer.writeln('Nguồn: SQLite Tra Cứu Chuẩn');
    if (primary.meaningStatus == TutorMeaningStatus.partialEnglishOnly &&
        primary.category == 'Từ vựng' &&
        ContentFallback.cleanText(primary.itemId) != null) {
      buffer.writeln('Bạn có thể mở kho từ vựng để xem thông tin chi tiết.');
    }

    if (items.length > 1) {
      buffer.writeln('\nCác mục liên quan khác trong SQLite:');
      for (var i = 1; i < items.length; i++) {
        final it = items[i];
        final itReading = ContentFallback.cleanText(it.hiragana) ??
            ContentFallback.cleanText(it.reading) ??
            '';
        final itMeaning = it.cleanedMeaningVi ??
            (it.cleanedMeaningEn != null
                ? '${it.cleanedMeaningEn} (EN)'
                : 'Chưa có dữ liệu nghĩa');
        buffer.writeln(
          '• [${it.category} ${it.level}] ${it.titleJp}${itReading.isNotEmpty ? "（$itReading）" : ""} → $itMeaning',
        );
      }
    }

    return buffer.toString().trim();
  }

  String? _extractPlainTextFromGeminiResponse(String rawResponseBody) {
    try {
      final decoded = jsonDecode(rawResponseBody);
      if (decoded is Map<String, dynamic>) {
        if (decoded['text'] is String) {
          return decoded['text'] as String;
        }
        final candidates = decoded['candidates'];
        if (candidates is List && candidates.isNotEmpty) {
          final first = candidates.first;
          final parts = first['content']?['parts'];
          if (parts is List && parts.isNotEmpty) {
            return parts.first['text']?.toString();
          }
        }
      }
    } catch (_) {}
    return null;
  }
}
