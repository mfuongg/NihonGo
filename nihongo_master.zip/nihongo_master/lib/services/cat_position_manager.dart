import 'dart:math' as math;
import 'dart:ui';

import '../models/cat_surface.dart';

/// Kết quả chọn bề mặt cho chân mèo.
class CatSnapResult {
  final CatSurface surface;

  /// Toạ độ chân mèo sau khi căn lên mặt phẳng.
  final Offset foot;

  /// Vị trí tương đối của chân mèo trên đường ngang (0..1), dùng để lưu bền.
  final double xRatio;

  const CatSnapResult({required this.surface, required this.foot, required this.xRatio});
}

/// Logic thuần Dart quản lý vị trí Mèo Hộ Pháp, chuyển từ hệ thống DOM edges
/// của bản HTML (`findNearestHorizontalEdge`, `applyCompanionPosition`).
///
/// Không phụ thuộc widget nên có thể kiểm thử độc lập.
class CatPositionManager {
  const CatPositionManager();

  /// Kích thước gốc sprite mèo (`IMG_6883/*.webp`).
  static const double spriteWidth = 453;
  static const double spriteHeight = 550;

  /// Điểm neo chân mèo trong sprite (HTML: X = 56.5%, Y = 81.82%).
  static const double footAnchorX = 0.565;
  static const double footAnchorY = 0.8182;

  /// Khoảng cách dọc tối đa để hút lên một đường ngang khi thả.
  static const double maxSnapDistanceY = 110;

  /// Dung sai ngang ngoài hai đầu đường kẻ.
  static const double horizontalTolerance = 36;

  /// Hệ số khoảng cách dọc / ngang trong hàm điểm (HTML: `dy * 1.35 + dx * 1.1 − bonus`).
  static const double verticalWeight = 1.35;
  static const double horizontalWeight = 1.1;

  static const double minRatio = 0.04;
  static const double maxRatio = 0.96;

  /// Chiều cao sprite tương ứng chiều rộng hiển thị.
  static double heightForWidth(double width) => width * spriteHeight / spriteWidth;

  /// Toạ độ góc trên-trái sprite từ toạ độ chân.
  static Offset topLeftFromFoot(Offset foot, double catWidth) {
    final h = heightForWidth(catWidth);
    return Offset(foot.dx - catWidth * footAnchorX, foot.dy - h * footAnchorY);
  }

  /// Toạ độ chân từ góc trên-trái sprite.
  static Offset footFromTopLeft(Offset topLeft, double catWidth) {
    final h = heightForWidth(catWidth);
    return Offset(topLeft.dx + catWidth * footAnchorX, topLeft.dy + h * footAnchorY);
  }

  /// Giới hạn đoạn chân mèo trên [surface] để sprite không tràn khỏi vùng hiển thị.
  static (double, double) footRange(CatSurface surface, double catWidth, double viewportWidth) {
    final leftReach = catWidth * footAnchorX;
    final rightReach = catWidth * (1 - footAnchorX);
    final viewMin = leftReach;
    final viewMax = math.max(viewMin, viewportWidth - rightReach);
    var lo = math.max(surface.xMin, viewMin);
    var hi = math.min(surface.xMax, viewMax);
    if (hi < lo) {
      final mid = ((surface.xMin + surface.xMax) / 2).clamp(viewMin, viewMax);
      lo = mid;
      hi = mid;
    }
    return (lo, hi);
  }

  /// Toạ độ chân khi đứng yên trên [surface] tại [xRatio].
  Offset restingFoot(
    CatSurface surface,
    double xRatio, {
    required double catWidth,
    required double viewportWidth,
  }) {
    final r = xRatio.clamp(minRatio, maxRatio);
    final raw = surface.left + r * surface.width;
    final (lo, hi) = footRange(surface, catWidth, viewportWidth);
    return Offset(raw.clamp(lo, hi), surface.y);
  }

  /// Tìm đường ngang hợp lệ gần chân mèo nhất.
  ///
  /// Giống HTML: chỉ xét đường có `|dy| <= maxSnapY` và chân nằm trong
  /// `[xMin - 36, xMax + 36]`; điểm = `1.35·|dy| + 1.1·dx − priorityBonus`.
  /// Nếu không tìm thấy, mở rộng tìm theo chiều dọc trên toàn màn hình.
  CatSnapResult? findNearest(
    Offset foot,
    Iterable<CatSurface> surfaces, {
    required double catWidth,
    required double viewportWidth,
    double maxSnapY = maxSnapDistanceY,
    bool allowGlobalFallback = true,
  }) {
    CatSnapResult? best;
    var bestScore = double.infinity;

    for (final s in surfaces) {
      if (!s.interactive || s.width <= 0) continue;
      final dy = (foot.dy - s.y).abs();
      if (dy > maxSnapY) continue;
      // Chỉ snap khi chân nằm trên đoạn ngang hoặc cách mút không quá 36px (cả khi fallback).
      final onLineX = foot.dx.clamp(s.xMin, s.xMax);
      final dx = (foot.dx - onLineX).abs();
      if (dx > horizontalTolerance) continue;

      final score = dy * verticalWeight + dx * horizontalWeight - s.priorityBonus;
      if (score < bestScore) {
        bestScore = score;
        final (lo, hi) = footRange(s, catWidth, viewportWidth);
        final clampedX = onLineX.clamp(lo, hi);
        final ratio = s.width > 0
            ? ((clampedX - s.left) / s.width).clamp(minRatio, maxRatio)
            : 0.5;
        best = CatSnapResult(surface: s, foot: Offset(clampedX, s.y), xRatio: ratio);
      }
    }

    if (best == null && allowGlobalFallback && maxSnapY < 9999) {
      return findNearest(
        foot,
        surfaces,
        catWidth: catWidth,
        viewportWidth: viewportWidth,
        maxSnapY: 9999,
        allowGlobalFallback: false,
      );
    }
    return best;
  }

  /// Giới hạn chân mèo trong vùng hiển thị khi đang kéo (không để rơi ra ngoài).
  static Offset clampFootToViewport(Offset foot, Size viewport, double catWidth) {
    final h = heightForWidth(catWidth);
    final minX = catWidth * footAnchorX;
    final maxX = math.max(minX, viewport.width - catWidth * (1 - footAnchorX));
    final minY = h * footAnchorY;
    final maxY = math.max(minY, viewport.height);
    return Offset(foot.dx.clamp(minX, maxX), foot.dy.clamp(minY, maxY));
  }
}
