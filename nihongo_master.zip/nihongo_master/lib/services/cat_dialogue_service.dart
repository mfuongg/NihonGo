import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../models/cat_anim_state.dart';

enum CatDialogueContext {
  tap,
  wrongAnswer,
  correctAnswer,
  feed,
  hungry,
  exhausted,
  furnitureSnap,
}

/// Module quản lý bộ thoại Hoàng Thượng ("Trẫm — Con sen") với cơ chế tự động
/// ẩn bong bóng thoại sau đúng 5 giây (`autoDismissDuration = Duration(seconds: 5)`).
class CatDialogueService extends ChangeNotifier {
  CatDialogueService._();

  static final CatDialogueService instance = CatDialogueService._();

  static const Duration autoDismissDuration = Duration(seconds: 5);

  static const List<String> tapLines = <String>[
    'To gan! Ai cho phép con sen chạm vào long thể của trẫm?!',
    'Trẫm không theo chủ. Chủ theo trẫm!',
    'Nhìn cái gì? Mau đi cày từ vựng kiếm cá cho trẫm!',
  ];

  static const List<String> wrongAnswerLines = <String>[
    'Kiến thức đâu không thấy, chỉ thấy con sen hơi báo đời rồi đấy!',
    'Cơm trẫm nuôi ngươi mấy hôm nay uổng phí quá...',
  ];

  static const List<String> correctAnswerLines = <String>[
    'Tốt! Con sen cũng có chút tố chất làm đệ tử của trẫm.',
    'Tạm duyệt! Trẫm ban khen cho ngươi một cái vẫy đuôi.',
  ];

  static const List<String> feedLines = <String>[
    'Ngon đấy! Món này hợp khẩu vị, trẫm tha tội lười cho ngươi.',
    'Cung phụng chu đáo đấy, tiếp tục phát huy nhé con sen!',
  ];

  static const List<String> hungryLines = <String>[
    'Con sen kia! Định bỏ đói trẫm để đi lướt Tóp Tóp à?!',
  ];

  static const List<String> exhaustedLines = <String>[
    'Trẫm kiệt sức rồi! Con sen đi mua cá hồi nạp năng lượng ngay!',
  ];

  static const List<String> furnitureSnapLines = <String>[
    'Chỗ này view đẹp, trẫm chuẩn tấu ngự tại đây!',
  ];

  final Random _rng = Random();
  int _tapCursor = 0;
  int _feedCursor = 0;
  int _correctCursor = 0;
  int _wrongCursor = 0;

  String? _activeSpeech;
  CatDialogueContext? _activeContext;
  Timer? _dismissTimer;
  bool _studyLocked = false;
  bool _postStudyTired = false;

  String? get activeSpeech => _activeSpeech;
  CatDialogueContext? get activeContext => _activeContext;
  bool get isVisible => _activeSpeech != null && _activeSpeech!.isNotEmpty;
  bool get isStudyLocked => _studyLocked;
  bool get isPostStudyTired => _postStudyTired;

  CatAnimState? _pomodoroCatState;

  /// Trạng thái mèo do phiên Pomodoro quyết định (`null` = mèo tự do).
  CatAnimState? get pomodoroCatState => _pomodoroCatState;

  void setPomodoroCatState(CatAnimState? state) {
    if (_pomodoroCatState == state) return;
    _pomodoroCatState = state;
    notifyListeners();
  }

  void setStudyState({required bool studyLocked, bool postStudyTired = false}) {
    if (_studyLocked == studyLocked && _postStudyTired == postStudyTired) {
      return;
    }
    _studyLocked = studyLocked;
    _postStudyTired = postStudyTired;
    notifyListeners();
  }

  String nextTapLine({int? hunger, int? energy}) {
    if (energy != null && energy < 20) {
      return exhaustedLine();
    }
    if (hunger != null && hunger < 20) {
      return hungryLine();
    }
    final line = tapLines[_tapCursor % tapLines.length];
    _tapCursor = (_tapCursor + 1) % tapLines.length;
    return line;
  }

  String nextFeedLine() {
    final line = feedLines[_feedCursor % feedLines.length];
    _feedCursor = (_feedCursor + 1) % feedLines.length;
    return line;
  }

  String nextCorrectAnswerLine() {
    final line = correctAnswerLines[_correctCursor % correctAnswerLines.length];
    _correctCursor = (_correctCursor + 1) % correctAnswerLines.length;
    return line;
  }

  String nextWrongAnswerLine() {
    final line = wrongAnswerLines[_wrongCursor % wrongAnswerLines.length];
    _wrongCursor = (_wrongCursor + 1) % wrongAnswerLines.length;
    return line;
  }

  String hungryLine() => hungryLines.first;

  String exhaustedLine() => exhaustedLines.first;

  String furnitureSnapLine({String? spotName}) => furnitureSnapLines.first;

  String randomLineFor(CatDialogueContext context, {int? hunger, int? energy}) {
    if (context == CatDialogueContext.exhausted ||
        (energy != null && energy < 20 && context == CatDialogueContext.tap)) {
      return exhaustedLine();
    }
    if (context == CatDialogueContext.hungry ||
        (hunger != null && hunger < 20 && context == CatDialogueContext.tap)) {
      return hungryLine();
    }
    switch (context) {
      case CatDialogueContext.tap:
        return tapLines[_rng.nextInt(tapLines.length)];
      case CatDialogueContext.wrongAnswer:
        return wrongAnswerLines[_rng.nextInt(wrongAnswerLines.length)];
      case CatDialogueContext.correctAnswer:
        return correctAnswerLines[_rng.nextInt(correctAnswerLines.length)];
      case CatDialogueContext.feed:
        return feedLines[_rng.nextInt(feedLines.length)];
      case CatDialogueContext.hungry:
        return hungryLines.first;
      case CatDialogueContext.exhausted:
        return exhaustedLines.first;
      case CatDialogueContext.furnitureSnap:
        return furnitureSnapLines.first;
    }
  }

  /// Kích hoạt bong bóng thoại Hoàng Thượng và tự động ẩn sau đúng 5 giây.
  String trigger(
    CatDialogueContext context, {
    String? customText,
    int? hunger,
    int? energy,
  }) {
    final text = customText ??
        switch (context) {
          CatDialogueContext.tap => nextTapLine(hunger: hunger, energy: energy),
          CatDialogueContext.feed => nextFeedLine(),
          CatDialogueContext.correctAnswer => nextCorrectAnswerLine(),
          CatDialogueContext.wrongAnswer => nextWrongAnswerLine(),
          CatDialogueContext.hungry => hungryLine(),
          CatDialogueContext.exhausted => exhaustedLine(),
          CatDialogueContext.furnitureSnap => furnitureSnapLine(),
        };

    _dismissTimer?.cancel();
    _activeSpeech = text;
    _activeContext = context;
    notifyListeners();

    _dismissTimer = Timer(autoDismissDuration, () {
      _activeSpeech = null;
      _activeContext = null;
      notifyListeners();
    });
    return text;
  }

  void dismiss() {
    _dismissTimer?.cancel();
    _dismissTimer = null;
    if (_activeSpeech != null) {
      _activeSpeech = null;
      _activeContext = null;
      notifyListeners();
    }
  }
}
