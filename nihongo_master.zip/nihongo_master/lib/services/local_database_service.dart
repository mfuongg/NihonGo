import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../data/grammar_data.dart';
import '../data/jlpt_test_data.dart';
import '../data/kanji_data.dart';
import '../data/reading_material_data.dart';
import '../data/vocabulary_data.dart';
import '../models/flashcard_progress.dart';
import '../models/grammar.dart';
import '../models/kanji.dart';
import '../models/quiz.dart';
import '../models/reading_material.dart';
import '../models/study_history.dart';
import '../models/vocabulary.dart';
import '../utils/content_fallback.dart';

class DatabaseInspectionReport {
  final String databasePath;
  final int version;
  final bool foreignKeysEnabled;
  final List<String> tables;
  final List<String> indexes;
  final Map<String, int> tableRowCounts;
  final Map<String, List<Map<String, Object?>>> tableForeignKeys;
  final List<Map<String, Object?>> foreignKeyViolations;

  const DatabaseInspectionReport({
    required this.databasePath,
    required this.version,
    required this.foreignKeysEnabled,
    required this.tables,
    required this.indexes,
    required this.tableRowCounts,
    required this.tableForeignKeys,
    required this.foreignKeyViolations,
  });

  bool get isHealthy =>
      version == LocalDatabaseService.databaseVersion &&
      foreignKeysEnabled &&
      LocalDatabaseService.requiredTables.every(tables.contains) &&
      foreignKeyViolations.isEmpty;

  bool get isAllLearningDataEmpty =>
      LocalDatabaseService.learningAndProgressTables.every(
        (table) => (tableRowCounts[table] ?? 0) == 0,
      );

  Map<String, Object?> toMap() => {
        'databasePath': databasePath,
        'version': version,
        'foreignKeysEnabled': foreignKeysEnabled,
        'tables': tables,
        'indexes': indexes,
        'tableRowCounts': tableRowCounts,
        'tableForeignKeys': tableForeignKeys,
        'foreignKeyViolations': foreignKeyViolations,
        'isHealthy': isHealthy,
        'isAllLearningDataEmpty': isAllLearningDataEmpty,
      };
}

class DatabaseResetReport {
  final bool executed;
  final String reason;
  final String databasePath;
  final String? backupPath;
  final DatabaseInspectionReport? preResetInspection;
  final DatabaseInspectionReport? postResetInspection;

  const DatabaseResetReport({
    required this.executed,
    required this.reason,
    required this.databasePath,
    this.backupPath,
    this.preResetInspection,
    this.postResetInspection,
  });

  Map<String, Object?> toMap() => {
        'executed': executed,
        'reason': reason,
        'databasePath': databasePath,
        'backupPath': backupPath,
        'preResetInspection': preResetInspection?.toMap(),
        'postResetInspection': postResetInspection?.toMap(),
      };
}

class TableImportResult {
  final String table;
  final String sourceFile;
  final int expectedCount;
  final int insertedCount;
  final int updatedCount;
  final int skippedCount;
  final int chunkCount;
  final int errorCount;
  final bool skipped;
  final String? skipReason;
  final List<String> errors;

  const TableImportResult({
    required this.table,
    required this.sourceFile,
    required this.expectedCount,
    required this.insertedCount,
    this.updatedCount = 0,
    required this.skippedCount,
    required this.chunkCount,
    required this.errorCount,
    required this.skipped,
    this.skipReason,
    this.errors = const <String>[],
  });

  int get failedCount => errorCount;

  Map<String, Object?> toMap() => {
        'table': table,
        'sourceFile': sourceFile,
        'expectedCount': expectedCount,
        'insertedCount': insertedCount,
        'updatedCount': updatedCount,
        'skippedCount': skippedCount,
        'failedCount': errorCount,
        'chunkCount': chunkCount,
        'errorCount': errorCount,
        'skipped': skipped,
        'skipReason': skipReason,
        'errors': errors,
      };
}

class ListeningPracticeItem {
  final String id;
  final String sourceId;
  final String externalClipId;
  final String title;
  final String audioPath;
  final String audioStatus;
  final int durationMs;
  final int sampleRate;
  final String speakerName;
  final String? estimatedLevel;
  final String levelSource;
  final double difficultyScore;
  final double classificationConfidence;
  final String classificationReason;
  final bool needsReview;
  final String transcriptNormalized;
  final String transcriptOriginal;
  final String reading;
  final String? questionId;
  final String promptVi;
  final String promptJp;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const ListeningPracticeItem({
    required this.id,
    required this.sourceId,
    required this.externalClipId,
    required this.title,
    required this.audioPath,
    required this.audioStatus,
    required this.durationMs,
    required this.sampleRate,
    required this.speakerName,
    required this.estimatedLevel,
    this.levelSource = 'estimated',
    this.difficultyScore = 0.0,
    this.classificationConfidence = 0.0,
    this.classificationReason = '',
    this.needsReview = false,
    required this.transcriptNormalized,
    required this.transcriptOriginal,
    required this.reading,
    this.questionId,
    required this.promptVi,
    required this.promptJp,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });

  bool get isPlayable =>
      audioStatus == 'available' &&
      audioPath.isNotEmpty &&
      audioPath.startsWith('assets/listening/');
}

class DatasetImportReport {
  final bool executed;
  final bool success;
  final String reason;
  final int chunkSize;
  final Map<String, TableImportResult> tableResults;
  final int orphanRecordCount;
  final int duplicateIdCount;
  final int unclassifiedReadingCount;
  final DatabaseInspectionReport postImportInspection;

  const DatasetImportReport({
    required this.executed,
    required this.success,
    required this.reason,
    required this.chunkSize,
    required this.tableResults,
    required this.orphanRecordCount,
    required this.duplicateIdCount,
    required this.unclassifiedReadingCount,
    required this.postImportInspection,
  });

  int get totalInsertedRecords =>
      tableResults.values.fold<int>(0, (sum, r) => sum + r.insertedCount);

  int get totalChunks =>
      tableResults.values.fold<int>(0, (sum, r) => sum + r.chunkCount);

  int get totalErrors =>
      tableResults.values.fold<int>(0, (sum, r) => sum + r.errorCount);

  Map<String, Object?> toMap() => {
        'executed': executed,
        'success': success,
        'reason': reason,
        'chunkSize': chunkSize,
        'totalInsertedRecords': totalInsertedRecords,
        'totalChunks': totalChunks,
        'totalErrors': totalErrors,
        'orphanRecordCount': orphanRecordCount,
        'duplicateIdCount': duplicateIdCount,
        'unclassifiedReadingCount': unclassifiedReadingCount,
        'tableResults': {
          for (final entry in tableResults.entries)
            entry.key: entry.value.toMap(),
        },
        'postImportInspection': postImportInspection.toMap(),
      };
}

class LocalDatabaseService {
  LocalDatabaseService._();
  static final LocalDatabaseService instance = LocalDatabaseService._();

  static const String databaseFileName = 'nihongo_master.db';
  /// v3: thêm cột `translation_status` cho các bảng nội dung có bản dịch tiếng Việt
  /// + bảng `dataset_meta` (xem [migrateToV3] và `tools/migrations/v3_translation_status.sql`).
  static const int databaseVersion = 3;

  /// Trạng thái bản dịch tiếng Việt của một bản ghi nội dung.
  static const String translationSource = 'source';
  static const String translationAiTranslated = 'ai_translated';
  static const String translationReviewed = 'reviewed';
  static const List<String> translationStatuses = <String>[
    translationSource,
    translationAiTranslated,
    translationReviewed,
  ];

  /// Bảng nội dung -> (file JSON, các cột tiếng Việt).
  static const Map<String, (String, List<String>)> translatableTables =
      <String, (String, List<String>)>{
    'vocabularies': ('vocabularies.json', <String>['meaning_vi']),
    'kanji_entries': ('kanji_entries.json', <String>['meaning_vi']),
    'grammar_points': ('grammar_points.json', <String>['title_vi', 'explanation_vi']),
    'example_sentences': ('example_sentences.json', <String>['translation_vi']),
    'reading_materials': ('reading_materials.json', <String>['title_vi', 'translation_vi']),
  };

  static const String translationFingerprintMetaKey = 'translation_fingerprint_v1';
  static const String devResetMarkerFileName = '.nihongo_master_dev_reset_v2.done';
  static const String devResetPrefsKey = 'dev_sqlite_clean_reset_v2_done';
  static const String verifiedImportMarkerFileName =
      '.nihongo_master_verified_import_v2.done';
  static const int defaultImportChunkSize = 500;

  static const List<String> requiredTables = <String>[
    'licenses',
    'data_sources',
    'vocabularies',
    'kanji_entries',
    'grammar_points',
    'example_sentences',
    'reading_materials',
    'listening_materials',
    'transcripts',
    'exams',
    'questions',
    'answers',
    'vocabulary_cache',
    'flashcard_progress',
    'test_history',
  ];

  static const List<String> learningAndProgressTables = <String>[
    'vocabularies',
    'kanji_entries',
    'grammar_points',
    'example_sentences',
    'reading_materials',
    'listening_materials',
    'transcripts',
    'exams',
    'questions',
    'answers',
    'vocabulary_cache',
    'flashcard_progress',
    'test_history',
  ];

  static const List<String> legacySharedPreferencesKeys = <String>[
    'learned_vocab',
    'learned_kanji',
    'fav_vocab',
    'fav_kanji',
    'test_history_json',
    'daily_tasks_json',
    'community_contributions_v1',
    'culture_spin_date',
    'culture_spin_index',
  ];

  Database? _database;
  Future<Database>? _openingFuture;
  Future<DatasetImportReport>? _importingFuture;
  bool _isResetting = false;
  int _activeOperations = 0;
  String? _customDatabasesDirPath;

  /// Allows overriding the database directory path in DEV/TEST unit tests.
  @visibleForTesting
  void setCustomDatabasesDirPathForTesting(String? path) {
    _customDatabasesDirPath = path;
  }

  bool get isDatabaseInUse => _activeOperations > 0;
  bool get isResetting => _isResetting;
  bool get isImporting => _importingFuture != null;

  Future<String> resolveDatabasesDirPath() async {
    if (_customDatabasesDirPath != null && _customDatabasesDirPath!.isNotEmpty) {
      return _customDatabasesDirPath!;
    }
    return getDatabasesPath();
  }

  Future<String> resolveDatabaseFilePath() async {
    final dirPath = await resolveDatabasesDirPath();
    return p.join(dirPath, databaseFileName);
  }

  Future<String> resolveResetMarkerFilePath() async {
    final dirPath = await resolveDatabasesDirPath();
    return p.join(dirPath, devResetMarkerFileName);
  }

  Future<String> resolveVerifiedImportMarkerFilePath() async {
    final dirPath = await resolveDatabasesDirPath();
    return p.join(dirPath, verifiedImportMarkerFileName);
  }

  Future<Database> get database async {
    if (_isResetting) {
      throw StateError('Cannot access database while DEV/TEST reset is in progress.');
    }
    if (_database != null && _database!.isOpen) {
      return _database!;
    }
    if (_openingFuture != null) {
      return _openingFuture!;
    }

    _openingFuture = _initAndOpenDatabase();
    try {
      _database = await _openingFuture!;
      return _database!;
    } finally {
      _openingFuture = null;
    }
  }

  Future<Database> _initAndOpenDatabase() async {
    if (!kReleaseMode) {
      final hasMarker = await isOneTimeDevResetCompleted();
      if (!hasMarker) {
        await _executeOneTimeDevResetInternal();
        if (_database != null && _database!.isOpen) {
          return _database!;
        }
      }
    }

    final dbFilePath = await resolveDatabaseFilePath();
    await Directory(p.dirname(dbFilePath)).create(recursive: true);
    return _openConfiguredDatabase(dbFilePath);
  }

  Future<Database> _openConfiguredDatabase(String dbFilePath) async {
    return databaseFactory.openDatabase(
      dbFilePath,
      options: OpenDatabaseOptions(
        version: databaseVersion,
        onConfigure: (db) async {
          await db.execute('PRAGMA foreign_keys = ON');
        },
        onCreate: (db, version) async {
          await _createSchemaV2(db);
          await migrateToV3(db);
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          if (oldVersion < 2) {
            await _createSchemaV2(db);
          }
          if (oldVersion < 3) {
            await migrateToV3(db);
          }
        },
      ),
    );
  }

  /// Checks whether the one-time DEV/TEST clean reset has already been completed.
  Future<bool> isOneTimeDevResetCompleted() async {
    final markerPath = await resolveResetMarkerFilePath();
    if (File(markerPath).existsSync()) {
      return true;
    }
    return false;
  }

  /// Creates a non-overwriting backup of the current database file if it exists on disk.
  Future<String?> backupCurrentDatabaseIfPresent({String? targetBackupDir}) async {
    final dbFilePath = await resolveDatabaseFilePath();
    final dbFile = File(dbFilePath);
    if (!dbFile.existsSync()) {
      return null;
    }

    final baseDir = targetBackupDir ?? p.join(await resolveDatabasesDirPath(), 'backups');
    await Directory(baseDir).create(recursive: true);

    final now = DateTime.now();
    final stamp =
        '${now.year}'
        '${now.month.toString().padLeft(2, '0')}'
        '${now.day.toString().padLeft(2, '0')}_'
        '${now.hour.toString().padLeft(2, '0')}'
        '${now.minute.toString().padLeft(2, '0')}'
        '${now.second.toString().padLeft(2, '0')}';

    var candidatePath = p.join(baseDir, 'nihongo_master_backup_$stamp.db');
    var suffix = 1;
    while (File(candidatePath).existsSync()) {
      candidatePath = p.join(baseDir, 'nihongo_master_backup_${stamp}_$suffix.db');
      suffix++;
    }

    await dbFile.copy(candidatePath);

    for (final ext in const ['-wal', '-shm']) {
      final sidecar = File('$dbFilePath$ext');
      if (sidecar.existsSync()) {
        final backupSidecar = '$candidatePath$ext';
        if (!File(backupSidecar).existsSync()) {
          await sidecar.copy(backupSidecar);
        }
      }
    }

    return candidatePath;
  }

  /// Triggers the one-time DEV/TEST database reset if not yet performed.
  /// Strictly disabled in production (`kReleaseMode`), refuses to run while
  /// active operations are using the database, closes existing connections safely,
  /// backs up the old database without overwriting, deletes the old database via
  /// `databaseFactory.deleteDatabase(path)`, recreates the clean v2 schema via
  /// `onCreate`, and verifies schema + foreign keys + empty tables.
  Future<DatabaseResetReport> performOneTimeDevResetIfNeeded({
    String? backupDirPath,
  }) async {
    if (kIsWeb) {
      return const DatabaseResetReport(
        executed: false,
        reason: 'Reset is skipped on Web (kIsWeb).',
        databasePath: 'web_memory',
      );
    }
    final dbFilePath = await resolveDatabaseFilePath();

    if (kReleaseMode) {
      return DatabaseResetReport(
        executed: false,
        reason: 'Reset is strictly disabled in production (kReleaseMode).',
        databasePath: dbFilePath,
      );
    }

    if (await isOneTimeDevResetCompleted()) {
      return DatabaseResetReport(
        executed: false,
        reason: 'One-time DEV/TEST reset has already been completed.',
        databasePath: dbFilePath,
      );
    }

    return _executeOneTimeDevResetInternal(backupDirPath: backupDirPath);
  }

  Future<DatabaseResetReport> _executeOneTimeDevResetInternal({
    String? backupDirPath,
  }) async {
    final dbFilePath = await resolveDatabaseFilePath();

    if (kReleaseMode) {
      throw StateError('Database reset is strictly forbidden in production (kReleaseMode).');
    }
    if (_isResetting) {
      throw StateError('A DEV/TEST database reset is already in progress.');
    }
    if (_activeOperations > 0) {
      throw StateError(
        'Cannot reset database while it is actively in use ($_activeOperations active operations).',
      );
    }

    _isResetting = true;
    try {
      await Directory(p.dirname(dbFilePath)).create(recursive: true);

      DatabaseInspectionReport? preInspection;
      if (File(dbFilePath).existsSync()) {
        try {
          if (_database == null || !_database!.isOpen) {
            _database = await databaseFactory.openDatabase(dbFilePath);
          }
          preInspection = await _inspectDatabaseInternal(_database!, dbFilePath);
        } catch (_) {
          preInspection = null;
        }
      }

      // Close any open connection before backup and deleteDatabase
      await closeDatabaseSafely();

      // 1. Backup existing database without overwriting
      final backupPath = await backupCurrentDatabaseIfPresent(
        targetBackupDir: backupDirPath,
      );

      // 2. Delete existing SQLite database via databaseFactory.deleteDatabase(path)
      await databaseFactory.deleteDatabase(dbFilePath);
      final importMarker = File(await resolveVerifiedImportMarkerFilePath());
      if (importMarker.existsSync()) {
        await importMarker.delete();
      }
      VocabularyData.setLoadedWords(const <VocabularyWord>[]);
      KanjiData.setLoadedKanji(const <KanjiItem>[]);
      GrammarData.setLoadedLessons(const <GrammarLesson>[]);
      ReadingMaterialData.setLoadedMaterials(const <ReadingMaterial>[]);
      JLPTTestData.setLoadedTests(const <JLPTTest>[]);

      // 3. Clear legacy learning state in SharedPreferences
      await clearLegacySharedPreferencesState();

      // 4. Open new database so SQLite recreates the schema via onCreate
      _database = await _openConfiguredDatabase(dbFilePath);

      // 5. Inspect & verify newly created database
      final postInspection = await _inspectDatabaseInternal(_database!, dbFilePath);
      if (!postInspection.isHealthy || !postInspection.isAllLearningDataEmpty) {
        throw StateError(
          'Post-reset database verification failed: ${jsonEncode(postInspection.toMap())}',
        );
      }

      // 6. Write one-time completion marker so subsequent app launches do NOT reset again
      final markerPath = await resolveResetMarkerFilePath();
      await File(markerPath).writeAsString(
        jsonEncode({
          'resetCompletedAt': DateTime.now().toIso8601String(),
          'databaseVersion': databaseVersion,
          'databasePath': dbFilePath,
          'backupPath': backupPath,
        }),
        flush: true,
      );

      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool(devResetPrefsKey, true);
      } catch (_) {}

      return DatabaseResetReport(
        executed: true,
        reason: 'One-time DEV/TEST SQLite reset completed and verified.',
        databasePath: dbFilePath,
        backupPath: backupPath,
        preResetInspection: preInspection,
        postResetInspection: postInspection,
      );
    } finally {
      _isResetting = false;
    }
  }

  /// Safely closes the current database connection if open.
  Future<void> closeDatabaseSafely() async {
    if (_activeOperations > 0) {
      throw StateError(
        'Cannot close database while $_activeOperations operations are still running.',
      );
    }
    if (_database != null) {
      if (_database!.isOpen) {
        await _database!.close();
      }
      _database = null;
    }
  }

  /// Clears legacy learning/progress keys in SharedPreferences during DEV/TEST reset.
  Future<void> clearLegacySharedPreferencesState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final key in legacySharedPreferencesKeys) {
        await prefs.remove(key);
      }
    } catch (_) {}
  }

  /// Clears user progress tables (`flashcard_progress`, `test_history`, and `cat_care_state`) without dropping schema.
  Future<void> clearUserProgressTables() async {
    if (kIsWeb) return;
    return _runOperation((db) async {
      await db.transaction((txn) async {
        await txn.delete('flashcard_progress');
        await txn.delete('test_history');
        try {
          await txn.delete('cat_care_state');
        } catch (_) {}
      });
    });
  }

  /// Saves Guardian Cat care state (`foodInventory`, `ownedOutfits`, `equippedOutfit`, and 3 vitals) to local SQLite.
  Future<void> saveCatCareState({
    required String userId,
    required Map<String, int> foodInventory,
    required List<String> ownedOutfits,
    required String? equippedOutfit,
    required int hunger,
    required int energy,
    required int mood,
    required bool companionEnabled,
    required double companionScale,
  }) async {
    if (kIsWeb || _isResetting) return;
    try {
      await _runOperation((db) async {
        await db.execute('''
          CREATE TABLE IF NOT EXISTS cat_care_state (
            user_id TEXT PRIMARY KEY,
            hunger INTEGER NOT NULL DEFAULT 75,
            energy INTEGER NOT NULL DEFAULT 80,
            mood INTEGER NOT NULL DEFAULT 85,
            food_inventory_json TEXT NOT NULL DEFAULT '{}',
            owned_outfits_json TEXT NOT NULL DEFAULT '[]',
            equipped_outfit TEXT,
            companion_enabled INTEGER NOT NULL DEFAULT 1,
            companion_scale REAL NOT NULL DEFAULT 1.0,
            updated_at TEXT NOT NULL
          )
        ''');
        await db.insert(
          'cat_care_state',
          {
            'user_id': userId,
            'hunger': hunger.clamp(0, 100),
            'energy': energy.clamp(0, 100),
            'mood': mood.clamp(0, 100),
            'food_inventory_json': jsonEncode(foodInventory),
            'owned_outfits_json': jsonEncode(ownedOutfits),
            'equipped_outfit': equippedOutfit,
            'companion_enabled': companionEnabled ? 1 : 0,
            'companion_scale': companionScale.clamp(0.60, 1.30),
            'updated_at': DateTime.now().toIso8601String(),
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
    } catch (_) {}
  }

  /// Loads Guardian Cat care state from local SQLite if present.
  Future<Map<String, Object?>?> loadCatCareState({required String userId}) async {
    if (kIsWeb || _isResetting) return null;
    try {
      return await _runOperation((db) async {
        final tables = await db.rawQuery(
          "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'cat_care_state'",
        );
        if (tables.isEmpty) return null;
        final rows = await db.query(
          'cat_care_state',
          where: 'user_id = ?',
          whereArgs: [userId],
          limit: 1,
        );
        if (rows.isEmpty) return null;
        return Map<String, Object?>.from(rows.first);
      });
    } catch (_) {
      return null;
    }
  }

  /// Inspects the current database version, tables, indexes, foreign keys, and row counts.
  Future<DatabaseInspectionReport> inspectDatabase() async {
    return _runOperation((db) async {
      final dbFilePath = await resolveDatabaseFilePath();
      return _inspectDatabaseInternal(db, dbFilePath);
    });
  }

  Future<DatabaseInspectionReport> _inspectDatabaseInternal(
    Database db,
    String dbFilePath,
  ) async {
    final version = await db.getVersion();

    final fkPragmaRows = await db.rawQuery('PRAGMA foreign_keys');
    final fkEnabled = fkPragmaRows.isNotEmpty &&
        ((fkPragmaRows.first['foreign_keys'] as int? ?? 0) == 1);

    final masterRows = await db.rawQuery(
      "SELECT type, name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY name",
    );
    final tables = <String>[];
    final indexes = <String>[];
    for (final row in masterRows) {
      final type = row['type'] as String?;
      final name = row['name'] as String?;
      if (name == null) continue;
      if (type == 'table') {
        tables.add(name);
      } else if (type == 'index') {
        indexes.add(name);
      }
    }

    final tableRowCounts = <String, int>{};
    final tableForeignKeys = <String, List<Map<String, Object?>>>{};
    for (final table in tables) {
      final countResult = await db.rawQuery('SELECT COUNT(*) AS cnt FROM "$table"');
      tableRowCounts[table] = (countResult.first['cnt'] as int?) ?? 0;

      final fkList = await db.rawQuery('PRAGMA foreign_key_list("$table")');
      tableForeignKeys[table] = fkList.map((e) => Map<String, Object?>.from(e)).toList();
    }

    final fkViolationsRaw = await db.rawQuery('PRAGMA foreign_key_check');
    final fkViolations = fkViolationsRaw.map((e) => Map<String, Object?>.from(e)).toList();

    return DatabaseInspectionReport(
      databasePath: dbFilePath,
      version: version,
      foreignKeysEnabled: fkEnabled,
      tables: tables,
      indexes: indexes,
      tableRowCounts: tableRowCounts,
      tableForeignKeys: tableForeignKeys,
      foreignKeyViolations: fkViolations,
    );
  }

  Future<T> _runOperation<T>(Future<T> Function(Database db) action) async {
    final db = await database;
    _activeOperations++;
    try {
      return await action(db);
    } finally {
      _activeOperations--;
    }
  }

  /// Migration v2 -> v3 (idempotent, không xoá/ghi đè dữ liệu):
  /// - `ALTER TABLE ... ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  ///   CHECK (translation_status IN ('source','ai_translated','reviewed'))` cho 5 bảng nội dung.
  ///   SQLite gán giá trị mặc định cho mọi dòng sẵn có, không rebuild bảng, không đụng FK.
  /// - Tạo `dataset_meta` (key/value) để lưu dấu vân tay bản dịch đã đồng bộ.
  /// Các bảng tiến trình (`flashcard_progress`, `test_history`, `cat_care_state`,
  /// `vocabulary_cache`) không bị chạm tới.
  static Future<void> migrateToV3(DatabaseExecutor db) async {
    for (final table in translatableTables.keys) {
      final exists = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
        <Object>[table],
      );
      if (exists.isEmpty) continue;
      final columns = await db.rawQuery('PRAGMA table_info("$table")');
      final hasColumn = columns.any((c) => c['name'] == 'translation_status');
      if (hasColumn) continue;
      await db.execute(
        'ALTER TABLE "$table" ADD COLUMN translation_status TEXT NOT NULL '
        "DEFAULT '$translationSource' "
        "CHECK (translation_status IN ('$translationSource', '$translationAiTranslated', '$translationReviewed'))",
      );
    }
    final examTableExists = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'exams'",
    );
    if (examTableExists.isNotEmpty) {
      final examCols = await db.rawQuery('PRAGMA table_info("exams")');
      final hasAiCol = examCols.any((c) => c['name'] == 'is_ai_generated');
      if (!hasAiCol) {
        await db.execute(
          'ALTER TABLE "exams" ADD COLUMN is_ai_generated INTEGER NOT NULL DEFAULT 0',
        );
      }
      final hasPassageCol = examCols.any((c) => c['name'] == 'reading_passage');
      if (!hasPassageCol) {
        await db.execute(
          'ALTER TABLE "exams" ADD COLUMN reading_passage TEXT',
        );
      }
    }
    await db.execute('''
      CREATE TABLE IF NOT EXISTS dataset_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
  }

  /// Đồng bộ bản dịch tiếng Việt từ file JSON (sau khi chạy `tools/auto_translate_dataset.py`)
  /// vào SQLite đã import sẵn, **không re-import** và không đụng tiến trình học.
  ///
  /// Quy tắc ghi:
  /// - Chỉ cập nhật các cột tiếng Việt + `translation_status`, theo `id`.
  /// - Không bao giờ ghi đè dòng `reviewed` trong DB.
  /// - Không ghi đè bản dịch `source` đã có nội dung bằng bản `ai_translated`.
  /// - Chỉ chạy lại khi dấu vân tay bản dịch trong JSON thay đổi.
  /// Trả về số dòng đã cập nhật.
  Future<int> syncTranslationsFromAssets({String? assetsDirPath, bool force = false}) async {
    final payloads = <String, List<Map<String, dynamic>>>{};
    var fingerprint = 0x811c9dc5;
    void mix(String s) {
      for (final unit in s.codeUnits) {
        fingerprint ^= unit;
        fingerprint = (fingerprint * 0x01000193) & 0xFFFFFFFF;
      }
    }

    for (final entry in translatableTables.entries) {
      final (fileName, viColumns) = entry.value;
      String raw;
      try {
        raw = await _readVerifiedJsonString(fileName, assetsDirPath: assetsDirPath);
      } catch (_) {
        continue;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! List) continue;
      final rows = <Map<String, dynamic>>[];
      for (final item in decoded) {
        if (item is! Map) continue;
        final hasVi = viColumns.any((c) => (item[c]?.toString().trim() ?? '').isNotEmpty);
        if (!hasVi) continue;
        final status = item['translation_status']?.toString() ?? translationSource;
        if (!translationStatuses.contains(status)) continue;
        final row = <String, dynamic>{'id': item['id'].toString(), 'translation_status': status};
        for (final c in viColumns) {
          row[c] = item[c];
        }
        rows.add(row);
        mix('${entry.key}|${row['id']}|$status|${viColumns.map((c) => item[c] ?? '').join('|')}');
      }
      payloads[entry.key] = rows;
    }
    final fp = fingerprint.toRadixString(16);

    return _runOperation((db) async {
      await migrateToV3(db);
      if (!force) {
        final meta = await db.query(
          'dataset_meta',
          where: 'key = ?',
          whereArgs: <Object>[translationFingerprintMetaKey],
        );
        if (meta.isNotEmpty && meta.first['value'] == fp) return 0;
      }
      var updated = 0;
      final updatedIdsByTable = <String, Set<String>>{};
      await db.transaction((txn) async {
        for (final entry in payloads.entries) {
          final table = entry.key;
          final viColumns = translatableTables[table]!.$2;
          final setClause = [
            ...viColumns.map((c) => '$c = ?'),
            'translation_status = ?',
          ].join(', ');
          // Ghi khi: DB chưa 'reviewed' VÀ (bản mới là reviewed/source, hoặc DB đang trống/ai_translated).
          final emptyCheck = viColumns.map((c) => "COALESCE($c, '') = ''").join(' AND ');
          final sql = 'UPDATE "$table" SET $setClause WHERE id = ? '
              "AND translation_status != '$translationReviewed' "
              "AND (? IN ('$translationReviewed', '$translationSource') "
              "OR ($emptyCheck) OR translation_status = '$translationAiTranslated')";
          final batch = txn.batch();
          for (final row in entry.value) {
            batch.rawUpdate(sql, <Object?>[
              ...viColumns.map((c) => row[c]),
              row['translation_status'],
              row['id'],
              row['translation_status'],
            ]);
          }
          final results = await batch.commit();
          for (var i = 0; i < results.length; i++) {
            final n = results[i] is int ? results[i] as int : 0;
            if (n <= 0) continue;
            updated += n;
            updatedIdsByTable.putIfAbsent(table, () => <String>{}).add(entry.value[i]['id'] as String);
          }
        }

        // Đưa bản dịch vào vocabulary_cache (bảng app đọc khi học) bằng UPDATE tại chỗ.
        // KHÔNG xoá/dựng lại cache: flashcard_progress có FK ON DELETE CASCADE sang cache.
        final vocabIds = updatedIdsByTable['vocabularies'] ?? const <String>{};
        for (final id in vocabIds) {
          await txn.rawUpdate(
            "UPDATE vocabulary_cache SET vietnamese = COALESCE((SELECT meaning_vi FROM vocabularies WHERE id = ?), '') WHERE id = ?",
            <Object>[id, id],
          );
        }
        final sentenceIds = updatedIdsByTable['example_sentences'] ?? const <String>{};
        if (sentenceIds.isNotEmpty) {
          final affectedVocab = <String>{};
          for (final sid in sentenceIds) {
            final r = await txn.query('example_sentences', columns: ['linked_vocab_id'], where: 'id = ?', whereArgs: [sid]);
            final vid = r.isEmpty ? null : r.first['linked_vocab_id'] as String?;
            if (vid != null) affectedVocab.add(vid);
          }
          for (final vid in affectedVocab) {
            final sRows = await txn.query(
              'example_sentences',
              where: 'linked_vocab_id = ?',
              whereArgs: [vid],
              orderBy: 'id ASC',
            );
            final translations = <String>[
              for (final s in sRows)
                if (((s['sentence_jp'] as String?) ?? '').isNotEmpty)
                  ContentFallback.cleanText(s['translation_vi'] as String?) ??
                      ContentFallback.cleanText(s['translation_en'] as String?) ??
                      '',
            ];
            await txn.update(
              'vocabulary_cache',
              <String, Object>{'exampleTranslations': jsonEncode(translations)},
              where: 'id = ?',
              whereArgs: [vid],
            );
          }
        }
        await txn.insert(
          'dataset_meta',
          <String, Object>{
            'key': translationFingerprintMetaKey,
            'value': fp,
            'updated_at': DateTime.now().toIso8601String(),
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
      return updated;
    });
  }

  static Future<void> _createSchemaV2(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS licenses (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        license_url TEXT,
        allow_redistribution INTEGER NOT NULL DEFAULT 1,
        allow_modification INTEGER NOT NULL DEFAULT 1,
        require_attribution INTEGER NOT NULL DEFAULT 1,
        require_share_alike INTEGER NOT NULL DEFAULT 0,
        notes TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS data_sources (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        source_url TEXT NOT NULL,
        license_id TEXT NOT NULL,
        attribution_text TEXT NOT NULL,
        upstream_credits TEXT,
        version_or_commit TEXT,
        fetched_at TEXT NOT NULL,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS vocabularies (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT,
        jmdict_id TEXT,
        expression TEXT NOT NULL,
        reading_hiragana TEXT NOT NULL,
        reading_romaji TEXT,
        part_of_speech TEXT,
        meaning_vi TEXT,
        meaning_en TEXT NOT NULL,
        category TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        estimation_basis TEXT,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS kanji_entries (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT,
        character TEXT NOT NULL UNIQUE,
        onyomi TEXT,
        kunyomi TEXT,
        nanori TEXT,
        stroke_count INTEGER NOT NULL,
        radical TEXT,
        meaning_vi TEXT,
        meaning_en TEXT NOT NULL,
        mnemonic_story TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        estimation_basis TEXT,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS grammar_points (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT,
        pattern TEXT NOT NULL,
        title_vi TEXT,
        title_en TEXT,
        formation TEXT,
        explanation_vi TEXT,
        explanation_en TEXT,
        notes TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        estimation_basis TEXT,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS example_sentences (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT,
        external_sentence_id TEXT,
        sentence_jp TEXT NOT NULL,
        sentence_furigana TEXT,
        sentence_hiragana TEXT,
        translation_vi TEXT,
        translation_en TEXT,
        linked_vocab_id TEXT,
        linked_kanji_id TEXT,
        linked_grammar_id TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT,
        FOREIGN KEY (linked_vocab_id) REFERENCES vocabularies(id) ON DELETE SET NULL,
        FOREIGN KEY (linked_kanji_id) REFERENCES kanji_entries(id) ON DELETE SET NULL,
        FOREIGN KEY (linked_grammar_id) REFERENCES grammar_points(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS reading_materials (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT NOT NULL,
        external_item_id TEXT,
        title_jp TEXT NOT NULL,
        title_furigana TEXT,
        title_vi TEXT,
        title_en TEXT,
        author_jp TEXT,
        author_romaji TEXT,
        category TEXT NOT NULL,
        content_jp TEXT NOT NULL,
        content_ruby_json TEXT,
        translation_vi TEXT,
        translation_en TEXT,
        summary TEXT,
        word_count INTEGER,
        estimated_minutes INTEGER,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        estimation_basis TEXT,
        has_audio INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS listening_materials (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT NOT NULL,
        external_clip_id TEXT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        audio_url TEXT NOT NULL,
        audio_format TEXT NOT NULL,
        duration_ms INTEGER,
        sample_rate INTEGER,
        speaker_name TEXT,
        reading_material_id TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 1,
        estimation_basis TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT,
        FOREIGN KEY (reading_material_id) REFERENCES reading_materials(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS transcripts (
        id TEXT PRIMARY KEY,
        listening_material_id TEXT NOT NULL,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        segment_index INTEGER NOT NULL DEFAULT 0,
        start_time_ms INTEGER DEFAULT 0,
        end_time_ms INTEGER,
        speaker_label TEXT,
        text_jp TEXT NOT NULL,
        text_furigana_reading TEXT,
        is_reading_machine_generated INTEGER NOT NULL DEFAULT 0,
        translation_vi TEXT,
        translation_en TEXT,
        verified_status TEXT NOT NULL DEFAULT 'auto',
        FOREIGN KEY (listening_material_id) REFERENCES listening_materials(id) ON DELETE CASCADE,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS exams (
        id TEXT PRIMARY KEY,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT NOT NULL,
        title TEXT NOT NULL,
        exam_type TEXT NOT NULL,
        delivery_mode TEXT NOT NULL DEFAULT 'in_app',
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        time_limit_minutes INTEGER NOT NULL DEFAULT 20,
        total_questions INTEGER NOT NULL DEFAULT 0,
        description TEXT,
        created_at TEXT NOT NULL,
        is_ai_generated INTEGER NOT NULL DEFAULT 0,
        reading_passage TEXT,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS questions (
        id TEXT PRIMARY KEY,
        exam_id TEXT,
        source_id TEXT NOT NULL,
        license_id TEXT NOT NULL,
        source_url TEXT,
        question_type TEXT NOT NULL,
        mondai_code TEXT,
        prompt_text_vi TEXT NOT NULL,
        prompt_text_jp TEXT NOT NULL,
        prompt_ruby_json TEXT,
        reading_material_id TEXT,
        listening_material_id TEXT,
        target_vocab_id TEXT,
        target_kanji_id TEXT,
        target_grammar_id TEXT,
        explanation_vi TEXT,
        explanation_en TEXT,
        original_level TEXT,
        estimated_level TEXT,
        is_level_estimated INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE SET NULL,
        FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT,
        FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT,
        FOREIGN KEY (reading_material_id) REFERENCES reading_materials(id) ON DELETE CASCADE,
        FOREIGN KEY (listening_material_id) REFERENCES listening_materials(id) ON DELETE CASCADE,
        FOREIGN KEY (target_vocab_id) REFERENCES vocabularies(id) ON DELETE SET NULL,
        FOREIGN KEY (target_kanji_id) REFERENCES kanji_entries(id) ON DELETE SET NULL,
        FOREIGN KEY (target_grammar_id) REFERENCES grammar_points(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS answers (
        id TEXT PRIMARY KEY,
        question_id TEXT NOT NULL,
        option_index INTEGER NOT NULL,
        content_text TEXT NOT NULL,
        content_ruby TEXT,
        is_correct INTEGER NOT NULL DEFAULT 0,
        option_explanation TEXT,
        FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS vocabulary_cache (
        id TEXT PRIMARY KEY,
        japanese TEXT NOT NULL,
        hiragana TEXT NOT NULL,
        romaji TEXT,
        vietnamese TEXT,
        english TEXT,
        jlptLevel TEXT,
        category TEXT,
        exampleSentences TEXT,
        exampleTranslations TEXT,
        isLearned INTEGER NOT NULL DEFAULT 0,
        isFavorite INTEGER NOT NULL DEFAULT 0,
        correctCount INTEGER NOT NULL DEFAULT 0,
        wrongCount INTEGER NOT NULL DEFAULT 0,
        lastStudied TEXT,
        srsInterval INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS flashcard_progress (
        vocabId TEXT NOT NULL,
        userId TEXT NOT NULL DEFAULT 'guest',
        interval INTEGER NOT NULL DEFAULT 0,
        easeFactor REAL NOT NULL DEFAULT 2.5,
        repetition INTEGER NOT NULL DEFAULT 0,
        nextReview TEXT,
        correctCount INTEGER NOT NULL DEFAULT 0,
        wrongCount INTEGER NOT NULL DEFAULT 0,
        lastReviewed TEXT,
        PRIMARY KEY (userId, vocabId),
        FOREIGN KEY (vocabId) REFERENCES vocabulary_cache(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS test_history (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL DEFAULT 'guest',
        testId TEXT,
        title TEXT,
        jlptLevel TEXT,
        totalQuestions INTEGER,
        correctAnswers INTEGER,
        wrongAnswers INTEGER,
        scorePercent REAL,
        timeTakenSeconds INTEGER,
        completedAt TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS cat_care_state (
        user_id TEXT PRIMARY KEY,
        hunger INTEGER NOT NULL DEFAULT 75,
        energy INTEGER NOT NULL DEFAULT 80,
        mood INTEGER NOT NULL DEFAULT 85,
        food_inventory_json TEXT NOT NULL DEFAULT '{}',
        owned_outfits_json TEXT NOT NULL DEFAULT '[]',
        equipped_outfit TEXT,
        companion_enabled INTEGER NOT NULL DEFAULT 1,
        companion_scale REAL NOT NULL DEFAULT 1.0,
        updated_at TEXT NOT NULL
      )
    ''');

    // Create indexes
    await db.execute('CREATE INDEX IF NOT EXISTS idx_vocab_expression ON vocabularies(expression)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_vocab_reading ON vocabularies(reading_hiragana)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_vocab_orig_level ON vocabularies(original_level)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_kanji_orig_level ON kanji_entries(original_level)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_grammar_orig_level ON grammar_points(original_level)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_sentences_vocab ON example_sentences(linked_vocab_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_reading_cat ON reading_materials(category)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_transcripts_listening ON transcripts(listening_material_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_questions_exam ON questions(exam_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_answers_question ON answers(question_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_flashcard_user_review ON flashcard_progress(userId, nextReview)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_test_history_user_date ON test_history(userId, completedAt DESC)');
  }

  Future<void> cacheVocabulary(List<VocabularyWord> words) async {
    if (words.isEmpty) return;
    return _runOperation((db) async {
      const chunkSize = 500;
      for (var offset = 0; offset < words.length; offset += chunkSize) {
        final end = (offset + chunkSize < words.length) ? offset + chunkSize : words.length;
        final chunk = words.sublist(offset, end);
        await db.transaction((txn) async {
          final batch = txn.batch();
          for (final word in chunk) {
            batch.rawInsert(
              '''
              INSERT INTO vocabulary_cache (
                id, japanese, hiragana, romaji, vietnamese, english,
                jlptLevel, category, exampleSentences, exampleTranslations,
                isLearned, isFavorite, correctCount, wrongCount, lastStudied, srsInterval
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
              ON CONFLICT(id) DO UPDATE SET
                japanese = excluded.japanese,
                hiragana = excluded.hiragana,
                romaji = excluded.romaji,
                vietnamese = excluded.vietnamese,
                english = excluded.english,
                jlptLevel = excluded.jlptLevel,
                category = excluded.category,
                exampleSentences = excluded.exampleSentences,
                exampleTranslations = excluded.exampleTranslations,
                isLearned = excluded.isLearned,
                isFavorite = excluded.isFavorite,
                correctCount = excluded.correctCount,
                wrongCount = excluded.wrongCount,
                lastStudied = excluded.lastStudied,
                srsInterval = excluded.srsInterval
              ''',
              <Object?>[
                word.id,
                word.japanese,
                word.hiragana,
                word.romaji,
                word.vietnamese,
                word.english,
                word.jlptLevel,
                word.category,
                jsonEncode(word.exampleSentences),
                jsonEncode(word.exampleTranslations),
                word.isLearned ? 1 : 0,
                word.isFavorite ? 1 : 0,
                word.correctCount,
                word.wrongCount,
                word.lastStudied?.toIso8601String(),
                word.srsInterval,
              ],
            );
          }
          await batch.commit(noResult: true);
        });
      }
    });
  }

  Future<void> updateCachedWordProgress(VocabularyWord word) async {
    return _runOperation((db) async {
      await db.update(
        'vocabulary_cache',
        <String, Object?>{
          'isLearned': word.isLearned ? 1 : 0,
          'isFavorite': word.isFavorite ? 1 : 0,
          'correctCount': word.correctCount,
          'wrongCount': word.wrongCount,
          'lastStudied': word.lastStudied?.toIso8601String(),
          'srsInterval': word.srsInterval,
        },
        where: 'id = ?',
        whereArgs: <Object?>[word.id],
      );
    });
  }

  Future<List<VocabularyWord>> getCachedVocabulary() async {
    return _runOperation((db) async {
      final rows = await db.query('vocabulary_cache');
      return rows.map((map) {
        return VocabularyWord(
          id: map['id'] as String,
          japanese: map['japanese'] as String,
          hiragana: map['hiragana'] as String,
          romaji: (map['romaji'] as String?) ?? '',
          vietnamese: (map['vietnamese'] as String?) ?? '',
          english: (map['english'] as String?) ?? '',
          jlptLevel: (map['jlptLevel'] as String?) ?? 'N5',
          category: (map['category'] as String?) ?? 'general',
          exampleSentences: List<String>.from(
            jsonDecode(map['exampleSentences'] as String? ?? '[]') as List,
          ),
          exampleTranslations: List<String>.from(
            jsonDecode(map['exampleTranslations'] as String? ?? '[]') as List,
          ),
          isLearned: (map['isLearned'] as int? ?? 0) == 1,
          isFavorite: (map['isFavorite'] as int? ?? 0) == 1,
          correctCount: map['correctCount'] as int? ?? 0,
          wrongCount: map['wrongCount'] as int? ?? 0,
          lastStudied: map['lastStudied'] == null
              ? null
              : DateTime.tryParse(map['lastStudied'] as String),
          srsInterval: map['srsInterval'] as int? ?? 1,
        );
      }).toList();
    });
  }

  /// Searches the SQLite `vocabularies` table (and linked `example_sentences`)
  /// using parameterized SQL following Priority 1 (exact `expression`),
  /// Priority 2 (`reading_hiragana`, `reading_romaji`, `meaning_vi`, `meaning_en`),
  /// and JLPT level priority (`original_level` / `estimated_level`).
  Future<List<VocabularyWord>> searchVocabulariesInSqlite({
    required List<String> candidates,
    required String targetLevel,
    bool allowCrossLevelFallback = true,
    int limit = 6,
  }) async {
    final cleanedCandidates = candidates
        .map((c) => c.trim())
        .where((c) => c.isNotEmpty)
        .toList();
    if (cleanedCandidates.isEmpty || limit <= 0) {
      return const <VocabularyWord>[];
    }

    return _runOperation((db) async {
      final normalizedLevel = targetLevel.trim().toUpperCase();
      final matchedRows = <Map<String, Object?>>[];
      final seenIds = <String>{};

      void appendRows(List<Map<String, Object?>> rows) {
        for (final row in rows) {
          if (matchedRows.length >= limit) break;
          final id = row['id']?.toString() ?? '';
          if (id.isNotEmpty && seenIds.add(id)) {
            matchedRows.add(row);
          }
        }
      }

      bool hasJapaneseScript(String text) {
        return RegExp(r'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]')
            .hasMatch(text);
      }

      Future<void> runTierQueries({required bool strictLevel}) async {
        final levelClause = strictLevel
            ? " AND COALESCE(original_level, estimated_level, 'N5') = ?"
            : '';

        // Priority 1: Exact match on `expression`
        for (final cand in cleanedCandidates) {
          if (matchedRows.length >= limit) return;
          final args = <Object?>[
            cand,
            if (strictLevel) normalizedLevel,
            limit,
          ];
          final rows = await db.rawQuery(
            'SELECT * FROM vocabularies WHERE expression = ?$levelClause ORDER BY id ASC LIMIT ?',
            args,
          );
          appendRows(rows);
        }

        // Priority 2a: Exact match on `reading_hiragana` or `reading_romaji`
        for (final cand in cleanedCandidates) {
          if (matchedRows.length >= limit) return;
          final lowerCand = cand.toLowerCase();
          final args = <Object?>[
            cand,
            lowerCand,
            if (strictLevel) normalizedLevel,
            limit,
          ];
          final rows = await db.rawQuery(
            'SELECT * FROM vocabularies WHERE (reading_hiragana = ? OR LOWER(reading_romaji) = ?)$levelClause ORDER BY id ASC LIMIT ?',
            args,
          );
          appendRows(rows);
        }

        // Priority 2b: Japanese substring match OR Latin/Vietnamese meaning match
        for (final cand in cleanedCandidates) {
          if (matchedRows.length >= limit) return;
          if (hasJapaneseScript(cand)) {
            if (cand.runes.length < 2) continue;
            final pattern = '%$cand%';
            final args = <Object?>[
              pattern,
              pattern,
              if (strictLevel) normalizedLevel,
              limit,
            ];
            final rows = await db.rawQuery(
              'SELECT * FROM vocabularies WHERE (expression LIKE ? OR reading_hiragana LIKE ?)$levelClause ORDER BY LENGTH(expression) ASC, id ASC LIMIT ?',
              args,
            );
            appendRows(rows);
          } else {
            final lowerCand = cand.toLowerCase();
            if (lowerCand.length < 2) continue;
            // Exact meaning match first
            final exactArgs = <Object?>[
              lowerCand,
              lowerCand,
              if (strictLevel) normalizedLevel,
              limit,
            ];
            final exactRows = await db.rawQuery(
              'SELECT * FROM vocabularies WHERE (LOWER(meaning_vi) = ? OR LOWER(meaning_en) = ?)$levelClause ORDER BY id ASC LIMIT ?',
              exactArgs,
            );
            appendRows(exactRows);

            if (matchedRows.length < limit && lowerCand.length >= 3) {
              final pattern = '%$lowerCand%';
              final subArgs = <Object?>[
                pattern,
                pattern,
                if (strictLevel) normalizedLevel,
                limit,
              ];
              final subRows = await db.rawQuery(
                'SELECT * FROM vocabularies WHERE (LOWER(meaning_vi) LIKE ? OR LOWER(meaning_en) LIKE ?)$levelClause ORDER BY LENGTH(meaning_en) ASC, id ASC LIMIT ?',
                subArgs,
              );
              appendRows(subRows);
            }
          }
        }
      }

      await runTierQueries(strictLevel: true);
      if (matchedRows.isEmpty && allowCrossLevelFallback) {
        await runTierQueries(strictLevel: false);
      }

      if (matchedRows.isEmpty) {
        return const <VocabularyWord>[];
      }

      final vocabIds = matchedRows.map((r) => r['id'] as String).toList();
      final placeholders = List.filled(vocabIds.length, '?').join(', ');
      final sentenceRows = await db.rawQuery(
        'SELECT linked_vocab_id, sentence_jp, translation_vi, translation_en FROM example_sentences WHERE linked_vocab_id IN ($placeholders) ORDER BY id ASC',
        vocabIds,
      );

      final sentencesByVocab = <String, List<String>>{};
      final translationsByVocab = <String, List<String>>{};
      for (final s in sentenceRows) {
        final vid = s['linked_vocab_id'] as String?;
        if (vid == null) continue;
        final jp = (s['sentence_jp'] as String?) ?? '';
        final trVi = ContentFallback.cleanText(s['translation_vi'] as String?);
        final trEn = ContentFallback.cleanText(s['translation_en'] as String?);
        if (jp.isNotEmpty) {
          (sentencesByVocab[vid] ??= <String>[]).add(jp);
          (translationsByVocab[vid] ??= <String>[]).add(trVi ?? trEn ?? '');
        }
      }

      return matchedRows.map((v) {
        final id = v['id'] as String;
        final pos = ContentFallback.cleanText(v['part_of_speech'] as String?);
        final cat = ContentFallback.cleanText(v['category'] as String?) ??
            _normalizePosCategory(pos);
        return VocabularyWord(
          id: id,
          japanese: (v['expression'] as String?) ?? '',
          hiragana: (v['reading_hiragana'] as String?) ?? '',
          romaji: (v['reading_romaji'] as String?) ?? '',
          vietnamese: ContentFallback.cleanText(v['meaning_vi'] as String?) ?? '',
          english: ContentFallback.cleanText(v['meaning_en'] as String?) ?? '',
          jlptLevel: (v['original_level'] as String?) ??
              (v['estimated_level'] as String?) ??
              'N5',
          category: cat,
          exampleSentences: sentencesByVocab[id] ?? const <String>[],
          exampleTranslations: translationsByVocab[id] ?? const <String>[],
        );
      }).toList();
    });
  }

  /// Looks up a single vocabulary record by exact [id] from SQLite (`vocabularies`
  /// or `vocabulary_cache`) using parameterized SQL.
  Future<VocabularyWord?> getVocabularyWordById(String id) async {
    final cleanId = id.trim();
    if (cleanId.isEmpty || kIsWeb || _isResetting) return null;
    try {
      return await _runOperation((db) async {
        final rows = await db.query(
          'vocabularies',
          where: 'id = ?',
          whereArgs: <Object?>[cleanId],
          limit: 1,
        );
        if (rows.isNotEmpty) {
          final v = rows.first;
          final sentenceRows = await db.rawQuery(
            'SELECT sentence_jp, translation_vi, translation_en FROM example_sentences WHERE linked_vocab_id = ? ORDER BY id ASC',
            <Object?>[cleanId],
          );
          final sentences = <String>[];
          final translations = <String>[];
          for (final s in sentenceRows) {
            final jp = (s['sentence_jp'] as String?) ?? '';
            final trVi =
                ContentFallback.cleanText(s['translation_vi'] as String?);
            final trEn =
                ContentFallback.cleanText(s['translation_en'] as String?);
            if (jp.isNotEmpty) {
              sentences.add(jp);
              translations.add(trVi ?? trEn ?? '');
            }
          }
          final pos = ContentFallback.cleanText(v['part_of_speech'] as String?);
          final cat = ContentFallback.cleanText(v['category'] as String?) ??
              _normalizePosCategory(pos);
          return VocabularyWord(
            id: cleanId,
            japanese: (v['expression'] as String?) ?? '',
            hiragana: (v['reading_hiragana'] as String?) ?? '',
            romaji: (v['reading_romaji'] as String?) ?? '',
            vietnamese:
                ContentFallback.cleanText(v['meaning_vi'] as String?) ?? '',
            english:
                ContentFallback.cleanText(v['meaning_en'] as String?) ?? '',
            jlptLevel: (v['original_level'] as String?) ??
                (v['estimated_level'] as String?) ??
                'N5',
            category: cat,
            exampleSentences: sentences,
            exampleTranslations: translations,
          );
        }

        final cacheRows = await db.query(
          'vocabulary_cache',
          where: 'id = ?',
          whereArgs: <Object?>[cleanId],
          limit: 1,
        );
        if (cacheRows.isNotEmpty) {
          final map = cacheRows.first;
          return VocabularyWord(
            id: cleanId,
            japanese: (map['japanese'] as String?) ?? '',
            hiragana: (map['hiragana'] as String?) ?? '',
            romaji: (map['romaji'] as String?) ?? '',
            vietnamese:
                ContentFallback.cleanText(map['vietnamese'] as String?) ?? '',
            english: ContentFallback.cleanText(map['english'] as String?) ?? '',
            jlptLevel: (map['jlptLevel'] as String?) ?? 'N5',
            category: (map['category'] as String?) ?? 'common',
            exampleSentences: List<String>.from(
              jsonDecode(map['exampleSentences'] as String? ?? '[]') as List,
            ),
            exampleTranslations: List<String>.from(
              jsonDecode(map['exampleTranslations'] as String? ?? '[]') as List,
            ),
          );
        }
        return null;
      });
    } catch (_) {
      return null;
    }
  }

  Future<void> upsertFlashcardProgress(FlashcardProgress progress) async {
    return _runOperation((db) async {
      final exists = await db.query(
        'vocabulary_cache',
        columns: const ['id'],
        where: 'id = ?',
        whereArgs: [progress.vocabId],
        limit: 1,
      );
      if (exists.isEmpty) {
        return;
      }
      await db.rawInsert(
        '''
        INSERT INTO flashcard_progress (
          userId, vocabId, interval, easeFactor, repetition,
          nextReview, correctCount, wrongCount, lastReviewed
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(userId, vocabId) DO UPDATE SET
          interval = excluded.interval,
          easeFactor = excluded.easeFactor,
          repetition = excluded.repetition,
          nextReview = excluded.nextReview,
          correctCount = excluded.correctCount,
          wrongCount = excluded.wrongCount,
          lastReviewed = excluded.lastReviewed
        ''',
        <Object?>[
          progress.userId,
          progress.vocabId,
          progress.interval,
          progress.easeFactor,
          progress.repetition,
          progress.nextReview.toIso8601String(),
          progress.correctCount,
          progress.wrongCount,
          progress.lastReviewed?.toIso8601String(),
        ],
      );
    });
  }

  Future<Map<String, FlashcardProgress>> getAllFlashcardProgress({String? userId}) async {
    return _runOperation((db) async {
      final rows = await db.query(
        'flashcard_progress',
        where: userId == null ? null : 'userId = ?',
        whereArgs: userId == null ? null : [userId],
      );
      return {
        for (final row in rows)
          (row['vocabId'] as String): FlashcardProgress.fromMap(row),
      };
    });
  }

  Future<List<Map<String, Object?>>> getFlashcardProgressJoinedWithVocabulary({
    String? userId,
  }) async {
    return _runOperation((db) async {
      final whereClause = userId == null ? '' : 'WHERE fp.userId = ?';
      final args = userId == null ? const <Object?>[] : <Object?>[userId];
      return db.rawQuery(
        '''
        SELECT
          fp.userId,
          fp.vocabId,
          fp.interval,
          fp.easeFactor,
          fp.repetition,
          fp.nextReview,
          fp.correctCount,
          fp.wrongCount,
          fp.lastReviewed,
          vc.japanese,
          vc.hiragana,
          vc.romaji,
          vc.vietnamese,
          vc.english,
          vc.jlptLevel,
          v.meaning_vi,
          v.meaning_en,
          v.original_level
        FROM flashcard_progress fp
        INNER JOIN vocabulary_cache vc ON fp.vocabId = vc.id
        INNER JOIN vocabularies v ON fp.vocabId = v.id
        $whereClause
        ORDER BY fp.nextReview ASC, fp.vocabId ASC
        ''',
        args,
      );
    });
  }

  Future<void> upsertStudyHistory(StudyHistory history) async {
    return _runOperation((db) async {
      await db.insert(
        'test_history',
        history.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  Future<List<StudyHistory>> getStudyHistories({String? userId}) async {
    return _runOperation((db) async {
      final rows = await db.query(
        'test_history',
        where: userId == null ? null : 'userId = ?',
        whereArgs: userId == null ? null : [userId],
        orderBy: 'completedAt DESC',
      );
      return rows.map(StudyHistory.fromMap).toList();
    });
  }

  static const List<Map<String, String>> _verifiedImportSpecs = <Map<String, String>>[
    {'table': 'licenses', 'file': 'licenses.json'},
    {'table': 'data_sources', 'file': 'data_sources.json'},
    {'table': 'vocabularies', 'file': 'vocabularies.json'},
    {'table': 'kanji_entries', 'file': 'kanji_entries.json'},
    {'table': 'grammar_points', 'file': 'grammar_points.json'},
    {'table': 'example_sentences', 'file': 'example_sentences.json'},
    {'table': 'reading_materials', 'file': 'reading_materials.json'},
    {'table': 'listening_materials', 'file': 'listening_materials.json'},
    {'table': 'transcripts', 'file': 'transcripts.json'},
    {'table': 'exams', 'file': 'exams.json'},
    {'table': 'questions', 'file': 'questions.json'},
    {'table': 'answers', 'file': 'answers.json'},
  ];

  static const Map<String, List<String>> _requiredColumnsByTable = <String, List<String>>{
    'licenses': <String>['id', 'code', 'name'],
    'data_sources': <String>['id', 'name', 'source_url', 'license_id', 'attribution_text', 'fetched_at'],
    'vocabularies': <String>['id', 'source_id', 'license_id', 'expression', 'reading_hiragana', 'meaning_en'],
    'kanji_entries': <String>['id', 'source_id', 'license_id', 'character', 'stroke_count', 'meaning_en'],
    'grammar_points': <String>['id', 'source_id', 'license_id', 'pattern'],
    'example_sentences': <String>['id', 'source_id', 'license_id', 'sentence_jp'],
    'reading_materials': <String>['id', 'source_id', 'license_id', 'source_url', 'title_jp', 'category', 'content_jp', 'created_at'],
    'listening_materials': <String>['id', 'source_id', 'license_id', 'source_url', 'title', 'category', 'audio_url', 'audio_format', 'created_at'],
    'transcripts': <String>['id', 'listening_material_id', 'source_id', 'license_id', 'text_jp'],
    'exams': <String>['id', 'source_id', 'license_id', 'source_url', 'title', 'exam_type', 'created_at'],
    'questions': <String>['id', 'source_id', 'license_id', 'question_type', 'prompt_text_vi', 'prompt_text_jp', 'created_at'],
    'answers': <String>['id', 'question_id', 'option_index', 'content_text'],
  };

  Future<bool> isVerifiedDatasetImported() async {
    return _runOperation((db) async {
      final markerFile = File(await resolveVerifiedImportMarkerFilePath());
      if (!markerFile.existsSync()) {
        return false;
      }
      final vocabCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM vocabularies'),
          ) ??
          0;
      final kanjiCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM kanji_entries'),
          ) ??
          0;
      final grammarCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM grammar_points'),
          ) ??
          0;
      final readingCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM reading_materials'),
          ) ??
          0;
      return vocabCnt > 0 && kanjiCnt > 0 && grammarCnt > 0 && readingCnt > 0;
    });
  }

  /// Ensures the verified v2 dataset is imported into SQLite once and loaded into memory.
  Future<DatasetImportReport> ensureVerifiedDatasetImportedAndLoaded({
    String? assetsDirPath,
    int chunkSize = defaultImportChunkSize,
  }) async {
    await performOneTimeDevResetIfNeeded();
    final report = await importVerifiedDataset(
      assetsDirPath: assetsDirPath,
      chunkSize: chunkSize,
      forceReimport: false,
    );
    try {
      await syncTranslationsFromAssets(assetsDirPath: assetsDirPath);
    } catch (e) {
      debugPrint('syncTranslationsFromAssets failed: $e');
    }
    await loadVerifiedDatasetsIntoMemory();
    return report;
  }

  /// Imports the verified v2 dataset into SQLite using chunked batches (`chunkSize = 500`),
  /// performing strict pre-import and post-import verification.
  Future<DatasetImportReport> importVerifiedDataset({
    String? assetsDirPath,
    int chunkSize = defaultImportChunkSize,
    void Function(
      String table,
      int chunkIndex,
      int totalChunks,
      int insertedCount,
      int expectedCount,
    )? onChunkProgress,
    bool forceReimport = false,
  }) async {
    if (_importingFuture != null) {
      return _importingFuture!;
    }
    _importingFuture = _importVerifiedDatasetInternal(
      assetsDirPath: assetsDirPath,
      chunkSize: chunkSize,
      onChunkProgress: onChunkProgress,
      forceReimport: forceReimport,
    );
    try {
      return await _importingFuture!;
    } finally {
      _importingFuture = null;
    }
  }

  Future<String> _readVerifiedJsonString(String fileName, {String? assetsDirPath}) async {
    final candidates = <String>[
      if (assetsDirPath != null && assetsDirPath.isNotEmpty)
        p.join(assetsDirPath, fileName),
      p.join(Directory.current.path, 'assets', 'data', 'verified_v2', fileName),
      p.join(
        Directory.current.path,
        'nihongo_master',
        'assets',
        'data',
        'verified_v2',
        fileName,
      ),
    ];
    for (final candidate in candidates) {
      final f = File(candidate);
      if (f.existsSync()) {
        return f.readAsString();
      }
    }
    return rootBundle.loadString('assets/data/verified_v2/$fileName');
  }

  Future<DatasetImportReport> _importVerifiedDatasetInternal({
    String? assetsDirPath,
    required int chunkSize,
    void Function(
      String table,
      int chunkIndex,
      int totalChunks,
      int insertedCount,
      int expectedCount,
    )? onChunkProgress,
    required bool forceReimport,
  }) async {
    if (!forceReimport && await isVerifiedDatasetImported()) {
      final inspection = await inspectDatabase();
      final orphanCount = await _countOrphanRecords();
      final unclassifiedReadings = await countUnclassifiedReadingMaterials();
      final tableResults = <String, TableImportResult>{};
      for (final spec in _verifiedImportSpecs) {
        final tbl = spec['table']!;
        final fname = spec['file']!;
        final cnt = inspection.tableRowCounts[tbl] ?? 0;
        final chunks = cnt == 0 ? 0 : ((cnt + chunkSize - 1) ~/ chunkSize);
        tableResults[tbl] = TableImportResult(
          table: tbl,
          sourceFile: fname,
          expectedCount: cnt,
          insertedCount: cnt,
          skippedCount: 0,
          chunkCount: chunks,
          errorCount: 0,
          skipped: cnt == 0,
          skipReason: cnt == 0 ? 'Dataset has 0 verified records.' : null,
        );
      }
      final cacheCnt = inspection.tableRowCounts['vocabulary_cache'] ?? 0;
      tableResults['vocabulary_cache'] = TableImportResult(
        table: 'vocabulary_cache',
        sourceFile: 'vocabularies.json + example_sentences.json',
        expectedCount: cacheCnt,
        insertedCount: cacheCnt,
        skippedCount: 0,
        chunkCount: cacheCnt == 0 ? 0 : ((cacheCnt + chunkSize - 1) ~/ chunkSize),
        errorCount: 0,
        skipped: false,
      );
      return DatasetImportReport(
        executed: false,
        success: inspection.isHealthy && orphanCount == 0,
        reason: 'Verified dataset v2 is already imported and verified.',
        chunkSize: chunkSize,
        tableResults: tableResults,
        orphanRecordCount: orphanCount,
        duplicateIdCount: 0,
        unclassifiedReadingCount: unclassifiedReadings,
        postImportInspection: inspection,
      );
    }

    return _runOperation((db) async {
      final dbFilePath = await resolveDatabaseFilePath();
      final preInspection = await _inspectDatabaseInternal(db, dbFilePath);
      if (!preInspection.isHealthy) {
        throw StateError(
          'Pre-import database schema check failed: ${jsonEncode(preInspection.toMap())}',
        );
      }

      final tableResults = <String, TableImportResult>{};
      var totalDuplicateIds = 0;

      final validLicenseIds = <String>{};
      final validSourceIds = <String>{};
      final validVocabIds = <String>{};
      final validKanjiIds = <String>{};
      final validGrammarIds = <String>{};
      final validReadingIds = <String>{};
      final validListeningIds = <String>{};
      final validExamIds = <String>{};
      final validQuestionIds = <String>{};

      for (final spec in _verifiedImportSpecs) {
        final table = spec['table']!;
        final fileName = spec['file']!;

        final rawJson = await _readVerifiedJsonString(
          fileName,
          assetsDirPath: assetsDirPath,
        );
        final decoded = jsonDecode(rawJson);
        if (decoded is! List) {
          throw FormatException('Import file $fileName must contain a JSON array.');
        }

        final rawRows = decoded.cast<Map<String, dynamic>>();
        final expectedCount = rawRows.length;

        if (expectedCount == 0) {
          final reason = switch (table) {
            'listening_materials' || 'transcripts' =>
              'Chưa có dataset Listening hợp pháp và đạt chuẩn JLPT (Kokoro là dữ liệu cắt tự động cho TTS, 57% câu bị cắt cụt; đề JLPT chính thức có bản quyền All Rights Reserved).',
            'exams' || 'questions' || 'answers' =>
              'Chưa có dataset JLPT Test hợp pháp để nhúng trong ứng dụng (câu hỏi cũ đã bị loại bỏ; đề thi mẫu JLPT chính thức có bản quyền All Rights Reserved).',
            _ => 'File $fileName có 0 bản ghi.',
          };
          tableResults[table] = TableImportResult(
            table: table,
            sourceFile: fileName,
            expectedCount: 0,
            insertedCount: 0,
            skippedCount: 0,
            chunkCount: 0,
            errorCount: 0,
            skipped: true,
            skipReason: reason,
          );
          continue;
        }

        final seenIds = <String>{};
        final seenKanjiChars = <String>{};
        final validatedRows = <Map<String, Object?>>[];
        final errors = <String>[];
        var skippedInTable = 0;

        final requiredCols = _requiredColumnsByTable[table] ?? const <String>['id'];

        for (var idx = 0; idx < rawRows.length; idx++) {
          final row = Map<String, Object?>.from(rawRows[idx]);
          final id = row['id']?.toString().trim() ?? '';

          // 1. Check required columns
          var missingRequired = false;
          for (final col in requiredCols) {
            final val = row[col];
            if (val == null || (val is String && val.trim().isEmpty)) {
              errors.add('$table[$idx] ($id): missing required column "$col"');
              missingRequired = true;
              break;
            }
          }
          if (missingRequired) {
            skippedInTable++;
            continue;
          }

          // 2. Reject legacy hardcoded IDs
          if (RegExp(r'^(n[1-5]_\d+|kanji_vocab_|kanji_practice_)').hasMatch(id)) {
            errors.add('$table[$idx]: legacy hardcoded ID "$id" is forbidden.');
            skippedInTable++;
            continue;
          }

          // 3. Check duplicate IDs
          if (!seenIds.add(id)) {
            totalDuplicateIds++;
            skippedInTable++;
            errors.add('$table[$idx]: duplicate primary key "$id".');
            continue;
          }

          if (table == 'kanji_entries') {
            final ch = row['character']?.toString() ?? '';
            if (ch.runes.length != 1 || !seenKanjiChars.add(ch)) {
              skippedInTable++;
              errors.add('$table[$idx]: invalid or duplicate Kanji character "$ch".');
              continue;
            }
          }

          // 4. Check foreign keys before insert
          if (row.containsKey('license_id') && row['license_id'] != null) {
            final licId = row['license_id'].toString();
            if (!validLicenseIds.contains(licId)) {
              errors.add('$table[$idx] ($id): invalid license_id "$licId".');
              skippedInTable++;
              continue;
            }
          }
          if (row.containsKey('source_id') && row['source_id'] != null) {
            final srcId = row['source_id'].toString();
            if (!validSourceIds.contains(srcId)) {
              errors.add('$table[$idx] ($id): invalid source_id "$srcId".');
              skippedInTable++;
              continue;
            }
          }
          if (table == 'example_sentences') {
            final vId = row['linked_vocab_id']?.toString();
            if (vId != null && !validVocabIds.contains(vId)) {
              errors.add('$table[$idx] ($id): orphan linked_vocab_id "$vId".');
              skippedInTable++;
              continue;
            }
            final gId = row['linked_grammar_id']?.toString();
            if (gId != null && !validGrammarIds.contains(gId)) {
              errors.add('$table[$idx] ($id): orphan linked_grammar_id "$gId".');
              skippedInTable++;
              continue;
            }
          }
          if (table == 'transcripts') {
            final lId = row['listening_material_id']?.toString();
            if (lId == null || !validListeningIds.contains(lId)) {
              errors.add('$table[$idx] ($id): orphan listening_material_id "$lId".');
              skippedInTable++;
              continue;
            }
          }

          validatedRows.add(row);
          switch (table) {
            case 'licenses':
              validLicenseIds.add(id);
              break;
            case 'data_sources':
              validSourceIds.add(id);
              break;
            case 'vocabularies':
              validVocabIds.add(id);
              break;
            case 'kanji_entries':
              validKanjiIds.add(id);
              break;
            case 'grammar_points':
              validGrammarIds.add(id);
              break;
            case 'reading_materials':
              validReadingIds.add(id);
              break;
            case 'listening_materials':
              validListeningIds.add(id);
              break;
            case 'exams':
              validExamIds.add(id);
              break;
            case 'questions':
              validQuestionIds.add(id);
              break;
          }
        }

        // Clear existing rows in table if forceReimport
        await db.delete(table);

        final totalToInsert = validatedRows.length;
        final totalChunks =
            totalToInsert == 0 ? 0 : ((totalToInsert + chunkSize - 1) ~/ chunkSize);
        var insertedSoFar = 0;

        for (var chunkIdx = 0; chunkIdx < totalChunks; chunkIdx++) {
          final start = chunkIdx * chunkSize;
          final end = (start + chunkSize < totalToInsert)
              ? (start + chunkSize)
              : totalToInsert;
          final chunk = validatedRows.sublist(start, end);

          try {
            await db.transaction((txn) async {
              final batch = txn.batch();
              for (final r in chunk) {
                batch.insert(
                  table,
                  r,
                  conflictAlgorithm: ConflictAlgorithm.abort,
                );
              }
              await batch.commit(noResult: true, continueOnError: false);
            });
          } catch (e) {
            errors.add('$table chunk ${chunkIdx + 1}/$totalChunks error: $e');
            rethrow;
          }

          // Verify actual row count in SQLite after each chunk
          final countAfterChunk = Sqflite.firstIntValue(
                await db.rawQuery('SELECT COUNT(*) FROM "$table"'),
              ) ??
              0;
          if (countAfterChunk != end) {
            final msg =
                'Row count mismatch in $table after chunk ${chunkIdx + 1}/$totalChunks: expected $end, got $countAfterChunk';
            errors.add(msg);
            throw StateError(msg);
          }

          insertedSoFar = countAfterChunk;
          onChunkProgress?.call(
            table,
            chunkIdx + 1,
            totalChunks,
            insertedSoFar,
            totalToInsert,
          );
          // Yield to event loop between chunks to prevent blocking UI thread
          await Future<void>.delayed(Duration.zero);
        }

        tableResults[table] = TableImportResult(
          table: table,
          sourceFile: fileName,
          expectedCount: expectedCount,
          insertedCount: insertedSoFar,
          skippedCount: skippedInTable,
          chunkCount: totalChunks,
          errorCount: errors.length,
          skipped: false,
          errors: errors,
        );
      }

      // Now synchronize vocabulary_cache in chunks of 500 so Flashcard & VocabularyProvider work offline
      final cacheResult = await _syncVocabularyCacheFromV2InChunks(
        db,
        chunkSize: chunkSize,
        onChunkProgress: onChunkProgress,
      );
      tableResults['vocabulary_cache'] = cacheResult;

      // Post-import verification
      final postInspection = await _inspectDatabaseInternal(db, dbFilePath);
      final orphanCount = await _countOrphanRecordsInternal(db);
      final unclassifiedReadings = await _countUnclassifiedReadingMaterialsInternal(db);

      if (!postInspection.isHealthy || orphanCount > 0) {
        throw StateError(
          'Post-import verification failed: healthy=${postInspection.isHealthy}, orphans=$orphanCount',
        );
      }

      // Write import marker so subsequent launches do not re-import or reset
      final importMarkerPath = await resolveVerifiedImportMarkerFilePath();
      await File(importMarkerPath).writeAsString(
        jsonEncode({
          'importedAt': DateTime.now().toIso8601String(),
          'databaseVersion': databaseVersion,
          'chunkSize': chunkSize,
          'tableCounts': postInspection.tableRowCounts,
        }),
        flush: true,
      );

      return DatasetImportReport(
        executed: true,
        success: true,
        reason: 'All verified datasets imported in chunks of $chunkSize and verified.',
        chunkSize: chunkSize,
        tableResults: tableResults,
        orphanRecordCount: orphanCount,
        duplicateIdCount: totalDuplicateIds,
        unclassifiedReadingCount: unclassifiedReadings,
        postImportInspection: postInspection,
      );
    });
  }

  Future<TableImportResult> _syncVocabularyCacheFromV2InChunks(
    Database db, {
    required int chunkSize,
    void Function(
      String table,
      int chunkIndex,
      int totalChunks,
      int insertedCount,
      int expectedCount,
    )? onChunkProgress,
  }) async {
    // Preserve any existing user flags in vocabulary_cache
    final existingRows = await db.query('vocabulary_cache');
    final existingById = <String, Map<String, Object?>>{
      for (final r in existingRows) (r['id'] as String): r,
    };

    final vocabRows = await db.query('vocabularies', orderBy: 'original_level ASC, id ASC');
    final sentenceRows = await db.query(
      'example_sentences',
      where: 'linked_vocab_id IS NOT NULL',
      orderBy: 'id ASC',
    );

    final sentencesByVocab = <String, List<String>>{};
    final translationsByVocab = <String, List<String>>{};
    for (final s in sentenceRows) {
      final vid = s['linked_vocab_id'] as String?;
      if (vid == null) continue;
      final jp = (s['sentence_jp'] as String?) ?? '';
      final trVi = ContentFallback.cleanText(s['translation_vi'] as String?);
      final trEn = ContentFallback.cleanText(s['translation_en'] as String?);
      if (jp.isNotEmpty) {
        (sentencesByVocab[vid] ??= <String>[]).add(jp);
        (translationsByVocab[vid] ??= <String>[]).add(trVi ?? trEn ?? '');
      }
    }

    await db.delete('vocabulary_cache');

    final total = vocabRows.length;
    final totalChunks = total == 0 ? 0 : ((total + chunkSize - 1) ~/ chunkSize);
    var insertedSoFar = 0;

    for (var chunkIdx = 0; chunkIdx < totalChunks; chunkIdx++) {
      final start = chunkIdx * chunkSize;
      final end = (start + chunkSize < total) ? (start + chunkSize) : total;
      final chunk = vocabRows.sublist(start, end);

      await db.transaction((txn) async {
        final batch = txn.batch();
        for (final v in chunk) {
          final id = v['id'] as String;
          final prev = existingById[id];
          final pos = ContentFallback.cleanText(v['part_of_speech'] as String?);
          final cat = ContentFallback.cleanText(v['category'] as String?) ??
              _normalizePosCategory(pos);
          batch.insert(
            'vocabulary_cache',
            <String, Object?>{
              'id': id,
              'japanese': v['expression'] as String,
              'hiragana': v['reading_hiragana'] as String,
              'romaji': (v['reading_romaji'] as String?) ?? '',
              // Keep raw meaning_vi (empty string if null) — do NOT overwrite with meaning_en
              'vietnamese': (v['meaning_vi'] as String?) ?? '',
              'english': (v['meaning_en'] as String?) ?? '',
              'jlptLevel': (v['original_level'] as String?) ??
                  (v['estimated_level'] as String?) ??
                  'N5',
              'category': cat,
              'exampleSentences': jsonEncode(sentencesByVocab[id] ?? const <String>[]),
              'exampleTranslations': jsonEncode(translationsByVocab[id] ?? const <String>[]),
              'isLearned': prev?['isLearned'] as int? ?? 0,
              'isFavorite': prev?['isFavorite'] as int? ?? 0,
              'correctCount': prev?['correctCount'] as int? ?? 0,
              'wrongCount': prev?['wrongCount'] as int? ?? 0,
              'lastStudied': prev?['lastStudied'] as String?,
              'srsInterval': prev?['srsInterval'] as int? ?? 1,
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
        await batch.commit(noResult: true, continueOnError: false);
      });

      final countAfter = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM vocabulary_cache'),
          ) ??
          0;
      if (countAfter != end) {
        throw StateError(
          'vocabulary_cache count mismatch after chunk ${chunkIdx + 1}/$totalChunks: expected $end, got $countAfter',
        );
      }
      insertedSoFar = countAfter;
      onChunkProgress?.call(
        'vocabulary_cache',
        chunkIdx + 1,
        totalChunks,
        insertedSoFar,
        total,
      );
      await Future<void>.delayed(Duration.zero);
    }

    return TableImportResult(
      table: 'vocabulary_cache',
      sourceFile: 'vocabularies.json + example_sentences.json',
      expectedCount: total,
      insertedCount: insertedSoFar,
      skippedCount: 0,
      chunkCount: totalChunks,
      errorCount: 0,
      skipped: false,
    );
  }

  static String _normalizePosCategory(String? pos) {
    if (pos == null || pos.isEmpty) return 'general';
    final lower = pos.toLowerCase();
    if (lower.contains('verb') || lower.startsWith('v')) return 'verbs';
    if (lower.contains('adj')) return 'adjectives';
    if (lower.contains('pn') || lower.contains('pronoun')) return 'pronouns';
    if (lower.contains('n') || lower.contains('noun')) return 'nouns';
    return 'common';
  }

  Future<int> _countOrphanRecords() async {
    return _runOperation((db) => _countOrphanRecordsInternal(db));
  }

  Future<int> _countOrphanRecordsInternal(Database db) async {
    const queries = <String>[
      'SELECT COUNT(*) FROM data_sources WHERE license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM vocabularies WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM kanji_entries WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM grammar_points WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM example_sentences WHERE (linked_vocab_id IS NOT NULL AND linked_vocab_id NOT IN (SELECT id FROM vocabularies)) OR (linked_grammar_id IS NOT NULL AND linked_grammar_id NOT IN (SELECT id FROM grammar_points))',
      'SELECT COUNT(*) FROM reading_materials WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM listening_materials WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM transcripts WHERE listening_material_id NOT IN (SELECT id FROM listening_materials)',
      'SELECT COUNT(*) FROM exams WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses)',
      'SELECT COUNT(*) FROM questions WHERE source_id NOT IN (SELECT id FROM data_sources) OR license_id NOT IN (SELECT id FROM licenses) OR (exam_id IS NOT NULL AND exam_id NOT IN (SELECT id FROM exams)) OR (listening_material_id IS NOT NULL AND listening_material_id NOT IN (SELECT id FROM listening_materials))',
      'SELECT COUNT(*) FROM answers WHERE question_id NOT IN (SELECT id FROM questions)',
      'SELECT COUNT(*) FROM flashcard_progress WHERE vocabId NOT IN (SELECT id FROM vocabulary_cache)',
    ];
    var totalOrphans = 0;
    for (final q in queries) {
      totalOrphans += Sqflite.firstIntValue(await db.rawQuery(q)) ?? 0;
    }
    return totalOrphans;
  }

  static const String p6ImportMarkerFileName =
      '.nihongo_master_p6_listening_jlpt_v2.done';

  static const List<Map<String, String>> _p6ImportSpecs = <Map<String, String>>[
    {'table': 'licenses', 'file': 'p6_licenses.json'},
    {'table': 'data_sources', 'file': 'p6_data_sources.json'},
    {'table': 'listening_materials', 'file': 'p6_listening_materials.json'},
    {'table': 'transcripts', 'file': 'p6_transcripts.json'},
    {'table': 'exams', 'file': 'p6_exams.json'},
    {'table': 'questions', 'file': 'p6_questions.json'},
    {'table': 'answers', 'file': 'p6_answers.json'},
  ];

  Future<String> resolveP6ImportMarkerFilePath() async {
    final dirPath = await resolveDatabasesDirPath();
    return p.join(dirPath, p6ImportMarkerFileName);
  }

  Future<bool> isListeningAndJlptDatasetImported() async {
    return _runOperation((db) async {
      final markerFile = File(await resolveP6ImportMarkerFilePath());
      if (!markerFile.existsSync()) {
        return false;
      }
      final listenCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM listening_materials'),
          ) ??
          0;
      final examCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM exams'),
          ) ??
          0;
      final qCnt = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM questions'),
          ) ??
          0;
      return listenCnt > 0 && examCnt > 0 && qCnt > 0;
    });
  }

  /// Ensures both the base verified datasets (Vocabulary, Kanji, Grammar, Reading)
  /// and the Prompt 6 Listening & JLPT datasets are imported non-destructively and loaded into memory.
  Future<DatasetImportReport> ensureListeningAndJlptDatasetsImportedAndLoaded({
    String? assetsDirPath,
    int chunkSize = defaultImportChunkSize,
  }) async {
    await ensureVerifiedDatasetImportedAndLoaded(
      assetsDirPath: assetsDirPath,
      chunkSize: chunkSize,
    );
    final report = await importListeningAndJlptDatasets(
      assetsDirPath: assetsDirPath,
      chunkSize: chunkSize,
      forceReimport: false,
    );
    await loadVerifiedDatasetsIntoMemory();
    return report;
  }

  /// Non-destructively and idempotently imports Listening (`kokoro_tiny`) and JLPT (`jlpt_freq`)
  /// datasets into SQLite without deleting or resetting any existing tables or user progress.
  Future<DatasetImportReport> importListeningAndJlptDatasets({
    String? assetsDirPath,
    int chunkSize = defaultImportChunkSize,
    bool forceReimport = false,
  }) async {
    if (!forceReimport && await isListeningAndJlptDatasetImported()) {
      final inspection = await inspectDatabase();
      final orphanCount = await _countOrphanRecords();
      final unclassifiedReadings = await countUnclassifiedReadingMaterials();
      final tableResults = <String, TableImportResult>{};
      for (final spec in _p6ImportSpecs) {
        final tbl = spec['table']!;
        final fname = spec['file']!;
        final cnt = inspection.tableRowCounts[tbl] ?? 0;
        tableResults[tbl] = TableImportResult(
          table: tbl,
          sourceFile: fname,
          expectedCount: cnt,
          insertedCount: 0,
          updatedCount: 0,
          skippedCount: cnt,
          chunkCount: 0,
          errorCount: 0,
          skipped: true,
          skipReason: 'Prompt 6 Listening & JLPT datasets already imported.',
        );
      }
      return DatasetImportReport(
        executed: false,
        success: inspection.isHealthy && orphanCount == 0,
        reason: 'Listening & JLPT datasets are already imported and verified.',
        chunkSize: chunkSize,
        tableResults: tableResults,
        orphanRecordCount: orphanCount,
        duplicateIdCount: 0,
        unclassifiedReadingCount: unclassifiedReadings,
        postImportInspection: inspection,
      );
    }

    return _runOperation((db) async {
      final dbFilePath = await resolveDatabaseFilePath();
      final preInspection = await _inspectDatabaseInternal(db, dbFilePath);
      if (!preInspection.isHealthy) {
        throw StateError(
          'Pre-import database schema check failed: ${jsonEncode(preInspection.toMap())}',
        );
      }

      // Record pre-import counts of protected tables to guarantee 0 data loss
      const protectedTables = <String>[
        'vocabularies',
        'kanji_entries',
        'grammar_points',
        'example_sentences',
        'reading_materials',
        'vocabulary_cache',
        'flashcard_progress',
        'test_history',
      ];
      final preProtectedCounts = <String, int>{
        for (final t in protectedTables)
          t: preInspection.tableRowCounts[t] ?? 0,
      };

      final validLicenseIds = <String>{
        for (final r in await db.query('licenses', columns: ['id']))
          r['id'] as String,
      };
      final validSourceIds = <String>{
        for (final r in await db.query('data_sources', columns: ['id']))
          r['id'] as String,
      };
      final validListeningIds = <String>{
        for (final r in await db.query('listening_materials', columns: ['id']))
          r['id'] as String,
      };
      final validExamIds = <String>{
        for (final r in await db.query('exams', columns: ['id']))
          r['id'] as String,
      };
      final validQuestionIds = <String>{
        for (final r in await db.query('questions', columns: ['id']))
          r['id'] as String,
      };

      final tableResults = <String, TableImportResult>{};
      var totalDuplicateIds = 0;

      for (final spec in _p6ImportSpecs) {
        final table = spec['table']!;
        final fileName = spec['file']!;

        final rawJson = await _readVerifiedJsonString(
          fileName,
          assetsDirPath: assetsDirPath,
        );
        final decoded = jsonDecode(rawJson);
        if (decoded is! List) {
          throw FormatException('Import file $fileName must contain a JSON array.');
        }

        final rawRows = decoded.cast<Map<String, dynamic>>();
        final expectedCount = rawRows.length;
        final seenIdsInPayload = <String>{};
        final validatedRows = <Map<String, Object?>>[];
        final errors = <String>[];
        var skippedInTable = 0;

        final requiredCols = _requiredColumnsByTable[table] ?? const <String>['id'];

        for (var idx = 0; idx < rawRows.length; idx++) {
          final row = Map<String, Object?>.from(rawRows[idx]);
          final id = row['id']?.toString().trim() ?? '';

          var missingRequired = false;
          for (final col in requiredCols) {
            final val = row[col];
            if (val == null || (val is String && val.trim().isEmpty)) {
              errors.add('$table[$idx] ($id): missing required column "$col"');
              missingRequired = true;
              break;
            }
          }
          if (missingRequired) {
            skippedInTable++;
            continue;
          }

          if (!seenIdsInPayload.add(id)) {
            totalDuplicateIds++;
            skippedInTable++;
            errors.add('$table[$idx]: duplicate primary key "$id" in payload.');
            continue;
          }

          // Validate foreign keys before upsert
          if (row.containsKey('license_id') && row['license_id'] != null) {
            final licId = row['license_id'].toString();
            if (!validLicenseIds.contains(licId)) {
              errors.add('$table[$idx] ($id): invalid license_id "$licId".');
              skippedInTable++;
              continue;
            }
          }
          if (row.containsKey('source_id') && row['source_id'] != null) {
            final srcId = row['source_id'].toString();
            if (!validSourceIds.contains(srcId)) {
              errors.add('$table[$idx] ($id): invalid source_id "$srcId".');
              skippedInTable++;
              continue;
            }
          }
          if (table == 'transcripts') {
            final lId = row['listening_material_id']?.toString();
            if (lId == null || !validListeningIds.contains(lId)) {
              errors.add('$table[$idx] ($id): orphan listening_material_id "$lId".');
              skippedInTable++;
              continue;
            }
          }
          if (table == 'questions') {
            final exId = row['exam_id']?.toString();
            if (exId != null && !validExamIds.contains(exId)) {
              errors.add('$table[$idx] ($id): orphan exam_id "$exId".');
              skippedInTable++;
              continue;
            }
            final lId = row['listening_material_id']?.toString();
            if (lId != null && !validListeningIds.contains(lId)) {
              errors.add('$table[$idx] ($id): orphan listening_material_id "$lId".');
              skippedInTable++;
              continue;
            }
          }
          if (table == 'answers') {
            final qId = row['question_id']?.toString();
            if (qId == null || !validQuestionIds.contains(qId)) {
              errors.add('$table[$idx] ($id): orphan question_id "$qId".');
              skippedInTable++;
              continue;
            }
          }

          validatedRows.add(row);
          switch (table) {
            case 'licenses':
              validLicenseIds.add(id);
              break;
            case 'data_sources':
              validSourceIds.add(id);
              break;
            case 'listening_materials':
              validListeningIds.add(id);
              break;
            case 'exams':
              validExamIds.add(id);
              break;
            case 'questions':
              validQuestionIds.add(id);
              break;
          }
        }

        // Check existing IDs in table so we can perform safe in-place UPDATE or INSERT
        // without triggering ON DELETE RESTRICT / CASCADE
        final existingIdRows = await db.query(table, columns: ['id']);
        final existingIds = <String>{
          for (final r in existingIdRows) r['id'] as String,
        };

        final totalToUpsert = validatedRows.length;
        final totalChunks =
            totalToUpsert == 0 ? 0 : ((totalToUpsert + chunkSize - 1) ~/ chunkSize);
        var insertedInTable = 0;
        var updatedInTable = 0;

        for (var chunkIdx = 0; chunkIdx < totalChunks; chunkIdx++) {
          final start = chunkIdx * chunkSize;
          final end = (start + chunkSize < totalToUpsert)
              ? (start + chunkSize)
              : totalToUpsert;
          final chunk = validatedRows.sublist(start, end);

          await db.transaction((txn) async {
            final batch = txn.batch();
            for (final r in chunk) {
              final rowId = r['id'] as String;
              if (existingIds.contains(rowId)) {
                batch.update(
                  table,
                  r,
                  where: 'id = ?',
                  whereArgs: [rowId],
                );
                updatedInTable++;
              } else {
                batch.insert(
                  table,
                  r,
                  conflictAlgorithm: ConflictAlgorithm.ignore,
                );
                existingIds.add(rowId);
                insertedInTable++;
              }
            }
            await batch.commit(noResult: true, continueOnError: false);
          });
          await Future<void>.delayed(Duration.zero);
        }

        tableResults[table] = TableImportResult(
          table: table,
          sourceFile: fileName,
          expectedCount: expectedCount,
          insertedCount: insertedInTable,
          updatedCount: updatedInTable,
          skippedCount: skippedInTable,
          chunkCount: totalChunks,
          errorCount: errors.length,
          skipped: false,
          errors: errors,
        );
      }

      // Post-import verification: verify protected tables have not lost a single row
      final postInspection = await _inspectDatabaseInternal(db, dbFilePath);
      for (final t in protectedTables) {
        final beforeCnt = preProtectedCounts[t] ?? 0;
        final afterCnt = postInspection.tableRowCounts[t] ?? 0;
        if (afterCnt != beforeCnt) {
          throw StateError(
            'Protected table $t row count changed during Prompt 6 import: before=$beforeCnt, after=$afterCnt',
          );
        }
      }

      final orphanCount = await _countOrphanRecordsInternal(db);
      final unclassifiedReadings = await _countUnclassifiedReadingMaterialsInternal(db);

      if (!postInspection.isHealthy || orphanCount > 0) {
        throw StateError(
          'Prompt 6 post-import verification failed: healthy=${postInspection.isHealthy}, orphans=$orphanCount',
        );
      }

      final markerPath = await resolveP6ImportMarkerFilePath();
      await File(markerPath).writeAsString(
        jsonEncode({
          'importedAt': DateTime.now().toIso8601String(),
          'databaseVersion': databaseVersion,
          'tableCounts': postInspection.tableRowCounts,
        }),
        flush: true,
      );

      return DatasetImportReport(
        executed: true,
        success: true,
        reason: 'Prompt 6 Listening & JLPT datasets imported non-destructively and verified.',
        chunkSize: chunkSize,
        tableResults: tableResults,
        orphanRecordCount: orphanCount,
        duplicateIdCount: totalDuplicateIds,
        unclassifiedReadingCount: unclassifiedReadings,
        postImportInspection: postInspection,
      );
    });
  }

  Future<int> countUnclassifiedReadingMaterials() async {
    return _runOperation((db) => _countUnclassifiedReadingMaterialsInternal(db));
  }

  Future<int> _countUnclassifiedReadingMaterialsInternal(Database db) async {
    return Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COUNT(*) FROM reading_materials WHERE original_level IS NULL',
          ),
        ) ??
        0;
  }

  /// Queries SQLite v2 and populates in-memory caches (`VocabularyData`, `KanjiData`,
  /// `GrammarData`, `ReadingMaterialData`, `JLPTTestData`, and playable `ListeningPracticeItem`s).
  static int _loadedListeningCount = 0;
  static bool _listeningCountInitialized = false;
  static List<ListeningPracticeItem> _loadedPlayableListeningItems =
      const <ListeningPracticeItem>[];

  static int get loadedListeningCount => _loadedListeningCount;
  static bool get listeningCountInitialized => _listeningCountInitialized;
  static List<ListeningPracticeItem> get loadedPlayableListeningItems =>
      _loadedPlayableListeningItems;

  static void setLoadedListeningCount(int count) {
    _loadedListeningCount = count;
    _listeningCountInitialized = true;
    if (count <= 0) {
      _loadedPlayableListeningItems = const <ListeningPracticeItem>[];
    }
  }

  static void setLoadedPlayableListeningItems(List<ListeningPracticeItem> items) {
    _loadedPlayableListeningItems = List<ListeningPracticeItem>.unmodifiable(items);
    _loadedListeningCount = items.length;
    _listeningCountInitialized = true;
  }

  static List<ListeningPracticeItem> getLoadedListeningItemsByLevel(String? level) {
    if (level == null || level.isEmpty || level == 'Tất cả' || level == 'All' || level == 'all') {
      return _loadedPlayableListeningItems;
    }
    return _loadedPlayableListeningItems
        .where((item) => item.estimatedLevel == level)
        .toList();
  }

  Future<void> loadVerifiedDatasetsIntoMemory() async {
    final vocabList = await getCachedVocabulary();
    VocabularyData.setLoadedWords(vocabList);

    final kanjiList = await getKanjiItemsFromDb();
    KanjiData.setLoadedKanji(kanjiList);

    final grammarList = await getGrammarLessonsFromDb();
    GrammarData.setLoadedLessons(grammarList);

    final readingList = await getReadingMaterialsFromDb();
    ReadingMaterialData.setLoadedMaterials(readingList);

    final testList = await getJlptTestsFromDb();
    JLPTTestData.setLoadedTests(testList);

    final playableItems = await getPlayableListeningItems();
    setLoadedPlayableListeningItems(playableItems);
  }

  Future<List<KanjiItem>> getKanjiItemsFromDb() async {
    return _runOperation((db) async {
      final rows = await db.query(
        'kanji_entries',
        orderBy: 'original_level ASC, stroke_count ASC, id ASC',
      );
      return rows.map((r) {
        return KanjiItem(
          id: r['id'] as String,
          kanji: r['character'] as String,
          onyomi: (r['onyomi'] as String?) ?? '',
          kunyomi: (r['kunyomi'] as String?) ?? '',
          vietnamese: (r['meaning_vi'] as String?) ?? '',
          english: (r['meaning_en'] as String?) ?? '',
          strokeCount: (r['stroke_count'] as int?) ?? 1,
          jlptLevel: (r['original_level'] as String?) ??
              (r['estimated_level'] as String?) ??
              'N5',
          radicalMeaning: (r['radical'] as String?) ?? '',
        );
      }).toList();
    });
  }

  Future<List<GrammarLesson>> getGrammarLessonsFromDb() async {
    return _runOperation((db) async {
      final gRows = await db.query(
        'grammar_points',
        orderBy: 'original_level DESC, id ASC',
      );
      final sRows = await db.query(
        'example_sentences',
        where: 'linked_grammar_id IS NOT NULL',
        orderBy: 'id ASC',
      );
      final examplesByGrammar = <String, List<ExampleSentence>>{};
      for (final s in sRows) {
        final gid = s['linked_grammar_id'] as String?;
        if (gid == null) continue;
        (examplesByGrammar[gid] ??= <ExampleSentence>[]).add(
          ExampleSentence(
            japanese: (s['sentence_jp'] as String?) ?? '',
            hiragana: (s['sentence_hiragana'] as String?) ??
                (s['sentence_furigana'] as String?) ??
                '',
            vietnamese: (s['translation_vi'] as String?) ?? '',
            english: (s['translation_en'] as String?) ?? '',
          ),
        );
      }

      return gRows.map((r) {
        final id = r['id'] as String;
        final titleVi = ContentFallback.cleanText(r['title_vi'] as String?);
        final titleEn = ContentFallback.cleanText(r['title_en'] as String?);
        final expVi = ContentFallback.cleanText(r['explanation_vi'] as String?);
        final expEn = ContentFallback.cleanText(r['explanation_en'] as String?);
        final formation = ContentFallback.cleanText(r['formation'] as String?);
        final rawNotes = ContentFallback.cleanText(r['notes'] as String?);
        final notesList = <String>[
          if (formation != null && formation.isNotEmpty) 'Cấu trúc: $formation',
          if (rawNotes != null && rawNotes.isNotEmpty) rawNotes,
        ];
        return GrammarLesson(
          id: id,
          pattern: (r['pattern'] as String?) ?? '',
          title: ContentFallback.resolveMeaning(
            meaningVi: titleVi,
            meaningEn: titleEn,
            language: 'vi',
          ),
          titleVi: titleVi,
          titleEn: titleEn,
          explanation: ContentFallback.resolveExplanation(
            explanationVi: expVi,
            explanationEn: expEn,
            language: 'vi',
          ),
          explanationVi: expVi,
          explanationEn: expEn,
          formation: formation,
          jlptLevel: (r['original_level'] as String?) ??
              (r['estimated_level'] as String?) ??
              'N5',
          examples: examplesByGrammar[id] ?? const <ExampleSentence>[],
          notes: notesList,
        );
      }).toList();
    });
  }

  Future<List<ReadingMaterial>> getReadingMaterialsFromDb() async {
    return _runOperation((db) async {
      final rows = await db.query(
        'reading_materials',
        orderBy: 'CASE WHEN original_level IS NULL THEN 1 ELSE 0 END ASC, original_level DESC, id ASC',
      );
      return rows.map((r) {
        final origLevel = ContentFallback.cleanText(r['original_level'] as String?);
        final titleJp = (r['title_jp'] as String?) ?? '';
        final titleVi = ContentFallback.cleanText(r['title_vi'] as String?);
        final titleEn = ContentFallback.cleanText(r['title_en'] as String?);
        final contentJp = (r['content_jp'] as String?) ?? '';
        final trVi = ContentFallback.cleanText(r['translation_vi'] as String?);
        final trEn = ContentFallback.cleanText(r['translation_en'] as String?);
        final rawSummary = ContentFallback.cleanText(r['summary'] as String?);
        final authorJp = ContentFallback.cleanText(r['author_jp'] as String?);
        final authorRomaji = ContentFallback.cleanText(r['author_romaji'] as String?);
        final sourceId = r['source_id'] as String?;
        final rawCat = (r['category'] as String?) ?? 'story';
        final uiCat = switch (rawCat) {
          'short_story' || 'literature' => 'Tiểu thuyết',
          'fairy_tale' => 'Cổ tích',
          _ => 'Đời sống',
        };
        final firstPara = contentJp.split('\n').firstWhere(
              (l) => l.trim().isNotEmpty,
              orElse: () => contentJp,
            );
        final previewText = firstPara.length > 120
            ? '${firstPara.substring(0, 120)}...'
            : firstPara;
        final levelLabel = ContentFallback.resolveJlptLevelLabel(
          origLevel,
          language: 'vi',
        );
        final tags = <String>[
          levelLabel,
          if (authorJp != null) authorJp,
          if (sourceId == 'src_aozora') 'Aozora Bunko',
          if (sourceId == 'src_hanabira') 'Hanabira CC BY 4.0',
        ];
        return ReadingMaterial(
          id: r['id'] as String,
          originalLevel: origLevel,
          level: levelLabel,
          category: uiCat,
          title: ContentFallback.resolveMeaning(
            meaningVi: titleVi,
            meaningEn: titleEn ?? titleJp,
            language: 'vi',
          ),
          titleVi: titleVi,
          titleEn: titleEn,
          japaneseTitle: titleJp,
          titleFurigana: ContentFallback.cleanText(r['title_furigana'] as String?),
          authorJp: authorJp,
          authorRomaji: authorRomaji,
          summary: rawSummary ??
              (authorJp != null ? 'Tác giả: $authorJp ($authorRomaji)' : previewText),
          preview: previewText,
          content: contentJp,
          translationVi: trVi,
          translationEn: trEn,
          contentRubyJson: r['content_ruby_json'] as String?,
          sourceId: sourceId,
          licenseId: r['license_id'] as String?,
          sourceUrl: r['source_url'] as String?,
          hasAudio: (r['has_audio'] as int? ?? 0) == 1,
          estimatedMinutes: (r['estimated_minutes'] as int?) ?? 5,
          tags: tags,
          isFeatured: true,
        );
      }).toList();
    });
  }

  Future<int> getListeningMaterialCount({
    String? level,
    bool playableOnly = true,
  }) async {
    return _runOperation((db) async {
      final whereParts = <String>[];
      final whereArgs = <Object?>[];
      if (playableOnly) {
        whereParts.add("category = 'available'");
        whereParts.add("audio_url LIKE 'assets/listening/%.wav'");
      }
      if (level != null &&
          level.isNotEmpty &&
          level != 'Tất cả' &&
          level != 'All' &&
          level != 'all') {
        whereParts.add('estimated_level = ?');
        whereArgs.add(level);
      }
      final whereClause =
          whereParts.isEmpty ? '' : 'WHERE ${whereParts.join(' AND ')}';
      return Sqflite.firstIntValue(
            await db.rawQuery(
              'SELECT COUNT(*) FROM listening_materials $whereClause',
              whereArgs,
            ),
          ) ??
          0;
    });
  }

  Future<int> getTotalListeningMaterialCount() async {
    return getListeningMaterialCount(playableOnly: false);
  }

  Future<List<ListeningPracticeItem>> getPlayableListeningItems({
    String? level,
  }) async {
    return _runOperation((db) async {
      final whereParts = <String>[
        "lm.category = 'available'",
        "lm.audio_url LIKE 'assets/listening/%.wav'",
      ];
      final whereArgs = <Object?>[];
      if (level != null &&
          level.isNotEmpty &&
          level != 'Tất cả' &&
          level != 'All' &&
          level != 'all') {
        whereParts.add('lm.estimated_level = ?');
        whereArgs.add(level);
      }

      final lmRows = await db.rawQuery('''
        SELECT
          lm.id,
          lm.source_id,
          lm.external_clip_id,
          lm.title,
          lm.category,
          lm.audio_url,
          lm.duration_ms,
          lm.sample_rate,
          lm.speaker_name,
          lm.estimated_level,
          lm.is_level_estimated,
          lm.estimation_basis,
          tr.text_jp,
          tr.text_furigana_reading,
          tr.translation_en
        FROM listening_materials lm
        INNER JOIN transcripts tr ON tr.listening_material_id = lm.id
        WHERE ${whereParts.join(' AND ')}
        ORDER BY lm.estimated_level DESC, lm.id ASC
      ''', whereArgs);

      if (lmRows.isEmpty) {
        return const <ListeningPracticeItem>[];
      }

      final items = <ListeningPracticeItem>[];
      for (final row in lmRows) {
        final lmId = row['id'] as String;
        final estBasisRaw = (row['estimation_basis'] as String?) ?? '{}';
        Map<String, dynamic> estMeta = const <String, dynamic>{};
        try {
          final parsed = jsonDecode(estBasisRaw);
          if (parsed is Map<String, dynamic>) {
            estMeta = parsed;
          }
        } catch (_) {}

        final qRows = await db.query(
          'questions',
          where: 'listening_material_id = ?',
          whereArgs: [lmId],
          orderBy: 'id ASC',
          limit: 1,
        );

        String? qId;
        var promptVi =
            'Nghe đoạn ghi âm và chọn câu tiếng Nhật khớp chính xác với nội dung vừa nghe:';
        var promptJp = '音声を聞いて、話されている内容と一致するものを選んでください。';
        var options = <String>[];
        var correctIdx = 0;
        var explanation = '';

        if (qRows.isNotEmpty) {
          final q = qRows.first;
          qId = q['id'] as String;
          promptVi = (q['prompt_text_vi'] as String?) ?? promptVi;
          promptJp = (q['prompt_text_jp'] as String?) ?? promptJp;
          explanation = ContentFallback.resolveExplanation(
            explanationVi: q['explanation_vi'] as String?,
            explanationEn: q['explanation_en'] as String?,
            language: 'vi',
          );
          final aRows = await db.query(
            'answers',
            where: 'question_id = ?',
            whereArgs: [qId],
            orderBy: 'option_index ASC',
          );
          options = aRows
              .map((a) => (a['content_text'] as String?) ?? '')
              .where((s) => s.isNotEmpty)
              .toList();
          final foundIdx =
              aRows.indexWhere((a) => (a['is_correct'] as int? ?? 0) == 1);
          correctIdx = foundIdx < 0 ? 0 : foundIdx;
        }

        final transcriptNorm = (row['text_jp'] as String?) ?? '';
        final transcriptOrig =
            (row['translation_en'] as String?) ?? transcriptNorm;
        final reading = (row['text_furigana_reading'] as String?) ?? '';

        if (options.isEmpty && transcriptNorm.isNotEmpty) {
          options = <String>[transcriptNorm];
          correctIdx = 0;
        }

        items.add(
          ListeningPracticeItem(
            id: lmId,
            sourceId: (row['source_id'] as String?) ?? 'src_kokoro_tiny',
            externalClipId: (row['external_clip_id'] as String?) ?? lmId,
            title: (row['title'] as String?) ?? lmId,
            audioPath: (row['audio_url'] as String?) ?? '',
            audioStatus: (row['category'] as String?) ?? 'available',
            durationMs: (row['duration_ms'] as int?) ?? 0,
            sampleRate: (row['sample_rate'] as int?) ?? 22050,
            speakerName:
                (row['speaker_name'] as String?) ?? 'ekzemplaro (LibriVox)',
            estimatedLevel: row['estimated_level'] as String?,
            levelSource: (estMeta['level_source'] as String?) ?? 'estimated',
            difficultyScore:
                (estMeta['difficulty_score'] as num?)?.toDouble() ?? 0.0,
            classificationConfidence:
                (estMeta['classification_confidence'] as num?)?.toDouble() ??
                    0.0,
            classificationReason:
                (estMeta['classification_reason'] as String?) ?? '',
            needsReview: (estMeta['needs_review'] as bool?) ?? false,
            transcriptNormalized: transcriptNorm,
            transcriptOriginal: transcriptOrig,
            reading: reading,
            questionId: qId,
            promptVi: promptVi,
            promptJp: promptJp,
            options: options,
            correctIndex: correctIdx,
            explanation: explanation,
          ),
        );
      }

      return items;
    });
  }

  Future<List<JLPTTest>> getJlptTestsFromDb() async {
    return _runOperation((db) async {
      final examRows = await db.query('exams', orderBy: 'id ASC');
      if (examRows.isEmpty) {
        return const <JLPTTest>[];
      }
      final tests = <JLPTTest>[];
      for (final exam in examRows) {
        final examId = exam['id'] as String;
        final examLevel = (exam['original_level'] as String?) ?? 'N5';
        final qRows = await db.query(
          'questions',
          where: 'exam_id = ?',
          whereArgs: [examId],
          orderBy: 'id ASC',
        );
        if (qRows.isEmpty) continue;
        final quizQuestions = <QuizQuestion>[];
        for (final q in qRows) {
          final qId = q['id'] as String;
          final aRows = await db.query(
            'answers',
            where: 'question_id = ?',
            whereArgs: [qId],
            orderBy: 'option_index ASC',
          );
          if (aRows.isEmpty) continue;
          final options = aRows.map((a) => (a['content_text'] as String?) ?? '').toList();
          final correctIdx = aRows.indexWhere((a) => (a['is_correct'] as int? ?? 0) == 1);
          final rawType = ((q['question_type'] as String?) ?? 'vocab').toLowerCase();
          final questionType = switch (rawType) {
            'kanji' => QuestionType.kanjiMeaning,
            'grammar' => QuestionType.grammar,
            'reading' => QuestionType.reading,
            'listening' => QuestionType.listening,
            _ => QuestionType.vocabularyMeaning,
          };
          final qLvl = (q['original_level'] as String?) ?? examLevel;
          final mondaiCode = (q['mondai_code'] as String?) ?? '';
          final secLabel = switch (rawType) {
            'grammar' => 'Ngữ pháp (文法)',
            'reading' => 'Đọc hiểu (読解)',
            'listening' => 'Nghe hiểu (聴解)',
            _ => 'Từ vựng (文字・語彙)',
          };
          final srcId = (exam['source_id'] as String?) ?? 'official_exam';
          final isAi = ((exam['is_ai_generated'] as int?) ?? 0) == 1;
          final isFb = !isAi && srcId == 'src_sqlite_backup';
          final promptViRaw = (q['prompt_text_vi'] as String?)?.trim() ?? '';
          final headerLine = (isAi || isFb) && promptViRaw.isNotEmpty
              ? promptViRaw
              : 'Cấp độ chính thức: $qLvl (official_exam) • $secLabel${mondaiCode.isNotEmpty ? ' • $mondaiCode' : ''}';
          quizQuestions.add(
            QuizQuestion(
              id: qId,
              question: headerLine,
              questionJp: (q['prompt_text_jp'] as String?) ?? '',
              options: options,
              correctIndex: correctIdx < 0 ? 0 : correctIdx,
              explanation: ContentFallback.resolveExplanation(
                explanationVi: q['explanation_vi'] as String?,
                explanationEn: q['explanation_en'] as String?,
                language: 'vi',
              ),
              jlptLevel: qLvl,
              type: questionType,
            ),
          );
        }
        if (quizQuestions.isNotEmpty) {
          final srcId = (exam['source_id'] as String?) ?? 'official_exam';
          final isAi = ((exam['is_ai_generated'] as int?) ?? 0) == 1;
          final isFb = !isAi && srcId == 'src_sqlite_backup';
          final passage = exam['reading_passage'] as String?;
          tests.add(
            JLPTTest(
              id: examId,
              level: examLevel,
              title: (exam['title'] as String?) ?? '',
              timeMinutes: (exam['time_limit_minutes'] as int?) ?? 20,
              questions: quizQuestions,
              isAiGenerated: isAi,
              isFallback: isFb,
              sourceId: srcId,
              readingPassage: passage,
            ),
          );
        }
      }
      return tests;
    });
  }

  /// Persists an AI-generated (`src_gemini_rag`, `is_ai_generated = 1`) or
  /// offline SQLite fallback (`src_sqlite_backup`, `is_ai_generated = 0`) exam
  /// into SQLite (`exams`, `questions`, `answers`) while preserving foreign key integrity.
  Future<void> saveGeneratedExamToDb(JLPTTest test) async {
    if (kIsWeb || _isResetting) return;
    return _runOperation((db) async {
      await migrateToV3(db);
      final nowIso = DateTime.now().toIso8601String();
      final sourceId = test.isAiGenerated
          ? 'src_gemini_rag'
          : (test.isFallback ? 'src_sqlite_backup' : test.sourceId);
      const licenseId = 'lic_cc_by_sa_4_0';

      await db.transaction((txn) async {
        await txn.insert(
          'licenses',
          <String, Object?>{
            'id': licenseId,
            'code': 'CC BY-SA 4.0',
            'name': 'Creative Commons Attribution-ShareAlike 4.0 International',
            'license_url': 'https://creativecommons.org/licenses/by-sa/4.0/',
            'allow_redistribution': 1,
            'allow_modification': 1,
            'require_attribution': 1,
            'require_share_alike': 1,
            'notes': 'Used by OpenJLPT and internal RAG/Fallback exam generator.',
          },
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );

        await txn.insert(
          'data_sources',
          <String, Object?>{
            'id': 'src_gemini_rag',
            'name': 'Gemini RAG Engine (Google Generative AI + OpenJLPT)',
            'source_url': 'https://ai.google.dev/gemini-api',
            'license_id': licenseId,
            'attribution_text':
                'Generated via Gemini RAG Engine using verified OpenJLPT vocabulary & grammar.',
            'upstream_credits': 'Google Gemini Flash + OpenJLPT',
            'version_or_commit': 'phase3-rag',
            'fetched_at': nowIso,
          },
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );

        await txn.insert(
          'data_sources',
          <String, Object?>{
            'id': 'src_sqlite_backup',
            'name': 'SQLite Verified Offline Fallback Pool',
            'source_url': 'sqlite://verified_v2/fallback',
            'license_id': licenseId,
            'attribution_text':
                'Synthesized offline from verified local SQLite JLPT dataset when AI endpoint is unavailable.',
            'upstream_credits': 'OpenJLPT / 5Mcv4He jlpt-freq',
            'version_or_commit': 'phase3-fallback',
            'fetched_at': nowIso,
          },
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );

        await txn.insert(
          'exams',
          <String, Object?>{
            'id': test.id,
            'source_id': sourceId,
            'license_id': licenseId,
            'source_url': test.isAiGenerated
                ? 'https://ai.google.dev/gemini-api'
                : 'sqlite://verified_v2/fallback',
            'title': test.title,
            'exam_type': test.isAiGenerated ? 'ai_rag_exam' : 'sqlite_fallback_exam',
            'delivery_mode': 'in_app',
            'original_level': test.level,
            'estimated_level': test.level,
            'is_level_estimated': 0,
            'time_limit_minutes': test.timeMinutes,
            'total_questions': test.questions.length,
            'description': test.readingPassage ?? test.title,
            'created_at': nowIso,
            'is_ai_generated': test.isAiGenerated ? 1 : 0,
            'reading_passage': test.readingPassage,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );

        for (final q in test.questions) {
          final qTypeStr = switch (q.type) {
            QuestionType.grammar => 'grammar',
            QuestionType.reading => 'reading',
            QuestionType.listening => 'listening',
            QuestionType.kanjiMeaning || QuestionType.kanjiReading => 'kanji',
            _ => 'vocab',
          };
          await txn.insert(
            'questions',
            <String, Object?>{
              'id': q.id,
              'exam_id': test.id,
              'source_id': sourceId,
              'license_id': licenseId,
              'source_url': test.isAiGenerated
                  ? 'https://ai.google.dev/gemini-api'
                  : 'sqlite://verified_v2/fallback',
              'question_type': qTypeStr,
              'mondai_code': test.isAiGenerated ? 'AI_RAG' : 'SQLITE_FALLBACK',
              'prompt_text_vi': q.question,
              'prompt_text_jp': q.questionJp,
              'explanation_vi': q.explanation,
              'explanation_en': q.explanation,
              'original_level': test.level,
              'estimated_level': test.level,
              'is_level_estimated': 0,
              'created_at': nowIso,
            },
            conflictAlgorithm: ConflictAlgorithm.replace,
          );

          for (var i = 0; i < q.options.length; i++) {
            await txn.insert(
              'answers',
              <String, Object?>{
                'id': '${q.id}_opt_$i',
                'question_id': q.id,
                'option_index': i,
                'content_text': q.options[i],
                'is_correct': i == q.correctIndex ? 1 : 0,
                'option_explanation': i == q.correctIndex ? q.explanation : null,
              },
              conflictAlgorithm: ConflictAlgorithm.replace,
            );
          }
        }
      });
    });
  }
}
