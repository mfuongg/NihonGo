import 'package:flutter/material.dart';

import '../utils/theme.dart';

class CozyAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final Widget? titleWidget;
  final String? subtitle;
  final bool allowBack;
  final VoidCallback? onBack;
  final Widget? leading;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;
  final bool centerTitle;
  final Color? backgroundColor;
  final bool showBottomBorder;

  const CozyAppBar({
    super.key,
    this.title,
    this.titleWidget,
    this.subtitle,
    this.allowBack = true,
    this.onBack,
    this.leading,
    this.actions,
    this.bottom,
    this.centerTitle = false,
    this.backgroundColor,
    this.showBottomBorder = false,
  });

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0),
      );

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final routeCanPop =
        ModalRoute.of(context)?.canPop ?? Navigator.of(context).canPop();
    final shouldShowBack = allowBack && routeCanPop;

    Widget? resolvedLeading = leading;
    if (resolvedLeading == null && shouldShowBack) {
      resolvedLeading = IconButton(
        key: const Key('cozy_app_bar_back_button'),
        tooltip: 'Quay lại',
        onPressed: onBack ?? () => Navigator.of(context).maybePop(),
        icon: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: cozy.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: cozy.borderSubtle),
          ),
          child: Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 16,
            color: cozy.textPrimary,
          ),
        ),
      );
    }

    Widget? resolvedTitle = titleWidget;
    if (resolvedTitle == null && title != null) {
      if (subtitle != null && subtitle!.isNotEmpty) {
        resolvedTitle = Column(
          crossAxisAlignment: centerTitle
              ? CrossAxisAlignment.center
              : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title!,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: cozy.textPrimary,
              ),
            ),
            Text(
              subtitle!,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: cozy.textSecondary,
              ),
            ),
          ],
        );
      } else {
        resolvedTitle = Text(
          title!,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: cozy.textPrimary,
          ),
        );
      }
    }

    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: backgroundColor ?? cozy.background,
      foregroundColor: cozy.textPrimary,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: centerTitle,
      leading: resolvedLeading,
      title: resolvedTitle,
      actions: actions,
      bottom: bottom ??
          (showBottomBorder
              ? PreferredSize(
                  preferredSize: const Size.fromHeight(1),
                  child: Divider(
                    height: 1,
                    thickness: 1,
                    color: cozy.borderSubtle,
                  ),
                )
              : null),
    );
  }
}

class CozyScaffold extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget body;
  final Widget? floatingActionButton;
  final Widget? bottomNavigationBar;
  final Color? backgroundColor;
  final bool resizeToAvoidBottomInset;

  const CozyScaffold({
    super.key,
    this.appBar,
    required this.body,
    this.floatingActionButton,
    this.bottomNavigationBar,
    this.backgroundColor,
    this.resizeToAvoidBottomInset = true,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Scaffold(
      backgroundColor: backgroundColor ?? cozy.background,
      appBar: appBar,
      body: body,
      floatingActionButton: floatingActionButton,
      bottomNavigationBar: bottomNavigationBar,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
    );
  }
}

class CozySurfaceCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Color? borderColor;
  final double borderRadius;

  const CozySurfaceCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.onTap,
    this.backgroundColor,
    this.borderColor,
    this.borderRadius = 20,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final card = Container(
      margin: margin,
      decoration: BoxDecoration(
        color: backgroundColor ?? cozy.surface,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: borderColor ?? cozy.borderSubtle,
          width: 1,
        ),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(borderRadius),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(borderRadius),
          child: Padding(
            padding: padding,
            child: child,
          ),
        ),
      ),
    );
    return card;
  }
}

class CozySectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData? icon;
  final String? actionLabel;
  final VoidCallback? onActionTap;

  const CozySectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.actionLabel,
    this.onActionTap,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            if (icon != null) ...[
              Icon(icon, size: 18, color: cozy.primary),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: cozy.textPrimary,
                ),
              ),
            ),
            if (actionLabel != null)
              TextButton(
                onPressed: onActionTap,
                style: TextButton.styleFrom(
                  foregroundColor: cozy.primary,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  minimumSize: const Size(44, 36),
                ),
                child: Text(
                  actionLabel!,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
        if (subtitle != null && subtitle!.isNotEmpty) ...[
          const SizedBox(height: 2),
          Text(
            subtitle!,
            style: TextStyle(
              fontSize: 12.5,
              color: cozy.textSecondary,
            ),
          ),
        ],
      ],
    );
  }
}

class CozyTagChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final bool useAccentStyle;
  final VoidCallback? onTap;

  const CozyTagChip({
    super.key,
    required this.label,
    this.isSelected = false,
    this.useAccentStyle = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final bgColor = useAccentStyle
        ? cozy.accent
        : (isSelected ? cozy.primary : cozy.surface);
    final fgColor = (useAccentStyle || isSelected)
        ? cozy.onPrimary
        : cozy.textPrimary;
    final borderColor = useAccentStyle
        ? cozy.accent
        : (isSelected
            ? cozy.primary
            : cozy.primary.withValues(alpha: 0.24));

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          constraints: const BoxConstraints(minHeight: 36, minWidth: 48),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: borderColor, width: 1),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: (isSelected || useAccentStyle)
                  ? FontWeight.w700
                  : FontWeight.w500,
              color: fgColor,
            ),
          ),
        ),
      ),
    );
  }
}

class CozyResourcePill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? iconColor;
  final VoidCallback? onTap;

  const CozyResourcePill({
    super.key,
    required this.icon,
    required this.label,
    this.iconColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: cozy.surface,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: cozy.primary.withValues(alpha: 0.20)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 15, color: iconColor ?? cozy.primary),
            const SizedBox(width: 5),
            Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: cozy.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CozyFeedbackBanner extends StatelessWidget {
  final bool isCorrect;
  final String title;
  final String message;
  final VoidCallback? onRetry;

  const CozyFeedbackBanner({
    super.key,
    required this.isCorrect,
    required this.title,
    required this.message,
    this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final tone = isCorrect ? cozy.success : cozy.error;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tone.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: tone.withValues(alpha: 0.45), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: tone,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isCorrect ? Icons.check_rounded : Icons.close_rounded,
                  size: 16,
                  color: cozy.onPrimary,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: cozy.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      message,
                      style: TextStyle(
                        fontSize: 13,
                        color: cozy.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (onRetry != null) ...[
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.center,
              child: OutlinedButton.icon(
                onPressed: onRetry,
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(120, 36),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  side: BorderSide(color: tone.withValues(alpha: 0.6)),
                  foregroundColor: cozy.textPrimary,
                ),
                icon: const Icon(Icons.refresh_rounded, size: 16),
                label: const Text('Thử lại', style: TextStyle(fontSize: 12.5)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class CozyPlaceholderBox extends StatelessWidget {
  final String label;
  final IconData icon;
  final double height;
  final double? width;
  final double borderRadius;

  const CozyPlaceholderBox({
    super.key,
    required this.label,
    this.icon = Icons.image_outlined,
    this.height = 110,
    this.width,
    this.borderRadius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Container(
      width: width ?? double.infinity,
      height: height,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cozy.surfaceSoft,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: cozy.primary.withValues(alpha: 0.22),
          width: 1,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 26, color: cozy.textSecondary),
          const SizedBox(height: 6),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: cozy.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
