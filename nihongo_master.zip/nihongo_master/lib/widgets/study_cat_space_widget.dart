import 'dart:async';
import 'package:flutter/material.dart';

import '../utils/theme.dart';

/// All animation states supported by Nihongo Master cats (mapped to the 5 base webp assets).
enum CatAnimationState {
  idle('idle', 'Nghỉ ngơi (Idle)', false),
  blink('blink', 'Chớp mắt', false),
  happy('happy', 'Vui vẻ', false),
  thinking('thinking', 'Tò mò', false),
  sleep('sleep', 'Ngủ gật', false),
  studyStart('happy', 'Bắt đầu học', true),
  studyIdle('idle', 'Ngồi học', true),
  studyRead('thinking', 'Đọc sách', true),
  studyWrite('thinking', 'Viết bài', true),
  studyThink('thinking', 'Suy nghĩ', true),
  studyFinish('happy', 'Hoàn thành', true);

  final String assetKey;
  final String label;
  final bool isStudyState;

  const CatAnimationState(this.assetKey, this.label, this.isStudyState);
}

class CatCharacterInfo {
  final String id;
  final String name;

  const CatCharacterInfo({required this.id, required this.name});
}

/// Complete catalog: 5 representative Group A cats.
const List<CatCharacterInfo> kNihongoMasterCats = [
  CatCharacterInfo(id: 'img_6883', name: 'Chiến Thần Hào Quang'),
  CatCharacterInfo(id: 'img_6831_2', name: 'Hắc Miêu Mắt Lờ Đờ'),
  CatCharacterInfo(id: 'img_6832_2', name: 'Hổ Báo Mẫu Giáo'),
  CatCharacterInfo(id: 'img_6839_2', name: 'Đàn Anh Socola'),
  CatCharacterInfo(id: 'img_6836_2', name: 'Ma Vương Khoai Môn'),
];

/// Singleton controller ensuring that cat study state, study progress, and
/// screen position are 100% independent of each other and persist across tabs.
class StudyCatController extends ChangeNotifier {
  StudyCatController._() {
    _startProgressTicker();
  }

  static final StudyCatController instance = StudyCatController._();

  CatCharacterInfo _selectedCat = kNihongoMasterCats.first;
  CatAnimationState _currentState = CatAnimationState.studyWrite;
  bool _isStudying = true;
  int _studyElapsedSeconds = 420; // Starts with 7 mins sample progress
  final int _studyTargetSeconds = 1500; // 25 mins Pomodoro target
  bool _floatingOnScreen = true;

  /// Position inside the Study Space Card (independent from desk position).
  Offset _roomCatPosition = const Offset(135, 58);

  /// Position when floating freely across the screen (including near bottom nav bar).
  Offset? _screenCatPosition;

  Timer? _transitionTimer;
  Timer? _progressTimer;

  CatCharacterInfo get selectedCat => _selectedCat;
  CatAnimationState get currentState => _currentState;
  bool get isStudying => _isStudying;
  int get studyElapsedSeconds => _studyElapsedSeconds;
  int get studyTargetSeconds => _studyTargetSeconds;
  bool get floatingOnScreen => _floatingOnScreen;
  Offset get roomCatPosition => _roomCatPosition;
  Offset? get screenCatPosition => _screenCatPosition;

  double get studyProgress =>
      (_studyElapsedSeconds / _studyTargetSeconds).clamp(0.0, 1.0);

  String get formattedStudyTime {
    final m = (_studyElapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (_studyElapsedSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String get currentWebpAssetPath =>
      'assets/study/cats/${_selectedCat.id}/${_currentState.assetKey}.webp';

  void _startProgressTicker() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_isStudying &&
          _currentState != CatAnimationState.studyFinish &&
          _studyElapsedSeconds < _studyTargetSeconds) {
        _studyElapsedSeconds++;
        notifyListeners();
      }
    });
  }

  void selectCat(CatCharacterInfo cat) {
    if (_selectedCat.id == cat.id) return;
    _selectedCat = cat;
    notifyListeners();
  }

  void toggleFloatingOnScreen(bool value) {
    _floatingOnScreen = value;
    notifyListeners();
  }

  /// Updates ONLY the cat's position inside the room container.
  /// Never cancels study state, never resets study progress, never snaps to desk.
  void updateRoomCatPosition(Offset delta, Size containerSize, double catSize) {
    final maxX = (containerSize.width - catSize).clamp(0.0, double.infinity);
    final maxY = (containerSize.height - catSize).clamp(0.0, double.infinity);
    _roomCatPosition = Offset(
      (_roomCatPosition.dx + delta.dx).clamp(0.0, maxX),
      (_roomCatPosition.dy + delta.dy).clamp(0.0, maxY),
    );
    notifyListeners();
  }

  /// Updates ONLY the cat's global screen position (including near the bottom navigation bar).
  /// Never cancels study state, never resets study progress, never snaps to desk.
  void updateScreenCatPosition(Offset delta, Size screenSize, double catSize) {
    final current = _screenCatPosition ??
        Offset(screenSize.width - catSize - 16, screenSize.height - catSize - 12);
    final maxX = (screenSize.width - catSize).clamp(0.0, double.infinity);
    final maxY = (screenSize.height - catSize).clamp(0.0, double.infinity);
    _screenCatPosition = Offset(
      (current.dx + delta.dx).clamp(0.0, maxX),
      (current.dy + delta.dy).clamp(0.0, maxY),
    );
    notifyListeners();
  }

  /// Starts study sequence: `study_start` -> `study_idle` without moving the cat.
  void startStudy() {
    _transitionTimer?.cancel();
    _isStudying = true;
    _currentState = CatAnimationState.studyStart;
    notifyListeners();

    _transitionTimer = Timer(const Duration(milliseconds: 1600), () {
      if (_isStudying && _currentState == CatAnimationState.studyStart) {
        _currentState = CatAnimationState.studyIdle;
        notifyListeners();
      }
    });
  }

  /// Switches to any specific study or base animation state without modifying cat position or progress.
  void setAnimationState(CatAnimationState state) {
    _transitionTimer?.cancel();
    if (state == CatAnimationState.studyStart) {
      startStudy();
      return;
    }
    if (state == CatAnimationState.studyFinish) {
      finishStudy();
      return;
    }
    _currentState = state;
    _isStudying = state.isStudyState;
    notifyListeners();
  }

  /// Finishes study activity: plays `study_finish` then returns to `idle` while keeping cat position.
  void finishStudy() {
    _transitionTimer?.cancel();
    _currentState = CatAnimationState.studyFinish;
    _isStudying = false;
    notifyListeners();

    _transitionTimer = Timer(const Duration(milliseconds: 1800), () {
      if (_currentState == CatAnimationState.studyFinish) {
        _currentState = CatAnimationState.idle;
        notifyListeners();
      }
    });
  }
}

/// Interactive Study Space Card used in GuardianCatScreen.
/// Displays independent furniture & study props and allows dragging the cat anywhere.
class StudyCatSpaceView extends StatelessWidget {
  const StudyCatSpaceView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: StudyCatController.instance,
      builder: (context, _) {
        final ctrl = StudyCatController.instance;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top bar: Character selector & Floating screen overlay toggle
            Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.background,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: ctrl.selectedCat.id,
                        isExpanded: true,
                        isDense: true,
                        icon: Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: AppTheme.primary,
                        ),
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary,
                        ),
                        items: kNihongoMasterCats
                            .map(
                              (c) => DropdownMenuItem<String>(
                                value: c.id,
                                child: Text(
                                  '${c.name} (${c.id.toUpperCase()})',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (val) {
                          if (val == null) return;
                          final found = kNihongoMasterCats.firstWhere(
                            (e) => e.id == val,
                            orElse: () => kNihongoMasterCats.first,
                          );
                          ctrl.selectCat(found);
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilterChip(
                  selected: ctrl.floatingOnScreen,
                  onSelected: ctrl.toggleFloatingOnScreen,
                  label: const Text(
                    'Nổi toàn màn hình',
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600),
                  ),
                  selectedColor: AppTheme.primary.withValues(alpha: 0.18),
                  checkmarkColor: AppTheme.primary,
                  side: BorderSide(color: AppTheme.borderSubtle),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Interactive Study Room Canvas (Furniture & Props are independent from Cat position)
            SizedBox(
              height: 270,
              width: double.infinity,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final boxSize = Size(constraints.maxWidth, constraints.maxHeight);
                  const double catSize = 152.0;

                  return Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFFFFF9F2),
                          Color(0xFFF7EADF),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          // Subtle floor baseboard line
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 0,
                            height: 78,
                            child: Container(
                              decoration: const BoxDecoration(
                                color: Color(0xFFEEDBCA),
                                border: Border(
                                  top: BorderSide(
                                    color: Color(0xFFD8BEAA),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          // Independent Prop 1: Mini Board on the wall (top-left)
                          Positioned(
                            left: 18,
                            top: 16,
                            width: 112,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/items/mini_board.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Independent Furniture 1: Mini Bookshelf (left side)
                          Positioned(
                            left: 14,
                            bottom: 42,
                            width: 108,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/furniture/mini_bookshelf.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Independent Furniture 2: Study Chair Cushion (center-right)
                          Positioned(
                            left: boxSize.width * 0.44,
                            bottom: 34,
                            width: 118,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/furniture/study_chair.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Independent Furniture 3: Study Desk (decorative prop, does NOT lock cat)
                          Positioned(
                            left: boxSize.width * 0.36,
                            bottom: 12,
                            width: 195,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/furniture/study_desk.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Independent Furniture 4: Desk Lamp
                          Positioned(
                            right: 22,
                            bottom: 54,
                            width: 82,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/furniture/desk_lamp.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Independent Study Items on floor/desk corner (study_book, flashcards, kanji_card)
                          Positioned(
                            right: 16,
                            bottom: 14,
                            width: 58,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/items/study_book.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 76,
                            bottom: 14,
                            width: 56,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/items/flashcard.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 116,
                            bottom: 14,
                            width: 48,
                            child: IgnorePointer(
                              child: Image.asset(
                                'assets/study/items/kanji_card.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          // Status & Study Progress Pill (top-right)
                          Positioned(
                            top: 10,
                            right: 10,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.90),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: AppTheme.borderSubtle),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    ctrl.isStudying
                                        ? Icons.menu_book_rounded
                                        : Icons.pets_rounded,
                                    size: 14,
                                    color: AppTheme.primary,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${ctrl.currentState.label} · ${ctrl.formattedStudyTime}',
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // Hint banner (bottom-left)
                          Positioned(
                            left: 10,
                            bottom: 6,
                            child: IgnorePointer(
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 3,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.80),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'Kéo mèo tự do tới mọi vị trí (không hủy trạng thái học)',
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          // Freely Draggable Cat Layer (100% independent of desk & preserves study state!)
                          Positioned(
                            left: ctrl.roomCatPosition.dx.clamp(
                              0.0,
                              (boxSize.width - catSize).clamp(0.0, double.infinity),
                            ),
                            top: ctrl.roomCatPosition.dy.clamp(
                              0.0,
                              (boxSize.height - catSize).clamp(0.0, double.infinity),
                            ),
                            width: catSize,
                            height: catSize,
                            child: GestureDetector(
                              behavior: HitTestBehavior.translucent,
                              onPanUpdate: (details) {
                                ctrl.updateRoomCatPosition(
                                  details.delta,
                                  boxSize,
                                  catSize,
                                );
                              },
                              child: MouseRegion(
                                cursor: SystemMouseCursors.grab,
                                child: Image.asset(
                                  ctrl.currentWebpAssetPath,
                                  key: ValueKey(ctrl.currentWebpAssetPath),
                                  fit: BoxFit.contain,
                                  gaplessPlayback: true,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),

            // 6 Study Animation State Selector Chips + Base States
            Text(
              'Trạng thái học tập của mèo (Độc lập với vị trí kéo thả):',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                CatAnimationState.studyStart,
                CatAnimationState.studyIdle,
                CatAnimationState.studyRead,
                CatAnimationState.studyWrite,
                CatAnimationState.studyThink,
                CatAnimationState.studyFinish,
                CatAnimationState.idle,
                CatAnimationState.happy,
                CatAnimationState.sleep,
              ].map((st) {
                final isSelected = ctrl.currentState == st;
                return ChoiceChip(
                  label: Text(
                    st.label,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      color: isSelected ? Colors.white : AppTheme.textPrimary,
                    ),
                  ),
                  selected: isSelected,
                  selectedColor: AppTheme.primary,
                  backgroundColor: AppTheme.background,
                  side: BorderSide(
                    color: isSelected ? AppTheme.primary : AppTheme.borderSubtle,
                  ),
                  onSelected: (_) => ctrl.setAnimationState(st),
                );
              }).toList(),
            ),
          ],
        );
      },
    );
  }
}

/// Screen-wide Floating Draggable Studying Cat Overlay.
/// Can be dragged to ANY valid position on screen, including right near the bottom navigation bar,
/// without interrupting or resetting the active study state or progress.
class DraggableFloatingStudyCatOverlay extends StatelessWidget {
  const DraggableFloatingStudyCatOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: StudyCatController.instance,
      builder: (context, _) {
        final ctrl = StudyCatController.instance;
        if (!ctrl.floatingOnScreen) {
          return const SizedBox.shrink();
        }

        return LayoutBuilder(
          builder: (context, constraints) {
            final screenSize = Size(constraints.maxWidth, constraints.maxHeight);
            const double catWidgetSize = 118.0;
            final pos = ctrl.screenCatPosition ??
                Offset(
                  (screenSize.width - catWidgetSize - 14).clamp(0.0, double.infinity),
                  (screenSize.height - catWidgetSize - 8).clamp(0.0, double.infinity),
                );

            final clampedX = pos.dx.clamp(
              0.0,
              (screenSize.width - catWidgetSize).clamp(0.0, double.infinity),
            );
            final clampedY = pos.dy.clamp(
              0.0,
              (screenSize.height - catWidgetSize).clamp(0.0, double.infinity),
            );

            return Stack(
              children: [
                Positioned(
                  left: clampedX,
                  top: clampedY,
                  width: catWidgetSize,
                  height: catWidgetSize + 24,
                  child: GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onPanUpdate: (details) {
                      ctrl.updateScreenCatPosition(
                        details.delta,
                        screenSize,
                        catWidgetSize,
                      );
                    },
                    onTap: () {
                      // Cycle through study_idle -> study_read -> study_write -> study_think on tap without resetting progress
                      final nextMap = {
                        CatAnimationState.studyIdle: CatAnimationState.studyRead,
                        CatAnimationState.studyRead: CatAnimationState.studyWrite,
                        CatAnimationState.studyWrite: CatAnimationState.studyThink,
                        CatAnimationState.studyThink: CatAnimationState.studyIdle,
                      };
                      final next =
                          nextMap[ctrl.currentState] ?? CatAnimationState.studyWrite;
                      ctrl.setAnimationState(next);
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.surface.withValues(alpha: 0.92),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: AppTheme.borderSubtle),
                            boxShadow: AppTheme.softCardShadow,
                          ),
                          child: Text(
                            '${ctrl.selectedCat.name} · ${ctrl.currentState.label}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textPrimary,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Image.asset(
                            ctrl.currentWebpAssetPath,
                            key: ValueKey('overlay_${ctrl.currentWebpAssetPath}'),
                            fit: BoxFit.contain,
                            gaplessPlayback: true,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
