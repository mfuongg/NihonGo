import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/theme.dart';

/// Hộp thư giả lập dùng khi chạy chế độ Local/Demo (Firebase chưa sẵn sàng),
/// hiển thị mã OTP để kiểm thử luồng quên mật khẩu.
class MockEmailDialog extends StatelessWidget {
  final String email;
  final String otp;

  const MockEmailDialog({super.key, required this.email, required this.otp});

  static Future<void> show(BuildContext context, {required String email, required String otp}) {
    return showDialog<void>(
      context: context,
      builder: (_) => MockEmailDialog(email: email, otp: otp),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 380),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryMuted.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.mark_email_unread_outlined, color: AppTheme.accent),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Hộp thư giả lập',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                'Đến: $email',
                style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 6),
              Text(
                'Mã xác thực đặt lại mật khẩu NihonGo Master của bạn là:',
                style: TextStyle(color: AppTheme.textPrimary, height: 1.4),
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: AppTheme.background,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.borderSubtle),
                ),
                child: SelectableText(
                  otp,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    letterSpacing: 8,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.accent,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Chế độ Demo: email không được gửi thật. Mã có hiệu lực 10 phút.',
                style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton.icon(
                    onPressed: () => Clipboard.setData(ClipboardData(text: otp)),
                    icon: const Icon(Icons.copy_rounded, size: 18),
                    label: const Text('Sao chép'),
                  ),
                  const SizedBox(width: 4),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppTheme.accent),
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Đã hiểu'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
