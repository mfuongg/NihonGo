import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/cat_anim_state.dart';
import '../models/cat_surface.dart';
import '../services/cat_dialogue_service.dart';
import '../services/cat_position_manager.dart';
import '../utils/theme.dart';
import 'app_asset_icon.dart';

export '../models/cat_surface.dart' show CatSurfaceType;

class CompanionAnchorInfo {
  final String? id;
  final CatSurfaceType type;
  final bool interactive;
  final String? label;

  const CompanionAnchorInfo({this.id, required this.type, required this.interactive, this.label});
}

/// Điều phối vị trí Mèo Hộ Pháp: bề mặt đang đứng (theo id hoặc key) và vị trí
/// tương đối `xRatio` trên đường ngang. Vị trí được lưu bền vào SharedPreferences
/// khi bề mặt có `id` ổn định (giống `localStorage.companionPosition` của HTML).
class CompanionCatController extends ChangeNotifier {
  static final GlobalKey appBarLedgeKey = GlobalKey(debugLabel: 'companion-appbar-ledge');

  static const String bottomNavSurfaceId = 'bottom_nav';
  static const String headerSurfaceId = 'header';
  static const String prefsSurfaceKey = 'companion_surface_id';
  static const String prefsRatioKey = 'companion_x_ratio';
  static const double defaultRatio = 0.82;

  /// Vị trí mặc định khi người dùng chưa từng kéo mèo (HTML: viền trên khung Tiến độ, xRatio 0.72).
  /// Nếu bề mặt mặc định không hiển thị (tab khác), mèo tạm đứng trên thanh điều hướng.
  final String? defaultSurfaceId;
  final double initialRatio;

  CompanionCatController({this.defaultSurfaceId, this.initialRatio = defaultRatio})
      : _attachedId = defaultSurfaceId,
        _relativeX = initialRatio;

  final Map<GlobalKey, CompanionAnchorInfo> _anchors = <GlobalKey, CompanionAnchorInfo>{};
  GlobalKey? _attachedKey;
  String? _attachedId;
  double _relativeX;
  bool _enabled = true;
  bool _loaded = false;

  Iterable<GlobalKey> get anchors => _anchors.keys;
  double get relativeX => _relativeX;
  bool get enabled => _enabled;

  /// Id bề mặt đang đứng (`bottom_nav`, `header` hoặc id của anchor).
  String? get attachedId => _attachedId;

  /// Key của anchor đang đứng (ưu tiên key trong phiên, sau đó tra theo id đã lưu).
  GlobalKey? get attached {
    if (_attachedKey == appBarLedgeKey) return appBarLedgeKey;
    if (_attachedKey != null && _anchors.containsKey(_attachedKey)) return _attachedKey;
    if (_attachedId == headerSurfaceId) return appBarLedgeKey;
    if (_attachedId != null && _attachedId != bottomNavSurfaceId) {
      for (final entry in _anchors.entries) {
        if (entry.value.id == _attachedId) return entry.key;
      }
    }
    return null;
  }

  CompanionAnchorInfo? infoFor(GlobalKey key) => _anchors[key];

  void register(
    GlobalKey key, {
    String? id,
    CatSurfaceType type = CatSurfaceType.card,
    bool interactive = true,
    String? label,
  }) {
    _anchors[key] = CompanionAnchorInfo(id: id, type: type, interactive: interactive, label: label);
  }

  void unregister(GlobalKey key) {
    _anchors.remove(key);
    if (_attachedKey == key) _attachedKey = null;
  }

  /// Gắn mèo lên bề mặt [key] (`null` = thanh điều hướng) tại [relativeX].
  void attach(GlobalKey? key, double relativeX, {bool persist = true}) {
    _attachedKey = key;
    if (key == null) {
      _attachedId = bottomNavSurfaceId;
    } else if (key == appBarLedgeKey) {
      _attachedId = headerSurfaceId;
    } else {
      _attachedId = _anchors[key]?.id;
    }
    _relativeX = relativeX.clamp(0.0, 1.0);
    notifyListeners();
    if (persist) unawaited(_save());
  }

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final id = prefs.getString(prefsSurfaceKey);
      final ratio = prefs.getDouble(prefsRatioKey);
      if (id != null) _attachedId = id;
      if (ratio != null) _relativeX = ratio.clamp(0.0, 1.0);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // Anchor không có id ổn định thì không lưu (khi mở lại sẽ về thanh điều hướng).
      final id = _attachedId ?? bottomNavSurfaceId;
      await prefs.setString(prefsSurfaceKey, id);
      await prefs.setDouble(prefsRatioKey, _relativeX);
    } catch (_) {}
  }

  void setEnabled(bool value) {
    if (_enabled == value) return;
    _enabled = value;
    notifyListeners();
  }

  /// Gọi khi bố cục thay đổi (cuộn trang, đổi tab, đổi kích thước) để mèo bám theo đường kẻ.
  void relayout() => notifyListeners();
}

class CompanionCatScope extends InheritedWidget {
  final CompanionCatController controller;

  const CompanionCatScope({super.key, required this.controller, required super.child});

  static CompanionCatController? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<CompanionCatScope>()?.controller;

  @override
  bool updateShouldNotify(CompanionCatScope oldWidget) => controller != oldWidget.controller;
}

/// Khai báo mép trên của [child] là một bề mặt mèo có thể đứng lên
/// (thẻ nội dung, bàn học, kệ sách, bệ...).
///
/// Đặt [id] ổn định để vị trí mèo được nhớ sau khi khởi động lại ứng dụng.
class CompanionLineAnchor extends StatefulWidget {
  final Widget child;
  final String? id;
  final CatSurfaceType surfaceType;
  final bool interactive;
  final String? label;

  const CompanionLineAnchor({
    super.key,
    required this.child,
    this.id,
    this.surfaceType = CatSurfaceType.card,
    this.interactive = true,
    this.label,
  });

  @override
  State<CompanionLineAnchor> createState() => _CompanionLineAnchorState();
}

class _CompanionLineAnchorState extends State<CompanionLineAnchor> {
  final GlobalKey _key = GlobalKey();
  CompanionCatController? _controller;

  void _register() {
    _controller?.register(
      _key,
      id: widget.id,
      type: widget.surfaceType,
      interactive: widget.interactive,
      label: widget.label,
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final next = CompanionCatScope.maybeOf(context);
    if (next != _controller) {
      _controller?.unregister(_key);
      _controller = next;
      _register();
    }
  }

  @override
  void didUpdateWidget(covariant CompanionLineAnchor oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.id != widget.id ||
        oldWidget.surfaceType != widget.surfaceType ||
        oldWidget.interactive != widget.interactive) {
      _register();
    }
  }

  @override
  void dispose() {
    _controller?.unregister(_key);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => KeyedSubtree(key: _key, child: widget.child);
}

/// Metadata căn chỉnh chuẩn xác cho từng bộ trang phục trong `assets/study/outfits/outfits_metadata.json`.
class CatOutfitMetadata {
  final String assetPath;
  final double canvasWidth;
  final double canvasHeight;
  final double displayOffsetX;
  final double displayOffsetY;
  final double scale;
  final double cx;
  final double cy;
  final double bw;
  final double bh;

  const CatOutfitMetadata({
    required this.assetPath,
    required this.canvasWidth,
    required this.canvasHeight,
    required this.displayOffsetX,
    required this.displayOffsetY,
    this.scale = 1.0,
    required this.cx,
    required this.cy,
    required this.bw,
    required this.bh,
  });

  factory CatOutfitMetadata.fromMap(Map<String, dynamic> map) {
    final bbox = map['bbox'] is Map
        ? Map<String, dynamic>.from(map['bbox'] as Map)
        : const <String, dynamic>{};
    return CatOutfitMetadata(
      assetPath: (map['asset_path'] ?? '').toString(),
      canvasWidth: (map['canvas_width'] as num?)?.toDouble() ?? 470.0,
      canvasHeight: (map['canvas_height'] as num?)?.toDouble() ?? 530.0,
      displayOffsetX: (map['display_offset_x'] as num?)?.toDouble() ?? 0.0,
      displayOffsetY: (map['display_offset_y'] as num?)?.toDouble() ?? 0.0,
      scale: (map['scale'] as num?)?.toDouble() ?? 1.0,
      cx: (bbox['cx'] as num?)?.toDouble() ?? 0.61,
      cy: (bbox['cy'] as num?)?.toDouble() ?? 0.74,
      bw: (bbox['bw'] as num?)?.toDouble() ?? 0.44,
      bh: (bbox['bh'] as num?)?.toDouble() ?? 0.26,
    );
  }
}

/// Bộ quản lý metadata 5 bộ trang phục đại diện (`assets/study/outfits/outfits_metadata.json`).
class CatOutfitMetadataRegistry {
  CatOutfitMetadataRegistry._();

  static const double referenceCatWidth = 453.0;
  static const double referenceCatHeight = 550.0;

  static final ValueNotifier<int> revision = ValueNotifier<int>(0);
  static bool _loadedFromBundle = false;
  static Future<void>? _loadingFuture;

  static final Map<String, CatOutfitMetadata> _byPath = <String, CatOutfitMetadata>{
    for (final item in _defaults) item.assetPath: item,
  };

  static const List<CatOutfitMetadata> _defaults = <CatOutfitMetadata>[
    CatOutfitMetadata(assetPath: 'assets/study/outfits/OUTFIT_01_IMG_6912.png', canvasWidth: 432, canvasHeight: 578, displayOffsetX: -2.82, displayOffsetY: -10.74, scale: 1.026, cx: 0.5706, cy: 0.6696, bw: 0.4583, bh: 0.2163),
    CatOutfitMetadata(assetPath: 'assets/study/outfits/OUTFIT_02_IMG_6913.png', canvasWidth: 464, canvasHeight: 538, displayOffsetX: -11.71, displayOffsetY: -10.22, scale: 0.933, cx: 0.5959, cy: 0.6942, bw: 0.4655, bh: 0.2491),
    CatOutfitMetadata(assetPath: 'assets/study/outfits/OUTFIT_03_IMG_6914.png', canvasWidth: 447, canvasHeight: 558, displayOffsetX: 11.52, displayOffsetY: -34.95, scale: 0.92, cx: 0.5391, cy: 0.7401, bw: 0.4720, bh: 0.2527),
    CatOutfitMetadata(assetPath: 'assets/study/outfits/OUTFIT_28_IMG_6941.png', canvasWidth: 496, canvasHeight: 503, displayOffsetX: -33.38, displayOffsetY: -29.03, scale: 0.92, cx: 0.6321, cy: 0.7724, bw: 0.5806, bh: 0.2982),
    CatOutfitMetadata(assetPath: 'assets/study/outfits/OUTFIT_29_IMG_6945.png', canvasWidth: 472, canvasHeight: 528, displayOffsetX: -1.54, displayOffsetY: -12.12, scale: 0.928, cx: 0.5720, cy: 0.7064, bw: 0.4470, bh: 0.2595),
  ];

  static Future<void> ensureLoaded() {
    if (_loadedFromBundle) return Future<void>.value();
    return _loadingFuture ??= _loadFromBundle();
  }

  static Future<void> _loadFromBundle() async {
    try {
      final raw = await rootBundle.loadString(AppAssets.outfitsMetadataJson);
      final decoded = jsonDecode(raw);
      if (decoded is Map && decoded['outfits'] is List) {
        for (final entry in decoded['outfits'] as List) {
          if (entry is Map) {
            final meta = CatOutfitMetadata.fromMap(Map<String, dynamic>.from(entry));
            if (meta.assetPath.isNotEmpty) {
              _byPath[meta.assetPath] = meta;
            }
          }
        }
        _loadedFromBundle = true;
        revision.value++;
      }
    } catch (_) {
      // Fallback to built-in defaults if asset bundle is unavailable in unit tests
    } finally {
      _loadingFuture = null;
    }
  }

  static CatOutfitMetadata forPath(String outfitPath) {
    if (!_loadedFromBundle && _loadingFuture == null) {
      unawaited(ensureLoaded());
    }
    return _byPath[outfitPath] ??
        const CatOutfitMetadata(
          assetPath: '',
          canvasWidth: 470,
          canvasHeight: 530,
          displayOffsetX: -24.0,
          displayOffsetY: -24.0,
          scale: 0.96,
          cx: 0.61,
          cy: 0.74,
          bw: 0.44,
          bh: 0.26,
        );
  }
}

/// Hiển thị ảnh trang phục căn giữa rõ nét trong khung vuông `size x size` thông qua [AppAssetIcon]
/// và giữ nguyên tỷ lệ khung ảnh gốc (`canvasWidth / canvasHeight`).
class CatOutfitPreviewBox extends StatelessWidget {
  final String outfitPath;
  final double size;

  const CatOutfitPreviewBox({
    super.key,
    required this.outfitPath,
    this.size = 64,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: CatOutfitMetadataRegistry.revision,
      builder: (context, _, __) {
        final meta = CatOutfitMetadataRegistry.forPath(outfitPath);
        final aspect = meta.canvasHeight / math.max(1.0, meta.canvasWidth);
        final maxSpan = math.max(meta.bw, meta.bh * aspect);
        final fullW = (size * 0.84) / math.max(0.1, maxSpan);
        final fullH = fullW * aspect;
        final left = size / 2 - meta.cx * fullW;
        final top = size / 2 - meta.cy * fullH;

        return SizedBox(
          width: size,
          height: size,
          child: ClipRect(
            child: Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                Positioned(
                  left: left,
                  top: top,
                  width: fullW,
                  height: fullH,
                  child: AppAssetIcon(
                    outfitPath,
                    width: fullW,
                    height: fullH,
                    fit: BoxFit.contain,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Hiển thị Mèo Hộ Pháp (WebP động) kèm trang phục đang mặc `equippedOutfit` (nếu có)
/// sử dụng `outfits_metadata.json` (`display_offset_x`, `display_offset_y`, `scale`)
/// và `BoxFit.contain` để không làm biến dạng hình dáng mèo hay trang phục.
class CatWithOutfitAvatar extends StatelessWidget {
  final String catAnimPath;
  final String? equippedOutfit;
  final double width;
  final double height;

  const CatWithOutfitAvatar({
    super.key,
    required this.catAnimPath,
    this.equippedOutfit,
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    final outfit = equippedOutfit;
    if (outfit == null || outfit.isEmpty) {
      return SizedBox(
        width: width,
        height: height,
        child: AppAssetIcon(
          catAnimPath,
          width: width,
          height: height,
          fit: BoxFit.contain,
        ),
      );
    }

    return ValueListenableBuilder<int>(
      valueListenable: CatOutfitMetadataRegistry.revision,
      builder: (context, _, __) {
        final meta = CatOutfitMetadataRegistry.forPath(outfit);
        final catScale = math.min(
          width / CatOutfitMetadataRegistry.referenceCatWidth,
          height / CatOutfitMetadataRegistry.referenceCatHeight,
        );
        final catBoxW = CatOutfitMetadataRegistry.referenceCatWidth * catScale;
        final catBoxH = CatOutfitMetadataRegistry.referenceCatHeight * catScale;
        final offsetX = meta.displayOffsetX * catScale;
        final offsetY = meta.displayOffsetY * catScale;

        return SizedBox(
          width: width,
          height: height,
          child: Center(
            child: SizedBox(
              width: catBoxW,
              height: catBoxH,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  Positioned.fill(
                    child: AppAssetIcon(
                      catAnimPath,
                      width: catBoxW,
                      height: catBoxH,
                      fit: BoxFit.contain,
                    ),
                  ),
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Transform.translate(
                        offset: Offset(offsetX, offsetY),
                        child: Transform.scale(
                          scale: meta.scale,
                          alignment: Alignment.center,
                          child: AppAssetIcon(
                            outfit,
                            width: catBoxW,
                            height: catBoxH,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Lớp phủ hiển thị Mèo Hộ Pháp. Đặt trong `Stack` phủ toàn bộ vùng nội dung,
/// mép dưới của lớp phủ trùng với viền trên thanh điều hướng.
///
/// Toạ độ trong widget này luôn là **toạ độ chân mèo** (foot anchor 56.5% / 81.82%
/// của sprite 453×550), sprite được dịch từ điểm chân giống bản HTML.
class LineCompanionCat extends StatefulWidget {
  final CompanionCatController controller;
  final String catId;
  final bool anchorsActive;
  final bool visible;
  final double scale;
  final String? equippedOutfit;
  final int hunger;
  final int energy;

  const LineCompanionCat({
    super.key,
    required this.controller,
    this.catId = AppAssets.defaultCatId,
    this.anchorsActive = true,
    this.visible = true,
    this.scale = 1.0,
    this.equippedOutfit,
    this.hunger = 80,
    this.energy = 80,
  });

  @override
  State<LineCompanionCat> createState() => _LineCompanionCatState();
}

class _LineCompanionCatState extends State<LineCompanionCat>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  static const double _baseCatWidth = 120;

  /// Sprite gốc nhìn về bên trái; khi đi sang phải sẽ lật ngang.
  static const bool _spriteFacesLeft = true;

  /// Tốc độ đi bộ (px/giây) khi mèo tự di chuyển dọc bề mặt.
  static const double _walkSpeed = 42;

  static const CatPositionManager _positions = CatPositionManager();

  final GlobalKey _overlayKey = GlobalKey();
  late final AnimationController _bob = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  CatAnimState _state = CatAnimState.idle;
  Offset? _dragFoot;
  CatSnapResult? _dragCandidate;
  bool _facingRight = false;
  Duration _moveDuration = Duration.zero;
  String? _bubble;
  Timer? _stateTimer;
  Timer? _bubbleTimer;
  Timer? _idleTimer;
  Timer? _moveTimer;
  int _idleTicks = 0;
  final math.Random _rng = math.Random();

  double get _catScale => widget.scale.clamp(0.60, 1.30);
  double get _catWidth => _baseCatWidth * _catScale;
  double get _catHeight => CatPositionManager.heightForWidth(_catWidth);
  double get _headInset => _catHeight * 90 / 550;

  bool get _isDragging => _dragFoot != null;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scheduleIdleBehaviour();
    CatDialogueService.instance.addListener(_onGlobalDialogueChanged);
    unawaited(widget.controller.load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    CatDialogueService.instance.removeListener(_onGlobalDialogueChanged);
    _stateTimer?.cancel();
    _bubbleTimer?.cancel();
    _idleTimer?.cancel();
    _moveTimer?.cancel();
    _bob.dispose();
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    // Xoay màn hình / đổi kích thước cửa sổ: tính lại vị trí sau khi layout xong.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) widget.controller.relayout();
    });
  }

  void _onGlobalDialogueChanged() {
    final active = CatDialogueService.instance.activeSpeech;
    if (active != null && active.isNotEmpty && active != _bubble) {
      _say(active);
    } else if (mounted) {
      setState(() {});
    }
  }

  /// Trạng thái hoạt ảnh thực tế sau khi kết hợp Pomodoro, thể lực và hành vi cục bộ.
  CatAnimState get _effectiveState {
    if (_isDragging) return CatAnimState.drag;
    final pomodoroState = CatDialogueService.instance.pomodoroCatState;
    if (pomodoroState == CatAnimState.studying || CatDialogueService.instance.isStudyLocked) {
      return CatAnimState.studying;
    }
    if (widget.energy < 20 || CatDialogueService.instance.isPostStudyTired) {
      return CatAnimState.sleep;
    }
    if (pomodoroState != null && _state != CatAnimState.walk && _state != CatAnimState.happy) {
      return pomodoroState;
    }
    return _state;
  }

  bool get _isFreeToRoam =>
      !_isDragging &&
      CatDialogueService.instance.pomodoroCatState == null &&
      !CatDialogueService.instance.isStudyLocked &&
      !CatDialogueService.instance.isPostStudyTired &&
      widget.energy >= 20;

  String get _assetPath => AppAssets.catAnimation(widget.catId, _effectiveState.assetKey);

  void _setState(CatAnimState next, {Duration? revertAfter}) {
    _stateTimer?.cancel();
    if (mounted) setState(() => _state = next);
    if (next.isWalking) {
      _bob.repeat(reverse: true);
    } else {
      _bob.stop();
      _bob.value = 0;
    }
    if (revertAfter != null) {
      _stateTimer = Timer(revertAfter, () {
        if (!mounted) return;
        _bob.stop();
        _bob.value = 0;
        setState(() => _state = CatAnimState.idle);
      });
    }
  }

  void _scheduleIdleBehaviour() {
    _idleTimer?.cancel();
    _idleTimer = Timer.periodic(const Duration(seconds: 7), (timer) {
      if (!mounted || !_isFreeToRoam || _state != CatAnimState.idle) return;
      _idleTicks++;
      if (_idleTicks % 6 == 0) {
        _setState(CatAnimState.sleep, revertAfter: const Duration(seconds: 6));
      } else if (_idleTicks % 3 == 0) {
        _wander();
      } else {
        _setState(CatAnimState.blink, revertAfter: const Duration(milliseconds: 1400));
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Bề mặt
  // ---------------------------------------------------------------------------

  RenderBox? get _overlayBox => _overlayKey.currentContext?.findRenderObject() as RenderBox?;

  bool _isOffstage(GlobalKey key) {
    final ctx = key.currentContext;
    if (ctx == null) return true;
    var offstage = false;
    ctx.visitAncestorElements((element) {
      final w = element.widget;
      if (w is Offstage && w.offstage) {
        offstage = true;
        return false;
      }
      if (w is Visibility && !w.visible) {
        offstage = true;
        return false;
      }
      return true;
    });
    return offstage;
  }

  CatSurface _bottomNavSurface(Size size) => CatSurface(
        id: CompanionCatController.bottomNavSurfaceId,
        type: CatSurfaceType.bottomNav,
        left: 0,
        y: size.height,
        width: size.width,
      );

  CatSurface? _headerSurface(Size size) {
    final y = math.max(56.0, _catHeight * CatPositionManager.footAnchorY + 4.0);
    if (y > size.height - 4) return null;
    return CatSurface(
      id: CompanionCatController.headerSurfaceId,
      type: CatSurfaceType.header,
      left: 8,
      y: y,
      width: math.max(80.0, size.width - 16.0),
      height: 4,
    );
  }

  CatSurface? _surfaceForKey(GlobalKey key, RenderBox overlay, Size size) {
    if (key == CompanionCatController.appBarLedgeKey) return _headerSurface(size);
    final info = widget.controller.infoFor(key);
    if (info == null || _isOffstage(key)) return null;
    final box = key.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.attached || !box.hasSize) return null;
    final topLeft = overlay.globalToLocal(box.localToGlobal(Offset.zero));
    final top = topLeft.dy;
    // Bỏ qua bề mặt cuộn khuất phía trên hoặc nằm dưới thanh điều hướng.
    if (top < 44.0 || top > size.height - 4) return null;
    final left = math.max(0.0, topLeft.dx);
    final right = math.min(size.width, topLeft.dx + box.size.width);
    if (right - left < 32) return null;
    return CatSurface(
      id: info.id ?? 'anchor_${key.hashCode}',
      type: info.type,
      left: left,
      y: top,
      width: right - left,
      height: box.size.height,
      interactive: info.interactive,
      label: info.label,
    );
  }

  /// Danh sách bề mặt hợp lệ, kèm key để gắn lại vào controller.
  List<(GlobalKey?, CatSurface)> _collectSurfaces(RenderBox overlay, Size size) {
    final list = <(GlobalKey?, CatSurface)>[(null, _bottomNavSurface(size))];
    if (!widget.anchorsActive) return list;
    final header = _headerSurface(size);
    if (header != null) list.add((CompanionCatController.appBarLedgeKey, header));
    for (final key in widget.controller.anchors) {
      final s = _surfaceForKey(key, overlay, size);
      if (s != null) list.add((key, s));
    }
    return list;
  }

  /// Bề mặt đang đứng; nếu bề mặt đã lưu không hiển thị thì tạm về thanh điều hướng
  /// (không ghi đè lựa chọn của người dùng — giống HTML).
  (GlobalKey?, CatSurface) _currentSurface(RenderBox? overlay, Size size) {
    final key = widget.controller.attached;
    if (key != null && widget.anchorsActive && overlay != null) {
      final s = _surfaceForKey(key, overlay, size);
      if (s != null) return (key, s);
    }
    return (null, _bottomNavSurface(size));
  }

  Offset _restingFoot(CatSurface surface, Size size) => _positions.restingFoot(
        surface,
        widget.controller.relativeX,
        catWidth: _catWidth,
        viewportWidth: size.width,
      );

  /// Góc trên-trái sprite từ điểm chân, có tính lật hướng (foot anchor không ở giữa).
  Offset _spriteTopLeft(Offset foot) {
    final flipped = _isFlipped;
    final anchorX = flipped ? 1 - CatPositionManager.footAnchorX : CatPositionManager.footAnchorX;
    return Offset(
      foot.dx - _catWidth * anchorX,
      foot.dy - _catHeight * CatPositionManager.footAnchorY,
    );
  }

  bool get _isFlipped => _spriteFacesLeft ? _facingRight : !_facingRight;

  // ---------------------------------------------------------------------------
  // Đi bộ dọc bề mặt
  // ---------------------------------------------------------------------------

  void _wander() {
    final overlay = _overlayBox;
    if (overlay == null || !overlay.hasSize) return;
    final size = overlay.size;
    final (key, surface) = _currentSurface(overlay, size);
    final fromFoot = _restingFoot(surface, size);
    final current = widget.controller.relativeX;
    final delta = (_rng.nextDouble() * 0.5 - 0.25);
    var target = (current + delta).clamp(CatPositionManager.minRatio, CatPositionManager.maxRatio);
    if ((target - current).abs() < 0.08) {
      target = (current + (delta >= 0 ? -0.18 : 0.18))
          .clamp(CatPositionManager.minRatio, CatPositionManager.maxRatio);
    }
    final toFoot = _positions.restingFoot(surface, target, catWidth: _catWidth, viewportWidth: size.width);
    final distance = (toFoot.dx - fromFoot.dx).abs();
    if (distance < 6) return;
    _walkTo(key, target, distance, toRight: toFoot.dx > fromFoot.dx);
  }

  void _walkTo(GlobalKey? key, double ratio, double distance, {required bool toRight}) {
    final ms = (distance / _walkSpeed * 1000).clamp(600, 4000).round();
    _moveTimer?.cancel();
    setState(() {
      _facingRight = toRight;
      _moveDuration = Duration(milliseconds: ms);
    });
    _setState(CatAnimState.walk);
    widget.controller.attach(key, ratio);
    _moveTimer = Timer(Duration(milliseconds: ms), () {
      if (!mounted) return;
      setState(() => _moveDuration = Duration.zero);
      if (_state == CatAnimState.walk) _setState(CatAnimState.idle);
    });
  }

  // ---------------------------------------------------------------------------
  // Kéo thả
  // ---------------------------------------------------------------------------

  void _onDragStart(Offset currentFoot) {
    _moveTimer?.cancel();
    _stateTimer?.cancel();
    _bob.stop();
    setState(() {
      _moveDuration = Duration.zero;
      _dragFoot = currentFoot;
      _dragCandidate = null;
      if (_state == CatAnimState.walk) _state = CatAnimState.idle;
    });
  }

  void _onDragUpdate(DragUpdateDetails details, Size size) {
    final overlay = _overlayBox;
    final foot = _dragFoot;
    if (overlay == null || foot == null) return;
    final next = CatPositionManager.clampFootToViewport(foot + details.delta, size, _catWidth);
    final surfaces = _collectSurfaces(overlay, size).map((e) => e.$2);
    if (details.delta.dx.abs() > 0.5) _facingRight = details.delta.dx > 0;
    setState(() {
      _dragFoot = next;
      _dragCandidate = _positions.findNearest(
        next,
        surfaces,
        catWidth: _catWidth,
        viewportWidth: size.width,
      );
    });
  }

  void _onDragEnd(Size size) {
    final overlay = _overlayBox;
    final foot = _dragFoot;
    if (overlay == null || foot == null) return;
    final entries = _collectSurfaces(overlay, size);
    final result = _positions.findNearest(
      foot,
      entries.map((e) => e.$2),
      catWidth: _catWidth,
      viewportWidth: size.width,
    );
    GlobalKey? targetKey;
    var ratio = CompanionCatController.defaultRatio;
    if (result != null) {
      ratio = result.xRatio;
      for (final (key, surface) in entries) {
        if (identical(surface, result.surface)) {
          targetKey = key;
          break;
        }
      }
    }
    // Hiệu ứng đáp xuống mặt phẳng (transition 0.2s như HTML).
    setState(() {
      _moveDuration = const Duration(milliseconds: 220);
      _dragFoot = null;
      _dragCandidate = null;
    });
    widget.controller.attach(targetKey, ratio);
    _moveTimer?.cancel();
    _moveTimer = Timer(const Duration(milliseconds: 240), () {
      if (mounted) setState(() => _moveDuration = Duration.zero);
    });
    if (_isFreeToRoam) {
      _setState(CatAnimState.happy, revertAfter: const Duration(milliseconds: 2200));
    } else {
      setState(() {});
    }
    _say(CatDialogueService.instance.furnitureSnapLine());
  }

  void _onTap() {
    if (CatDialogueService.instance.isStudyLocked) {
      _say('Trẫm đang tập trung học Pomodoro, con sen đừng làm phiền!');
      return;
    }
    if (widget.energy < 20 || CatDialogueService.instance.isPostStudyTired) {
      _say(CatDialogueService.instance.exhaustedLine());
      return;
    }
    if (CatDialogueService.instance.pomodoroCatState == null) {
      _setState(CatAnimState.happy, revertAfter: const Duration(milliseconds: 2200));
    }
    _say(
      CatDialogueService.instance.nextTapLine(
        hunger: widget.hunger,
        energy: widget.energy,
      ),
    );
  }

  void _say(String text) {
    _bubbleTimer?.cancel();
    if (!mounted) return;
    setState(() => _bubble = text);
    _bubbleTimer = Timer(CatDialogueService.autoDismissDuration, () {
      if (mounted) setState(() => _bubble = null);
    });
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.controller,
      builder: (context, _) {
        if (!widget.visible || !widget.controller.enabled) return const SizedBox.shrink();
        return LayoutBuilder(
          key: _overlayKey,
          builder: (context, constraints) {
            final size = Size(constraints.maxWidth, constraints.maxHeight);
            final overlay = _overlayBox;
            final (_, surface) = _currentSurface(overlay, size);
            final foot = _dragFoot ?? _restingFoot(surface, size);
            final topLeft = _spriteTopLeft(foot);
            final duration = _isDragging ? Duration.zero : _moveDuration;
            final candidate = _dragCandidate;
            final shadowW = 48 * _catScale;

            return Stack(
              clipBehavior: Clip.none,
              children: [
                if (candidate != null)
                  Positioned(
                    key: const ValueKey('companion-line'),
                    left: candidate.surface.xMin,
                    width: math.max(24.0, candidate.surface.xMax - candidate.surface.xMin),
                    top: candidate.surface.y - 1.5,
                    height: 3,
                    child: IgnorePointer(
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Positioned.fill(
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    AppTheme.primary.withValues(alpha: 0),
                                    AppTheme.primary,
                                    AppTheme.success,
                                    AppTheme.primary,
                                    AppTheme.primary.withValues(alpha: 0),
                                  ],
                                  stops: const [0, 0.15, 0.5, 0.85, 1],
                                ),
                                borderRadius: BorderRadius.circular(999),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppTheme.primary.withValues(alpha: 0.6),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            top: -22,
                            left: 0,
                            right: 0,
                            child: Center(
                              child: Container(
                                key: const ValueKey('companion-line-label'),
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
                                decoration: BoxDecoration(
                                  color: AppTheme.surface,
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: AppTheme.primary, width: 1.5),
                                ),
                                child: Text(
                                  candidate.surface.displayLabel,
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.textPrimary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                // Bóng đổ ngay dưới chân mèo.
                AnimatedPositioned(
                  key: const ValueKey('companion-foot-shadow'),
                  duration: duration,
                  curve: Curves.easeOutCubic,
                  left: foot.dx - shadowW / 2,
                  top: foot.dy - 4.5 * _catScale,
                  width: shadowW,
                  height: 9 * _catScale,
                  child: IgnorePointer(
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 150),
                      opacity: _isDragging ? 0.4 : 1,
                      child: const DecoratedBox(
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.all(Radius.elliptical(24, 5)),
                          gradient: RadialGradient(
                            colors: [Color(0x522D2024), Color(0x1A2D2024), Color(0x002D2024)],
                            stops: [0, 0.6, 1],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                AnimatedPositioned(
                  key: const ValueKey('companion-cat'),
                  duration: duration,
                  curve: _moveDuration.inMilliseconds > 400 ? Curves.linear : Curves.easeOutCubic,
                  left: topLeft.dx,
                  top: topLeft.dy,
                  width: _catWidth,
                  height: _catHeight,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned.fill(
                        child: IgnorePointer(
                          child: Semantics(
                            label: 'Mèo Hộ Pháp',
                            button: true,
                            child: AnimatedBuilder(
                        animation: _bob,
                        builder: (context, child) {
                          final lift = _state.isWalking && !_isDragging
                              ? -math.sin(_bob.value * math.pi) * 4 * _catScale
                              : 0.0;
                          return Transform.translate(offset: Offset(0, lift), child: child);
                        },
                        child: AnimatedScale(
                          duration: const Duration(milliseconds: 150),
                          scale: _isDragging ? 1.06 : 1.0,
                          alignment: Alignment(
                            (_isFlipped ? 1 - CatPositionManager.footAnchorX : CatPositionManager.footAnchorX) * 2 - 1,
                            CatPositionManager.footAnchorY * 2 - 1,
                          ),
                          child: Transform.flip(
                            flipX: _isFlipped,
                            child: CatWithOutfitAvatar(
                              key: ValueKey('companion-cat-anim-${_effectiveState.name}'),
                              catAnimPath: _assetPath,
                              equippedOutfit: widget.equippedOutfit,
                              width: _catWidth,
                              height: _catHeight,
                            ),
                          ),
                        ),
                            ),
                          ),
                        ),
                      ),
                      // Vùng chạm chỉ bao phần thân mèo (giống .companion-drag-handle của HTML)
                      // để phần rìa trong suốt không che các nút chức năng bên dưới.
                      Positioned(
                        key: const ValueKey('companion-cat-handle'),
                        left: _catWidth * 0.20,
                        top: _catHeight * 0.12,
                        width: _catWidth * 0.60,
                        height: _catHeight * 0.68,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: _onTap,
                          onPanStart: (_) => _onDragStart(foot),
                          onPanUpdate: (d) => _onDragUpdate(d, size),
                          onPanEnd: (_) => _onDragEnd(size),
                          onPanCancel: () => _onDragEnd(size),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_bubble != null)
                  Positioned(
                    key: const ValueKey('companion-bubble'),
                    left: (topLeft.dx + _catWidth / 2 - 110).clamp(8.0, math.max(8.0, size.width - 228)),
                    top: math.max(8.0, topLeft.dy + _headInset - 54),
                    width: 220,
                    child: IgnorePointer(child: _CheerBubble(text: _bubble!)),
                  ),
              ],
            );
          },
        );
      },
    );
  }
}

class _CheerBubble extends StatelessWidget {
  final String text;

  const _CheerBubble({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.primaryMuted.withValues(alpha: 0.7)),
          boxShadow: AppTheme.softCardShadow,
        ),
        child: Text(
          text,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: FontWeight.w800,
            color: AppTheme.accent,
            height: 1.25,
          ),
        ),
      ),
    );
  }
}
