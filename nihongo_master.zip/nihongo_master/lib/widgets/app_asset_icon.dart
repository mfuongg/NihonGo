import 'package:flutter/material.dart';

/// Danh mục toàn bộ đường dẫn tài nguyên đồ họa chuẩn hóa của Nihongo Master.
class AppAssets {
  AppAssets._();

  // ── 0. Phòng Mèo Hoàng Thượng (Cozy Cat Room 2.5D Background) ──
  static const String catRoomBg = 'assets/room.png';

  // ── 1. Navigation Icons (assets/icons/navigation/) ──
  static const String navArrowLeft = 'assets/icons/navigation/arrow_left.png';
  static const String navArrowRight = 'assets/icons/navigation/arrow_right.png';
  static const String navBell = 'assets/icons/navigation/bell.png';
  static const String navCalendar = 'assets/icons/navigation/calendar.png';
  static const String navCart = 'assets/icons/navigation/shop.png';
  static const String navChart = 'assets/icons/achievements/star.png';
  static const String navCheck = 'assets/icons/achievements/star.png';
  static const String navClose = 'assets/icons/navigation/arrow_left.png';
  static const String navCompass = 'assets/icons/navigation/paw.png';
  static const String navGift = 'assets/icons/achievements/gift.png';
  static const String navHelp = 'assets/icons/navigation/help.png';
  static const String navHome = 'assets/icons/navigation/home.png';
  static const String navInventory = 'assets/icons/navigation/inventory.png';
  static const String navLock = 'assets/icons/achievements/rank_shield.png';
  static const String navMail = 'assets/icons/navigation/mail.png';
  static const String navMenu = 'assets/icons/navigation/inventory.png';
  static const String navPaw = 'assets/icons/navigation/paw.png';
  static const String navProfile = 'assets/icons/navigation/chat_cat.png';
  static const String navRefresh = 'assets/icons/navigation/paw.png';
  static const String navSearch = 'assets/icons/navigation/help.png';
  static const String navSettings = 'assets/icons/navigation/settings.png';
  static const String navShare = 'assets/icons/navigation/mail.png';
  static const String navShop = 'assets/icons/navigation/shop.png';
  static const String navUnlock = 'assets/icons/achievements/rank_shield.png';

  // ── 2. Status Icons (assets/icons/status/) ──
  static const String statusCoin = 'assets/icons/status/coin.png';
  static const String statusEnergy01 = 'assets/icons/status/energy_01.png';
  static const String statusEnergy02 = 'assets/icons/status/energy_02.png';
  static const String statusGem = 'assets/icons/status/gem.png';
  static const String statusHeart = 'assets/icons/status/heart_02.png';
  static const String statusHunger = 'assets/icons/status/hunger_01.png';
  static const String statusSleepCat = 'assets/icons/status/sleep_cat.png';
  static const String statusStreak = 'assets/icons/status/streak.png';

  // ── 3. Learning Icons (assets/icons/learning/) ──
  static const String learnAudio = 'assets/icons/learning/audio.png';
  static const String learnBook01 = 'assets/icons/learning/book_01.png';
  static const String learnBook02 = 'assets/icons/learning/book_02.png';
  static const String learnGraduationCap = 'assets/icons/learning/graduation_cap.png';
  static const String learnSparkles = 'assets/icons/learning/tap_hand.png';
  static const String learnStudyCat = 'assets/icons/learning/study_cat.png';

  // ── 3b. AI Practice Lab & Gia Sư Quàng Thượng Icons (assets/icons/lab/) ──
  static const String labAiPractice = 'assets/icons/lab/lab_ai_practice.png';
  static const String labWriting = 'assets/icons/lab/lab_writing.png';
  static const String labReading = 'assets/icons/lab/lab_reading.png';
  static const String labPronunciation = 'assets/icons/lab/lab_pronunciation.png';
  static const String labTutorCat = 'assets/icons/lab/lab_tutor_cat.png';
  static const String labChatbot = 'assets/icons/lab/lab_chatbot.png';
  static const String labAiDrill = 'assets/icons/lab/lab_ai_drill.png';
  static const String labAdaptiveQuest = 'assets/icons/lab/lab_adaptive_quest.png';
  static const String labVocab = 'assets/icons/lab/lab_vocab.png';
  static const String labKanji = 'assets/icons/lab/lab_kanji.png';
  static const String labGrammar = 'assets/icons/lab/lab_grammar.png';
  static const String labReadingBook = 'assets/icons/lab/lab_reading_book.png';
  static const String labListening = 'assets/icons/lab/lab_listening.png';
  static const String aiStateLoading = 'assets/icons/lab/ai_state_loading.png';
  static const String aiStateError = 'assets/icons/lab/ai_state_error.png';
  static const String aiStateCompleted = 'assets/icons/lab/ai_state_completed.png';

  static const List<String> aiLabIcons = <String>[
    labAiPractice,
    labWriting,
    labReading,
    labPronunciation,
    labTutorCat,
    labChatbot,
    labAiDrill,
    labAdaptiveQuest,
    labVocab,
    labKanji,
    labGrammar,
    labReadingBook,
    labListening,
    aiStateLoading,
    aiStateError,
    aiStateCompleted,
  ];

  // ── 4. Achievement Icons (assets/icons/achievements/) ──
  static const String achCrown = 'assets/icons/achievements/crown.png';
  static const String achMedal = 'assets/icons/achievements/medal.png';
  static const String achRankShield = 'assets/icons/achievements/rank_shield.png';
  static const String achStar = 'assets/icons/achievements/star.png';
  static const String achTitleBlue = 'assets/icons/achievements/title_blue.png';
  static const String achTitleRed = 'assets/icons/achievements/title_red.png';
  static const String achTrophy = 'assets/icons/achievements/trophy.png';
  static const String achWingBadge = 'assets/icons/achievements/title_yellow.png';

  // ── 5. Card Assets (assets/cards/) ──
  static const String cardBackDeck = 'assets/cards/card_back_deck.png';
  static const String cardExplodingCat = 'assets/cards/card_exploding_cat.png';
  static const String cardSafeCat = 'assets/cards/card_safe_cat.png';
  static const String cardShieldProtect = 'assets/cards/card_shield_protect.png';

  // ── 6. Illustrations & Banners (assets/images/ & assets/images/pk/) ──
  static const String kawaiiCatAvatar = 'assets/images/auth/kawaii_cat_icon.png';
  static const String catHeroIdle = 'assets/icons/learning/study_cat.png';
  static const String pkLobbyHeroBanner = 'assets/images/pk/pk_lobby_hero_banner.png';
  static const String leaderboardPodiumBanner = 'assets/images/pk/leaderboard_podium_banner.png';
  static const String pkVictoryBanner = 'assets/images/pk/pk_victory_banner.png';
  static const String pkDefeatBanner = 'assets/images/pk/pk_defeat_banner.png';
  static const String pkExplosionFx = 'assets/images/pk/pk_explosion_fx.png';

  // ── 6b. Huy hiệu Mèo Nổ PK & 7 Bậc Rank Học Thuật (assets/images/pk/) ──
  static const String badgeShieldCat = 'assets/images/pk/badge_shield_cat.png';
  static const String badgeTrophyCat = 'assets/images/pk/badge_trophy_cat.png';
  static const String badgeDefeatGhost = 'assets/images/pk/badge_defeat_ghost.png';

  static const String rank01Bronze = 'assets/images/pk/rank_01_bronze.png';
  static const String rank02Silver = 'assets/images/pk/rank_02_silver.png';
  static const String rank03Gold = 'assets/images/pk/rank_03_gold.png';
  static const String rank04Purple = 'assets/images/pk/rank_04_purple.png';
  static const String rank05Diamond = 'assets/images/pk/rank_05_diamond.png';
  static const String rank06Master = 'assets/images/pk/rank_06_master.png';
  static const String rank07Mythic = 'assets/images/pk/rank_07_mythic.png';

  static const List<String> pkRankBadges = <String>[
    rank01Bronze,
    rank02Silver,
    rank03Gold,
    rank04Purple,
    rank05Diamond,
    rank06Master,
    rank07Mythic,
  ];

  // Vương miện Podium (Top 1 / Top 2 / Top 3)
  static const String crownGold = achCrown;
  static const String crownSilver = achWingBadge;
  static const String crownBronze = achMedal;

  // ── 7. Food Assets (10 món đại diện chuẩn hóa trong assets/food/) ──
  // 7.1 Món chính (assets/food/dishes/ - 3 món)
  static const String dishFishCake = 'assets/food/dishes/fish_cake_01.png';
  static const String dishSushi = 'assets/food/dishes/sushi_01.png';
  static const String dishGrilledFish = 'assets/food/dishes/grilled_fish_01.png';

  static const List<String> dishes = <String>[
    dishFishCake,
    dishSushi,
    dishGrilledFish,
  ];

  // 7.2 Trái cây (assets/food/fruits/ - 4 món)
  static const String fruitApple = 'assets/food/fruits/apple_01.png';
  static const String fruitOrange = 'assets/food/fruits/orange_01.png';
  static const String fruitStrawberry = 'assets/food/fruits/strawberry_01.png';
  static const String fruitWatermelon = 'assets/food/fruits/watermelon_01.png';

  static const List<String> fruits = <String>[
    fruitApple,
    fruitOrange,
    fruitStrawberry,
    fruitWatermelon,
  ];

  // 7.3 Hải sản (assets/food/seafood/ - 3 món)
  static const String seafoodSalmon = 'assets/food/seafood/salmon_01.png';
  static const String seafoodShrimp = 'assets/food/seafood/shrimp_01.png';
  static const String seafoodCrab = 'assets/food/seafood/crab_01.png';

  static const List<String> seafoodList = <String>[
    seafoodSalmon,
    seafoodShrimp,
    seafoodCrab,
  ];

  // ── 8. Outfits (5 bộ trang phục đại diện trong assets/study/outfits/) ──
  static const String outfitsMetadataJson = 'assets/study/outfits/outfits_metadata.json';

  static const List<String> outfits = <String>[
    'assets/study/outfits/OUTFIT_01_IMG_6912.png',
    'assets/study/outfits/OUTFIT_02_IMG_6913.png',
    'assets/study/outfits/OUTFIT_03_IMG_6914.png',
    'assets/study/outfits/OUTFIT_28_IMG_6941.png',
    'assets/study/outfits/OUTFIT_29_IMG_6945.png',
  ];

  // ── 9. Cats (5 nhân vật đại diện trong assets/study/cats/) ──
  static const String defaultCatId = 'img_6883';

  static const Set<String> availableCatIds = <String>{
    'img_6883',
    'img_6831_2',
    'img_6832_2',
    'img_6839_2',
    'img_6836_2',
  };

  static String normalizeCatFolderId(String catId) {
    final cleaned = catId.trim().toLowerCase();
    if (cleaned.isEmpty || !availableCatIds.contains(cleaned)) {
      return defaultCatId;
    }
    return cleaned;
  }

  static String catAnimation(String catId, String stateKey) {
    final folder = normalizeCatFolderId(catId);
    return 'assets/study/cats/$folder/$stateKey.webp';
  }
}

/// Alias tương thích ngược cho toàn bộ màn hình hiện có.
class AppIcons {
  AppIcons._();

  static const String home = AppAssets.navHome;
  static const String jlptBadge = AppAssets.learnGraduationCap;
  static const String trophy = AppAssets.achTrophy;
  static const String paw = AppAssets.navPaw;
  static const String profile = AppAssets.navProfile;
  static const String settings = AppAssets.navSettings;
  static const String search = AppAssets.navSearch;
  static const String bell = AppAssets.navBell;
  static const String shop = AppAssets.navShop;
  static const String inventory = AppAssets.navInventory;

  static const String streakFire = AppAssets.statusStreak;
  static const String coin = AppAssets.statusCoin;
  static const String gem = AppAssets.statusGem;
  static const String energy = AppAssets.statusEnergy01;
  static const String heart = AppAssets.statusHeart;
  static const String hunger = AppAssets.statusHunger;
  static const String sleepCat = AppAssets.statusSleepCat;
  static const String star = AppAssets.achStar;
  static const String crown = AppAssets.achCrown;
  static const String medalRank = AppAssets.achMedal;

  static const String bomb = AppAssets.cardExplodingCat;
  static const String shield = AppAssets.cardShieldProtect;
  static const String cards = AppAssets.cardBackDeck;
  static const String timer = AppAssets.navCalendar;
  static const String book = AppAssets.learnBook01;
  static const String audio = AppAssets.learnAudio;
  static const String sparkles = AppAssets.learnSparkles;
  static const String gift = AppAssets.navGift;
  static const String check = AppAssets.navCheck;
  static const String lock = AppAssets.navLock;
  static const String unlock = AppAssets.navUnlock;
  static const String refresh = AppAssets.navRefresh;
  static const String analytics = AppAssets.navChart;
}

/// Alias tương thích cho danh mục 10 món ăn đại diện của Mèo.
class AppFoods {
  AppFoods._();

  // Trái cây (4 món)
  static const String fruitApple = AppAssets.fruitApple;
  static const String fruitOrange = AppAssets.fruitOrange;
  static const String fruitStrawberry = AppAssets.fruitStrawberry;
  static const String fruitWatermelon = AppAssets.fruitWatermelon;

  // Món chính (3 món)
  static const String dishFishCake = AppAssets.dishFishCake;
  static const String dishSushi = AppAssets.dishSushi;
  static const String dishGrilledFish = AppAssets.dishGrilledFish;

  // Hải sản thượng hạng (3 món)
  static const String seafoodSalmon = AppAssets.seafoodSalmon;
  static const String seafoodShrimp = AppAssets.seafoodShrimp;
  static const String seafoodCrab = AppAssets.seafoodCrab;

  static const List<String> dishes = AppAssets.dishes;
  static const List<String> fruits = AppAssets.fruits;
  static const List<String> seafood = AppAssets.seafoodList;
}

/// Widget hiển thị icon PNG từ `assets/icons/` (hoặc `assets/`) kèm fallback an toàn.
class AppAssetIcon extends StatelessWidget {
  final String assetPath;
  final double size;
  final double? width;
  final double? height;
  final IconData? fallbackIcon;
  final Color? fallbackColor;
  final BoxFit fit;

  const AppAssetIcon(
    this.assetPath, {
    super.key,
    this.size = 22,
    this.width,
    this.height,
    this.fallbackIcon,
    this.fallbackColor,
    this.fit = BoxFit.contain,
  });

  const AppAssetIcon.food(
    this.assetPath, {
    super.key,
    this.size = 36,
    this.width,
    this.height,
    this.fallbackIcon = Icons.restaurant_rounded,
    this.fallbackColor,
    this.fit = BoxFit.contain,
  });

  @override
  Widget build(BuildContext context) {
    final effectiveW = width ?? size;
    final effectiveH = height ?? size;
    return Image.asset(
      assetPath,
      width: effectiveW,
      height: effectiveH,
      fit: fit,
      filterQuality: FilterQuality.medium,
      errorBuilder: (_, __, ___) {
        return Icon(
          fallbackIcon ?? Icons.auto_awesome_rounded,
          size: effectiveW * 0.9,
          color: fallbackColor,
        );
      },
    );
  }
}
