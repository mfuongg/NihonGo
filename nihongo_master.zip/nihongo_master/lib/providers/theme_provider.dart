import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/theme.dart';

class ThemeProvider extends ChangeNotifier {
  static const String prefsKey = 'selected_theme_id';
  static const String globalPrefsKey = 'global_selected_theme_id';

  String _selectedThemeId;

  ThemeProvider({String? initialThemeId})
      : _selectedThemeId = AppTheme.specFor(initialThemeId).id {
    AppTheme.setActiveTheme(_selectedThemeId);
  }

  String get selectedThemeId => _selectedThemeId;
  AppThemeSpec get activeSpec => AppTheme.specFor(_selectedThemeId);
  ThemeData get themeData => AppTheme.themeFor(_selectedThemeId);

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(globalPrefsKey) ??
        prefs.getString(prefsKey) ??
        AppTheme.defaultThemeId;
    final normalized = AppTheme.specFor(saved).id;
    if (_selectedThemeId != normalized) {
      _selectedThemeId = normalized;
      AppTheme.setActiveTheme(_selectedThemeId);
      notifyListeners();
    } else {
      AppTheme.setActiveTheme(_selectedThemeId);
    }
  }

  Future<void> setTheme(String themeId) async {
    final normalized = AppTheme.specFor(themeId).id;
    _selectedThemeId = normalized;
    AppTheme.setActiveTheme(normalized);
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(prefsKey, normalized);
    await prefs.setString(globalPrefsKey, normalized);
  }
}
