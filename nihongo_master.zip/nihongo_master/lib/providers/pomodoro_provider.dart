import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/cat_anim_state.dart';
import '../services/cat_dialogue_service.dart';
import 'progress_provider.dart';

/// Các trạng thái của phiên Pomodoro.
enum PomodoroPhase {
  /// Chưa bắt đầu.
  idle,

  /// Đang học (khoá trạng thái mèo, Anti-Cheat bật).
  studying,

  /// Tạm dừng (giữ nguyên thời gian còn lại).
  paused,

  /// Nghỉ ngắn.
  shortBreak,

  /// Nghỉ dài.
  longBreak,

  /// Đã hoàn thành phiên + nghỉ, chờ người dùng bấm Bắt đầu phiên tiếp theo.
  completed,

  /// Phiên học bị huỷ (thoát sớm / rời app) và đã bị phạt.
  cancelled,
}

extension PomodoroPhaseX on PomodoroPhase {
  bool get isBreak => this == PomodoroPhase.shortBreak || this == PomodoroPhase.longBreak;

  /// Đồng hồ đang chạy.
  bool get isTicking => this == PomodoroPhase.studying || isBreak;

  /// Có thể bắt đầu phiên học mới.
  bool get canStart =>
      this == PomodoroPhase.idle || this == PomodoroPhase.completed || this == PomodoroPhase.cancelled;

  String get label {
    switch (this) {
      case PomodoroPhase.idle:
        return 'Chưa bắt đầu';
      case PomodoroPhase.studying:
        return 'Đang học';
      case PomodoroPhase.paused:
        return 'Tạm dừng';
      case PomodoroPhase.shortBreak:
        return 'Nghỉ ngắn';
      case PomodoroPhase.longBreak:
        return 'Nghỉ dài';
      case PomodoroPhase.completed:
        return 'Hoàn thành';
      case PomodoroPhase.cancelled:
        return 'Đã huỷ';
    }
  }

  /// Trạng thái mèo tương ứng (`null` = mèo tự do theo hành vi thường).
  CatAnimState? get catState {
    switch (this) {
      case PomodoroPhase.idle:
      case PomodoroPhase.cancelled:
        return null;
      case PomodoroPhase.studying:
        return CatAnimState.studying;
      case PomodoroPhase.paused:
        return CatAnimState.paused;
      case PomodoroPhase.shortBreak:
        return CatAnimState.relax;
      case PomodoroPhase.longBreak:
        return CatAnimState.sleep;
      case PomodoroPhase.completed:
        return CatAnimState.happy;
    }
  }
}

/// Pomodoro học tiếng Nhật cùng Mèo Hộ Pháp.
///
/// - Đồng hồ tính theo thời điểm kết thúc dự kiến (wall clock), `Timer` chỉ là
///   nhịp làm mới giao diện nên không bị lệch khi app chậm / chuyển màn hình.
/// - Chu kỳ: học → nghỉ ngắn (hoặc nghỉ dài sau N phiên) → chờ người dùng bấm Bắt đầu.
/// - Anti-Cheat: rời app hoặc kết thúc sớm khi đang học → −50 Xu, huỷ phiên.
/// - Energy Drain: mỗi phút học thành công trừ 1% năng lượng mèo.
class PomodoroProvider extends ChangeNotifier with WidgetsBindingObserver {
  static const String activeSessionPrefsKey = 'pomodoro_active_session';
  static const String activeDurationPrefsKey = 'pomodoro_active_duration_min';
  static const String activeStartedAtPrefsKey = 'pomodoro_active_started_ms';
  static const String statePrefsKey = 'pomodoro_state_v2';
  static const String configPrefsKey = 'pomodoro_config_v2';
  static const int antiCheatPenaltyCoins = 50;
  static const int lowEnergyThreshold = 20;

  static const List<int> presetMinutes = <int>[15, 25, 45, 60];
  static const List<int> shortBreakPresets = <int>[3, 5, 10];
  static const List<int> longBreakPresets = <int>[15, 20, 30];

  final DateTime Function() _clock;
  final bool _observeLifecycle;

  ProgressProvider? _progressProvider;
  SharedPreferences? _prefs;
  Timer? _ticker;

  // Cấu hình
  int _studyMinutes = 25;
  int _shortBreakMinutes = 5;
  int _longBreakMinutes = 15;
  int _sessionsBeforeLongBreak = 4;

  // Trạng thái phiên
  PomodoroPhase _phase = PomodoroPhase.idle;
  PomodoroPhase? _pausedFrom;
  DateTime? _phaseStartedAt;
  DateTime? _phaseEndsAt;
  int _phaseTotalSeconds = 25 * 60;
  int? _pausedRemainingSeconds;
  int _cycleSessions = 0;
  int _completedSessionsCount = 0;
  bool _finishing = false;

  bool _isPostStudyTired = false;
  String? _lastPenaltyMessage;
  String? _lastCompletionMessage;

  PomodoroProvider({DateTime Function()? clock, bool observeLifecycle = true})
      : _clock = clock ?? DateTime.now,
        _observeLifecycle = observeLifecycle {
    if (_observeLifecycle) {
      WidgetsBinding.instance.addObserver(this);
    }
  }

  // ---------------------------------------------------------------------------
  // Getters
  // ---------------------------------------------------------------------------

  PomodoroPhase get phase => _phase;
  PomodoroPhase? get pausedFrom => _pausedFrom;

  int get studyMinutes => _studyMinutes;
  int get shortBreakMinutes => _shortBreakMinutes;
  int get longBreakMinutes => _longBreakMinutes;
  int get sessionsBeforeLongBreak => _sessionsBeforeLongBreak;

  /// Tương thích API cũ: thời lượng một phiên học.
  int get selectedMinutes => _studyMinutes;

  /// Đồng hồ đang chạy (học hoặc nghỉ).
  bool get isRunning => _phase.isTicking;

  bool get isPaused => _phase == PomodoroPhase.paused;

  /// Đang trong phiên học (đang chạy hoặc tạm dừng giữa phiên học).
  bool get isInStudySession =>
      _phase == PomodoroPhase.studying ||
      (_phase == PomodoroPhase.paused && _pausedFrom == PomodoroPhase.studying);

  bool get isStudyLocked => _phase == PomodoroPhase.studying;
  bool get isCompleted => _phase == PomodoroPhase.completed;
  bool get canStart => _phase.canStart;
  bool get canConfigure => _phase.canStart;
  bool get isPostStudyTired => _isPostStudyTired;
  String? get lastPenaltyMessage => _lastPenaltyMessage;
  String? get lastCompletionMessage => _lastCompletionMessage;
  int get completedSessionsCount => _completedSessionsCount;

  /// Số phiên đã học trong chu kỳ hiện tại (reset sau nghỉ dài).
  int get cycleSessions => _cycleSessions;

  int get phaseTotalSeconds => _phaseTotalSeconds;
  DateTime? get phaseEndsAt => _phaseEndsAt;
  bool get hasActiveTicker => _ticker?.isActive ?? false;

  int get remainingSeconds {
    if (_phase.isTicking && _phaseEndsAt != null) {
      final ms = _phaseEndsAt!.difference(_clock()).inMilliseconds;
      return max(0, (ms / 1000).ceil());
    }
    if (_phase == PomodoroPhase.paused) {
      return _pausedRemainingSeconds ?? 0;
    }
    return _studyMinutes * 60;
  }

  double get progressFraction {
    final total = max(1, _phase.canStart ? _studyMinutes * 60 : _phaseTotalSeconds);
    return ((total - remainingSeconds) / total).clamp(0.0, 1.0);
  }

  String get formattedRemaining {
    final secs = remainingSeconds;
    final m = (secs ~/ 60).toString().padLeft(2, '0');
    final s = (secs % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ---------------------------------------------------------------------------
  // Khởi tạo & cấu hình
  // ---------------------------------------------------------------------------

  void bindProgressProvider(ProgressProvider progressProvider) {
    _progressProvider = progressProvider;
  }

  Future<void> init({ProgressProvider? progressProvider}) async {
    if (progressProvider != null) {
      _progressProvider = progressProvider;
    }
    _prefs = await SharedPreferences.getInstance();
    _loadConfig();

    final wasStudying = _prefs?.getBool(activeSessionPrefsKey) ?? false;
    if (wasStudying) {
      // App bị đóng đột ngột khi đang học -> Anti-Cheat.
      _phase = PomodoroPhase.cancelled;
      _resetPhaseTiming();
      await _persistState();
      await _applyPenalty(
        reason:
            'Phát hiện đóng ứng dụng đột ngột (Force Kill) khi Pomodoro đang chạy! Hệ thống Anti-Cheat đã trừ -50 Xu.',
      );
      _syncCat();
      return;
    }

    _restoreState();
    _syncCat();
    notifyListeners();
  }

  void _loadConfig() {
    final raw = _prefs?.getString(configPrefsKey);
    if (raw == null) return;
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      _studyMinutes = ((map['study'] as num?)?.toInt() ?? 25).clamp(1, 120);
      _shortBreakMinutes = ((map['short'] as num?)?.toInt() ?? 5).clamp(1, 60);
      _longBreakMinutes = ((map['long'] as num?)?.toInt() ?? 15).clamp(1, 90);
      _sessionsBeforeLongBreak = ((map['cycle'] as num?)?.toInt() ?? 4).clamp(1, 12);
    } catch (_) {}
  }

  Future<void> _persistConfig() async {
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs?.setString(
      configPrefsKey,
      jsonEncode({
        'study': _studyMinutes,
        'short': _shortBreakMinutes,
        'long': _longBreakMinutes,
        'cycle': _sessionsBeforeLongBreak,
      }),
    );
  }

  void _restoreState() {
    final raw = _prefs?.getString(statePrefsKey);
    if (raw == null) return;
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      final phase = PomodoroPhase.values.firstWhere(
        (p) => p.name == map['phase'],
        orElse: () => PomodoroPhase.idle,
      );
      _cycleSessions = (map['cycle'] as num?)?.toInt() ?? 0;
      _completedSessionsCount = (map['done'] as num?)?.toInt() ?? 0;
      _phaseTotalSeconds = (map['total'] as num?)?.toInt() ?? _studyMinutes * 60;
      final endsMs = (map['endsAt'] as num?)?.toInt();
      final pausedFromName = map['pausedFrom'] as String?;
      _pausedFrom = pausedFromName == null
          ? null
          : PomodoroPhase.values.firstWhere(
              (p) => p.name == pausedFromName,
              orElse: () => PomodoroPhase.shortBreak,
            );
      _pausedRemainingSeconds = (map['pausedRemaining'] as num?)?.toInt();

      if (phase.isBreak && endsMs != null) {
        _phase = phase;
        _phaseEndsAt = DateTime.fromMillisecondsSinceEpoch(endsMs);
        if (!_clock().isBefore(_phaseEndsAt!)) {
          // Hết giờ nghỉ trong lúc app đóng.
          _finishBreak(fromRestore: true);
        } else {
          _startTicker();
        }
      } else if (phase == PomodoroPhase.paused && _pausedRemainingSeconds != null) {
        _phase = phase;
      } else if (phase == PomodoroPhase.completed || phase == PomodoroPhase.cancelled) {
        _phase = phase;
      } else {
        _phase = PomodoroPhase.idle;
      }
    } catch (_) {
      _phase = PomodoroPhase.idle;
    }
  }

  Future<void> _persistState() async {
    _prefs ??= await SharedPreferences.getInstance();
    final studying = _phase == PomodoroPhase.studying;
    await _prefs?.setBool(activeSessionPrefsKey, studying);
    if (studying) {
      await _prefs?.setInt(activeDurationPrefsKey, _studyMinutes);
      await _prefs?.setInt(
        activeStartedAtPrefsKey,
        (_phaseStartedAt ?? _clock()).millisecondsSinceEpoch,
      );
    } else {
      await _prefs?.remove(activeDurationPrefsKey);
      await _prefs?.remove(activeStartedAtPrefsKey);
    }
    await _prefs?.setString(
      statePrefsKey,
      jsonEncode({
        'phase': _phase.name,
        'pausedFrom': _pausedFrom?.name,
        'endsAt': _phaseEndsAt?.millisecondsSinceEpoch,
        'total': _phaseTotalSeconds,
        'pausedRemaining': _pausedRemainingSeconds,
        'cycle': _cycleSessions,
        'done': _completedSessionsCount,
      }),
    );
  }

  /// Tương thích API cũ: đặt thời lượng phiên học.
  void selectDurationMinutes(int minutes) => setStudyMinutes(minutes);

  void setStudyMinutes(int minutes) {
    if (!canConfigure) return;
    _studyMinutes = minutes.clamp(1, 120);
    _onConfigChanged();
  }

  void setShortBreakMinutes(int minutes) {
    if (!canConfigure) return;
    _shortBreakMinutes = minutes.clamp(1, 60);
    _onConfigChanged();
  }

  void setLongBreakMinutes(int minutes) {
    if (!canConfigure) return;
    _longBreakMinutes = minutes.clamp(1, 90);
    _onConfigChanged();
  }

  void setSessionsBeforeLongBreak(int sessions) {
    if (!canConfigure) return;
    _sessionsBeforeLongBreak = sessions.clamp(1, 12);
    _onConfigChanged();
  }

  void _onConfigChanged() {
    _lastCompletionMessage = null;
    notifyListeners();
    unawaited(_persistConfig());
  }

  /// Dành cho kiểm thử nhanh: rút ngắn thời gian còn lại của giai đoạn đang chạy.
  void setRemainingSecondsForTest(int seconds) {
    final s = max(1, seconds);
    if (_phase.isTicking) {
      _phaseEndsAt = _clock().add(Duration(seconds: s));
    } else if (_phase == PomodoroPhase.paused) {
      _pausedRemainingSeconds = s;
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Điều khiển phiên
  // ---------------------------------------------------------------------------

  /// Bắt đầu phiên học. Chỉ hoạt động khi người dùng chủ động bấm.
  Future<void> startTimer({int? customSeconds}) async {
    if (!canStart) return;
    _isPostStudyTired = false;
    _lastPenaltyMessage = null;
    _lastCompletionMessage = null;
    _enterTickingPhase(PomodoroPhase.studying, customSeconds ?? _studyMinutes * 60);

    CatDialogueService.instance.trigger(
      CatDialogueContext.tap,
      customText: 'Trẫm đã khóa trạng thái học tập! Con sen cấm thoát app kẻo bay 50 Xu đấy!',
    );
    notifyListeners();
    await _persistState();
  }

  void _enterTickingPhase(PomodoroPhase phase, int seconds) {
    final now = _clock();
    _phase = phase;
    _pausedFrom = null;
    _pausedRemainingSeconds = null;
    _phaseTotalSeconds = max(1, seconds);
    _phaseStartedAt = now;
    _phaseEndsAt = now.add(Duration(seconds: _phaseTotalSeconds));
    _startTicker();
    _syncCat();
  }

  void pause() {
    if (!_phase.isTicking) return;
    final remaining = remainingSeconds;
    _pausedFrom = _phase;
    _pausedRemainingSeconds = max(1, remaining);
    _phase = PomodoroPhase.paused;
    _phaseEndsAt = null;
    _stopTicker();
    _syncCat();
    notifyListeners();
    unawaited(_persistState());
  }

  void resume() {
    if (_phase != PomodoroPhase.paused || _pausedFrom == null) return;
    final remaining = _pausedRemainingSeconds ?? 1;
    final now = _clock();
    _phase = _pausedFrom!;
    _pausedFrom = null;
    _pausedRemainingSeconds = null;
    _phaseEndsAt = now.add(Duration(seconds: remaining));
    _startTicker();
    _syncCat();
    notifyListeners();
    unawaited(_persistState());
  }

  /// Nút Kết thúc. Trong phiên học = thoát sớm (bị phạt); trong giờ nghỉ = dừng chu kỳ.
  Future<void> stop() async {
    if (isInStudySession) {
      await abortWithPenalty(
        customReason: 'Phát hiện rời phiên học! Phạt 50 Xu! (Bạn đã kết thúc sớm khi chưa hết giờ.)',
      );
      return;
    }
    if (_phase == PomodoroPhase.idle) return;
    _stopTicker();
    _phase = PomodoroPhase.idle;
    _cycleSessions = 0;
    _resetPhaseTiming();
    _syncCat();
    notifyListeners();
    await _persistState();
  }

  /// Bỏ qua giờ nghỉ, chuyển sang trạng thái sẵn sàng học phiên tiếp theo.
  void skipBreak() {
    final inBreak = _phase.isBreak || (_phase == PomodoroPhase.paused && (_pausedFrom?.isBreak ?? false));
    if (!inBreak) return;
    _finishBreak();
  }

  /// Huỷ phiên học khi đang học / tạm dừng giữa phiên học -> phạt 50 Xu.
  Future<void> abortWithPenalty({String? customReason}) async {
    if (!isInStudySession) return;
    _stopTicker();
    _phase = PomodoroPhase.cancelled;
    _resetPhaseTiming();
    _syncCat();
    await _persistState();
    await _applyPenalty(
      reason: customReason ?? 'Phát hiện rời phiên học! Phạt 50 Xu!',
    );
  }

  void _resetPhaseTiming() {
    _pausedFrom = null;
    _pausedRemainingSeconds = null;
    _phaseEndsAt = null;
    _phaseStartedAt = null;
    _phaseTotalSeconds = _studyMinutes * 60;
  }

  // ---------------------------------------------------------------------------
  // Đồng hồ
  // ---------------------------------------------------------------------------

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void _stopTicker() {
    _ticker?.cancel();
    _ticker = null;
  }

  /// Một nhịp đồng hồ: tính lại thời gian còn lại theo đồng hồ thực.
  @visibleForTesting
  void tick() {
    if (!_phase.isTicking || _phaseEndsAt == null) {
      _stopTicker();
      return;
    }
    if (_clock().isBefore(_phaseEndsAt!)) {
      notifyListeners();
      return;
    }
    if (_phase == PomodoroPhase.studying) {
      unawaited(_handleStudyCompleted());
    } else {
      _finishBreak();
    }
  }

  Future<void> _handleStudyCompleted() async {
    if (_finishing) return;
    _finishing = true;
    try {
      _stopTicker();
      final studiedMinutes = max(1, (_phaseTotalSeconds / 60).round());
      _completedSessionsCount += 1;
      _cycleSessions += 1;

      final energyDrain = studiedMinutes;
      final rewardCoins = max(10, (studiedMinutes * 0.8).round());
      final rewardXp = studiedMinutes * 2;
      if (_progressProvider != null) {
        await _progressProvider!.drainCatEnergy(energyDrain, notify: false);
        await _progressProvider!.rewardCoinsAndGems(coins: rewardCoins, xp: rewardXp);
      }
      final energy = _progressProvider?.progress.catEnergy ?? 100;
      final lowEnergy = energy < lowEnergyThreshold;
      _isPostStudyTired = lowEnergy;

      final isLong = _cycleSessions >= _sessionsBeforeLongBreak;
      _enterTickingPhase(
        isLong ? PomodoroPhase.longBreak : PomodoroPhase.shortBreak,
        (isLong ? _longBreakMinutes : _shortBreakMinutes) * 60,
      );

      final breakText = isLong
          ? 'Nghỉ dài $_longBreakMinutes phút'
          : 'Nghỉ ngắn $_shortBreakMinutes phút';
      _lastCompletionMessage =
          '🎉 Hoàn thành phiên $studiedMinutes phút! +$rewardCoins Xu, +$rewardXp EXP, Mèo -$energyDrain% Thể lực. $breakText bắt đầu.'
          '${lowEnergy ? ' ⚠️ Năng lượng Mèo còn $energy% — vào Shop mua thức ăn để nạp lại!' : ''}';

      CatDialogueService.instance.setStudyState(studyLocked: false, postStudyTired: lowEnergy);
      CatDialogueService.instance.trigger(
        CatDialogueContext.exhausted,
        customText: lowEnergy
            ? 'Trẫm kiệt sức rồi ($energy%)! Con sen vào Shop mua cá hồi nạp năng lượng ngay!'
            : 'Phù... Học xong $studiedMinutes phút (-$energyDrain% Energy)! Trẫm đi nghỉ chút đây.',
      );
      notifyListeners();
      await _persistState();
    } finally {
      _finishing = false;
    }
  }

  void _finishBreak({bool fromRestore = false}) {
    _stopTicker();
    final wasLong = _phase == PomodoroPhase.longBreak || _pausedFrom == PomodoroPhase.longBreak;
    if (wasLong) _cycleSessions = 0;
    _phase = PomodoroPhase.completed;
    _resetPhaseTiming();
    _lastCompletionMessage = 'Hết giờ nghỉ! Nhấn "Bắt đầu" để học phiên tiếp theo.';
    _syncCat();
    if (!fromRestore) {
      CatDialogueService.instance.trigger(
        CatDialogueContext.tap,
        customText: 'Hết giờ nghỉ rồi con sen! Sẵn sàng thì bấm Bắt đầu, trẫm học cùng.',
      );
      notifyListeners();
    }
    unawaited(_persistState());
  }

  void _syncCat() {
    CatDialogueService.instance.setPomodoroCatState(_phase.catState);
    CatDialogueService.instance.setStudyState(
      studyLocked: _phase == PomodoroPhase.studying,
      postStudyTired: _isPostStudyTired,
    );
  }

  Future<void> _applyPenalty({required String reason}) async {
    if (_progressProvider != null) {
      await _progressProvider!.penalizeCoins(antiCheatPenaltyCoins);
    } else {
      final prefs = _prefs ?? await SharedPreferences.getInstance();
      final current = prefs.getInt('wallet_coins') ?? 0;
      await prefs.setInt('wallet_coins', max(0, current - antiCheatPenaltyCoins));
    }
    _lastPenaltyMessage = reason;
    CatDialogueService.instance.trigger(
      CatDialogueContext.wrongAnswer,
      customText: 'To gan! Dám trốn học giữa chừng à?! Trẫm tịch thu 50 Xu của con sen!',
    );
    notifyListeners();
  }

  void clearMessages() {
    _lastPenaltyMessage = null;
    _lastCompletionMessage = null;
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Quay lại app: tính lại thời gian theo đồng hồ thực.
      if (_phase.isTicking) tick();
      return;
    }
    if (_phase != PomodoroPhase.studying) return;
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden ||
        state == AppLifecycleState.detached) {
      unawaited(
        abortWithPenalty(
          customReason: '⚠️ Phát hiện rời phiên học! Phạt 50 Xu! (Ứng dụng bị thu nhỏ / chuyển tab khi đang học.)',
        ),
      );
    }
  }

  @override
  void dispose() {
    if (_observeLifecycle) {
      WidgetsBinding.instance.removeObserver(this);
    }
    _stopTicker();
    super.dispose();
  }
}
