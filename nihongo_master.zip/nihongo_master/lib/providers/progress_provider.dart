import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/grammar_data.dart';
import '../data/kanji_data.dart';
import '../data/reading_material_data.dart';
import '../data/vocabulary_data.dart';
import '../models/daily_task.dart';
import '../models/user_progress.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/firebase_service.dart';
import '../services/local_database_service.dart';
import '../utils/constants.dart';
import '../utils/theme.dart';
import '../widgets/app_asset_icon.dart';
import '../widgets/line_companion_cat.dart';

class AdaptiveQuest {
  final String id;
  final String title;
  final String description;
  final String skillType;
  final String level;
  final String iconAsset;
  final int currentProgress;
  final int targetCount;
  final int xpReward;
  final int coinReward;
  final bool isClaimed;

  const AdaptiveQuest({
    required this.id,
    required this.title,
    required this.description,
    required this.skillType,
    required this.level,
    required this.iconAsset,
    required this.currentProgress,
    required this.targetCount,
    required this.xpReward,
    this.coinReward = 5,
    required this.isClaimed,
  });

  bool get isCompleted => currentProgress >= targetCount;

  String get status {
    if (isCompleted) return 'completed';
    if (currentProgress > 0) return 'in_progress';
    return 'not_started';
  }

  String get statusLabelVi {
    if (isClaimed) return 'Đã nhận thưởng';
    if (isCompleted) return 'Hoàn thành';
    if (currentProgress > 0) return 'Đang làm';
    return 'Chưa làm';
  }

  double get progressRatio =>
      targetCount <= 0 ? 1.0 : (currentProgress / targetCount).clamp(0.0, 1.0);
}

class ProgressProvider extends ChangeNotifier {
  static const _dailyTasksKey = 'daily_tasks_json';
  static const _dailyTaskDateKey = 'daily_task_date';
  static const _todayXpDateKey = 'today_xp_date';
  static const _progressOwnerKey = 'progress_owner_uid';
  static const _adaptiveProgressKey = 'adaptive_quest_progress_json';
  static const _claimedAdaptiveQuestsKey = 'claimed_adaptive_quests';

  final FirestoreService _firestoreService = FirestoreService();

  UserProgress _progress = UserProgress();
  SharedPreferences? _prefs;
  List<DailyTask> _dailyTasks = [];
  Map<String, int> _adaptiveQuestProgress = <String, int>{};
  Set<String> _claimedAdaptiveQuestIds = <String>{};
  bool _adminAccountActive = false;
  bool _adminUnlimitedOverride = true;

  UserProgress get progress => _progress;
  UserProgress get userProgress => _progress;
  List<DailyTask> get dailyTasks => List.unmodifiable(_dailyTasks);
  int get claimableDailyTaskCount =>
      _dailyTasks.where((task) => task.isCompleted && !task.isClaimed).length;

  bool get isAdminAccount => _adminAccountActive;
  bool get isAdminMode => isAdminAccount && _adminUnlimitedOverride;
  bool get adminUnlimitedOverride => _adminUnlimitedOverride;
  bool get isCatExhausted => _progress.catEnergy < 20;
  bool get isCatOutOfEnergy => _progress.catEnergy <= 0;

  bool isWorldUnlocked(bool isBuiltByDefault) => isBuiltByDefault || isAdminMode;

  bool isMapLevelUnlocked({required int index, required String? previousLevelKey}) {
    if (isAdminMode) return true;
    if (index == 0 || previousLevelKey == null) return true;
    return mapStarsFor(previousLevelKey) >= 1;
  }

  void setAdminAccount(bool isAdmin) {
    _adminAccountActive = isAdmin;
    _progress.adminUnlimited = isAdminMode;
    notifyListeners();
  }

  void setAdminUnlimitedOverride(bool enabled) {
    _adminUnlimitedOverride = enabled;
    _progress.adminUnlimited = isAdminMode;
    notifyListeners();
  }

  bool _detectAdminFromSession() {
    if (FirebaseService.isEnabled) {
      final fbEmail = FirebaseAuth.instance.currentUser?.email;
      if (AuthService.isAdminEmail(fbEmail)) return true;
    }
    final rawLocal = _prefs?.getString('current_local_user');
    if (rawLocal != null && rawLocal.isNotEmpty) {
      try {
        final map = jsonDecode(rawLocal) as Map<String, dynamic>;
        if (AuthService.isAdminEmail(map['email'] as String?)) return true;
      } catch (_) {}
    }
    return false;
  }

  Future<void> init() async {
    unawaited(CatOutfitMetadataRegistry.ensureLoaded());
    await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    _prefs = await SharedPreferences.getInstance();
    _adminAccountActive = _detectAdminFromSession();
    _loadProgress();
    final previousOwner = _prefs?.getString(_progressOwnerKey);
    _checkStreak();
    _ensureFreshDailyState();
    final restored = await _restoreRemoteProgressIfAvailable();
    if (!restored && _shouldResetForCurrentUser(previousOwner)) {
      _progress = UserProgress(adminUnlimited: isAdminMode);
      _dailyTasks = _generateDailyTasks(_todayKey());
      await _saveProgress();
    }
    _progress.adminUnlimited = isAdminMode;
    await _syncRemoteProgress();
    notifyListeners();
  }

  void _loadProgress() {
    List<Map<String, dynamic>> decodedHistory = <Map<String, dynamic>>[];
    final rawHistory = _prefs?.getString('test_history_json');
    if (rawHistory != null && rawHistory.isNotEmpty) {
      try {
        decodedHistory = List<Map<String, dynamic>>.from(jsonDecode(rawHistory) as List);
      } catch (_) {
        decodedHistory = <Map<String, dynamic>>[];
      }
    }

    final hasStoredFoodInventory = _prefs?.containsKey('cat_food_inventory_json') ?? false;
    final loadedFoodInventory = hasStoredFoodInventory
        ? _decodeFoodInventory(_prefs?.getString('cat_food_inventory_json'))
        : UserProgress.defaultStarterFoodInventory();
    final rawEquippedOutfit = _prefs?.getString('cat_equipped_outfit');

    _progress = UserProgress(
      totalXP: _prefs?.getInt(AppConstants.keyXP) ?? 0,
      currentStreak: _prefs?.getInt(AppConstants.keyStreak) ?? 0,
      longestStreak: _prefs?.getInt('longest_streak') ?? 0,
      selectedLevel: _prefs?.getString(AppConstants.keyUserLevel) ?? 'N5',
      dailyGoal: _prefs?.getInt(AppConstants.keyDailyGoal) ?? 50,
      todayXP: _prefs?.getInt('today_xp') ?? 0,
      learnedVocabIds: Set<String>.from(_prefs?.getStringList('learned_vocab') ?? []),
      learnedKanjiIds: Set<String>.from(_prefs?.getStringList('learned_kanji') ?? []),
      favoriteVocabIds: Set<String>.from(_prefs?.getStringList('fav_vocab') ?? []),
      favoriteKanjiIds: Set<String>.from(_prefs?.getStringList('fav_kanji') ?? []),
      unlockedAchievements: Set<String>.from(_prefs?.getStringList('achievements') ?? []),
      testHistory: decodedHistory,
      coins: _prefs?.getInt('wallet_coins') ?? 0,
      gems: _prefs?.getInt('wallet_gems') ?? 0,
      adminUnlimited: isAdminMode,
      vocabStudyDay: _prefs?.getString('vocab_study_day'),
      dailyReviewClaimDay: _prefs?.getString('daily_review_claim_day'),
      mapLevelStars: _decodeStars(_prefs?.getString('map_level_stars_json')),
      mapPracticeRewarded: Set<String>.from(_prefs?.getStringList('map_practice_rewarded') ?? []),
      foodInventory: loadedFoodInventory,
      ownedOutfits: List<String>.from(_prefs?.getStringList('cat_owned_outfits') ?? const <String>[]),
      equippedOutfit: (rawEquippedOutfit == null || rawEquippedOutfit.isEmpty) ? null : rawEquippedOutfit,
      unlockedThemeIds: _prefs?.getStringList('unlocked_theme_ids'),
      selectedThemeId: _prefs?.getString('global_selected_theme_id') ??
          _prefs?.getString('selected_theme_id') ??
          'dusty_rose',
      ownedCatIds: _prefs?.getStringList('owned_cat_ids'),
      selectedCatId: _prefs?.getString('selected_cat_id') ?? AppAssets.defaultCatId,
      catHunger: (_prefs?.getInt('cat_hunger') ?? 75).clamp(0, 100),
      catEnergy: (_prefs?.getInt('cat_energy') ?? 80).clamp(0, 100),
      catMood: (_prefs?.getInt('cat_mood') ?? 85).clamp(0, 100),
      catCompanionEnabled: _prefs?.getBool('cat_companion_enabled') ?? true,
      catCompanionScale: (_prefs?.getDouble('cat_companion_scale') ?? 1.0).clamp(0.60, 1.30),
      pkRating: max(0, _prefs?.getInt('pk_rating') ?? 720),
      pkWins: max(0, _prefs?.getInt('pk_wins') ?? 28),
      pkMatches: max(0, _prefs?.getInt('pk_matches') ?? 42),
      avatarBase64: _prefs?.getString('profile_avatar_base64'),
      gender: _prefs?.getString('profile_gender') ?? 'Bí mật',
      bio: _prefs?.getString('profile_bio') ?? 'Chiến thần N3 quyết tâm chinh phục JLPT! 🌸',
      selectedTitle: _prefs?.getString('profile_selected_title') ?? 'Tân Binh Nihongo',
      showBio: _prefs?.getBool('privacy_show_bio') ?? true,
      showVip: _prefs?.getBool('privacy_show_vip') ?? true,
      showStreak: _prefs?.getBool('privacy_show_streak') ?? true,
    );
    AppTheme.setActiveTheme(_progress.selectedThemeId);

    final lastStudyStr = _prefs?.getString(AppConstants.keyLastStudy);
    if (lastStudyStr != null) {
      _progress.lastStudyDate = DateTime.tryParse(lastStudyStr);
    }

    final rawDailyTasks = _prefs?.getString(_dailyTasksKey);
    if (rawDailyTasks != null && rawDailyTasks.isNotEmpty) {
      try {
        _dailyTasks = List<Map<String, dynamic>>.from(jsonDecode(rawDailyTasks) as List)
            .map(DailyTask.fromMap)
            .toList();
      } catch (_) {
        _dailyTasks = [];
      }
    }

    _adaptiveQuestProgress =
        _decodeStars(_prefs?.getString(_adaptiveProgressKey));
    _claimedAdaptiveQuestIds = Set<String>.from(
      _prefs?.getStringList(_claimedAdaptiveQuestsKey) ?? const <String>[],
    );
  }

  void _checkStreak() {
    if (_progress.lastStudyDate == null) return;
    final now = DateTime.now();
    final last = _progress.lastStudyDate!;
    final diff = DateTime(now.year, now.month, now.day)
        .difference(DateTime(last.year, last.month, last.day))
        .inDays;
    if (diff > 1) {
      _progress.currentStreak = 0;
    }
  }

  void _ensureFreshDailyState() {
    final todayKey = _todayKey();
    final storedXpDay = _prefs?.getString(_todayXpDateKey);
    if (storedXpDay != todayKey) {
      _progress.todayXP = 0;
      _prefs?.setString(_todayXpDateKey, todayKey);
    }

    final storedTaskDay = _prefs?.getString(_dailyTaskDateKey);
    if (storedTaskDay != todayKey || _dailyTasks.isEmpty) {
      _dailyTasks = _generateDailyTasks(todayKey);
      _prefs?.setString(_dailyTaskDateKey, todayKey);
    }

    unawaited(_saveProgress());
  }

  String _todayKey() {
    final now = DateTime.now();
    final month = now.month.toString().padLeft(2, '0');
    final day = now.day.toString().padLeft(2, '0');
    return '${now.year}-$month-$day';
  }

  List<DailyTask> _generateDailyTasks(String dayKey) {
    final templates = <Map<String, dynamic>>[
      {
        'type': 'earn_xp',
        'icon': '⚡',
        'title': 'Tăng tốc EXP',
        'description': 'Tích lũy 60 EXP trong hôm nay.',
        'target': 60,
        'rewardXp': 30,
      },
      {
        'type': 'earn_xp',
        'icon': '🚀',
        'title': 'Bùng nổ năng lượng',
        'description': 'Kiếm 100 EXP để mở đà học tập.',
        'target': 100,
        'rewardXp': 45,
      },
      {
        'type': 'learn_vocab',
        'icon': '📖',
        'title': 'Thu thập từ mới',
        'description': 'Học 5 từ vựng mới.',
        'target': 5,
        'rewardXp': 25,
      },
      {
        'type': 'learn_vocab',
        'icon': '📝',
        'title': 'Ghi nhớ đều tay',
        'description': 'Đánh dấu 8 từ vựng đã học.',
        'target': 8,
        'rewardXp': 35,
      },
      {
        'type': 'learn_kanji',
        'icon': '🈶',
        'title': 'Kanji mỗi ngày',
        'description': 'Học 3 chữ kanji mới.',
        'target': 3,
        'rewardXp': 35,
      },
      {
        'type': 'complete_test',
        'icon': '🧪',
        'title': 'Làm 1 bài luyện',
        'description': 'Hoàn thành ít nhất 1 bài kiểm tra hoặc bài AI practice.',
        'target': 1,
        'rewardXp': 35,
      },
      {
        'type': 'complete_test',
        'icon': '🎯',
        'title': 'Hai lượt bứt phá',
        'description': 'Hoàn thành 2 lượt luyện bất kỳ.',
        'target': 2,
        'rewardXp': 50,
      },
      {
        'type': 'finish_pronunciation',
        'icon': '🎙️',
        'title': 'Mic check',
        'description': 'Hoàn thành 1 lượt luyện phát âm AI.',
        'target': 1,
        'rewardXp': 30,
      },
      {
        'type': 'finish_writing',
        'icon': '✍️',
        'title': 'Luyện nét đẹp',
        'description': 'Hoàn thành 1 lượt luyện viết AI.',
        'target': 1,
        'rewardXp': 30,
      },
      {
        'type': 'perfect_test',
        'icon': '🏅',
        'title': 'Điểm tuyệt đối',
        'description': 'Đạt 100% trong một lượt luyện hôm nay.',
        'target': 1,
        'rewardXp': 50,
      },
    ];

    final rng = Random(dayKey.hashCode ^ (_progress.totalXP + _progress.currentStreak + 17));
    final pool = [...templates]..shuffle(rng);
    final selected = <DailyTask>[];
    final usedTypes = <String>{};

    for (final template in pool) {
      final type = template['type'] as String;
      if (usedTypes.contains(type) && selected.length < 3) continue;
      usedTypes.add(type);
      selected.add(
        DailyTask(
          id: '${dayKey}_${type}_${selected.length}',
          type: type,
          icon: template['icon'] as String,
          title: template['title'] as String,
          description: template['description'] as String,
          target: template['target'] as int,
          rewardXp: template['rewardXp'] as int,
        ),
      );
      if (selected.length == 3) break;
    }

    return selected;
  }

  Future<void> _saveProgress() async {
    await _prefs?.setInt(AppConstants.keyXP, _progress.totalXP);
    await _prefs?.setInt(AppConstants.keyStreak, _progress.currentStreak);
    await _prefs?.setInt('longest_streak', _progress.longestStreak);
    await _prefs?.setString(AppConstants.keyUserLevel, _progress.selectedLevel);
    await _prefs?.setInt(AppConstants.keyDailyGoal, _progress.dailyGoal);
    await _prefs?.setInt('today_xp', _progress.todayXP);
    await _prefs?.setString(_todayXpDateKey, _todayKey());
    await _prefs?.setStringList('learned_vocab', _progress.learnedVocabIds.toList());
    await _prefs?.setStringList('learned_kanji', _progress.learnedKanjiIds.toList());
    await _prefs?.setStringList('fav_vocab', _progress.favoriteVocabIds.toList());
    await _prefs?.setStringList('fav_kanji', _progress.favoriteKanjiIds.toList());
    await _prefs?.setStringList('achievements', _progress.unlockedAchievements.toList());
    await _prefs?.setString('test_history_json', jsonEncode(_progress.testHistory));
    await _prefs?.setString(_dailyTasksKey, jsonEncode(_dailyTasks.map((task) => task.toMap()).toList()));
    await _prefs?.setString(_dailyTaskDateKey, _todayKey());
    final ownerUid = FirebaseService.isEnabled
        ? (FirebaseAuth.instance.currentUser?.uid ?? 'guest')
        : 'guest';
    await _prefs?.setString(_progressOwnerKey, ownerUid);
    await _prefs?.setInt('wallet_coins', _progress.rawCoins);
    await _prefs?.setInt('wallet_gems', _progress.rawGems);
    await _setOrRemove('vocab_study_day', _progress.vocabStudyDay);
    await _setOrRemove('daily_review_claim_day', _progress.dailyReviewClaimDay);
    await _prefs?.setString('map_level_stars_json', jsonEncode(_progress.mapLevelStars));
    await _prefs?.setStringList('map_practice_rewarded', _progress.mapPracticeRewarded.toList());
    await _prefs?.setString(_adaptiveProgressKey, jsonEncode(_adaptiveQuestProgress));
    await _prefs?.setStringList(_claimedAdaptiveQuestsKey, _claimedAdaptiveQuestIds.toList());
    await _prefs?.setString('cat_food_inventory_json', jsonEncode(_progress.rawFoodInventory));
    await _prefs?.setStringList('cat_owned_outfits', _progress.rawOwnedOutfits);
    await _setOrRemove('cat_equipped_outfit', _progress.equippedOutfit);
    await _prefs?.setStringList('unlocked_theme_ids', _progress.rawUnlockedThemeIds);
    await _prefs?.setString('selected_theme_id', _progress.selectedThemeId);
    await _prefs?.setString('global_selected_theme_id', _progress.selectedThemeId);
    await _prefs?.setStringList('owned_cat_ids', _progress.rawOwnedCatIds);
    await _prefs?.setString('selected_cat_id', _progress.selectedCatId);
    await _prefs?.setInt('cat_hunger', _progress.catHunger.clamp(0, 100));
    await _prefs?.setInt('cat_energy', _progress.catEnergy.clamp(0, 100));
    await _prefs?.setInt('cat_mood', _progress.catMood.clamp(0, 100));
    await _prefs?.setBool('cat_companion_enabled', _progress.catCompanionEnabled);
    await _prefs?.setDouble('cat_companion_scale', _progress.catCompanionScale.clamp(0.60, 1.30));
    await _prefs?.setInt('pk_rating', max(0, _progress.pkRating));
    await _prefs?.setInt('pk_wins', max(0, _progress.pkWins));
    await _prefs?.setInt('pk_matches', max(0, _progress.pkMatches));
    await _setOrRemove('profile_avatar_base64', _progress.avatarBase64);
    await _prefs?.setString('profile_gender', _progress.gender);
    await _prefs?.setString('profile_bio', _progress.bio);
    await _prefs?.setString('profile_selected_title', _progress.selectedTitle);
    await _prefs?.setBool('privacy_show_bio', _progress.showBio);
    await _prefs?.setBool('privacy_show_vip', _progress.showVip);
    await _prefs?.setBool('privacy_show_streak', _progress.showStreak);
    if (_progress.lastStudyDate != null) {
      await _prefs?.setString(
        AppConstants.keyLastStudy,
        _progress.lastStudyDate!.toIso8601String(),
      );
    } else {
      await _prefs?.remove(AppConstants.keyLastStudy);
    }
  }

  Future<void> _setOrRemove(String key, String? value) async {
    if (value == null || value.isEmpty) {
      await _prefs?.remove(key);
    } else {
      await _prefs?.setString(key, value);
    }
  }

  static const int dailyReviewRewardCoins = 5;

  bool get hasStudiedVocabToday => isAdminMode || _progress.vocabStudyDay == _todayKey();
  bool get isDailyReviewClaimedToday => !isAdminMode && _progress.dailyReviewClaimDay == _todayKey();
  bool get canClaimDailyReview => hasStudiedVocabToday && !isDailyReviewClaimedToday;

  Future<bool> claimDailyReviewReward() async {
    if (!canClaimDailyReview) return false;
    _progress.rawCoins += dailyReviewRewardCoins;
    _progress.dailyReviewClaimDay = _todayKey();
    await _persist();
    return true;
  }

  static const int mapPracticeRewardCoins = 5;

  int mapStarsFor(String levelKey) =>
      _progress.mapLevelStars[levelKey] ?? (isAdminMode ? 3 : 0);

  bool isMapPracticeRewarded(String levelKey) => _progress.mapPracticeRewarded.contains(levelKey);

  /// Ghi nhận hoàn thành phần Học/Luyện tập của một level bản đồ.
  /// Trả về `true` nếu đây là lần đầu và đã cộng thưởng Coin.
  Future<bool> completeMapPractice(String levelKey) async {
    if (_progress.mapPracticeRewarded.contains(levelKey)) return false;
    _progress.mapPracticeRewarded.add(levelKey);
    _progress.rawCoins += mapPracticeRewardCoins;
    await _persist();
    return true;
  }

  /// Lưu số sao của bài Kiểm tra vượt level (chỉ giữ kỷ lục cao nhất).
  Future<void> recordMapLevelStars(String levelKey, int stars) async {
    final clamped = stars.clamp(0, 3);
    if (clamped <= mapStarsFor(levelKey)) return;
    _progress.mapLevelStars[levelKey] = clamped;
    await _persist();
  }

  static Map<String, int> _decodeStars(dynamic raw) {
    try {
      final decoded = raw is String ? (raw.isEmpty ? null : jsonDecode(raw)) : raw;
      if (decoded is Map) {
        return decoded.map(
          (key, value) => MapEntry(key.toString(), value is num ? value.toInt() : int.tryParse('$value') ?? 0),
        );
      }
    } catch (_) {}
    return <String, int>{};
  }

  static Map<String, int> _decodeFoodInventory(dynamic raw) {
    try {
      final decoded = raw is String ? (raw.isEmpty ? null : jsonDecode(raw)) : raw;
      if (decoded is Map) {
        final result = <String, int>{};
        decoded.forEach((key, value) {
          final qty = value is num ? value.toInt() : int.tryParse('$value') ?? 0;
          if (qty > 0) {
            result[key.toString()] = qty;
          }
        });
        return result;
      }
    } catch (_) {}
    return <String, int>{};
  }

  int foodCountFor(String assetPath) => _progress.foodInventory[assetPath] ?? 0;

  int get totalOwnedFoodCount =>
      _progress.foodInventory.values.fold<int>(0, (sum, qty) => sum + (qty > 0 ? qty : 0));

  bool isOutfitOwned(String outfitPath) => _progress.ownedOutfits.contains(outfitPath);

  bool isThemeUnlocked(String themeId) =>
      _progress.unlockedThemeIds.contains(themeId);

  /// Mua 1 Chủ đề Giao diện (Theme) bằng Xu hoặc Gem.
  Future<bool> buyAppTheme({
    required String themeId,
    int coinCost = 0,
    int gemCost = 0,
  }) async {
    if (_progress.unlockedThemeIds.contains(themeId)) return false;
    if (coinCost < 0 || gemCost < 0) return false;
    if (_progress.coins < coinCost || _progress.gems < gemCost) return false;
    if (!isAdminMode) {
      _progress.rawCoins = max(0, _progress.rawCoins - coinCost);
      _progress.rawGems = max(0, _progress.rawGems - gemCost);
    }
    if (!_progress.rawUnlockedThemeIds.contains(themeId)) {
      _progress.rawUnlockedThemeIds.add(themeId);
    }
    await _persist();
    return true;
  }

  /// Chọn áp dụng 1 Chủ đề Giao diện đã mở khóa cho toàn ứng dụng.
  Future<bool> selectAppTheme(String themeId) async {
    if (!isThemeUnlocked(themeId)) return false;
    AppTheme.setActiveTheme(themeId);
    if (_progress.selectedThemeId == themeId) {
      await _prefs?.setString('selected_theme_id', themeId);
      await _prefs?.setString('global_selected_theme_id', themeId);
      notifyListeners();
      return true;
    }
    _progress.selectedThemeId = themeId;
    await _persist();
    return true;
  }

  bool isCatOwned(String catId) {
    final normalized = AppAssets.normalizeCatFolderId(catId);
    return _progress.ownedCatIds.contains(normalized);
  }

  /// Mua 1 Linh thú Mèo đồng hành bằng Xu hoặc Gem.
  Future<bool> buyCatCharacter({
    required String catId,
    int coinCost = 0,
    int gemCost = 0,
  }) async {
    final normalized = AppAssets.normalizeCatFolderId(catId);
    if (isCatOwned(normalized)) return false;
    if (coinCost < 0 || gemCost < 0) return false;
    if (_progress.coins < coinCost || _progress.gems < gemCost) return false;
    if (!isAdminMode) {
      _progress.rawCoins = max(0, _progress.rawCoins - coinCost);
      _progress.rawGems = max(0, _progress.rawGems - gemCost);
    }
    if (!_progress.rawOwnedCatIds.contains(normalized)) {
      _progress.rawOwnedCatIds.add(normalized);
    }
    await _persist();
    return true;
  }

  /// Chọn Linh thú Mèo đại diện xuất hiện ở Phòng Mèo và thanh điều hướng.
  Future<bool> selectCatCharacter(String catId) async {
    final normalized = AppAssets.normalizeCatFolderId(catId);
    if (!isCatOwned(normalized) && !isAdminMode) return false;
    if (!_progress.rawOwnedCatIds.contains(normalized)) {
      _progress.rawOwnedCatIds.add(normalized);
    }
    if (_progress.selectedCatId == normalized) return true;
    _progress.selectedCatId = normalized;
    await _persist();
    return true;
  }

  /// Mua 1 món ăn cho mèo bằng Xu (vật phẩm tiêu hao, mua được nhiều lần).
  Future<bool> buyCatFood({
    required String assetPath,
    required int coinCost,
  }) async {
    if (coinCost < 0 || _progress.coins < coinCost) return false;
    if (!isAdminMode) {
      _progress.rawCoins = max(0, _progress.rawCoins - coinCost);
    }
    _progress.rawFoodInventory[assetPath] =
        (_progress.rawFoodInventory[assetPath] ?? 0) + 1;
    await _persist();
    return true;
  }

  /// Mua 1 bộ trang phục vĩnh viễn bằng Xu hoặc Gem (không thể mua trùng).
  Future<bool> buyCatOutfit({
    required String outfitPath,
    int coinCost = 0,
    int gemCost = 0,
  }) async {
    if (isOutfitOwned(outfitPath)) return false;
    if (coinCost < 0 || gemCost < 0) return false;
    if (_progress.coins < coinCost || _progress.gems < gemCost) return false;
    if (!isAdminMode) {
      _progress.rawCoins = max(0, _progress.rawCoins - coinCost);
      _progress.rawGems = max(0, _progress.rawGems - gemCost);
    }
    if (!_progress.rawOwnedOutfits.contains(outfitPath)) {
      _progress.rawOwnedOutfits.add(outfitPath);
    }
    await _persist();
    return true;
  }

  /// Mặc hoặc cởi trang phục đã sở hữu cho Mèo Hộ Pháp.
  Future<bool> equipCatOutfit(String? outfitPath) async {
    if (outfitPath != null && outfitPath.isNotEmpty) {
      if (!isOutfitOwned(outfitPath) && !isAdminMode) return false;
      _progress.equippedOutfit = outfitPath;
    } else {
      _progress.equippedOutfit = null;
    }
    await _persist();
    return true;
  }

  /// Cho mèo ăn 1 món từ Túi đồ cá nhân: trừ 1 số lượng và cộng chỉ số Độ no, Tâm trạng, Năng lượng.
  Future<bool> feedCat({
    required String assetPath,
    required int hungerBonus,
    required int moodBonus,
    int energyBonus = 0,
  }) async {
    final currentQty = foodCountFor(assetPath);
    if (currentQty <= 0) return false;
    if (!isAdminMode) {
      if (currentQty == 1) {
        _progress.rawFoodInventory.remove(assetPath);
      } else {
        _progress.rawFoodInventory[assetPath] = currentQty - 1;
      }
    }
    _progress.catHunger = (_progress.catHunger + hungerBonus).clamp(0, 100);
    _progress.catMood = (_progress.catMood + moodBonus).clamp(0, 100);
    _progress.catEnergy = (_progress.catEnergy + energyBonus).clamp(0, 100);
    await _persist();
    return true;
  }

  /// Cho mèo nghỉ ngơi để hồi phục Năng lượng và Tâm trạng.
  Future<void> restCat({int energyBonus = 20, int moodBonus = 5}) async {
    _progress.catEnergy = (_progress.catEnergy + energyBonus).clamp(0, 100);
    _progress.catMood = (_progress.catMood + moodBonus).clamp(0, 100);
    await _persist();
  }

  /// Hao mòn Thể lực Mèo Hộ Pháp (Energy Drain) khi học Flashcard (-1), làm bài Test (-5), hoặc hoàn thành Pomodoro (-1/phút).
  Future<int> drainCatEnergy(int amount, {bool notify = true}) async {
    if (amount <= 0) return _progress.catEnergy;
    _progress.catEnergy = (_progress.catEnergy - amount).clamp(0, 100);
    await _persist(notify: notify);
    return _progress.catEnergy;
  }

  /// Phạt trừ Xu khi vi phạm Anti-Cheat Pomodoro (tối thiểu về 0, không âm).
  Future<int> penalizeCoins(int amount) async {
    if (amount <= 0) return _progress.coins;
    _progress.rawCoins = max(0, _progress.rawCoins - amount);
    await _persist();
    return _progress.coins;
  }

  /// Thưởng Xu, Gem và EXP khi hoàn thành Pomodoro hoặc Đề thi JLPT.
  Future<void> rewardCoinsAndGems({
    int coins = 0,
    int gems = 0,
    int xp = 0,
  }) async {
    if (coins > 0) _progress.rawCoins += coins;
    if (gems > 0) _progress.rawGems += gems;
    if (xp > 0) {
      addXP(xp, notify: false);
    }
    await _persist();
  }

  Future<void> setCatCompanionEnabled(bool enabled) async {
    if (_progress.catCompanionEnabled == enabled) return;
    _progress.catCompanionEnabled = enabled;
    await _persist();
  }

  Future<void> setCatCompanionScale(double scale) async {
    final clamped = scale.clamp(0.60, 1.30);
    if ((_progress.catCompanionScale - clamped).abs() < 0.005) return;
    _progress.catCompanionScale = clamped;
    await _persist();
  }

  /// Cập nhật thông tin Hồ sơ & Quyền riêng tư (Avatar 1:1 < 500KB, Giới tính, Chữ ký Bio, Danh hiệu, các công tắc hiển thị).
  Future<void> updateProfileAndPrivacy({
    String? avatarBase64,
    bool clearAvatar = false,
    String? gender,
    String? bio,
    String? selectedTitle,
    bool? showBio,
    bool? showVip,
    bool? showStreak,
  }) async {
    if (clearAvatar) {
      _progress.avatarBase64 = null;
    } else if (avatarBase64 != null) {
      _progress.avatarBase64 = avatarBase64.trim().isEmpty ? null : avatarBase64.trim();
    }
    if (gender != null && gender.trim().isNotEmpty) {
      _progress.gender = gender.trim();
    }
    if (bio != null) {
      _progress.bio = bio.trim();
    }
    if (selectedTitle != null && selectedTitle.trim().isNotEmpty) {
      _progress.selectedTitle = selectedTitle.trim();
    }
    if (showBio != null) {
      _progress.showBio = showBio;
    }
    if (showVip != null) {
      _progress.showVip = showVip;
    }
    if (showStreak != null) {
      _progress.showStreak = showStreak;
    }
    await _persist();
  }

  /// Cập nhật kết quả trận đấu Mèo Nổ PK (+20 MR khi thắng, 0 MR khi thua thường/solo, -15 MR khi thua đấu Rank hoặc thoát giữa trận).
  Future<int> recordPkMatchResult({
    required String mode,
    required bool isWin,
    bool quitEarly = false,
  }) async {
    int mrDelta = 0;
    if (quitEarly) {
      mrDelta = -15;
    } else if (isWin) {
      mrDelta = 20;
    } else if (mode == 'ranked') {
      mrDelta = -15;
    } else {
      mrDelta = 0;
    }
    _progress.pkRating = max(0, _progress.pkRating + mrDelta);
    _progress.pkMatches += 1;
    if (isWin && !quitEarly) {
      _progress.pkWins += 1;
      _progress.rawCoins += 5;
      addXP(15, notify: false);
    }
    await _persist();
    return mrDelta;
  }

  Future<void> _persist({bool notify = true}) async {
    await _saveProgress();
    unawaited(_syncRemoteProgress());
    if (notify) notifyListeners();
  }

  List<Map<String, dynamic>> get sortedTestHistory {
    final items = [..._progress.testHistory];
    items.sort((a, b) {
      final aDate = DateTime.tryParse((a['date'] ?? '').toString()) ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bDate = DateTime.tryParse((b['date'] ?? '').toString()) ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bDate.compareTo(aDate);
    });
    return items;
  }

  Future<void> syncRemoteProgress() => _syncRemoteProgress();

  Future<void> reloadForCurrentUser({bool preferRemote = true, bool? isAdmin}) async {
    _adminAccountActive = isAdmin ?? _detectAdminFromSession();
    _loadProgress();
    final previousOwner = _prefs?.getString(_progressOwnerKey);
    _checkStreak();
    _ensureFreshDailyState();
    var restored = false;
    if (preferRemote && !isAdminAccount) {
      restored = await _restoreRemoteProgressIfAvailable();
    }
    if (!restored && _shouldResetForCurrentUser(previousOwner)) {
      final savedTheme = _prefs?.getString('global_selected_theme_id') ??
          _prefs?.getString('selected_theme_id') ??
          AppTheme.activeThemeId;
      _progress = UserProgress(
        adminUnlimited: isAdminMode,
        selectedThemeId: savedTheme,
      );
      _dailyTasks = _generateDailyTasks(_todayKey());
      await _saveProgress();
    }
    _progress.adminUnlimited = isAdminMode;
    AppTheme.setActiveTheme(_progress.selectedThemeId);
    await _syncRemoteProgress();
    notifyListeners();
  }

  Future<void> useGuestState() async {
    _adminAccountActive = false;
    final savedTheme = _prefs?.getString('global_selected_theme_id') ??
        _prefs?.getString('selected_theme_id') ??
        _progress.selectedThemeId;
    _progress = UserProgress(
      adminUnlimited: false,
      selectedThemeId: savedTheme,
    );
    AppTheme.setActiveTheme(savedTheme);
    _dailyTasks = _generateDailyTasks(_todayKey());
    await _saveProgress();
    notifyListeners();
  }

  Future<bool> _restoreRemoteProgressIfAvailable() async {
    if (!FirebaseService.isEnabled || isAdminAccount) return false;
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return false;

    try {
      final remote = await _firestoreService.fetchUserProgressData(currentUser.uid);
      if (remote == null || remote.isEmpty) return false;
      final remoteSchemaVersion = _readInt(remote['schemaVersion'], fallback: 1);
      if (remoteSchemaVersion < LocalDatabaseService.databaseVersion) {
        return false;
      }
      _applyRemoteProgress(remote);
      await _saveProgress();
      return true;
    } catch (_) {
      return false;
    }
  }

  void _applyRemoteProgress(Map<String, dynamic> data) {
    List<Map<String, dynamic>> parsedHistory = <Map<String, dynamic>>[];
    final rawHistory = data['testHistory'];
    if (rawHistory is List) {
      parsedHistory = rawHistory
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    }

    _progress = UserProgress(
      totalXP: _readInt(data['totalXP']),
      currentStreak: _readInt(data['currentStreak']),
      longestStreak: _readInt(data['longestStreak']),
      selectedLevel: _readString(data['selectedLevel'], fallback: 'N5'),
      dailyGoal: _readInt(data['dailyGoal'], fallback: 50),
      todayXP: _readInt(data['todayXP']),
      learnedVocabIds: _readStringSet(data['learnedVocabIds']),
      learnedKanjiIds: _readStringSet(data['learnedKanjiIds']),
      favoriteVocabIds: _readStringSet(data['favoriteVocabIds']),
      favoriteKanjiIds: _readStringSet(data['favoriteKanjiIds']),
      unlockedAchievements: _readStringSet(data['unlockedAchievements']),
      testHistory: parsedHistory,
      coins: _readInt(data['coins']),
      gems: _readInt(data['gems']),
      adminUnlimited: isAdminMode,
      vocabStudyDay: data['vocabStudyDay'] is String ? data['vocabStudyDay'] as String : null,
      dailyReviewClaimDay:
          data['dailyReviewClaimDay'] is String ? data['dailyReviewClaimDay'] as String : null,
      mapLevelStars: _decodeStars(data['mapLevelStars']),
      mapPracticeRewarded: _readStringSet(data['mapPracticeRewarded']),
      foodInventory: data.containsKey('foodInventory')
          ? _decodeFoodInventory(data['foodInventory'])
          : UserProgress.defaultStarterFoodInventory(),
      ownedOutfits: _readStringSet(data['ownedOutfits']).toList(),
      equippedOutfit: data['equippedOutfit'] is String && (data['equippedOutfit'] as String).isNotEmpty
          ? data['equippedOutfit'] as String
          : null,
      unlockedThemeIds: _readStringSet(data['unlockedThemeIds']).toList(),
      selectedThemeId: _readString(data['selectedThemeId'], fallback: 'dusty_rose'),
      ownedCatIds: _readStringSet(data['ownedCatIds']).toList(),
      selectedCatId: _readString(data['selectedCatId'], fallback: AppAssets.defaultCatId),
      catHunger: _readInt(data['catHunger'], fallback: 75).clamp(0, 100),
      catEnergy: _readInt(data['catEnergy'], fallback: 80).clamp(0, 100),
      catMood: _readInt(data['catMood'], fallback: 85).clamp(0, 100),
      catCompanionEnabled: data['catCompanionEnabled'] is bool ? data['catCompanionEnabled'] as bool : true,
      catCompanionScale: data['catCompanionScale'] is num
          ? (data['catCompanionScale'] as num).toDouble().clamp(0.60, 1.30)
          : 1.0,
      pkRating: max(0, _readInt(data['pkRating'], fallback: 720)),
      pkWins: max(0, _readInt(data['pkWins'], fallback: 28)),
      pkMatches: max(0, _readInt(data['pkMatches'], fallback: 42)),
      avatarBase64: data['avatarBase64'] is String && (data['avatarBase64'] as String).isNotEmpty
          ? data['avatarBase64'] as String
          : null,
      gender: _readString(data['gender'], fallback: 'Bí mật'),
      bio: _readString(data['bio'], fallback: 'Chiến thần N3 quyết tâm chinh phục JLPT! 🌸'),
      selectedTitle: _readString(data['selectedTitle'], fallback: 'Tân Binh Nihongo'),
      showBio: data['showBio'] is bool ? data['showBio'] as bool : true,
      showVip: data['showVip'] is bool ? data['showVip'] as bool : true,
      showStreak: data['showStreak'] is bool ? data['showStreak'] as bool : true,
    );

    final lastStudyRaw = data['lastStudyDate'];
    if (lastStudyRaw is String && lastStudyRaw.isNotEmpty) {
      _progress.lastStudyDate = DateTime.tryParse(lastStudyRaw);
    }

    _dailyTasks = [];
    final rawTasks = data['dailyTasks'];
    if (rawTasks is List) {
      _dailyTasks = rawTasks
          .whereType<Map>()
          .map((item) => DailyTask.fromMap(Map<String, dynamic>.from(item)))
          .toList();
    }

    _ensureFreshDailyState();
  }

  int _readInt(dynamic value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value) ?? fallback;
    return fallback;
  }

  String _readString(dynamic value, {String fallback = ''}) {
    if (value is String) {
      final trimmed = value.trim();
      if (trimmed.isNotEmpty) return trimmed;
    }
    return fallback;
  }

  Set<String> _readStringSet(dynamic value) {
    if (value is List) {
      return value
          .map((item) => item.toString().trim())
          .where((item) => item.isNotEmpty)
          .toSet();
    }
    return <String>{};
  }

  bool _shouldResetForCurrentUser(String? storedOwner) {
    if (!FirebaseService.isEnabled) return false;
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return false;
    return storedOwner != null && storedOwner.isNotEmpty && storedOwner != currentUser.uid;
  }

  Map<String, dynamic> _buildRemoteProgressPayload() {
    final history = _progress.testHistory.length <= 250
        ? _progress.testHistory
        : _progress.testHistory.sublist(_progress.testHistory.length - 250);
    return {
      'schemaVersion': LocalDatabaseService.databaseVersion,
      'totalXP': _progress.totalXP,
      'currentStreak': _progress.currentStreak,
      'longestStreak': _progress.longestStreak,
      'selectedLevel': _progress.selectedLevel,
      'dailyGoal': _progress.dailyGoal,
      'todayXP': _progress.todayXP,
      'lastStudyDate': _progress.lastStudyDate?.toIso8601String(),
      'learnedVocabIds': _progress.learnedVocabIds.toList(),
      'learnedKanjiIds': _progress.learnedKanjiIds.toList(),
      'favoriteVocabIds': _progress.favoriteVocabIds.toList(),
      'favoriteKanjiIds': _progress.favoriteKanjiIds.toList(),
      'unlockedAchievements': _progress.unlockedAchievements.toList(),
      'testHistory': history,
      'dailyTasks': _dailyTasks.map((task) => task.toMap()).toList(),
      'coins': _progress.rawCoins,
      'gems': _progress.rawGems,
      'vocabStudyDay': _progress.vocabStudyDay,
      'dailyReviewClaimDay': _progress.dailyReviewClaimDay,
      'mapLevelStars': _progress.mapLevelStars,
      'mapPracticeRewarded': _progress.mapPracticeRewarded.toList(),
      'foodInventory': _progress.rawFoodInventory,
      'ownedOutfits': _progress.rawOwnedOutfits,
      'equippedOutfit': _progress.equippedOutfit,
      'unlockedThemeIds': _progress.rawUnlockedThemeIds,
      'selectedThemeId': _progress.selectedThemeId,
      'ownedCatIds': _progress.rawOwnedCatIds,
      'selectedCatId': _progress.selectedCatId,
      'catHunger': _progress.catHunger,
      'catEnergy': _progress.catEnergy,
      'catMood': _progress.catMood,
      'catCompanionEnabled': _progress.catCompanionEnabled,
      'catCompanionScale': _progress.catCompanionScale,
      'pkRating': _progress.pkRating,
      'pkWins': _progress.pkWins,
      'pkMatches': _progress.pkMatches,
      'avatarBase64': _progress.avatarBase64,
      'gender': _progress.gender,
      'bio': _progress.bio,
      'selectedTitle': _progress.selectedTitle,
      'showBio': _progress.showBio,
      'showVip': _progress.showVip,
      'showStreak': _progress.showStreak,
    };
  }

  Future<void> _syncRemoteProgress() async {
    if (!FirebaseService.isEnabled || isAdminAccount) return;
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    try {
      await _firestoreService.syncUserProgressStats(
        totalXp: _progress.totalXP,
        currentStreak: _progress.currentStreak,
        longestStreak: _progress.longestStreak,
        learnedVocabCount: _progress.learnedVocabIds.length,
        learnedKanjiCount: _progress.learnedKanjiIds.length,
        achievementCount: _progress.unlockedAchievements.length,
        todayXp: _progress.todayXP,
        userLevel: _progress.userLevel,
        selectedJlptLevel: _progress.selectedLevel,
      );
      await _firestoreService.saveUserProgressData(
        uid: currentUser.uid,
        data: _buildRemoteProgressPayload(),
      );
      final displayName = (currentUser.displayName?.trim().isNotEmpty ?? false)
          ? currentUser.displayName!.trim()
          : (currentUser.email?.split('@').first ?? 'Học viên NihonGo');
      await _firestoreService.syncWeeklyMonthlyLeaderboard(
        uid: currentUser.uid,
        displayName: displayName,
        totalXp: _progress.totalXP,
        currentStreak: _progress.currentStreak,
        userLevel: _progress.userLevel,
        learnedVocabCount: _progress.learnedVocabIds.length,
        learnedKanjiCount: _progress.learnedKanjiIds.length,
        selectedJlptLevel: _progress.selectedLevel,
      );
    } catch (_) {}
  }

  void addXP(int amount, {bool trackDailyTask = true, bool notify = true}) {
    if (amount <= 0) return;
    _ensureFreshDailyState();
    final previousLevel = _progress.userLevel;
    _progress.totalXP += amount;
    _progress.todayXP += amount;
    _updateStudyStreak();
    if (trackDailyTask) {
      _updateDailyTaskProgress('earn_xp', by: amount);
    }
    if (_progress.userLevel > previousLevel) {
      
    }
    unawaited(_persist(notify: notify));
  }

  void _updateStudyStreak() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (_progress.lastStudyDate == null) {
      _progress.currentStreak = 1;
      _progress.longestStreak = max(_progress.longestStreak, 1);
      _progress.lastStudyDate = today;
      return;
    }

    final last = DateTime(
      _progress.lastStudyDate!.year,
      _progress.lastStudyDate!.month,
      _progress.lastStudyDate!.day,
    );
    final diff = today.difference(last).inDays;
    if (diff == 0) return;
    if (diff == 1) {
      _progress.currentStreak++;
      _progress.lastStudyDate = today;
      if (_progress.currentStreak > _progress.longestStreak) {
        _progress.longestStreak = _progress.currentStreak;
      }
      if (_progress.currentStreak % 7 == 0) {
        _progress.totalXP += AppConstants.xpDailyStreak;
        _unlockAchievement('streak_7');
      }
      if (_progress.currentStreak >= 30) {
        _unlockAchievement('streak_30');
      }
      return;
    }

    _progress.currentStreak = 1;
    _progress.lastStudyDate = today;
    _progress.longestStreak = max(_progress.longestStreak, 1);
  }

  void _updateDailyTaskProgress(String type, {int by = 1}) {
    if (by <= 0) return;
    _ensureFreshDailyState();
    _dailyTasks = _dailyTasks.map((task) {
      if (task.type != type || task.isClaimed || task.isCompleted) {
        return task;
      }
      final nextProgress = min(task.target, task.progress + by);
      return task.copyWith(progress: nextProgress);
    }).toList();
  }

  Future<bool> claimDailyTask(String taskId) async {
    _ensureFreshDailyState();
    final index = _dailyTasks.indexWhere((task) => task.id == taskId);
    if (index == -1) return false;

    final task = _dailyTasks[index];
    if (!task.isCompleted || task.isClaimed) return false;

    _dailyTasks[index] = task.copyWith(isClaimed: true);
    addXP(task.rewardXp, trackDailyTask: false, notify: false);
    await _persist();
    return true;
  }

  void markVocabLearned(String id) {
    if (_progress.learnedVocabIds.contains(id)) {
      return;
    }
    String lv = _progress.selectedLevel.trim().toUpperCase();
    for (final w in VocabularyData.getAllWords()) {
      if (w.id == id && w.jlptLevel.trim().isNotEmpty) {
        lv = w.jlptLevel.trim().toUpperCase();
        break;
      }
    }
    _adaptiveQuestProgress['adaptive_vocab_$lv'] =
        (_adaptiveQuestProgress['adaptive_vocab_$lv'] ?? 0) + 1;
    _progress.learnedVocabIds.add(id);
    _progress.vocabStudyDay = _todayKey();
    _progress.catEnergy = (_progress.catEnergy - 1).clamp(0, 100);
    _updateDailyTaskProgress('learn_vocab');
    addXP(AppConstants.xpVocabLearn, notify: false);
    _checkVocabAchievements();
    unawaited(_persist());
  }

  void addVocabularyProgress(String id) => markVocabLearned(id);

  void markKanjiLearned(String id) {
    if (_progress.learnedKanjiIds.contains(id)) {
      return;
    }
    String lv = _progress.selectedLevel.trim().toUpperCase();
    for (final k in KanjiData.getAllKanji()) {
      if (k.id == id && k.jlptLevel.trim().isNotEmpty) {
        lv = k.jlptLevel.trim().toUpperCase();
        break;
      }
    }
    _adaptiveQuestProgress['adaptive_kanji_$lv'] =
        (_adaptiveQuestProgress['adaptive_kanji_$lv'] ?? 0) + 1;
    _progress.learnedKanjiIds.add(id);
    _progress.catEnergy = (_progress.catEnergy - 1).clamp(0, 100);
    _updateDailyTaskProgress('learn_kanji');
    addXP(AppConstants.xpKanjiLearn, notify: false);
    if (_progress.learnedKanjiIds.length >= 50) {
      _unlockAchievement('kanji_50');
    }
    unawaited(_persist());
  }

  void addKanjiProgress(String id) => markKanjiLearned(id);

  void toggleFavoriteVocab(String id) {
    if (_progress.favoriteVocabIds.contains(id)) {
      _progress.favoriteVocabIds.remove(id);
    } else {
      _progress.favoriteVocabIds.add(id);
    }
    unawaited(_persist());
  }

  void toggleFavoriteKanji(String id) {
    if (_progress.favoriteKanjiIds.contains(id)) {
      _progress.favoriteKanjiIds.remove(id);
    } else {
      _progress.favoriteKanjiIds.add(id);
    }
    unawaited(_persist());
  }

  void recordTestResult(
    String level,
    int correct,
    int total, {
    String title = 'JLPT Test',
    String mode = 'jlpt',
    double? playbackRate,
  }) {
    if (total <= 0) return;
    _ensureFreshDailyState();

    final score = correct / total * 100;
    _progress.catEnergy = (_progress.catEnergy - 5).clamp(0, 100);
    addXP(AppConstants.xpTestComplete, notify: false);
    _updateDailyTaskProgress('complete_test');

    final normLv = level.trim().toUpperCase();
    if (mode == 'pronunciation_ai' ||
        mode == 'pronunciation_self_practice' ||
        mode == 'listening') {
      _adaptiveQuestProgress['adaptive_listening_$normLv'] =
          (_adaptiveQuestProgress['adaptive_listening_$normLv'] ?? 0) + 1;
      if (mode == 'pronunciation_ai') {
        _updateDailyTaskProgress('finish_pronunciation');
      }
    }
    if (mode == 'writing_ai') {
      _updateDailyTaskProgress('finish_writing');
    }

    if (score == 100) {
      addXP(AppConstants.xpPerfectScore, notify: false);
      _updateDailyTaskProgress('perfect_test');
      _unlockAchievement('perfect_test');
    }

    _progress.testHistory.add({
      'level': level,
      'title': title,
      'mode': mode,
      'correct': correct,
      'wrong': total - correct,
      'total': total,
      'score': score,
      'playbackRate': playbackRate,
      'date': DateTime.now().toIso8601String(),
    });
    if (_progress.testHistory.length > 250) {
      _progress.testHistory.removeRange(0, _progress.testHistory.length - 250);
    }

    unawaited(_persist());
  }

  void _checkVocabAchievements() {
    final count = _progress.learnedVocabIds.length;
    if (count >= 1) _unlockAchievement('first_vocab');
    if (count >= 50) _unlockAchievement('vocab_50');
    if (count >= 100) _unlockAchievement('vocab_100');
  }

  void _unlockAchievement(String id) {
    if (_progress.unlockedAchievements.contains(id)) return;
    _progress.unlockedAchievements.add(id);
    final achievement = AppConstants.achievements.firstWhere(
      (a) => a['id'] == id,
      orElse: () => {},
    );
    if (achievement.isNotEmpty) {
      _progress.totalXP += (achievement['xp'] as int? ?? 0);
    }
  }

  void setSelectedLevel(String level) {
    _progress.selectedLevel = level;
    unawaited(_persist());
  }

  void setDailyGoal(int goal) {
    _progress.dailyGoal = goal;
    unawaited(_persist());
  }

  void resetProgress() {
    final savedTheme = _prefs?.getString('global_selected_theme_id') ??
        _prefs?.getString('selected_theme_id') ??
        _progress.selectedThemeId;
    _progress = UserProgress(
      adminUnlimited: isAdminMode,
      selectedThemeId: savedTheme,
    );
    AppTheme.setActiveTheme(savedTheme);
    _dailyTasks = _generateDailyTasks(_todayKey());
    unawaited(LocalDatabaseService.instance.clearUserProgressTables());
    unawaited(_persist());
  }

  Future<void> adminGrantResources({
    int coins = 0,
    int gems = 0,
    int xp = 0,
    int streak = 0,
  }) async {
    if (!isAdminAccount) return;
    if (coins != 0) _progress.rawCoins = max(0, _progress.rawCoins + coins);
    if (gems != 0) _progress.rawGems = max(0, _progress.rawGems + gems);
    if (xp > 0) {
      _progress.totalXP += xp;
      _progress.todayXP += xp;
    }
    if (streak > 0) {
      _progress.currentStreak += streak;
      _progress.longestStreak = max(_progress.longestStreak, _progress.currentStreak);
      _progress.lastStudyDate = DateTime.now();
    }
    await _persist();
  }

  Future<void> adminUnlockAllAchievements() async {
    if (!isAdminAccount) return;
    for (final a in AppConstants.achievements) {
      final id = a['id'] as String?;
      if (id != null && id.isNotEmpty) {
        _progress.unlockedAchievements.add(id);
      }
    }
    await _persist();
  }

  Future<void> adminSetAllMapStars({int stars = 3}) async {
    if (!isAdminAccount) return;
    final clamped = stars.clamp(0, 3);
    for (final level in const ['N5', 'N4', 'N3', 'N2', 'N1']) {
      for (final prefix in const ['vocab', 'kanji']) {
        for (var i = 1; i <= 10; i++) {
          final key = '$prefix:$level:$i';
          if (clamped == 0) {
            _progress.mapLevelStars.remove(key);
          } else {
            _progress.mapLevelStars[key] = clamped;
          }
        }
      }
    }
    await _persist();
  }

  bool isVocabLearned(String id) => _progress.learnedVocabIds.contains(id);
  bool isKanjiLearned(String id) => _progress.learnedKanjiIds.contains(id);
  bool isVocabFavorite(String id) => _progress.favoriteVocabIds.contains(id);
  bool isKanjiFavorite(String id) => _progress.favoriteKanjiIds.contains(id);

  /// Tạo danh sách 5 nhiệm vụ luyện tập thích ứng (Adaptive Quests) dựa trên
  /// dữ liệu học tập thực tế của người dùng ở cấp độ JLPT hiện tại.
  /// Mỗi nhiệm vụ có ID cố định theo cấp độ, không bao giờ sinh trùng vô hạn,
  /// và chỉ cho phép nhận thưởng đúng 1 lần khi hoàn thành.
  List<AdaptiveQuest> getAdaptiveQuests({
    String? levelOverride,
    int dueSrsCount = 0,
  }) {
    final lv = (levelOverride ?? _progress.selectedLevel).trim().toUpperCase();

    final vocabId = 'adaptive_vocab_$lv';
    final kanjiId = 'adaptive_kanji_$lv';
    final grammarId = 'adaptive_grammar_$lv';
    final readingId = 'adaptive_reading_$lv';
    final listeningId = 'adaptive_listening_$lv';

    final levelVocab = VocabularyData.getWordsByLevel(lv);
    final learnedVocabInLevel = levelVocab
        .where((w) => _progress.learnedVocabIds.contains(w.id))
        .length;
    final unlearnedVocabInLevel =
        max(0, levelVocab.length - learnedVocabInLevel);

    final levelKanji = KanjiData.getKanjiByLevel(lv);
    final learnedKanjiInLevel = levelKanji
        .where((k) => _progress.learnedKanjiIds.contains(k.id))
        .length;
    final unlearnedKanjiPreview = levelKanji
        .where((k) => !_progress.learnedKanjiIds.contains(k.id))
        .take(3)
        .map((k) => k.kanji)
        .join(', ');

    final levelGrammar = GrammarData.getLessonsByLevel(lv);
    final grammarPreview = levelGrammar.isNotEmpty
        ? ' (VD: ${levelGrammar.first.pattern})'
        : '';

    final levelReadings = ReadingMaterialData.getAllMaterials()
        .where((r) => r.level.trim().toUpperCase() == lv)
        .length;

    final vocabProg =
        max(_adaptiveQuestProgress[vocabId] ?? 0, learnedVocabInLevel)
            .clamp(0, 5);
    final kanjiProg =
        max(_adaptiveQuestProgress[kanjiId] ?? 0, learnedKanjiInLevel)
            .clamp(0, 3);
    final grammarProg = (_adaptiveQuestProgress[grammarId] ?? 0).clamp(0, 2);
    final readingProg = (_adaptiveQuestProgress[readingId] ?? 0).clamp(0, 1);
    final listeningProg =
        (_adaptiveQuestProgress[listeningId] ?? 0).clamp(0, 2);

    final vocabDesc = dueSrsCount > 0
        ? 'Bạn có $dueSrsCount thẻ SRS đến hạn ôn và từ vựng cấp $lv cần củng cố.'
        : (unlearnedVocabInLevel > 0
            ? 'Còn $unlearnedVocabInLevel từ cấp $lv chưa thuộc — ôn tập 5 từ vựng trọng tâm.'
            : 'Ôn tập 5 từ vựng trọng tâm cấp $lv qua Flashcard hoặc Quiz.');

    final kanjiDesc = unlearnedKanjiPreview.isNotEmpty
        ? 'Luyện viết và ghi nhớ 3 chữ Kanji chưa thuộc cấp $lv ($unlearnedKanjiPreview).'
        : 'Luyện viết và ghi nhớ 3 chữ Kanji chưa thuộc của cấp $lv.';

    final readingDesc = levelReadings > 0
        ? 'Đọc hiểu 1 đoạn văn tiếng Nhật cấp $lv có furigana và dịch nghĩa ($levelReadings bài hiện có).'
        : 'Đọc hiểu 1 tác phẩm văn học Aozora Bunko hoặc bài đọc phù hợp trình độ $lv.';

    return <AdaptiveQuest>[
      AdaptiveQuest(
        id: vocabId,
        title: 'Ôn từ vựng cần củng cố ($lv)',
        description: vocabDesc,
        skillType: 'vocab',
        level: lv,
        iconAsset: AppAssets.labVocab,
        currentProgress: vocabProg,
        targetCount: 5,
        xpReward: 25,
        coinReward: 5,
        isClaimed: _claimedAdaptiveQuestIds.contains(vocabId),
      ),
      AdaptiveQuest(
        id: kanjiId,
        title: 'Luyện Kanji chưa thuộc ($lv)',
        description: kanjiDesc,
        skillType: 'kanji',
        level: lv,
        iconAsset: AppAssets.labKanji,
        currentProgress: kanjiProg,
        targetCount: 3,
        xpReward: 30,
        coinReward: 5,
        isClaimed: _claimedAdaptiveQuestIds.contains(kanjiId),
      ),
      AdaptiveQuest(
        id: grammarId,
        title: 'Học mẫu ngữ pháp cấp $lv',
        description:
            'Xem và thực hành 2 mẫu câu ngữ pháp trọng tâm của trình độ $lv$grammarPreview.',
        skillType: 'grammar',
        level: lv,
        iconAsset: AppAssets.labGrammar,
        currentProgress: grammarProg,
        targetCount: 2,
        xpReward: 25,
        coinReward: 5,
        isClaimed: _claimedAdaptiveQuestIds.contains(grammarId),
      ),
      AdaptiveQuest(
        id: readingId,
        title: 'Đọc 1 bài phù hợp cấp $lv',
        description: readingDesc,
        skillType: 'reading',
        level: lv,
        iconAsset: AppAssets.labReadingBook,
        currentProgress: readingProg,
        targetCount: 1,
        xpReward: 30,
        coinReward: 5,
        isClaimed: _claimedAdaptiveQuestIds.contains(readingId),
      ),
      AdaptiveQuest(
        id: listeningId,
        title: 'Luyện nghe & phát âm ($lv)',
        description:
            'Nghe mẫu và hoàn thành 2 lượt luyện đọc/phát âm hoặc nghe hiểu cấp $lv.',
        skillType: 'listening',
        level: lv,
        iconAsset: AppAssets.labListening,
        currentProgress: listeningProg,
        targetCount: 2,
        xpReward: 25,
        coinReward: 5,
        isClaimed: _claimedAdaptiveQuestIds.contains(listeningId),
      ),
    ];
  }

  /// Cập nhật tiến độ thực tế cho nhiệm vụ thích ứng theo `skillType`
  /// (`vocab`, `kanji`, `grammar`, `reading`, `listening`).
  Future<void> recordAdaptiveQuestProgress(
    String skillType, {
    String? levelOverride,
    int step = 1,
  }) async {
    if (step <= 0) return;
    final lv = (levelOverride ?? _progress.selectedLevel).trim().toUpperCase();
    final key = 'adaptive_${skillType.trim().toLowerCase()}_$lv';
    _adaptiveQuestProgress[key] = (_adaptiveQuestProgress[key] ?? 0) + step;
    await _persist();
  }

  /// Nhận thưởng 1 lần duy nhất cho nhiệm vụ thích ứng đã hoàn thành.
  /// Trả về `false` nếu nhiệm vụ chưa hoàn thành hoặc đã nhận thưởng trước đó.
  Future<bool> claimAdaptiveQuestReward(
    String questId, {
    String? levelOverride,
  }) async {
    if (_claimedAdaptiveQuestIds.contains(questId)) {
      return false;
    }
    final quests = getAdaptiveQuests(levelOverride: levelOverride);
    AdaptiveQuest? target;
    for (final q in quests) {
      if (q.id == questId) {
        target = q;
        break;
      }
    }
    if (target == null || !target.isCompleted) {
      return false;
    }

    _claimedAdaptiveQuestIds.add(questId);
    _progress.rawCoins += target.coinReward;
    addXP(target.xpReward, trackDailyTask: false, notify: false);
    await _persist();
    return true;
  }
}
