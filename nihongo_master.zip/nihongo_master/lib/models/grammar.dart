import '../utils/content_fallback.dart';

class GrammarLesson {
  final String id;
  final String pattern;
  final String title;
  final String? titleVi;
  final String? titleEn;
  final String explanation;
  final String? explanationVi;
  final String? explanationEn;
  final String? formation;
  final String jlptLevel;
  final List<ExampleSentence> examples;
  final List<String> notes;
  bool isLearned;

  GrammarLesson({
    required this.id,
    required this.pattern,
    required this.title,
    this.titleVi,
    this.titleEn,
    required this.explanation,
    this.explanationVi,
    this.explanationEn,
    this.formation,
    required this.jlptLevel,
    required this.examples,
    this.notes = const [],
    this.isLearned = false,
  });

  String displayTitle({String language = 'vi'}) {
    return ContentFallback.resolveMeaning(
      meaningVi: titleVi,
      meaningEn: titleEn ?? title,
      language: language,
    );
  }

  String displayExplanation({String language = 'vi'}) {
    return ContentFallback.resolveExplanation(
      explanationVi: explanationVi,
      explanationEn: explanationEn ?? explanation,
      language: language,
    );
  }
}

class ExampleSentence {
  final String japanese;
  final String hiragana;
  final String vietnamese;
  final String english;

  const ExampleSentence({
    required this.japanese,
    required this.hiragana,
    required this.vietnamese,
    required this.english,
  });

  String displayTranslation({String language = 'vi'}) {
    return ContentFallback.resolveTranslation(
      translationVi: vietnamese,
      translationEn: english,
      language: language,
    );
  }
}
