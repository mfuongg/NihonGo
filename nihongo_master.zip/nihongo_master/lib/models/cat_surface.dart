import 'dart:math' as math;

/// Loại mặt phẳng mà Mèo Hộ Pháp có thể đứng lên.
enum CatSurfaceType {
  /// Viền trên thanh điều hướng dưới (vị trí mặc định, luôn tồn tại).
  bottomNav,

  /// Viền dưới vùng Header / AppBar.
  header,

  /// Mép trên một thẻ nội dung.
  card,

  /// Đường kẻ phân cách mảnh giữa các khu vực.
  divider,

  /// Mép bàn học.
  desk,

  /// Kệ sách.
  shelf,

  /// Bệ đứng / mặt phẳng tuỳ chỉnh khác.
  platform,
}

extension CatSurfaceTypeX on CatSurfaceType {
  /// Điểm ưu tiên khi chọn bề mặt (giống `priorityBonus` trong HTML).
  double get priorityBonus {
    switch (this) {
      case CatSurfaceType.desk:
      case CatSurfaceType.shelf:
      case CatSurfaceType.platform:
        return 14;
      case CatSurfaceType.card:
        return 6;
      case CatSurfaceType.divider:
        return 4;
      case CatSurfaceType.header:
      case CatSurfaceType.bottomNav:
        return 0;
    }
  }

  String get label {
    switch (this) {
      case CatSurfaceType.bottomNav:
        return 'Viền trên thanh điều hướng';
      case CatSurfaceType.header:
        return 'Viền dưới Header';
      case CatSurfaceType.card:
        return 'Mép trên thẻ';
      case CatSurfaceType.divider:
        return 'Đường kẻ phân cách';
      case CatSurfaceType.desk:
        return 'Mép bàn học';
      case CatSurfaceType.shelf:
        return 'Kệ sách';
      case CatSurfaceType.platform:
        return 'Bệ đứng';
    }
  }
}

/// Một đường ngang hợp lệ cho chân mèo, toạ độ trong hệ của lớp phủ mèo.
///
/// - [left], [y]: điểm bắt đầu của đường ngang (y = mặt phẳng chân mèo chạm vào).
/// - [width]: chiều dài đường ngang.
/// - [height]: chiều cao phần tử chứa bề mặt (dùng để biết vùng đứng / hiển thị).
class CatSurface {
  final String id;
  final CatSurfaceType type;
  final double left;
  final double y;
  final double width;
  final double height;
  final bool interactive;
  final String? label;

  const CatSurface({
    required this.id,
    required this.type,
    required this.left,
    required this.y,
    required this.width,
    this.height = 0,
    this.interactive = true,
    this.label,
  });

  double get right => left + width;

  /// Lề an toàn hai đầu đường ngang (`padX = min(14, 10% width)` như HTML).
  double get padX => math.min(14.0, width * 0.1);

  /// Đoạn chân mèo được phép đặt lên.
  double get xMin => left + padX;
  double get xMax => math.max(xMin, right - padX);

  double get priorityBonus => type.priorityBonus;

  String get displayLabel => label ?? type.label;

  @override
  String toString() =>
      'CatSurface($id, ${type.name}, y=${y.toStringAsFixed(1)}, x=[${xMin.toStringAsFixed(1)}..${xMax.toStringAsFixed(1)}])';
}
