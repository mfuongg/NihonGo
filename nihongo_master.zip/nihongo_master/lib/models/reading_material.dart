import '../utils/content_fallback.dart';

class ReadingMaterial {
  final String id;
  final String? originalLevel;
  final String level;
  final String category;
  final String title;
  final String? titleVi;
  final String? titleEn;
  final String japaneseTitle;
  final String? titleFurigana;
  final String? authorJp;
  final String? authorRomaji;
  final String summary;
  final String preview;
  final String content;
  final String? translationVi;
  final String? translationEn;
  final String? contentRubyJson;
  final String? sourceId;
  final String? licenseId;
  final String? sourceUrl;
  final bool hasAudio;
  final int estimatedMinutes;
  final List<String> tags;
  final bool isFeatured;

  const ReadingMaterial({
    required this.id,
    this.originalLevel,
    required this.level,
    required this.category,
    required this.title,
    this.titleVi,
    this.titleEn,
    required this.japaneseTitle,
    this.titleFurigana,
    this.authorJp,
    this.authorRomaji,
    required this.summary,
    required this.preview,
    required this.content,
    this.translationVi,
    this.translationEn,
    this.contentRubyJson,
    this.sourceId,
    this.licenseId,
    this.sourceUrl,
    this.hasAudio = false,
    required this.estimatedMinutes,
    required this.tags,
    this.isFeatured = false,
  });

  bool get isUnclassified => ContentFallback.isUnclassifiedLevel(originalLevel);

  String? get author =>
      (authorJp != null && authorJp!.trim().isNotEmpty) ? authorJp : authorRomaji;

  String displayLevelLabel({String language = 'vi'}) {
    return ContentFallback.resolveJlptLevelLabel(
      originalLevel,
      language: language,
    );
  }

  String displayTitle({String language = 'vi'}) {
    return ContentFallback.resolveMeaning(
      meaningVi: titleVi,
      meaningEn: titleEn ?? title,
      language: language,
    );
  }

  String displayTranslation({String language = 'vi'}) {
    return ContentFallback.resolveTranslation(
      translationVi: translationVi,
      translationEn: translationEn,
      language: language,
    );
  }
}

class CultureTopic {
  final String id;
  final String title;
  final String subtitle;
  final String icon;
  final String content;
  final List<String> keywords;

  const CultureTopic({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.content,
    required this.keywords,
  });
}
