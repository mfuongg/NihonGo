/// Trạng thái hoạt ảnh logic của Mèo Hộ Pháp.
///
/// Dự án chỉ có 5 asset WebP cho mỗi giống mèo (`idle`, `blink`, `happy`,
/// `thinking`, `sleep`), nên các trạng thái logic được ánh xạ về asset gần nhất
/// thay vì tạo asset mới.
enum CatAnimState {
  idle,
  blink,
  walk,
  drag,
  happy,
  thinking,
  studying,
  paused,
  relax,
  sleep,
}

extension CatAnimStateX on CatAnimState {
  /// Tên file animation trong `assets/study/cats/<catId>/<key>.webp`.
  String get assetKey {
    switch (this) {
      case CatAnimState.idle:
      case CatAnimState.walk:
      case CatAnimState.paused:
        return 'idle';
      case CatAnimState.blink:
      case CatAnimState.relax:
        return 'blink';
      case CatAnimState.happy:
        return 'happy';
      case CatAnimState.drag:
      case CatAnimState.thinking:
      case CatAnimState.studying:
        return 'thinking';
      case CatAnimState.sleep:
        return 'sleep';
    }
  }

  /// Trạng thái có nhún nhảy theo bước chân hay không.
  bool get isWalking => this == CatAnimState.walk;
}
