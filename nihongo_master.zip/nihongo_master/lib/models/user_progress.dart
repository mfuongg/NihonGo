import '../widgets/app_asset_icon.dart';

class UserProgress {
  static const int adminUnlimitedBalance = 999999;

  static const List<String> allCatIds = <String>[
    'img_6883',
    'img_6831_2',
    'img_6832_2',
    'img_6839_2',
    'img_6836_2',
  ];

  static const List<String> allThemeIds = <String>[
    'dusty_rose',
    'ocean_blue',
    'sky_butter',
    'white_sage',
    'cyber_midnight',
    'royal_palace',
  ];

  static List<String> get allFoodAssets => <String>[
        ...AppAssets.dishes,
        ...AppAssets.fruits,
        ...AppAssets.seafoodList,
      ];

  static Map<String, int> defaultStarterFoodInventory() => <String, int>{
        AppFoods.fruitApple: 2,
        AppFoods.dishFishCake: 1,
      };

  static List<String> defaultUnlockedThemes() => <String>[
        'dusty_rose',
        'ocean_blue',
        'sky_butter',
        'white_sage',
      ];

  static List<String> defaultOwnedCats() => <String>[
        AppAssets.defaultCatId,
      ];

  int totalXP;
  int currentStreak;
  int longestStreak;
  DateTime? lastStudyDate;
  Set<String> learnedVocabIds;
  Set<String> learnedKanjiIds;
  Set<String> favoriteVocabIds;
  Set<String> favoriteKanjiIds;
  Set<String> unlockedAchievements;
  List<Map<String, dynamic>> testHistory;
  String selectedLevel;
  int dailyGoal;
  int todayXP;
  Map<String, int> categoryProgress;
  int rawCoins;
  int rawGems;
  bool adminUnlimited;
  String? vocabStudyDay;
  String? dailyReviewClaimDay;
  Map<String, int> mapLevelStars;
  Set<String> mapPracticeRewarded;

  // Cat Room, Food Inventory (36 items), Outfits (32 items), Themes (6 items), Cats (24 items) & Cat Vitals
  Map<String, int> rawFoodInventory;
  List<String> rawOwnedOutfits;
  String? equippedOutfit;
  List<String> rawUnlockedThemeIds;
  String selectedThemeId;
  List<String> rawOwnedCatIds;
  String selectedCatId;
  int catHunger;
  int catEnergy;
  int catMood;
  bool catCompanionEnabled;
  double catCompanionScale;

  // Mèo Nổ PK (Match Rating & Battle Stats)
  int pkRating;
  int pkWins;
  int pkMatches;

  // Hồ sơ & Quyền riêng tư (Profile & Privacy - Phase 2G)
  String? avatarBase64;
  String gender;
  String bio;
  String selectedTitle;
  bool showBio;
  bool showVip;
  bool showStreak;

  static const List<String> allAvailableTitles = <String>[
    'Tân Binh Nihongo',
    'Chiến Thần Từ Vựng',
    'Thợ Săn Kanji',
    'Kẻ Hủy Diệt Đề Thi',
    'Mèo Tinh Anh Học Thuật',
    'Đại Sư Ngôn Ngữ',
    'Thần Mèo Đại Chiến',
  ];

  UserProgress({
    this.totalXP = 0,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.lastStudyDate,
    Set<String>? learnedVocabIds,
    Set<String>? learnedKanjiIds,
    Set<String>? favoriteVocabIds,
    Set<String>? favoriteKanjiIds,
    Set<String>? unlockedAchievements,
    List<Map<String, dynamic>>? testHistory,
    this.selectedLevel = 'N5',
    this.dailyGoal = 50,
    this.todayXP = 0,
    Map<String, int>? categoryProgress,
    int coins = 0,
    int gems = 0,
    this.adminUnlimited = false,
    this.vocabStudyDay,
    this.dailyReviewClaimDay,
    Map<String, int>? mapLevelStars,
    Set<String>? mapPracticeRewarded,
    Map<String, int>? foodInventory,
    List<String>? ownedOutfits,
    this.equippedOutfit,
    List<String>? unlockedThemeIds,
    this.selectedThemeId = 'dusty_rose',
    List<String>? ownedCatIds,
    String selectedCatId = AppAssets.defaultCatId,
    this.catHunger = 75,
    this.catEnergy = 80,
    this.catMood = 85,
    this.catCompanionEnabled = true,
    this.catCompanionScale = 1.0,
    this.pkRating = 720,
    this.pkWins = 28,
    this.pkMatches = 42,
    this.avatarBase64,
    this.gender = 'Bí mật',
    this.bio = 'Chiến thần N3 quyết tâm chinh phục JLPT! 🌸',
    this.selectedTitle = 'Tân Binh Nihongo',
    this.showBio = true,
    this.showVip = true,
    this.showStreak = true,
  })  : rawCoins = coins,
        rawGems = gems,
        mapLevelStars = mapLevelStars ?? {},
        mapPracticeRewarded = mapPracticeRewarded ?? {},
        rawFoodInventory = foodInventory ?? defaultStarterFoodInventory(),
        rawOwnedOutfits = ownedOutfits ?? <String>[],
        rawUnlockedThemeIds = _normalizeUnlockedThemes(unlockedThemeIds),
        rawOwnedCatIds = _normalizeOwnedCats(ownedCatIds),
        selectedCatId = AppAssets.normalizeCatFolderId(selectedCatId),
        learnedVocabIds = learnedVocabIds ?? {},
        learnedKanjiIds = learnedKanjiIds ?? {},
        favoriteVocabIds = favoriteVocabIds ?? {},
        favoriteKanjiIds = favoriteKanjiIds ?? {},
        unlockedAchievements = unlockedAchievements ?? {},
        testHistory = testHistory ?? [],
        categoryProgress = categoryProgress ?? {};

  Map<String, int> get foodInventory {
    if (!adminUnlimited) return rawFoodInventory;
    final godFood = <String, int>{};
    for (final path in allFoodAssets) {
      final rawQty = rawFoodInventory[path] ?? 0;
      godFood[path] = rawQty > 99 ? rawQty : 99;
    }
    return godFood;
  }

  set foodInventory(Map<String, int> value) => rawFoodInventory = value;

  List<String> get ownedOutfits =>
      adminUnlimited ? <String>[...AppAssets.outfits] : rawOwnedOutfits;

  set ownedOutfits(List<String> value) => rawOwnedOutfits = value;

  List<String> get unlockedThemeIds =>
      adminUnlimited ? <String>[...allThemeIds] : rawUnlockedThemeIds;

  set unlockedThemeIds(List<String> value) => rawUnlockedThemeIds = value;

  List<String> get ownedCatIds =>
      adminUnlimited ? <String>[...allCatIds] : rawOwnedCatIds;

  set ownedCatIds(List<String> value) => rawOwnedCatIds = value;

  List<String> get unlockedTitles {
    if (adminUnlimited) {
      final list = <String>[...allAvailableTitles];
      if (!list.contains(selectedTitle) && selectedTitle.isNotEmpty) {
        list.insert(0, selectedTitle);
      }
      return list;
    }
    final titles = <String>{
      'Tân Binh Nihongo',
      pkRankTitle,
    };
    if (learnedVocabIds.isNotEmpty || unlockedAchievements.contains('first_vocab')) {
      titles.add('Chiến Thần Từ Vựng');
    }
    if (learnedKanjiIds.isNotEmpty || unlockedAchievements.contains('kanji_50')) {
      titles.add('Thợ Săn Kanji');
    }
    if (testHistory.isNotEmpty || unlockedAchievements.contains('perfect_test')) {
      titles.add('Kẻ Hủy Diệt Đề Thi');
    }
    if (currentStreak >= 3 || pkRating >= 650) {
      titles.add('Mèo Tinh Anh Học Thuật');
    }
    if (userLevel >= 5 || pkRating >= 1600) {
      titles.add('Đại Sư Ngôn Ngữ');
    }
    if (selectedTitle.isNotEmpty) {
      titles.add(selectedTitle);
    }
    return titles.toList();
  }

  static List<String> _normalizeUnlockedThemes(List<String>? custom) {
    final merged = <String>[...defaultUnlockedThemes()];
    if (custom != null) {
      for (final item in custom) {
        final trimmed = item.trim();
        if (trimmed.isNotEmpty && !merged.contains(trimmed)) {
          merged.add(trimmed);
        }
      }
    }
    return merged;
  }

  static List<String> _normalizeOwnedCats(List<String>? custom) {
    final merged = <String>[...defaultOwnedCats()];
    if (custom != null) {
      for (final item in custom) {
        final normalized = AppAssets.normalizeCatFolderId(item);
        if (normalized.isNotEmpty && !merged.contains(normalized)) {
          merged.add(normalized);
        }
      }
    }
    return merged;
  }

  int get coins => adminUnlimited ? adminUnlimitedBalance : rawCoins;
  set coins(int value) => rawCoins = value;

  int get gems => adminUnlimited ? adminUnlimitedBalance : rawGems;
  set gems(int value) => rawGems = value;

  int get userLevel {
    if (totalXP >= 5000) return 7;
    if (totalXP >= 3500) return 6;
    if (totalXP >= 2000) return 5;
    if (totalXP >= 1000) return 4;
    if (totalXP >= 600) return 3;
    if (totalXP >= 300) return 2;
    if (totalXP >= 100) return 1;
    return 0;
  }

  int get xpForNextLevel {
    const thresholds = [100, 300, 600, 1000, 2000, 3500, 5000, 10000];
    if (userLevel >= thresholds.length) return thresholds.last;
    return thresholds[userLevel];
  }

  double get levelProgress {
    const thresholds = [0, 100, 300, 600, 1000, 2000, 3500, 5000];
    if (userLevel >= 7) return 1.0;
    final currentMin = thresholds[userLevel];
    final nextMin = xpForNextLevel;
    return (totalXP - currentMin) / (nextMin - currentMin);
  }

  double get dailyProgress {
    return (todayXP / dailyGoal).clamp(0.0, 1.0);
  }

  bool get isStreakAlive {
    if (lastStudyDate == null) return false;
    final now = DateTime.now();
    final diff = now.difference(lastStudyDate!).inDays;
    return diff <= 1;
  }

  int get pkWinRatePercent {
    if (pkMatches <= 0) return 0;
    return ((pkWins / pkMatches) * 100).round().clamp(0, 100);
  }

  String get pkRankTitle => pkRankTitleFor(pkRating);

  String get pkRankIcon => pkRankIconFor(pkRating);

  static String pkRankTitleFor(int mr) {
    if (mr >= 2000) return 'Thần Mèo Đại Chiến';
    if (mr >= 1600) return 'Đại Sư Ngôn Ngữ';
    if (mr >= 1200) return 'Chiến Thần Học Thuật';
    if (mr >= 900) return 'Cao Thủ Mèo Nổ';
    if (mr >= 650) return 'Mèo Tinh Anh';
    if (mr >= 400) return 'Mèo Phản Xạ';
    if (mr >= 200) return 'Mèo Nhanh Trí';
    return 'Mèo Tập Sự';
  }

  static String pkRankIconFor(int mr) {
    if (mr >= 2000) return AppAssets.rank07Mythic;
    if (mr >= 1200) return AppAssets.rank06Master;
    if (mr >= 900) return AppAssets.rank05Diamond;
    if (mr >= 650) return AppAssets.rank04Purple;
    if (mr >= 400) return AppAssets.rank03Gold;
    if (mr >= 200) return AppAssets.rank02Silver;
    return AppAssets.rank01Bronze;
  }
}
