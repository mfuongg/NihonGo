import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'providers/auth_provider.dart';
import 'providers/flashcard_provider.dart';
import 'providers/pomodoro_provider.dart';
import 'providers/progress_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/study_history_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/vocabulary_provider.dart';
import 'screens/onboarding/splash_screen.dart';
import 'services/firebase_service.dart';
import 'services/local_database_service.dart';
import 'services/notification_service.dart';
import 'services/tts_service.dart';
import 'theme/theme_refresh_scope.dart';
import 'utils/theme.dart';
import 'utils/web_dataset_bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final savedThemeId = prefs.getString(ThemeProvider.globalPrefsKey) ??
      prefs.getString(ThemeProvider.prefsKey) ??
      AppTheme.defaultThemeId;
  AppTheme.setActiveTheme(savedThemeId);

  await FirebaseService.initialize();
  if (!kIsWeb) {
    await LocalDatabaseService.instance
        .ensureListeningAndJlptDatasetsImportedAndLoaded();
    await NotificationService.instance.init();
  } else {
    await WebDatasetBootstrap.ensureLoadedForWeb();
  }
  try {
    await TtsService.instance.init();
  } catch (_) {}

  if (!kIsWeb) {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(NihonGoApp(initialThemeId: savedThemeId));
}

class NihonGoApp extends StatelessWidget {
  final String initialThemeId;

  const NihonGoApp({
    super.key,
    this.initialThemeId = AppTheme.defaultThemeId,
  });

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProxyProvider<AuthProvider, ProgressProvider>(
          create: (_) => ProgressProvider()..init(),
          update: (_, auth, progress) {
            final target = progress ?? ProgressProvider();
            if (auth.isLoggedIn && target.isAdminAccount != auth.isAdmin) {
              target.setAdminAccount(auth.isAdmin);
            }
            return target;
          },
        ),
        ChangeNotifierProvider(
          create: (_) => ThemeProvider(initialThemeId: initialThemeId)..init(),
        ),
        ChangeNotifierProxyProvider<ProgressProvider, PomodoroProvider>(
          create: (_) => PomodoroProvider()..init(),
          update: (_, progress, pomodoro) {
            final target = pomodoro ?? PomodoroProvider();
            target.bindProgressProvider(progress);
            return target;
          },
        ),
        ChangeNotifierProvider(create: (_) => SettingsProvider()..init()),
        ChangeNotifierProvider(create: (_) => VocabularyProvider()..init()),
        ChangeNotifierProvider(create: (_) => FlashcardProvider()),
        ChangeNotifierProvider(create: (_) => StudyHistoryProvider()..init(userId: 'guest')),
      ],
      child: Consumer3<SettingsProvider, ProgressProvider, ThemeProvider>(
        builder: (context, settings, progress, themeProvider, _) {
          final resolvedThemeId = progress.userProgress.selectedThemeId.isNotEmpty
              ? progress.userProgress.selectedThemeId
              : themeProvider.selectedThemeId;
          AppTheme.setActiveTheme(resolvedThemeId);
          final activeTheme = AppTheme.themeFor(resolvedThemeId);
          return MaterialApp(
            title: 'NihonGo Master',
            debugShowCheckedModeBanner: false,
            theme: activeTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: settings.isDarkMode ? ThemeMode.dark : ThemeMode.light,
            home: const SplashScreen(),
            builder: (context, child) => ThemeRefreshScope(
              themeId: '${AppTheme.activeThemeId}|${settings.isDarkMode}',
              child: _PhoneFrame(child: child),
            ),
          );
        },
      ),
    );
  }
}

class _PhoneFrame extends StatelessWidget {
  static const double maxWidth = 480;

  final Widget? child;

  const _PhoneFrame({required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    return Material(
      color: isDark ? const Color(0xFF1E191C) : theme.scaffoldBackgroundColor,
      child: Center(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth > maxWidth ? maxWidth : constraints.maxWidth;
            final framed = constraints.maxWidth > maxWidth;
            final media = MediaQuery.of(context);
            return Container(
              width: width,
              height: constraints.maxHeight,
              decoration: BoxDecoration(
                color: theme.scaffoldBackgroundColor,
                boxShadow: framed
                    ? [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 24,
                          offset: const Offset(0, 4),
                        ),
                      ]
                    : null,
              ),
              clipBehavior: Clip.hardEdge,
              child: MediaQuery(
                data: media.copyWith(size: Size(width, constraints.maxHeight)),
                child: child ?? const SizedBox.shrink(),
              ),
            );
          },
        ),
      ),
    );
  }
}
