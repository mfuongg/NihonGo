import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/cat_anim_state.dart';
import '../../providers/progress_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/cat_dialogue_service.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/line_companion_cat.dart';
import '../lab/quang_thuong_tutor_screen.dart';

enum CatFoodCategory {
  all('Tất cả (10)'),
  fruits('Trái cây (4)'),
  dishes('Món chính (3)'),
  seafood('Hải sản thượng hạng (3)');

  final String label;
  const CatFoodCategory(this.label);
}

class CatFoodSpec {
  final String assetPath;
  final String name;
  final CatFoodCategory category;
  final int coinPrice;
  final int hungerBonus;
  final int moodBonus;
  final int energyBonus;

  const CatFoodSpec({
    required this.assetPath,
    required this.name,
    required this.category,
    required this.coinPrice,
    required this.hungerBonus,
    required this.moodBonus,
    this.energyBonus = 5,
  });

  String get effectSummary {
    final parts = <String>['+$hungerBonus% No', '+$moodBonus% Vui'];
    if (energyBonus > 0) {
      parts.add('+$energyBonus% NL');
    }
    return parts.join(' · ');
  }
}

class CatOutfitSpec {
  final int index;
  final String assetPath;
  final String name;
  final String rarity;
  final int coinPrice;
  final int gemPrice;

  const CatOutfitSpec({
    required this.index,
    required this.assetPath,
    required this.name,
    required this.rarity,
    this.coinPrice = 0,
    this.gemPrice = 0,
  });

  bool get isGemItem => gemPrice > 0;
}

class CatCharacterSpec {
  final String id;
  final String folderId;
  final String name;
  final String tier;
  final int coinPrice;
  final int gemPrice;
  final bool isDefault;

  const CatCharacterSpec({
    required this.id,
    required this.folderId,
    required this.name,
    required this.tier,
    this.coinPrice = 0,
    this.gemPrice = 0,
    this.isDefault = false,
  });

  bool get isGemCat => gemPrice > 0;
  bool get isGemItem => gemPrice > 0;
  bool get isFree => isDefault;
  String get idleAssetPath => AppAssets.catAnimation(folderId, 'idle');
}

class CatRoomSpot {
  final String id;
  final String name;
  final double fx;
  final double fy;

  const CatRoomSpot({
    required this.id,
    required this.name,
    required this.fx,
    required this.fy,
  });
}

class CatCatalog {
  CatCatalog._();

  /// 10 tọa độ snap nội thất chuẩn tỷ lệ trên `assets/room.png`
  static const List<CatRoomSpot> roomSpots = <CatRoomSpot>[
    CatRoomSpot(id: 'center_rug', name: 'Thảm Tròn Trung Tâm', fx: 0.50, fy: 0.84),
    CatRoomSpot(id: 'green_cushion', name: 'Đệm Ngủ Xanh Lá', fx: 0.13, fy: 0.82),
    CatRoomSpot(id: 'tea_table', name: 'Bàn Trà Gỗ', fx: 0.37, fy: 0.66),
    CatRoomSpot(id: 'bookshelf_top', name: 'Nóc Tủ Sách', fx: 0.16, fy: 0.42),
    CatRoomSpot(id: 'window_sill', name: 'Bệ Cửa Sổ Ngắm Hoa', fx: 0.48, fy: 0.50),
    CatRoomSpot(id: 'cat_tree_top', name: 'Đỉnh Trụ Cào Móng', fx: 0.73, fy: 0.34),
    CatRoomSpot(id: 'cat_tree_mid', name: 'Tầng Giữa Trụ Mèo', fx: 0.70, fy: 0.48),
    CatRoomSpot(id: 'cat_tree_box', name: 'Nhà Hộp Trụ Cào Móng', fx: 0.73, fy: 0.66),
    CatRoomSpot(id: 'yellow_bed', name: 'Đệm Ngủ Tai Mèo Vàng', fx: 0.87, fy: 0.70),
    CatRoomSpot(id: 'wall_shelf', name: 'Kệ Gỗ Treo Tường', fx: 0.86, fy: 0.36),
  ];

  /// Danh sách 5 Nhân vật Mèo Hộ Pháp đại diện kèm Tên tiếng Việt và Định giá Xu / Gem
  static const List<CatCharacterSpec> characters = <CatCharacterSpec>[
    // Linh Thú Mặc Định (Của người dùng từ đầu - Mở khóa sẵn)
    CatCharacterSpec(
      id: 'IMG_6883',
      folderId: 'img_6883',
      name: 'Chiến Thần Hào Quang',
      tier: 'Mặc Định',
      isDefault: true,
    ),
    // Hạng Phổ Thông (3 mèo đại diện — Bán bằng Coin/Xu: 200 – 350 Xu)
    CatCharacterSpec(
      id: 'IMG_6831_2',
      folderId: 'img_6831_2',
      name: 'Hắc Miêu Mắt Lờ Đờ',
      tier: 'Phổ Thông',
      coinPrice: 200,
    ),
    CatCharacterSpec(
      id: 'IMG_6832_2',
      folderId: 'img_6832_2',
      name: 'Hổ Báo Mẫu Giáo',
      tier: 'Phổ Thông',
      coinPrice: 250,
    ),
    CatCharacterSpec(
      id: 'IMG_6839_2',
      folderId: 'img_6839_2',
      name: 'Đàn Anh Socola',
      tier: 'Phổ Thông',
      coinPrice: 350,
    ),
    // Hạng Cao Cấp / Huyền Thoại (1 mèo đại diện — Bán bằng Gem/Kim Cương: 50 Gem)
    CatCharacterSpec(
      id: 'IMG_6836_2',
      folderId: 'img_6836_2',
      name: 'Ma Vương Khoai Môn',
      tier: 'Huyền Thoại',
      gemPrice: 50,
    ),
  ];

  static CatCharacterSpec findCharacter(String? catId) {
    final normalized = AppAssets.normalizeCatFolderId(catId ?? AppAssets.defaultCatId);
    for (final item in characters) {
      if (item.folderId == normalized || item.id.toLowerCase() == normalized) {
        return item;
      }
    }
    return characters.first;
  }

  static const List<CatFoodSpec> foods = <CatFoodSpec>[
    // 1. Nhóm Trái cây (AppFoods.fruits - 4 món đại diện): 5 – 10 Xu, +15% Độ no, +5% Tâm trạng
    CatFoodSpec(
      assetPath: AppFoods.fruitApple,
      name: 'Táo Đỏ Aomori',
      category: CatFoodCategory.fruits,
      coinPrice: 5,
      hungerBonus: 15,
      moodBonus: 5,
    ),
    CatFoodSpec(
      assetPath: AppFoods.fruitOrange,
      name: 'Quýt Mikan Ehime',
      category: CatFoodCategory.fruits,
      coinPrice: 6,
      hungerBonus: 15,
      moodBonus: 5,
    ),
    CatFoodSpec(
      assetPath: AppFoods.fruitStrawberry,
      name: 'Dâu Tây Amaou',
      category: CatFoodCategory.fruits,
      coinPrice: 8,
      hungerBonus: 15,
      moodBonus: 5,
    ),
    CatFoodSpec(
      assetPath: AppFoods.fruitWatermelon,
      name: 'Dưa Hấu Suika',
      category: CatFoodCategory.fruits,
      coinPrice: 10,
      hungerBonus: 15,
      moodBonus: 5,
    ),

    // 2. Nhóm Món chính (AppFoods.dishes - 3 món đại diện): 20 – 30 Xu, +40% Độ no, +15% Tâm trạng, +10% Năng lượng
    CatFoodSpec(
      assetPath: AppFoods.dishFishCake,
      name: 'Chả Cá Narutomaki',
      category: CatFoodCategory.dishes,
      coinPrice: 20,
      hungerBonus: 40,
      moodBonus: 15,
      energyBonus: 10,
    ),
    CatFoodSpec(
      assetPath: AppFoods.dishSushi,
      name: 'Sushi Trứng Tamago',
      category: CatFoodCategory.dishes,
      coinPrice: 25,
      hungerBonus: 40,
      moodBonus: 15,
      energyBonus: 10,
    ),
    CatFoodSpec(
      assetPath: AppFoods.dishGrilledFish,
      name: 'Cá Nướng Muối Shioyaki',
      category: CatFoodCategory.dishes,
      coinPrice: 30,
      hungerBonus: 40,
      moodBonus: 15,
      energyBonus: 10,
    ),

    // 3. Nhóm Hải sản thượng hạng (AppFoods.seafood - 3 món đại diện): 55 – 80 Xu, +80% Độ no, +40% Tâm trạng, +25% Năng lượng
    CatFoodSpec(
      assetPath: AppFoods.seafoodSalmon,
      name: 'Phi Lê Cá Hồi Toro',
      category: CatFoodCategory.seafood,
      coinPrice: 55,
      hungerBonus: 80,
      moodBonus: 40,
      energyBonus: 25,
    ),
    CatFoodSpec(
      assetPath: AppFoods.seafoodShrimp,
      name: 'Tôm Ngọt Amaebi',
      category: CatFoodCategory.seafood,
      coinPrice: 65,
      hungerBonus: 80,
      moodBonus: 40,
      energyBonus: 25,
    ),
    CatFoodSpec(
      assetPath: AppFoods.seafoodCrab,
      name: 'Cua Hoàng Đế Taraba',
      category: CatFoodCategory.seafood,
      coinPrice: 80,
      hungerBonus: 80,
      moodBonus: 40,
      energyBonus: 25,
    ),
  ];

  static final List<CatOutfitSpec> outfits = <CatOutfitSpec>[
    // 3 Bộ trang phục thường (100 – 250 Xu)
    CatOutfitSpec(index: 0, assetPath: AppAssets.outfits[0], name: 'Áo Thun Hồng Sakura', rarity: 'Thường', coinPrice: 100),
    CatOutfitSpec(index: 1, assetPath: AppAssets.outfits[1], name: 'Áo Sơ Mi Học Đường', rarity: 'Thường', coinPrice: 150),
    CatOutfitSpec(index: 2, assetPath: AppAssets.outfits[2], name: 'Áo Khoác Gió Mùa Xuân', rarity: 'Hiếm', coinPrice: 250),
    // 2 Bộ trang phục đặc biệt (Cyberpunk, Samurai — 55 – 75 Gem)
    CatOutfitSpec(index: 3, assetPath: AppAssets.outfits[3], name: 'Giáp Cyberpunk Neon 2099', rarity: 'Huyền Thoại', gemPrice: 55),
    CatOutfitSpec(index: 4, assetPath: AppAssets.outfits[4], name: 'Chiến Giáp Đại Tướng Samurai', rarity: 'Huyền Thoại', gemPrice: 75),
  ];

  static CatFoodSpec? findFood(String assetPath) {
    for (final item in foods) {
      if (item.assetPath == assetPath) return item;
    }
    return null;
  }

  static CatOutfitSpec? findOutfit(String? assetPath) {
    if (assetPath == null || assetPath.isEmpty) return null;
    for (final item in outfits) {
      if (item.assetPath == assetPath) return item;
    }
    return null;
  }
}

class GuardianCatScreen extends StatefulWidget {
  const GuardianCatScreen({super.key});

  @override
  State<GuardianCatScreen> createState() => _GuardianCatScreenState();
}

class _GuardianCatScreenState extends State<GuardianCatScreen> {
  int _subTabIndex = 0; // 0: Phòng Mèo, 1: Shop, 2: Cài đặt Mèo
  int _shopSectionIndex = 0; // 0: Thức ăn (36), 1: Trang phục (32), 2: Chủ đề (6), 3: Linh Thú (24)
  CatFoodCategory _foodCategory = CatFoodCategory.all;

  String _catAnimKey = 'idle';
  String? _speechText;
  Timer? _animResetTimer;
  Timer? _speechDismissTimer;

  @override
  void initState() {
    super.initState();
    CatDialogueService.instance.addListener(_onGlobalDialogueChanged);
  }

  @override
  void dispose() {
    CatDialogueService.instance.removeListener(_onGlobalDialogueChanged);
    _animResetTimer?.cancel();
    _speechDismissTimer?.cancel();
    super.dispose();
  }

  void _onGlobalDialogueChanged() {
    final active = CatDialogueService.instance.activeSpeech;
    if (active != null && active.isNotEmpty && mounted) {
      _showRoyalSpeech(active, animKey: 'happy');
    }
  }

  void _showRoyalSpeech(
    String speech, {
    String animKey = 'happy',
    Duration? animRevertAfter = const Duration(seconds: 4),
  }) {
    _animResetTimer?.cancel();
    _speechDismissTimer?.cancel();
    if (!mounted) return;
    setState(() {
      _catAnimKey = animKey;
      _speechText = speech;
    });
    if (animRevertAfter != null) {
      _animResetTimer = Timer(animRevertAfter, () {
        if (!mounted) return;
        setState(() {
          _catAnimKey = 'idle';
        });
      });
    }
    _speechDismissTimer = Timer(CatDialogueService.autoDismissDuration, () {
      if (!mounted) return;
      setState(() {
        _speechText = null;
      });
    });
  }

  Future<void> _handleFeedFood(CatFoodSpec food) async {
    final provider = context.read<ProgressProvider>();
    final ok = await provider.feedCat(
      assetPath: food.assetPath,
      hungerBonus: food.hungerBonus,
      moodBonus: food.moodBonus,
      energyBonus: food.energyBonus,
    );
    if (!mounted || !ok) return;
    if (provider.progress.catEnergy >= 20) {
      CatDialogueService.instance.setStudyState(
        studyLocked: CatDialogueService.instance.isStudyLocked,
        postStudyTired: false,
      );
    }
    final activeCat = CatCatalog.findCharacter(provider.progress.selectedCatId);
    _showRoyalSpeech(
      CatDialogueService.instance.nextFeedLine(),
      animKey: 'happy',
    );
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppTheme.textPrimary,
          content: Text('Đã dâng ${food.name} cho ${activeCat.name}! (${food.effectSummary})'),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  Future<void> _handleRestCat() async {
    final provider = context.read<ProgressProvider>();
    await provider.restCat(energyBonus: 20, moodBonus: 5);
    if (!mounted) return;
    _showRoyalSpeech(
      'Trẫm chợp mắt một lát, con sen nhớ tự giác ôn bài đấy zZz...',
      animKey: 'sleep',
      animRevertAfter: null,
    );
  }

  void _openFoodInventorySheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) {
        return _FoodInventoryBottomSheet(
          onSelectFood: (food) async {
            Navigator.of(sheetCtx).pop();
            await _handleFeedFood(food);
          },
          onGoToShop: () {
            Navigator.of(sheetCtx).pop();
            setState(() {
              _subTabIndex = 1;
              _shopSectionIndex = 0;
            });
          },
        );
      },
    );
  }

  void _openWardrobeSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) {
        return _OutfitWardrobeBottomSheet(
          onEquipOutfit: (outfitSpec) async {
            final navigator = Navigator.of(sheetCtx);
            final provider = context.read<ProgressProvider>();
            await provider.equipCatOutfit(outfitSpec?.assetPath);
            if (!mounted) return;
            navigator.pop();
            if (outfitSpec != null) {
              _showRoyalSpeech(
                'Bộ "${outfitSpec.name}" khá hợp với khí chất Hoàng Thượng của trẫm đấy!',
                animKey: 'happy',
              );
            } else {
              _showRoyalSpeech(
                'Cởi long bào ra cho thoáng mát, con sen cất giữ cẩn thận nhé!',
                animKey: 'idle',
              );
            }
          },
          onGoToOutfitShop: () {
            Navigator.of(sheetCtx).pop();
            setState(() {
              _subTabIndex = 1;
              _shopSectionIndex = 1;
            });
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProgressProvider>();
    final progress = provider.progress;
    final safeLevelIndex = progress.userLevel.clamp(0, AppConstants.userLevels.length - 1);
    final levelData = AppConstants.userLevels[safeLevelIndex];
    final stageNumber = (safeLevelIndex + 1).clamp(1, 5);
    final activeThemeSpec = AppTheme.specFor(progress.selectedThemeId);
    final activeCatSpec = CatCatalog.findCharacter(progress.selectedCatId);
    final pomodoroCatState = CatDialogueService.instance.pomodoroCatState;
    final effectiveAnimKey = CatDialogueService.instance.isStudyLocked
        ? 'thinking'
        : ((progress.catEnergy < 20 || CatDialogueService.instance.isPostStudyTired) &&
                _catAnimKey == 'idle'
            ? 'sleep'
            : (pomodoroCatState != null && _catAnimKey == 'idle'
                ? pomodoroCatState.assetKey
                : _catAnimKey));
    final catAnimPath = AppAssets.catAnimation(activeCatSpec.folderId, effectiveAnimKey);
    final effectiveSpeechText = _speechText ??
        (progress.catEnergy < 20 ? CatDialogueService.instance.exhaustedLine() : null);

    return Scaffold(
      backgroundColor: activeThemeSpec.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: _TopCatBar(
                catSpec: activeCatSpec,
                stageNumber: stageNumber,
                levelName: levelData['name'] as String,
                coins: progress.coins,
                gems: progress.gems,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _CatSubTabSwitcher(
                currentIndex: _subTabIndex,
                ownedFoodCount: provider.totalOwnedFoodCount,
                ownedOutfitCount: progress.ownedOutfits.length,
                onSelect: (idx) => setState(() => _subTabIndex = idx),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: IndexedStack(
                index: _subTabIndex,
                children: [
                  _CatRoomTabView(
                    catSpec: activeCatSpec,
                    catAnimPath: catAnimPath,
                    speechText: effectiveSpeechText,
                    equippedOutfit: progress.equippedOutfit,
                    hunger: progress.catHunger,
                    energy: progress.catEnergy,
                    mood: progress.catMood,
                    foodInventory: progress.foodInventory,
                    ownedOutfitCount: progress.ownedOutfits.length,
                    onTapCat: () => _showRoyalSpeech(
                      CatDialogueService.instance.nextTapLine(
                        hunger: progress.catHunger,
                        energy: progress.catEnergy,
                      ),
                      animKey: progress.catEnergy < 20 ? 'sleep' : 'happy',
                    ),
                    onSnapCatToSpot: (spot) => _showRoyalSpeech(
                      CatDialogueService.instance.furnitureSnapLine(spotName: spot.name),
                      animKey: 'happy',
                    ),
                    onOpenFoodSheet: _openFoodInventorySheet,
                    onOpenWardrobeSheet: _openWardrobeSheet,
                    onRestCat: _handleRestCat,
                    onQuickFeed: _handleFeedFood,
                    onGoToShop: () => setState(() {
                      _subTabIndex = 1;
                      _shopSectionIndex = 0;
                    }),
                  ),
                  _CatShopTabView(
                    sectionIndex: _shopSectionIndex,
                    foodCategory: _foodCategory,
                    onSelectSection: (idx) => setState(() => _shopSectionIndex = idx),
                    onSelectFoodCategory: (cat) => setState(() => _foodCategory = cat),
                  ),
                  _CatSettingsTabView(
                    activeCatSpec: activeCatSpec,
                    catAnimPath: catAnimPath,
                    equippedOutfit: progress.equippedOutfit,
                    companionEnabled: progress.catCompanionEnabled,
                    companionScale: progress.catCompanionScale,
                    ownedCatIds: progress.ownedCatIds,
                    selectedCatId: progress.selectedCatId,
                    unlockedThemeIds: progress.unlockedThemeIds,
                    selectedThemeId: progress.selectedThemeId,
                    onToggleCompanion: (val) => provider.setCatCompanionEnabled(val),
                    onChangeScale: (val) => provider.setCatCompanionScale(val),
                    onSelectCat: (catSpec) async {
                      await provider.selectCatCharacter(catSpec.folderId);
                      if (!context.mounted) return;
                      _showRoyalSpeech(
                        'Trẫm — ${catSpec.name} — chính thức lâm triều!',
                        animKey: 'happy',
                      );
                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: activeThemeSpec.primary,
                            content: Text('Đã chọn linh thú đại diện: ${catSpec.name}!'),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                    },
                    onGoToCatShop: () => setState(() {
                      _subTabIndex = 1;
                      _shopSectionIndex = 3;
                    }),
                    onSelectTheme: (themeId) async {
                      final themeProvider = context.read<ThemeProvider?>();
                      await provider.selectAppTheme(themeId);
                      await themeProvider?.setTheme(themeId);
                      if (!context.mounted) return;
                      final spec = AppTheme.specFor(themeId);
                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(
                          SnackBar(
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: spec.primary,
                            content: Text('Đã chuyển sang chủ đề ${spec.displayName}!'),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                    },
                    onGoToThemeShop: () => setState(() {
                      _subTabIndex = 1;
                      _shopSectionIndex = 2;
                    }),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopCatBar extends StatelessWidget {
  final CatCharacterSpec catSpec;
  final int stageNumber;
  final String levelName;
  final int coins;
  final int gems;

  const _TopCatBar({
    required this.catSpec,
    required this.stageNumber,
    required this.levelName,
    required this.coins,
    required this.gems,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.borderSubtle),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: AppTheme.primarySoft,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.primaryMuted.withValues(alpha: 0.45)),
            ),
            child: AppAssetIcon(catSpec.idleAssetPath, size: 34),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trợ lý AI & Không gian',
                  key: const ValueKey('cat-academic-header-label'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.primary,
                    letterSpacing: 0.2,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  catSpec.name,
                  key: const ValueKey('cat-active-name-badge'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${catSpec.tier} · Cấp $stageNumber/5 ($levelName)',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          IconButton(
            key: const ValueKey('cat-open-ai-tutor-btn'),
            tooltip: 'Hỏi Gia sư Quàng Thượng',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const QuangThuongTutorScreen(),
                ),
              );
            },
            icon: const AppAssetIcon(AppAssets.labTutorCat, size: 28),
          ),
          _WalletBadge(
            key: const ValueKey('cat-wallet-coins'),
            iconPath: AppIcons.coin,
            value: coins >= 99999 ? '99,999' : '$coins',
            bgColor: const Color(0xFFFFF6E5),
            textColor: const Color(0xFFB7791F),
          ),
          const SizedBox(width: 6),
          _WalletBadge(
            key: const ValueKey('cat-wallet-gems'),
            iconPath: AppIcons.gem,
            value: gems >= 99999 ? '99,999' : '$gems',
            bgColor: const Color(0xFFEEF6FF),
            textColor: const Color(0xFF2B6CB0),
          ),
        ],
      ),
    );
  }
}

class _WalletBadge extends StatelessWidget {
  final String iconPath;
  final String value;
  final Color bgColor;
  final Color textColor;

  const _WalletBadge({
    super.key,
    required this.iconPath,
    required this.value,
    required this.bgColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: textColor.withValues(alpha: 0.22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppAssetIcon(iconPath, size: 16),
          const SizedBox(width: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _CatSubTabSwitcher extends StatelessWidget {
  final int currentIndex;
  final int ownedFoodCount;
  final int ownedOutfitCount;
  final ValueChanged<int> onSelect;

  const _CatSubTabSwitcher({
    required this.currentIndex,
    required this.ownedFoodCount,
    required this.ownedOutfitCount,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderSubtle),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Row(
        children: [
          Expanded(
            child: _SubTabPill(
              key: const ValueKey('cat-subtab-room'),
              iconPath: AppIcons.home,
              label: 'Phòng Mèo',
              badge: ownedFoodCount > 0 ? '$ownedFoodCount' : null,
              selected: currentIndex == 0,
              onTap: () => onSelect(0),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: _SubTabPill(
              key: const ValueKey('cat-subtab-shop'),
              iconPath: AppIcons.shop,
              label: 'Shop',
              badge: ownedOutfitCount > 0 ? '$ownedOutfitCount/${CatCatalog.outfits.length}' : null,
              selected: currentIndex == 1,
              onTap: () => onSelect(1),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: _SubTabPill(
              key: const ValueKey('cat-subtab-settings'),
              iconPath: AppIcons.settings,
              label: 'Cài đặt Mèo',
              selected: currentIndex == 2,
              onTap: () => onSelect(2),
            ),
          ),
        ],
      ),
    );
  }
}

class _SubTabPill extends StatelessWidget {
  final String iconPath;
  final String label;
  final String? badge;
  final bool selected;
  final VoidCallback onTap;

  const _SubTabPill({
    super.key,
    required this.iconPath,
    required this.label,
    this.badge,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppAssetIcon(iconPath, size: 17),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: selected ? Colors.white : AppTheme.textSecondary,
                ),
              ),
            ),
            if (badge != null) ...[
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                decoration: BoxDecoration(
                  color: selected
                      ? Colors.white.withValues(alpha: 0.24)
                      : AppTheme.primarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  badge!,
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : AppTheme.accent,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _CatRoomTabView extends StatefulWidget {
  final CatCharacterSpec catSpec;
  final String catAnimPath;
  final String? speechText;
  final String? equippedOutfit;
  final int hunger;
  final int energy;
  final int mood;
  final Map<String, int> foodInventory;
  final int ownedOutfitCount;
  final VoidCallback onTapCat;
  final ValueChanged<CatRoomSpot> onSnapCatToSpot;
  final VoidCallback onOpenFoodSheet;
  final VoidCallback onOpenWardrobeSheet;
  final VoidCallback onRestCat;
  final ValueChanged<CatFoodSpec> onQuickFeed;
  final VoidCallback onGoToShop;

  const _CatRoomTabView({
    required this.catSpec,
    required this.catAnimPath,
    required this.speechText,
    required this.equippedOutfit,
    required this.hunger,
    required this.energy,
    required this.mood,
    required this.foodInventory,
    required this.ownedOutfitCount,
    required this.onTapCat,
    required this.onSnapCatToSpot,
    required this.onOpenFoodSheet,
    required this.onOpenWardrobeSheet,
    required this.onRestCat,
    required this.onQuickFeed,
    required this.onGoToShop,
  });

  @override
  State<_CatRoomTabView> createState() => _CatRoomTabViewState();
}

class _CatRoomTabViewState extends State<_CatRoomTabView> {
  static const double _stageHeight = 305.0;
  static const double _catW = 136.0;
  static const double _catH = 165.0;

  int _currentSpotIndex = 0;
  Offset? _dragFootPos;
  int? _previewNearestSpotIndex;
  bool _isPointerOnCat = false;
  Offset? _pointerDownPos;
  bool _hasMovedCat = false;

  CatRoomSpot get _activeSpot => CatCatalog.roomSpots[_currentSpotIndex];

  int _findNearestSpotIndex(Offset footPos, Size stageSize) {
    var bestIdx = 0;
    var bestDist = double.infinity;
    for (var i = 0; i < CatCatalog.roomSpots.length; i++) {
      final s = CatCatalog.roomSpots[i];
      final target = Offset(s.fx * stageSize.width, s.fy * stageSize.height);
      final dist = (target - footPos).distance;
      if (dist < bestDist) {
        bestDist = dist;
        bestIdx = i;
      }
    }
    return bestIdx;
  }

  void _handleSpotTap(int idx) {
    setState(() {
      _currentSpotIndex = idx;
      _dragFootPos = null;
      _previewNearestSpotIndex = null;
    });
    widget.onSnapCatToSpot(CatCatalog.roomSpots[idx]);
  }

  @override
  Widget build(BuildContext context) {
    final equippedSpec = CatCatalog.findOutfit(widget.equippedOutfit);
    final ownedFoodEntries = <MapEntry<CatFoodSpec, int>>[];
    for (final spec in CatCatalog.foods) {
      final qty = widget.foodInventory[spec.assetPath] ?? 0;
      if (qty > 0) {
        ownedFoodEntries.add(MapEntry(spec, qty));
      }
    }

    return ListView(
      physics: _isPointerOnCat ? const NeverScrollableScrollPhysics() : null,
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        // 1. Sân khấu Căn phòng 2.5D (room.png) hỗ trợ Kéo Thả 10 điểm nội thất
        Container(
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              ClipRRect(
                key: const ValueKey('cat-room-stage-clip'),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                clipBehavior: Clip.hardEdge,
                child: SizedBox(
                  height: _stageHeight,
                  width: double.infinity,
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final stageSize = Size(constraints.maxWidth, _stageHeight);
                      final spotPos = Offset(
                        _activeSpot.fx * stageSize.width,
                        _activeSpot.fy * stageSize.height,
                      );
                      final currentFoot = _dragFootPos ?? spotPos;
                      final catLeft = (currentFoot.dx - _catW / 2)
                          .clamp(0.0, math.max(0.0, stageSize.width - _catW))
                          .toDouble();
                      final catTop = (currentFoot.dy - _catH + 26)
                          .clamp(0.0, math.max(0.0, stageSize.height - _catH))
                          .toDouble();

                    return Stack(
                      clipBehavior: Clip.hardEdge,
                      children: [
                        const Positioned.fill(
                          child: AppAssetIcon(
                            AppAssets.catRoomBg,
                            width: double.infinity,
                            height: _stageHeight,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Positioned.fill(
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.black.withValues(alpha: 0.12),
                                  Colors.transparent,
                                  Colors.black.withValues(alpha: 0.18),
                                ],
                              ),
                            ),
                          ),
                        ),
                        // 10 Điểm neo nội thất trên room.png (hiển thị chấm sáng khi đang kéo hoặc chạm nhanh)
                        for (var i = 0; i < CatCatalog.roomSpots.length; i++)
                          Builder(
                            builder: (context) {
                              final spot = CatCatalog.roomSpots[i];
                              final sx = spot.fx * stageSize.width;
                              final sy = spot.fy * stageSize.height;
                              final isHighlighted = _previewNearestSpotIndex == i ||
                                  (_dragFootPos == null && _currentSpotIndex == i);
                              final showPin = _dragFootPos != null || _currentSpotIndex == i;
                              return Positioned(
                                key: ValueKey('room-spot-${spot.id}'),
                                left: sx - 14,
                                top: sy - 14,
                                width: 28,
                                height: 28,
                                child: GestureDetector(
                                  behavior: HitTestBehavior.translucent,
                                  onTap: () => _handleSpotTap(i),
                                  child: AnimatedOpacity(
                                    duration: const Duration(milliseconds: 180),
                                    opacity: showPin ? (isHighlighted ? 0.95 : 0.55) : 0.0,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isHighlighted
                                            ? AppTheme.primary.withValues(alpha: 0.42)
                                            : Colors.white.withValues(alpha: 0.35),
                                        border: Border.all(
                                          color: isHighlighted ? Colors.white : AppTheme.primary,
                                          width: isHighlighted ? 2.0 : 1.2,
                                        ),
                                      ),
                                      alignment: Alignment.center,
                                      child: Container(
                                        width: 7,
                                        height: 7,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        // Nhãn góc trên căn phòng: Vị trí nội thất đang ngự + Trang phục đang mặc
                        Positioned(
                          top: 10,
                          left: 12,
                          right: 12,
                          child: Row(
                            children: [
                              Container(
                                key: const ValueKey('cat-room-spot-badge'),
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: AppTheme.surface.withValues(alpha: 0.92),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: AppTheme.borderSubtle),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const AppAssetIcon(AppIcons.home, size: 15),
                                    const SizedBox(width: 5),
                                    Text(
                                      '📍 ${_activeSpot.name}',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                        color: AppTheme.textPrimary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              if (equippedSpec != null)
                                Flexible(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primarySoft.withValues(alpha: 0.95),
                                        borderRadius: BorderRadius.circular(999),
                                        border: Border.all(color: AppTheme.primary),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const AppAssetIcon(AppIcons.crown, size: 14),
                                          const SizedBox(width: 5),
                                          Flexible(
                                            child: Text(
                                              equippedSpec.name,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w800,
                                                color: AppTheme.accent,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        // Nhân vật Mèo Hộ Pháp hỗ trợ chạm & kéo thả tới 10 điểm nội thất
                        Positioned(
                          left: catLeft,
                          top: catTop,
                          width: _catW,
                          height: _catH,
                          child: Listener(
                            key: const ValueKey('cat-room-avatar'),
                            behavior: HitTestBehavior.translucent,
                            onPointerDown: (event) {
                              setState(() {
                                _isPointerOnCat = true;
                                _pointerDownPos = event.position;
                                _hasMovedCat = false;
                              });
                            },
                            onPointerMove: (event) {
                              final down = _pointerDownPos;
                              if (!_hasMovedCat &&
                                  down != null &&
                                  (event.position - down).distance < 4.0) {
                                return;
                              }
                              final base = _dragFootPos ?? spotPos;
                              const minFootX = _catW / 2;
                              final maxFootX = math.max(minFootX, stageSize.width - _catW / 2);
                              final minFootY = (_catH - 26).clamp(32.0, stageSize.height);
                              final maxFootY = math.max(minFootY, stageSize.height - 6.0);
                              final next = Offset(
                                (base.dx + event.delta.dx).clamp(minFootX, maxFootX),
                                (base.dy + event.delta.dy).clamp(minFootY, maxFootY),
                              );
                              setState(() {
                                _hasMovedCat = true;
                                _dragFootPos = next;
                                _previewNearestSpotIndex = _findNearestSpotIndex(next, stageSize);
                              });
                            },
                            onPointerUp: (_) {
                              if (_hasMovedCat) {
                                final pos = _dragFootPos ?? spotPos;
                                final nearestIdx = _findNearestSpotIndex(pos, stageSize);
                                setState(() {
                                  _isPointerOnCat = false;
                                  _pointerDownPos = null;
                                  _currentSpotIndex = nearestIdx;
                                  _dragFootPos = null;
                                  _previewNearestSpotIndex = null;
                                });
                                widget.onSnapCatToSpot(CatCatalog.roomSpots[nearestIdx]);
                              } else {
                                setState(() {
                                  _isPointerOnCat = false;
                                  _pointerDownPos = null;
                                  _dragFootPos = null;
                                  _previewNearestSpotIndex = null;
                                });
                              }
                            },
                            onPointerCancel: (_) {
                              setState(() {
                                _isPointerOnCat = false;
                                _pointerDownPos = null;
                                _hasMovedCat = false;
                                _dragFootPos = null;
                                _previewNearestSpotIndex = null;
                              });
                            },
                            child: GestureDetector(
                              behavior: HitTestBehavior.translucent,
                              onTap: () {
                                if (!_hasMovedCat) {
                                  widget.onTapCat();
                                }
                              },
                              child: CatWithOutfitAvatar(
                                catAnimPath: widget.catAnimPath,
                                equippedOutfit: widget.equippedOutfit,
                                width: _catW,
                                height: _catH,
                              ),
                            ),
                          ),
                        ),
                        // Bong bóng thoại Hoàng Thượng ("Trẫm — Con sen") tự ẩn sau đúng 5 giây
                        if (widget.speechText != null && widget.speechText!.isNotEmpty)
                          Positioned(
                            top: math.max(42.0, catTop - 52.0),
                            left: 16,
                            right: 16,
                            child: IgnorePointer(
                              child: Center(
                                child: Container(
                                  key: const ValueKey('cat-room-speech-bubble'),
                                  constraints: const BoxConstraints(maxWidth: 310),
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: AppTheme.surface.withValues(alpha: 0.97),
                                    borderRadius: BorderRadius.circular(18),
                                    border: Border.all(color: AppTheme.primary, width: 1.4),
                                    boxShadow: AppTheme.softCardShadow,
                                  ),
                                  child: Text(
                                    widget.speechText!,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w800,
                                      color: AppTheme.accent,
                                      height: 1.25,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
              ),
              // Thanh công cụ chăm sóc 3 nút: [Cho ăn], [Tủ đồ], [Nghỉ ngơi]
              Container(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  border: Border(top: BorderSide(color: AppTheme.borderSubtle)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _CareToolbarButton(
                        key: const ValueKey('cat-action-feed'),
                        iconPath: AppIcons.hunger,
                        label: 'Cho ăn',
                        subtitle: 'Túi đồ (${ownedFoodEntries.fold<int>(0, (s, e) => s + e.value)})',
                        accentColor: const Color(0xFFE07A5F),
                        onTap: widget.onOpenFoodSheet,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _CareToolbarButton(
                        key: const ValueKey('cat-action-wardrobe'),
                        iconPath: AppIcons.inventory,
                        label: 'Tủ đồ',
                        subtitle: 'Đã có ${widget.ownedOutfitCount} bộ',
                        accentColor: AppTheme.primary,
                        onTap: widget.onOpenWardrobeSheet,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _CareToolbarButton(
                        key: const ValueKey('cat-action-rest'),
                        iconPath: AppIcons.sleepCat,
                        label: 'Nghỉ ngơi',
                        subtitle: 'Hồi +20% NL',
                        accentColor: AppTheme.secondary,
                        onTap: widget.onRestCat,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 2. Khung 3 Thanh Chỉ Số Bo Tròn (Độ no, Năng lượng, Tâm trạng)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const AppAssetIcon(AppIcons.paw, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Chỉ Số Long Thể · ${widget.catSpec.name}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: widget.hunger < 20 ? const Color(0xFFFEE2E2) : AppTheme.secondarySoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      widget.hunger < 20
                          ? 'Đang đói bụng!'
                          : (widget.hunger >= 70 && widget.mood >= 70 ? 'Sẵn sàng học ♡' : 'Cần chăm sóc'),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: widget.hunger < 20 ? AppTheme.error : AppTheme.success,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _CatVitalRoundedBar(
                key: const ValueKey('vital-bar-hunger'),
                iconPath: AppIcons.hunger,
                label: 'Độ no (Hunger)',
                value: widget.hunger,
                barColor: const Color(0xFFE8986B),
                trackColor: const Color(0xFFFFEFE5),
              ),
              const SizedBox(height: 10),
              _CatVitalRoundedBar(
                key: const ValueKey('vital-bar-energy'),
                iconPath: AppIcons.energy,
                label: 'Năng lượng (Energy)',
                value: widget.energy,
                barColor: const Color(0xFF7FB685),
                trackColor: const Color(0xFFEEF7EF),
              ),
              const SizedBox(height: 10),
              _CatVitalRoundedBar(
                key: const ValueKey('vital-bar-mood'),
                iconPath: AppIcons.heart,
                label: 'Tâm trạng (Mood)',
                value: widget.mood,
                barColor: const Color(0xFFD98B99),
                trackColor: const Color(0xFFFDF0F3),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 3. Khay Túi đồ cá nhân (Inventory trong Phòng Mèo - CHỈ hiển thị các món đã sở hữu kèm số lượng x1, x3)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const AppAssetIcon(AppIcons.inventory, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Túi Đồ Thức Ăn Cá Nhân',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: widget.onGoToShop,
                    borderRadius: BorderRadius.circular(999),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppTheme.primarySoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppAssetIcon(AppIcons.shop, size: 14),
                          SizedBox(width: 4),
                          Text(
                            'Mua thêm ở Shop',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.accent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Chạm vào món ăn đang có trong túi để cung phụng ngay cho Hoàng Thượng.',
                style: TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              if (ownedFoodEntries.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                  decoration: BoxDecoration(
                    color: AppTheme.background,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Column(
                    children: [
                      AppAssetIcon(AppIcons.gift, size: 32),
                      SizedBox(height: 8),
                      Text(
                        'Túi đồ thức ăn đang trống meo!',
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Hãy ghé Cửa hàng (Shop) để mua trái cây, món chính hoặc hải sản nhé.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                )
              else
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final entry in ownedFoodEntries)
                      _OwnedFoodInventoryTile(
                        food: entry.key,
                        quantity: entry.value,
                        onTap: () => widget.onQuickFeed(entry.key),
                      ),
                  ],
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _CareToolbarButton extends StatelessWidget {
  final String iconPath;
  final String label;
  final String subtitle;
  final Color accentColor;
  final VoidCallback onTap;

  const _CareToolbarButton({
    super.key,
    required this.iconPath,
    required this.label,
    required this.subtitle,
    required this.accentColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: AppTheme.background,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accentColor.withValues(alpha: 0.35)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 36,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: accentColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(12),
              ),
              child: AppAssetIcon(iconPath, size: 22),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CatVitalRoundedBar extends StatelessWidget {
  final String iconPath;
  final String label;
  final int value;
  final Color barColor;
  final Color trackColor;

  const _CatVitalRoundedBar({
    super.key,
    required this.iconPath,
    required this.label,
    required this.value,
    required this.barColor,
    required this.trackColor,
  });

  @override
  Widget build(BuildContext context) {
    final safeVal = value.clamp(0, 100);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderSubtle),
      ),
      child: Column(
        children: [
          Row(
            children: [
              AppAssetIcon(iconPath, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ),
              Text(
                '$safeVal%',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: barColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: safeVal / 100.0,
              minHeight: 9,
              backgroundColor: trackColor,
              valueColor: AlwaysStoppedAnimation<Color>(barColor),
            ),
          ),
        ],
      ),
    );
  }
}

class _OwnedFoodInventoryTile extends StatelessWidget {
  final CatFoodSpec food;
  final int quantity;
  final VoidCallback onTap;

  const _OwnedFoodInventoryTile({
    required this.food,
    required this.quantity,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      key: ValueKey('inventory-food-${food.assetPath}'),
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: 104,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppTheme.background,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.borderSubtle),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppTheme.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: AppAssetIcon.food(food.assetPath, size: 38),
                ),
                Positioned(
                  right: -6,
                  top: -6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.accent,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'x$quantity',
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              food.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              '+${food.hungerBonus}% No',
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                color: AppTheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CatShopTabView extends StatelessWidget {
  final int sectionIndex;
  final CatFoodCategory foodCategory;
  final ValueChanged<int> onSelectSection;
  final ValueChanged<CatFoodCategory> onSelectFoodCategory;

  const _CatShopTabView({
    required this.sectionIndex,
    required this.foodCategory,
    required this.onSelectSection,
    required this.onSelectFoodCategory,
  });

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProgressProvider>();
    final progress = provider.progress;

    final filteredFoods = foodCategory == CatFoodCategory.all
        ? CatCatalog.foods
        : CatCatalog.foods.where((item) => item.category == foodCategory).toList();

    return Column(
      children: [
        // Header Ví Tiền + Chuyển đổi 4 danh mục Cửa hàng: Thức ăn (36), Trang phục (32), Chủ đề (6), Linh Thú (24)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.borderSubtle),
              boxShadow: AppTheme.softCardShadow,
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    const AppAssetIcon(AppIcons.shop, size: 19),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        'Cửa Hàng Mèo Hộ Pháp',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                    ),
                    _WalletBadge(
                      iconPath: AppIcons.coin,
                      value: '${progress.coins} Xu',
                      bgColor: const Color(0xFFFFF6E5),
                      textColor: const Color(0xFFB7791F),
                    ),
                    const SizedBox(width: 6),
                    _WalletBadge(
                      iconPath: AppIcons.gem,
                      value: '${progress.gems} Gem',
                      bgColor: const Color(0xFFEEF6FF),
                      textColor: const Color(0xFF2B6CB0),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _ShopSectionTabButton(
                        key: const ValueKey('shop-tab-foods'),
                        iconPath: AppIcons.hunger,
                        label: 'Thức ăn',
                        selected: sectionIndex == 0,
                        onTap: () => onSelectSection(0),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: _ShopSectionTabButton(
                        key: const ValueKey('shop-tab-outfits'),
                        iconPath: AppIcons.crown,
                        label: 'Trang phục',
                        selected: sectionIndex == 1,
                        onTap: () => onSelectSection(1),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: _ShopSectionTabButton(
                        key: const ValueKey('shop-tab-themes'),
                        iconPath: AppIcons.star,
                        label: 'Chủ đề',
                        selected: sectionIndex == 2,
                        onTap: () => onSelectSection(2),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: _ShopSectionTabButton(
                        key: const ValueKey('shop-tab-cats'),
                        iconPath: AppIcons.paw,
                        label: 'Linh Thú',
                        selected: sectionIndex == 3,
                        onTap: () => onSelectSection(3),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (sectionIndex == 0) ...[
          SizedBox(
            height: 38,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: CatFoodCategory.values.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, idx) {
                final cat = CatFoodCategory.values[idx];
                final isSelected = cat == foodCategory;
                return InkWell(
                  key: ValueKey('food-filter-${cat.name}'),
                  onTap: () => onSelectFoodCategory(cat),
                  borderRadius: BorderRadius.circular(999),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.accent : AppTheme.surface,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: isSelected ? AppTheme.accent : AppTheme.borderSubtle,
                      ),
                    ),
                    child: Text(
                      cat.label,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: isSelected ? Colors.white : AppTheme.textSecondary,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 28),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.78,
              ),
              itemCount: filteredFoods.length,
              itemBuilder: (context, idx) {
                final food = filteredFoods[idx];
                final ownedQty = provider.foodCountFor(food.assetPath);
                return _FoodShopCard(
                  food: food,
                  ownedQuantity: ownedQty,
                  canAfford: progress.coins >= food.coinPrice,
                  onBuy: () async {
                    final ok = await provider.buyCatFood(
                      assetPath: food.assetPath,
                      coinCost: food.coinPrice,
                    );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: ok ? AppTheme.textPrimary : AppTheme.error,
                          content: Text(
                            ok
                                ? 'Đã mua 1 ${food.name} vào Túi đồ!'
                                : 'Không đủ Xu để mua ${food.name}!',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                  },
                );
              },
            ),
          ),
        ] else if (sectionIndex == 1) ...[
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 28),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.74,
              ),
              itemCount: CatCatalog.outfits.length,
              itemBuilder: (context, idx) {
                final outfit = CatCatalog.outfits[idx];
                final owned = provider.isOutfitOwned(outfit.assetPath);
                final canAfford = outfit.isGemItem
                    ? progress.gems >= outfit.gemPrice
                    : progress.coins >= outfit.coinPrice;
                return _OutfitShopCard(
                  outfit: outfit,
                  isOwned: owned,
                  canAfford: canAfford,
                  onBuy: () async {
                    final ok = await provider.buyCatOutfit(
                      outfitPath: outfit.assetPath,
                      coinCost: outfit.coinPrice,
                      gemCost: outfit.gemPrice,
                    );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: ok ? AppTheme.textPrimary : AppTheme.error,
                          content: Text(
                            ok
                                ? 'Đã sở hữu "${outfit.name}"! Mở Tủ đồ để mặc ngay nhé.'
                                : 'Không đủ tài nguyên để mua "${outfit.name}".',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                  },
                );
              },
            ),
          ),
        ] else if (sectionIndex == 2) ...[
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 28),
              itemCount: AppTheme.themes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, idx) {
                final themeSpec = AppTheme.themes[idx];
                final isUnlocked = provider.isThemeUnlocked(themeSpec.id);
                final isSelected = progress.selectedThemeId == themeSpec.id;
                final canAfford = themeSpec.isGemTheme
                    ? progress.gems >= themeSpec.gemPrice
                    : progress.coins >= themeSpec.coinPrice;
                return _ThemeShopCard(
                  themeSpec: themeSpec,
                  isUnlocked: isUnlocked,
                  isSelected: isSelected,
                  canAfford: canAfford,
                  onBuy: () async {
                    final ok = await provider.buyAppTheme(
                      themeId: themeSpec.id,
                      coinCost: themeSpec.coinPrice,
                      gemCost: themeSpec.gemPrice,
                    );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: ok ? themeSpec.primary : AppTheme.error,
                          content: Text(
                            ok
                                ? 'Đã mở khóa chủ đề "${themeSpec.displayName}"! Sang Cài đặt Mèo để áp dụng nhé.'
                                : 'Không đủ tài nguyên để mua chủ đề "${themeSpec.displayName}".',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                  },
                );
              },
            ),
          ),
        ] else ...[
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 28),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.74,
              ),
              itemCount: CatCatalog.characters.length,
              itemBuilder: (context, idx) {
                final catSpec = CatCatalog.characters[idx];
                final isOwned = provider.isCatOwned(catSpec.folderId);
                final isSelected = progress.selectedCatId == catSpec.folderId;
                final canAfford = catSpec.isGemCat
                    ? progress.gems >= catSpec.gemPrice
                    : progress.coins >= catSpec.coinPrice;
                return _CatCharacterShopCard(
                  catSpec: catSpec,
                  isOwned: isOwned,
                  isSelected: isSelected,
                  canAfford: canAfford,
                  onBuy: () async {
                    final ok = await provider.buyCatCharacter(
                      catId: catSpec.folderId,
                      coinCost: catSpec.coinPrice,
                      gemCost: catSpec.gemPrice,
                    );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          backgroundColor: ok ? AppTheme.textPrimary : AppTheme.error,
                          content: Text(
                            ok
                                ? 'Đã chiêu mộ "${catSpec.name}"! Sang Cài đặt Mèo để chọn đồng hành nhé.'
                                : 'Không đủ tài nguyên để chiêu mộ "${catSpec.name}".',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                  },
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}

class _CatCharacterShopCard extends StatelessWidget {
  final CatCharacterSpec catSpec;
  final bool isOwned;
  final bool isSelected;
  final bool canAfford;
  final VoidCallback onBuy;

  const _CatCharacterShopCard({
    required this.catSpec,
    required this.isOwned,
    required this.isSelected,
    required this.canAfford,
    required this.onBuy,
  });

  Color _tierColor(String tier) {
    switch (tier) {
      case 'Huyền Thoại':
        return const Color(0xFFD97706);
      case 'Mặc Định':
        return AppTheme.primary;
      default:
        return AppTheme.success;
    }
  }

  @override
  Widget build(BuildContext context) {
    final badgeColor = _tierColor(catSpec.tier);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isOwned ? AppTheme.secondary : AppTheme.borderSubtle,
          width: isOwned ? 1.5 : 1.0,
        ),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: badgeColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    catSpec.tier,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w800,
                      color: badgeColor,
                    ),
                  ),
                ),
              ),
              if (isSelected) ...[
                const SizedBox(width: 4),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.primarySoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'Đang chọn',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 9.0,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.accent,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
          const Spacer(),
          Container(
            width: 82,
            height: 82,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: AppAssetIcon(
              catSpec.idleAssetPath,
              width: 72,
              height: 72,
              fit: BoxFit.contain,
            ),
          ),
          const Spacer(),
          Text(
            catSpec.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: InkWell(
              key: ValueKey('buy-cat-${catSpec.folderId}'),
              onTap: isOwned ? null : onBuy,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: isOwned
                      ? AppTheme.secondarySoft
                      : canAfford
                          ? (catSpec.isGemCat ? const Color(0xFF7C3AED) : AppTheme.primary)
                          : AppTheme.surfaceSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: isOwned
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AppAssetIcon(AppIcons.star, size: 14),
                          SizedBox(width: 5),
                          Text(
                            'Đã sở hữu',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.success,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AppAssetIcon(
                            catSpec.isGemCat ? AppIcons.gem : AppIcons.coin,
                            size: 15,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            catSpec.isGemCat
                                ? '${catSpec.gemPrice} Gem'
                                : '${catSpec.coinPrice} Xu',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: canAfford ? Colors.white : AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ShopSectionTabButton extends StatelessWidget {
  final String iconPath;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ShopSectionTabButton({
    super.key,
    required this.iconPath,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primarySoft : AppTheme.background,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppTheme.primary : AppTheme.borderSubtle,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppAssetIcon(iconPath, size: 15),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: selected ? AppTheme.accent : AppTheme.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FoodShopCard extends StatelessWidget {
  final CatFoodSpec food;
  final int ownedQuantity;
  final bool canAfford;
  final VoidCallback onBuy;

  const _FoodShopCard({
    required this.food,
    required this.ownedQuantity,
    required this.canAfford,
    required this.onBuy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderSubtle),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                decoration: BoxDecoration(
                  color: AppTheme.secondarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  food.category == CatFoodCategory.fruits
                      ? 'Trái cây'
                      : food.category == CatFoodCategory.dishes
                          ? 'Món chính'
                          : 'Hải sản',
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.success,
                  ),
                ),
              ),
              const Spacer(),
              if (ownedQuantity > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                  decoration: BoxDecoration(
                    color: AppTheme.primarySoft,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    'Túi: x$ownedQuantity',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.accent,
                    ),
                  ),
                ),
            ],
          ),
          const Spacer(),
          Container(
            width: 64,
            height: 64,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: AppAssetIcon.food(food.assetPath, size: 46),
          ),
          const Spacer(),
          Text(
            food.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            food.effectSummary,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              color: AppTheme.textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: InkWell(
              key: ValueKey('buy-food-${food.assetPath}'),
              onTap: onBuy,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: canAfford ? AppTheme.primary : AppTheme.surfaceSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const AppAssetIcon(AppIcons.coin, size: 15),
                    const SizedBox(width: 5),
                    Text(
                      'Mua · ${food.coinPrice} Xu',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: canAfford ? Colors.white : AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OutfitShopCard extends StatelessWidget {
  final CatOutfitSpec outfit;
  final bool isOwned;
  final bool canAfford;
  final VoidCallback onBuy;

  const _OutfitShopCard({
    required this.outfit,
    required this.isOwned,
    required this.canAfford,
    required this.onBuy,
  });

  Color _rarityColor(String rarity) {
    switch (rarity) {
      case 'Huyền Thoại':
        return const Color(0xFFD97706);
      case 'Sử Thi':
        return const Color(0xFF9333EA);
      case 'Hiếm':
        return const Color(0xFF2563EB);
      default:
        return AppTheme.success;
    }
  }

  @override
  Widget build(BuildContext context) {
    final badgeColor = _rarityColor(outfit.rarity);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isOwned ? AppTheme.secondary : AppTheme.borderSubtle,
          width: isOwned ? 1.5 : 1.0,
        ),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
                decoration: BoxDecoration(
                  color: badgeColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  outfit.rarity,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: badgeColor,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                '#${outfit.index + 1}',
                style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            width: 78,
            height: 78,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.borderSubtle),
            ),
            child: CatOutfitPreviewBox(
              outfitPath: outfit.assetPath,
              size: 66,
            ),
          ),
          const Spacer(),
          Text(
            outfit.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: InkWell(
              key: ValueKey('buy-outfit-${outfit.index}'),
              onTap: isOwned ? null : onBuy,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: isOwned
                      ? AppTheme.secondarySoft
                      : canAfford
                          ? AppTheme.primary
                          : AppTheme.surfaceSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: isOwned
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AppAssetIcon(AppIcons.star, size: 14),
                          SizedBox(width: 5),
                          Text(
                            'Đã sở hữu',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.success,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AppAssetIcon(
                            outfit.isGemItem ? AppIcons.gem : AppIcons.coin,
                            size: 15,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            outfit.isGemItem
                                ? 'Mua · ${outfit.gemPrice} Gem'
                                : 'Mua · ${outfit.coinPrice} Xu',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: canAfford ? Colors.white : AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ThemeShopCard extends StatelessWidget {
  final AppThemeSpec themeSpec;
  final bool isUnlocked;
  final bool isSelected;
  final bool canAfford;
  final VoidCallback onBuy;

  const _ThemeShopCard({
    required this.themeSpec,
    required this.isUnlocked,
    required this.isSelected,
    required this.canAfford,
    required this.onBuy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isUnlocked ? themeSpec.primary : AppTheme.borderSubtle,
          width: isUnlocked ? 1.6 : 1.0,
        ),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: themeSpec.background,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: themeSpec.borderSubtle),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  themeSpec.emoji,
                  style: const TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: themeSpec.primary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 3),
                    Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: themeSpec.primaryMuted,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 3),
                    Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: themeSpec.secondary,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        themeSpec.displayName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: themeSpec.isFree
                            ? AppTheme.secondarySoft
                            : themeSpec.primarySoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        themeSpec.isFree ? 'Mặc định' : 'Cao cấp',
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: FontWeight.w800,
                          color: themeSpec.isFree
                              ? AppTheme.success
                              : themeSpec.accent,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  themeSpec.subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          InkWell(
            key: ValueKey('buy-theme-${themeSpec.id}'),
            onTap: isUnlocked ? null : onBuy,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: isUnlocked
                    ? AppTheme.secondarySoft
                    : canAfford
                        ? themeSpec.primary
                        : AppTheme.surfaceSoft,
                borderRadius: BorderRadius.circular(14),
              ),
              child: isUnlocked
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppIcons.star, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          isSelected ? 'Đang dùng' : 'Đã mở khóa',
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.success,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AppAssetIcon(
                          themeSpec.isGemTheme ? AppIcons.gem : AppIcons.coin,
                          size: 15,
                        ),
                        const SizedBox(width: 5),
                        Text(
                          themeSpec.isGemTheme
                              ? '${themeSpec.gemPrice} Gem'
                              : '${themeSpec.coinPrice} Xu',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: canAfford ? Colors.white : AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CatSettingsTabView extends StatelessWidget {
  final CatCharacterSpec activeCatSpec;
  final String catAnimPath;
  final String? equippedOutfit;
  final bool companionEnabled;
  final double companionScale;
  final List<String> ownedCatIds;
  final String selectedCatId;
  final List<String> unlockedThemeIds;
  final String selectedThemeId;
  final ValueChanged<bool> onToggleCompanion;
  final ValueChanged<double> onChangeScale;
  final ValueChanged<CatCharacterSpec> onSelectCat;
  final VoidCallback onGoToCatShop;
  final ValueChanged<String> onSelectTheme;
  final VoidCallback onGoToThemeShop;

  const _CatSettingsTabView({
    required this.activeCatSpec,
    required this.catAnimPath,
    required this.equippedOutfit,
    required this.companionEnabled,
    required this.companionScale,
    required this.ownedCatIds,
    required this.selectedCatId,
    required this.unlockedThemeIds,
    required this.selectedThemeId,
    required this.onToggleCompanion,
    required this.onChangeScale,
    required this.onSelectCat,
    required this.onGoToCatShop,
    required this.onSelectTheme,
    required this.onGoToThemeShop,
  });

  @override
  Widget build(BuildContext context) {
    final percent = (companionScale.clamp(0.60, 1.30) * 100).round();
    final activeTheme = AppTheme.specFor(selectedThemeId);
    final unlockedThemes = AppTheme.themes
        .where((t) => unlockedThemeIds.contains(t.id))
        .toList();
    final ownedCats = CatCatalog.characters
        .where((c) => ownedCatIds.contains(c.folderId))
        .toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        // 1. Cài đặt hiển thị & kích thước Mèo đồng hành
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: activeTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: activeTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const AppAssetIcon(AppIcons.settings, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Cài Đặt Mèo Đồng Hành',
                      style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w800,
                        color: activeTheme.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: activeTheme.background,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: activeTheme.borderSubtle),
                ),
                child: Row(
                  children: [
                    const AppAssetIcon(AppIcons.paw, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hiển thị Mèo đồng hành trên màn hình chính',
                            style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${activeCatSpec.name} sẽ đứng trên thanh điều hướng & thẻ bài học.',
                            style: TextStyle(
                              fontSize: 11.5,
                              color: activeTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      key: const ValueKey('cat-companion-switch'),
                      value: companionEnabled,
                      activeThumbColor: activeTheme.primary,
                      onChanged: onToggleCompanion,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: activeTheme.background,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: activeTheme.borderSubtle),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const AppAssetIcon(AppIcons.star, size: 19),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Kích thước Mèo đồng hành (Scale)',
                            style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.textPrimary,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3.5),
                          decoration: BoxDecoration(
                            color: activeTheme.primarySoft,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            '$percent%',
                            key: const ValueKey('cat-scale-label'),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.accent,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Slider(
                      key: const ValueKey('cat-companion-scale-slider'),
                      value: companionScale.clamp(0.60, 1.30),
                      min: 0.60,
                      max: 1.30,
                      divisions: 14,
                      activeColor: activeTheme.primary,
                      inactiveColor: activeTheme.primarySoft,
                      label: '$percent%',
                      onChanged: onChangeScale,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '60%',
                          style: TextStyle(fontSize: 11, color: activeTheme.textSecondary),
                        ),
                        Text(
                          '100%',
                          style: TextStyle(fontSize: 11, color: activeTheme.textSecondary),
                        ),
                        Text(
                          '130%',
                          style: TextStyle(fontSize: 11, color: activeTheme.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                decoration: BoxDecoration(
                  color: activeTheme.background,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: activeTheme.borderSubtle),
                ),
                child: Column(
                  children: [
                    Text(
                      'Đang chọn: ${activeCatSpec.name} (${activeCatSpec.tier})',
                      key: const ValueKey('cat-settings-selected-name'),
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: activeTheme.accent,
                      ),
                    ),
                    const SizedBox(height: 10),
                    CatWithOutfitAvatar(
                      catAnimPath: catAnimPath,
                      equippedOutfit: equippedOutfit,
                      width: 110 * companionScale.clamp(0.60, 1.30),
                      height: 134 * companionScale.clamp(0.60, 1.30),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 2. Bộ chọn Linh Thú Đại Diện (Hiển thị các giống mèo ĐÃ SỞ HỮU)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: activeTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: activeTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const AppAssetIcon(AppIcons.paw, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Linh Thú Đại Diện Đã Sở Hữu (${ownedCats.length}/${CatCatalog.characters.length})',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: activeTheme.textPrimary,
                      ),
                    ),
                  ),
                  InkWell(
                    key: const ValueKey('cat-settings-open-cat-shop'),
                    onTap: onGoToCatShop,
                    borderRadius: BorderRadius.circular(999),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: activeTheme.primarySoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const AppAssetIcon(AppIcons.shop, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            'Shop Linh Thú',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.accent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Chạm vào Linh Thú bên dưới để đổi mèo xuất hiện ở Phòng Mèo & thanh điều hướng.',
                style: TextStyle(
                  fontSize: 12,
                  color: activeTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.05,
                ),
                itemCount: ownedCats.length,
                itemBuilder: (context, idx) {
                  final cat = ownedCats[idx];
                  final isCurrent = selectedCatId == cat.folderId;
                  return InkWell(
                    key: ValueKey('select-cat-${cat.folderId}'),
                    onTap: () => onSelectCat(cat),
                    borderRadius: BorderRadius.circular(18),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isCurrent ? activeTheme.primarySoft : activeTheme.background,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: isCurrent ? activeTheme.primary : activeTheme.borderSubtle,
                          width: isCurrent ? 1.8 : 1.0,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 58,
                            height: 58,
                            child: AppAssetIcon(
                              cat.idleAssetPath,
                              width: 58,
                              height: 58,
                              fit: BoxFit.contain,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            cat.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3.5),
                            decoration: BoxDecoration(
                              color: isCurrent ? activeTheme.primary : activeTheme.surface,
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: activeTheme.primary),
                            ),
                            child: Text(
                              isCurrent ? 'Đang chọn' : 'Chọn',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: isCurrent ? Colors.white : activeTheme.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 3. Bộ chọn Chủ đề Giao diện (Theme Selector - Chỉ hiển thị các Theme đã mở khóa/đã mua)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: activeTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: activeTheme.borderSubtle),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const AppAssetIcon(AppIcons.star, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Chủ Đề Giao Diện Đã Sở Hữu (${unlockedThemes.length}/${AppTheme.themes.length})',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: activeTheme.textPrimary,
                      ),
                    ),
                  ),
                  InkWell(
                    key: const ValueKey('cat-settings-open-theme-shop'),
                    onTap: onGoToThemeShop,
                    borderRadius: BorderRadius.circular(999),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: activeTheme.primarySoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const AppAssetIcon(AppIcons.shop, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            'Shop Chủ đề',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: activeTheme.accent,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Chạm vào chủ đề đã mở khóa bên dưới để đổi màu sắc toàn ứng dụng tức thì.',
                style: TextStyle(
                  fontSize: 12,
                  color: activeTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              for (final themeSpec in unlockedThemes) ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    key: ValueKey('select-theme-${themeSpec.id}'),
                    onTap: () => onSelectTheme(themeSpec.id),
                    borderRadius: BorderRadius.circular(16),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                      decoration: BoxDecoration(
                        color: selectedThemeId == themeSpec.id
                            ? themeSpec.primarySoft
                            : activeTheme.background,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: selectedThemeId == themeSpec.id
                              ? themeSpec.primary
                              : activeTheme.borderSubtle,
                          width: selectedThemeId == themeSpec.id ? 1.8 : 1.0,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: themeSpec.background,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: themeSpec.primary),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              themeSpec.emoji,
                              style: const TextStyle(fontSize: 18),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  themeSpec.displayName,
                                  style: TextStyle(
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w800,
                                    color: activeTheme.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  themeSpec.subtitle,
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    color: activeTheme.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: themeSpec.primary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: themeSpec.secondary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: selectedThemeId == themeSpec.id
                                      ? themeSpec.primary
                                      : activeTheme.surface,
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(
                                    color: themeSpec.primary,
                                  ),
                                ),
                                child: Text(
                                  selectedThemeId == themeSpec.id
                                      ? 'Đang dùng'
                                      : 'Áp dụng',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    color: selectedThemeId == themeSpec.id
                                        ? Colors.white
                                        : themeSpec.primary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _FoodInventoryBottomSheet extends StatelessWidget {
  final ValueChanged<CatFoodSpec> onSelectFood;
  final VoidCallback onGoToShop;

  const _FoodInventoryBottomSheet({
    required this.onSelectFood,
    required this.onGoToShop,
  });

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProgressProvider>();
    final inventory = provider.progress.foodInventory;
    final ownedItems = <MapEntry<CatFoodSpec, int>>[];
    for (final spec in CatCatalog.foods) {
      final qty = inventory[spec.assetPath] ?? 0;
      if (qty > 0) {
        ownedItems.add(MapEntry(spec, qty));
      }
    }

    return Container(
      constraints: const BoxConstraints(maxHeight: 500),
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.borderSubtle,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const AppAssetIcon(AppIcons.hunger, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Túi Đồ Thức Ăn (Chọn món cho Mèo ăn)',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ),
              InkWell(
                onTap: onGoToShop,
                borderRadius: BorderRadius.circular(999),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppTheme.primarySoft,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AppAssetIcon(AppIcons.shop, size: 14),
                      SizedBox(width: 4),
                      Text(
                        'Tới Shop',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.accent,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (ownedItems.isEmpty)
            Padding(
              padding: EdgeInsets.symmetric(vertical: 28),
              child: Center(
                child: Column(
                  children: [
                    AppAssetIcon(AppIcons.gift, size: 40),
                    SizedBox(height: 10),
                    Text(
                      'Bạn chưa có món ăn nào trong Túi đồ!',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Hãy mở tab Shop để mua Trái cây, Món chính hoặc Hải sản cho Mèo nhé.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
            )
          else
            Flexible(
              child: GridView.builder(
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.78,
                ),
                itemCount: ownedItems.length,
                itemBuilder: (context, idx) {
                  final entry = ownedItems[idx];
                  final food = entry.key;
                  final qty = entry.value;
                  return InkWell(
                    key: ValueKey('sheet-feed-${food.assetPath}'),
                    onTap: () => onSelectFood(food),
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.background,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                width: 50,
                                height: 50,
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: AppTheme.surface,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: AppTheme.borderSubtle),
                                ),
                                child: AppAssetIcon.food(food.assetPath, size: 36),
                              ),
                              Positioned(
                                right: -6,
                                top: -6,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: AppTheme.accent,
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    'x$qty',
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            food.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '+${food.hungerBonus}% No · +${food.moodBonus}% Vui',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _OutfitWardrobeBottomSheet extends StatelessWidget {
  final ValueChanged<CatOutfitSpec?> onEquipOutfit;
  final VoidCallback onGoToOutfitShop;

  const _OutfitWardrobeBottomSheet({
    required this.onEquipOutfit,
    required this.onGoToOutfitShop,
  });

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProgressProvider>();
    final progress = provider.progress;
    final ownedPaths = progress.ownedOutfits.toSet();
    final ownedOutfits = CatCatalog.outfits
        .where((spec) => ownedPaths.contains(spec.assetPath))
        .toList();

    return Container(
      constraints: const BoxConstraints(maxHeight: 520),
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.borderSubtle,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const AppAssetIcon(AppIcons.inventory, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Tủ Đồ Trang Phục Đã Sở Hữu (${ownedOutfits.length}/${CatCatalog.outfits.length})',
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ),
              if (progress.equippedOutfit != null)
                InkWell(
                  key: const ValueKey('wardrobe-unequip-btn'),
                  onTap: () => onEquipOutfit(null),
                  borderRadius: BorderRadius.circular(999),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceSoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'Cởi trang phục',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (ownedOutfits.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 28),
              child: Center(
                child: Column(
                  children: [
                    const AppAssetIcon(AppIcons.crown, size: 40),
                    const SizedBox(height: 10),
                    Text(
                      'Tủ đồ chưa có bộ trang phục nào!',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Hãy ghé Cửa hàng Trang phục (${CatCatalog.outfits.length} bộ) để sắm đồ mới cho Mèo Hộ Pháp.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                    ),
                    const SizedBox(height: 14),
                    InkWell(
                      onTap: onGoToOutfitShop,
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: AppTheme.primary,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AppAssetIcon(AppIcons.shop, size: 16),
                            SizedBox(width: 6),
                            Text(
                              'Mở Shop Trang Phục',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Flexible(
              child: GridView.builder(
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.80,
                ),
                itemCount: ownedOutfits.length,
                itemBuilder: (context, idx) {
                  final outfit = ownedOutfits[idx];
                  final isEquipped = progress.equippedOutfit == outfit.assetPath;
                  return InkWell(
                    key: ValueKey('equip-outfit-${outfit.index}'),
                    onTap: () => onEquipOutfit(isEquipped ? null : outfit),
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isEquipped ? AppTheme.primarySoft : AppTheme.background,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isEquipped ? AppTheme.primary : AppTheme.borderSubtle,
                          width: isEquipped ? 1.8 : 1.0,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: AppTheme.surface,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppTheme.borderSubtle),
                            ),
                            child: CatOutfitPreviewBox(
                              outfitPath: outfit.assetPath,
                              size: 62,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            outfit.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: isEquipped ? AppTheme.accent : AppTheme.primary,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              isEquipped ? 'Đang mặc · Cởi' : 'Mặc thử / Trang bị',
                              style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
