import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/bgm_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/line_companion_cat.dart';
import '../cat/guardian_cat_screen.dart';
import '../home/home_screen.dart';
import '../home/leaderboard_screen.dart';
import '../jlpt/jlpt_screen.dart';

/// Vỏ chính với đúng 4 tab: Học, Luyện đề, Xếp hạng, Mèo.
class MainShell extends StatefulWidget {
  final int initialIndex;

  const MainShell({super.key, this.initialIndex = 0});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  static const _tabs = <_TabSpec>[
    _TabSpec(label: 'Học', icon: AppAssets.navHome),
    _TabSpec(label: 'Luyện đề', icon: AppAssets.learnGraduationCap),
    _TabSpec(label: 'Xếp hạng', icon: AppAssets.achTrophy),
    _TabSpec(label: 'Trợ lý AI & Không gian', icon: AppAssets.navPaw),
  ];

  final CompanionCatController _catController = CompanionCatController(
    defaultSurfaceId: 'home_progress_card',
    initialRatio: 0.72,
  );
  late int _index = widget.initialIndex.clamp(0, _tabs.length - 1);
  bool? _lastSoundEnabled;

  late final List<Widget> _pages = [
    HomeScreen(onOpenJlpt: () => _select(1)),
    const JLPTScreen(),
    const LeaderboardScreen(),
    const GuardianCatScreen(),
  ];

  @override
  void dispose() {
    _catController.dispose();
    super.dispose();
  }

  void _select(int index) {
    if (index == _index) return;
    setState(() => _index = index);
    WidgetsBinding.instance.addPostFrameCallback((_) => _catController.relayout());
  }

  void _syncMusic(bool enabled) {
    if (_lastSoundEnabled == enabled) return;
    _lastSoundEnabled = enabled;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (enabled) {
        await BgmService.instance.playStudyMusic();
      } else {
        await BgmService.instance.stop();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    _syncMusic(context.watch<SettingsProvider>().soundEnabled);
    final progress = context.watch<ProgressProvider>().progress;
    final themeSpec = AppTheme.specFor(progress.selectedThemeId);

    return CompanionCatScope(
      controller: _catController,
      child: Scaffold(
        backgroundColor: themeSpec.background,
        body: NotificationListener<ScrollNotification>(
          onNotification: (_) {
            _catController.relayout();
            return false;
          },
          child: Stack(
            children: [
              IndexedStack(index: _index, children: _pages),
              Positioned.fill(
                child: LineCompanionCat(
                  controller: _catController,
                  catId: progress.selectedCatId,
                  anchorsActive: _index != 3,
                  visible: progress.catCompanionEnabled && _index != 3,
                  scale: progress.catCompanionScale,
                  equippedOutfit: progress.equippedOutfit,
                  hunger: progress.catHunger,
                  energy: progress.catEnergy,
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _BottomNav(
          tabs: _tabs,
          currentIndex: _index,
          onSelect: _select,
          themeSpec: themeSpec,
        ),
      ),
    );
  }
}

class _TabSpec {
  final String label;
  final String icon;

  const _TabSpec({required this.label, required this.icon});
}

class _BottomNav extends StatelessWidget {
  final List<_TabSpec> tabs;
  final int currentIndex;
  final ValueChanged<int> onSelect;
  final AppThemeSpec themeSpec;

  const _BottomNav({
    required this.tabs,
    required this.currentIndex,
    required this.onSelect,
    required this.themeSpec,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: themeSpec.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
        border: Border.all(color: themeSpec.borderSubtle),
        boxShadow: [
          BoxShadow(
            color: themeSpec.textPrimary.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        child: Row(
          children: [
            for (var i = 0; i < tabs.length; i++)
              Expanded(
                child: _NavItem(
                  spec: tabs[i],
                  selected: i == currentIndex,
                  onTap: () => onSelect(i),
                  themeSpec: themeSpec,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final _TabSpec spec;
  final bool selected;
  final VoidCallback onTap;
  final AppThemeSpec themeSpec;

  const _NavItem({
    required this.spec,
    required this.selected,
    required this.onTap,
    required this.themeSpec,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      selected: selected,
      button: true,
      label: spec.label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 7),
          decoration: BoxDecoration(
            color: selected ? themeSpec.primary.withValues(alpha: 0.14) : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: selected ? 1 : 0.55,
                child: AnimatedScale(
                  duration: const Duration(milliseconds: 200),
                  scale: selected ? 1.08 : 1,
                  child: AppAssetIcon(spec.icon, size: 26),
                ),
              ),
              const SizedBox(height: 3),
              Text(
                spec.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: selected ? themeSpec.primary : themeSpec.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
