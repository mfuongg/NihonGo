import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../providers/progress_provider.dart';
import '../../services/gemini_exam_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../grammar/grammar_screen.dart';
import '../kanji/kanji_screen.dart';
import '../vocabulary/pronunciation_practice_screen.dart';
import '../vocabulary/vocabulary_screen.dart';
import '../vocabulary/writing_practice_screen.dart';

class TutorChatMessage {
  final String id;
  final bool isUser;
  final String query;
  final String text;
  final String level;
  final List<TutorRetrievedItem> retrievedSqliteItems;
  final String? aiGeneratedExplanation;
  final bool isAiOnline;
  final String? errorMessage;
  final String suggestedPracticeRoute;
  final DateTime createdAt;

  const TutorChatMessage({
    required this.id,
    required this.isUser,
    this.query = '',
    required this.text,
    required this.level,
    this.retrievedSqliteItems = const <TutorRetrievedItem>[],
    this.aiGeneratedExplanation,
    this.isAiOnline = false,
    this.errorMessage,
    this.suggestedPracticeRoute = 'vocab',
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'isUser': isUser,
        'query': query,
        'text': text,
        'level': level,
        'retrievedSqliteItems':
            retrievedSqliteItems.map((e) => e.toJson()).toList(),
        'aiGeneratedExplanation': aiGeneratedExplanation,
        'isAiOnline': isAiOnline,
        'errorMessage': errorMessage,
        'suggestedPracticeRoute': suggestedPracticeRoute,
        'createdAt': createdAt.toIso8601String(),
      };

  factory TutorChatMessage.fromJson(Map<String, dynamic> map) {
    final rawItems = map['retrievedSqliteItems'];
    final items = <TutorRetrievedItem>[];
    if (rawItems is List) {
      for (final item in rawItems) {
        if (item is Map<String, dynamic>) {
          items.add(TutorRetrievedItem.fromJson(item));
        } else if (item is Map) {
          items.add(
            TutorRetrievedItem.fromJson(Map<String, dynamic>.from(item)),
          );
        }
      }
    }
    return TutorChatMessage(
      id: map['id']?.toString() ?? '',
      isUser: map['isUser'] == true,
      query: map['query']?.toString() ?? '',
      text: map['text']?.toString() ?? '',
      level: map['level']?.toString() ?? 'N5',
      retrievedSqliteItems: items,
      aiGeneratedExplanation: map['aiGeneratedExplanation']?.toString(),
      isAiOnline: map['isAiOnline'] == true,
      errorMessage: map['errorMessage']?.toString(),
      suggestedPracticeRoute:
          map['suggestedPracticeRoute']?.toString() ?? 'vocab',
      createdAt: DateTime.tryParse(map['createdAt']?.toString() ?? '') ??
          DateTime.now(),
    );
  }
}

class QuangThuongTutorScreen extends StatefulWidget {
  final String? initialPrompt;

  const QuangThuongTutorScreen({
    super.key,
    this.initialPrompt,
  });

  @override
  State<QuangThuongTutorScreen> createState() => _QuangThuongTutorScreenState();
}

class _QuangThuongTutorScreenState extends State<QuangThuongTutorScreen> {
  static const String _historyPrefsKey = 'quang_thuong_tutor_chat_history_v1';
  static const List<String> _levels = <String>['N5', 'N4', 'N3', 'N2', 'N1'];

  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<TutorChatMessage> _messages = <TutorChatMessage>[];
  String _selectedLevel = 'N5';
  bool _isSending = false;

  static const List<String> _quickSuggestions = <String>[
    'Giải thích ngữ pháp N5 và cho câu ví dụ',
    'Tra cứu Kanji N5 và số nét viết',
    'Từ vựng tiếng Nhật chủ đề trường học',
    'Cách phân biệt trợ từ は và が',
    'Gợi ý bài luyện đọc hiểu phù hợp cấp độ',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final progress = context.read<ProgressProvider>();
      setState(() {
        _selectedLevel = progress.progress.selectedLevel;
      });
      await _loadPersistedHistory();
      if (widget.initialPrompt != null &&
          widget.initialPrompt!.trim().isNotEmpty) {
        await _sendMessage(widget.initialPrompt!.trim());
      }
    });
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadPersistedHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_historyPrefsKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          final loaded = <TutorChatMessage>[];
          for (final item in decoded) {
            if (item is Map<String, dynamic>) {
              loaded.add(TutorChatMessage.fromJson(item));
            } else if (item is Map) {
              loaded.add(
                TutorChatMessage.fromJson(Map<String, dynamic>.from(item)),
              );
            }
          }
          if (loaded.isNotEmpty && mounted) {
            setState(() {
              _messages
                ..clear()
                ..addAll(loaded.take(20));
            });
            _scrollToBottom();
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _saveHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final recent = _messages.length > 20
          ? _messages.sublist(_messages.length - 20)
          : _messages;
      final raw = jsonEncode(recent.map((m) => m.toJson()).toList());
      await prefs.setString(_historyPrefsKey, raw);
    } catch (_) {}
  }

  Future<void> _clearHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_historyPrefsKey);
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _messages.clear();
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 240),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _sendMessage([
    String? customText,
    bool appendUserBubble = true,
    int? insertAtIndex,
  ]) async {
    if (_isSending) return;
    final query = (customText ?? _inputController.text).trim();
    if (query.isEmpty) return;

    if (customText == null) {
      _inputController.clear();
    }

    final progress = context.read<ProgressProvider>();
    setState(() {
      if (appendUserBubble) {
        _messages.add(
          TutorChatMessage(
            id: 'u_${DateTime.now().millisecondsSinceEpoch}',
            isUser: true,
            query: query,
            text: query,
            level: _selectedLevel,
            createdAt: DateTime.now(),
          ),
        );
      }
      _isSending = true;
    });
    _scrollToBottom();

    try {
      final response = await GeminiExamService.instance.askQuangThuongTutor(
        query: query,
        level: _selectedLevel,
        learnedVocabCount: progress.progress.learnedVocabIds.length,
        learnedKanjiCount: progress.progress.learnedKanjiIds.length,
      );

      if (!mounted) return;
      final botMsg = TutorChatMessage(
        id: 'b_${DateTime.now().millisecondsSinceEpoch}',
        isUser: false,
        query: response.query,
        text: response.sqliteSummaryAnswer,
        level: response.level,
        retrievedSqliteItems: response.retrievedSqliteItems,
        aiGeneratedExplanation: response.aiGeneratedExplanation,
        isAiOnline: response.isAiOnline,
        errorMessage: response.errorMessage,
        suggestedPracticeRoute: response.suggestedPracticeRoute,
        createdAt: DateTime.now(),
      );

      setState(() {
        if (insertAtIndex != null &&
            insertAtIndex >= 0 &&
            insertAtIndex <= _messages.length) {
          _messages.insert(insertAtIndex, botMsg);
        } else {
          _messages.add(botMsg);
        }
        _isSending = false;
      });
      await _saveHistory();
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      final errMsg = TutorChatMessage(
        id: 'b_err_${DateTime.now().millisecondsSinceEpoch}',
        isUser: false,
        query: query,
        text:
            'Trẫm gặp sự cố khi tra cứu câu hỏi "$query". Con sen hãy bấm "Gửi lại" nhé!',
        level: _selectedLevel,
        isAiOnline: false,
        errorMessage: 'Lỗi xử lý yêu cầu: $e',
        createdAt: DateTime.now(),
      );
      setState(() {
        if (insertAtIndex != null &&
            insertAtIndex >= 0 &&
            insertAtIndex <= _messages.length) {
          _messages.insert(insertAtIndex, errMsg);
        } else {
          _messages.add(errMsg);
        }
        _isSending = false;
      });
      _scrollToBottom();
    }
  }

  Future<void> _retryFailedMessage(TutorChatMessage failedBotMsg) async {
    if (_isSending) return;
    final idx = _messages.indexWhere((m) => m.id == failedBotMsg.id);
    String question = failedBotMsg.query.trim();
    if (question.isEmpty) {
      question = _findLastUserQuestion();
      if (idx > 0) {
        for (var i = idx - 1; i >= 0; i--) {
          if (_messages[i].isUser && _messages[i].text.trim().isNotEmpty) {
            question = _messages[i].text.trim();
            break;
          }
        }
      }
    }
    setState(() {
      _messages.removeWhere((m) => m.id == failedBotMsg.id);
    });
    await _sendMessage(question, false, idx >= 0 ? idx : null);
  }

  void _openSuggestedPractice(TutorChatMessage msg) {
    final route = msg.suggestedPracticeRoute;
    final level = msg.level;
    TutorRetrievedItem? matchedVocab;
    for (final it in msg.retrievedSqliteItems) {
      if (it.category == 'Từ vựng' &&
          it.itemId != null &&
          it.itemId!.trim().isNotEmpty) {
        matchedVocab = it;
        break;
      }
    }
    final Widget screen = switch (route) {
      'writing' => WritingPracticeScreen(level: level),
      'pronunciation' => PronunciationPracticeScreen(level: level),
      'kanji' => const KanjiScreen(),
      'grammar' => const GrammarScreen(),
      _ => VocabularyScreen(
          initialLevel: matchedVocab?.level ?? level,
          initialVocabId: matchedVocab?.itemId,
        ),
    };
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final palette = CozyPalette.of(context);
    final levelColor = AppTheme.jlptColor(_selectedLevel);

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: palette.background,
      appBar: AppBar(
        backgroundColor: palette.surface,
        surfaceTintColor: Colors.transparent,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppAssets.labTutorCat, size: 28),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                'Gia Sư Quàng Thượng',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: levelColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: levelColor.withValues(alpha: 0.28)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedLevel,
                isDense: true,
                borderRadius: BorderRadius.circular(12),
                dropdownColor: palette.surface,
                items: _levels
                    .map(
                      (lv) => DropdownMenuItem<String>(
                        value: lv,
                        child: Text(
                          lv,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: AppTheme.jlptColor(lv),
                          ),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (lv) {
                  if (lv == null) return;
                  setState(() => _selectedLevel = lv);
                },
              ),
            ),
          ),
          IconButton(
            tooltip: 'Xóa lịch sử trò chuyện',
            onPressed: _messages.isEmpty ? null : _clearHistory,
            icon: const Icon(Icons.delete_sweep_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 820),
            child: Column(
              children: [
                _buildTutorHeaderBanner(palette, levelColor),
                _buildSuggestionStrip(palette, levelColor),
                Expanded(
                  child: _messages.isEmpty
                      ? _buildEmptyState(palette, levelColor)
                      : ListView.builder(
                          controller: _scrollController,
                          keyboardDismissBehavior:
                              ScrollViewKeyboardDismissBehavior.onDrag,
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                          itemCount: _messages.length + (_isSending ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index == _messages.length) {
                              return _buildTypingIndicator(palette, levelColor);
                            }
                            final msg = _messages[index];
                            return msg.isUser
                                ? _buildUserBubble(msg, levelColor)
                                : _buildTutorBubble(palette, msg, levelColor);
                          },
                        ),
                ),
                _buildInputBar(palette, levelColor),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTutorHeaderBanner(CozyPalette palette, Color levelColor) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: levelColor.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: levelColor.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          const AppAssetIcon(AppAssets.labTutorCat, size: 38),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Gia sư Quàng Thượng • Gemini + SQLite RAG ($_selectedLevel)',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    color: levelColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Tách biệt rõ dữ liệu chuẩn truy xuất từ SQLite và lời giảng mở rộng từ AI.',
                  style: TextStyle(fontSize: 12, color: palette.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestionStrip(CozyPalette palette, Color levelColor) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        scrollDirection: Axis.horizontal,
        itemCount: _quickSuggestions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final suggestion = _quickSuggestions[index];
          return ActionChip(
            backgroundColor: palette.surface,
            side: BorderSide(color: palette.borderSubtle),
            avatar: const AppAssetIcon(AppAssets.labChatbot, size: 16),
            label: Text(
              suggestion,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: palette.textPrimary,
              ),
            ),
            onPressed: _isSending ? null : () => _sendMessage(suggestion),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(CozyPalette palette, Color levelColor) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppAssets.labTutorCat, size: 78),
            const SizedBox(height: 14),
            Text(
              'Meow~ Hỏi Quàng Thượng bất cứ điều gì về tiếng Nhật!',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: palette.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Quàng Thượng sẽ tra cứu từ vựng, Kanji, ngữ pháp và bài đọc trong SQLite trước, sau đó dùng Gemini giải thích chi tiết phù hợp cấp độ của bạn.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: palette.textSecondary,
                height: 1.45,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypingIndicator(CozyPalette palette, Color levelColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const AppAssetIcon(AppAssets.aiStateLoading, size: 32),
          const SizedBox(width: 10),
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: palette.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: palette.borderSubtle),
              ),
              child: Text(
                'Quàng Thượng đang tra cứu SQLite & hỏi Gemini...',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: palette.textSecondary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserBubble(TutorChatMessage msg, Color levelColor) {
    return Align(
      alignment: Alignment.centerRight,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12, left: 36),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: levelColor,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(18),
              topRight: Radius.circular(18),
              bottomLeft: Radius.circular(18),
              bottomRight: Radius.circular(4),
            ),
          ),
          child: Text(
            msg.text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
              height: 1.4,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTutorBubble(
    CozyPalette palette,
    TutorChatMessage msg,
    Color levelColor,
  ) {
    final routeLabel = switch (msg.suggestedPracticeRoute) {
      'writing' => 'Luyện viết ngay',
      'pronunciation' => 'Luyện phát âm ngay',
      'kanji' => 'Mở bảng Kanji',
      'grammar' => 'Mở bài Ngữ pháp',
      _ => 'Mở kho Từ vựng',
    };
    final routeIcon = switch (msg.suggestedPracticeRoute) {
      'writing' => AppAssets.labWriting,
      'pronunciation' => AppAssets.labPronunciation,
      'kanji' => AppAssets.labKanji,
      'grammar' => AppAssets.labGrammar,
      _ => AppAssets.labVocab,
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 14, right: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: levelColor.withValues(alpha: 0.22)),
        boxShadow: palette.softCardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 6,
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const AppAssetIcon(AppAssets.labTutorCat, size: 26),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      'Gia Sư Quàng Thượng',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        color: palette.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: (msg.isAiOnline
                          ? AppTheme.successGreen
                          : AppTheme.accentBlue)
                      .withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  msg.isAiOnline
                      ? 'Gemini + SQLite RAG'
                      : 'SQLite Tra Cứu Chuẩn • Gemini Offline',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: msg.isAiOnline
                        ? AppTheme.successGreen
                        : AppTheme.accentBlue,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // 1. Khối dữ liệu truy xuất từ SQLite
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: levelColor.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: levelColor.withValues(alpha: 0.18)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const AppAssetIcon(AppAssets.labReadingBook, size: 16),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'Dữ liệu chuẩn truy xuất từ SQLite (${msg.level})',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                          color: levelColor,
                        ),
                      ),
                    ),
                    if (msg.retrievedSqliteItems.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: levelColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          '${msg.retrievedSqliteItems.length} mục',
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            color: levelColor,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  msg.text,
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.45,
                    color: palette.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          // 2. Khối lời giảng do Gemini AI sinh thêm (tách biệt rõ ràng)
          if (msg.aiGeneratedExplanation != null &&
              msg.aiGeneratedExplanation!.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.successGreen.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.successGreen.withValues(alpha: 0.22),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      AppAssetIcon(AppAssets.labAiPractice, size: 16),
                      SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Lời giảng mở rộng từ AI Gemini',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            color: AppTheme.successGreen,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    msg.aiGeneratedExplanation!,
                    style: TextStyle(
                      fontSize: 13.5,
                      height: 1.48,
                      color: palette.textPrimary,
                    ),
                  ),
                ],
              ),
            ),
          ],
          // 3. Khối thông báo lỗi / ngoại tuyến kèm nút Gửi lại
          if (msg.errorMessage != null &&
              msg.errorMessage!.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: palette.coinSoft,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: palette.warning.withValues(alpha: 0.5)),
              ),
              child: Wrap(
                spacing: 8,
                runSpacing: 6,
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const AppAssetIcon(AppAssets.aiStateError, size: 20),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          msg.errorMessage!,
                          style: TextStyle(
                            fontSize: 12,
                            color: palette.textPrimary,
                            height: 1.35,
                          ),
                        ),
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed:
                        _isSending ? null : () => _retryFailedMessage(msg),
                    style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      foregroundColor: levelColor,
                    ),
                    icon: const Icon(Icons.refresh_rounded, size: 16),
                    label: const Text(
                      'Gửi lại',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              alignment: WrapAlignment.end,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                if ((msg.errorMessage == null ||
                        msg.errorMessage!.trim().isEmpty) &&
                    !msg.isAiOnline)
                  TextButton.icon(
                    onPressed:
                        _isSending ? null : () => _retryFailedMessage(msg),
                    style: TextButton.styleFrom(
                      visualDensity: VisualDensity.compact,
                      foregroundColor: levelColor,
                    ),
                    icon: const Icon(Icons.refresh_rounded, size: 16),
                    label: const Text(
                      'Gửi lại',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                OutlinedButton.icon(
                  onPressed: () => _openSuggestedPractice(msg),
                  icon: AppAssetIcon(routeIcon, size: 18),
                  label: Text(routeLabel),
                  style: OutlinedButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                    foregroundColor: levelColor,
                    side: BorderSide(color: levelColor.withValues(alpha: 0.35)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _findLastUserQuestion() {
    for (var i = _messages.length - 1; i >= 0; i--) {
      if (_messages[i].isUser && _messages[i].text.trim().isNotEmpty) {
        return _messages[i].text.trim();
      }
    }
    return _quickSuggestions.first;
  }

  Widget _buildInputBar(CozyPalette palette, Color levelColor) {
    final canSend = !_isSending && _inputController.text.trim().isNotEmpty;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: BoxDecoration(
        color: palette.surface,
        border: Border(top: BorderSide(color: palette.borderSubtle)),
        boxShadow: palette.softCardShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: TextField(
              controller: _inputController,
              onChanged: (_) => setState(() {}),
              onSubmitted: (_) => _sendMessage(),
              minLines: 1,
              maxLines: 3,
              textInputAction: TextInputAction.send,
              style: TextStyle(color: palette.textPrimary, fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                filled: true,
                fillColor: palette.background,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                hintText:
                    'Hỏi Quàng Thượng về từ vựng, Kanji, ngữ pháp $_selectedLevel...',
                hintStyle: TextStyle(color: palette.textSecondary, fontSize: 13),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: palette.borderSubtle),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: levelColor, width: 1.5),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          ElevatedButton.icon(
            onPressed: canSend ? () => _sendMessage() : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: levelColor,
              foregroundColor: Colors.white,
              minimumSize: const Size(52, 46),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            icon: _isSending
                ? const AppAssetIcon(AppAssets.aiStateLoading, size: 18)
                : const AppAssetIcon(AppAssets.labChatbot, size: 18),
            label: const Text('Gửi'),
          ),
        ],
      ),
    );
  }
}
