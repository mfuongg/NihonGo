import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/flashcard_provider.dart';
import '../../providers/progress_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../grammar/grammar_screen.dart';
import '../jlpt/jlpt_screen.dart';
import '../kanji/kanji_screen.dart';
import '../read/read_screen.dart';
import '../vocabulary/listening_practice_screen.dart';
import '../vocabulary/pronunciation_practice_screen.dart';
import '../vocabulary/vocabulary_screen.dart';
import '../vocabulary/writing_practice_screen.dart';
import 'quang_thuong_tutor_screen.dart';

class AiPracticeLabScreen extends StatefulWidget {
  final String? initialLevel;

  const AiPracticeLabScreen({
    super.key,
    this.initialLevel,
  });

  @override
  State<AiPracticeLabScreen> createState() => _AiPracticeLabScreenState();
}

class _AiPracticeLabScreenState extends State<AiPracticeLabScreen> {
  static const List<String> _levels = <String>['N5', 'N4', 'N3', 'N2', 'N1'];
  late String _selectedLevel;

  @override
  void initState() {
    super.initState();
    final currentLv = context.read<ProgressProvider>().progress.selectedLevel;
    _selectedLevel = widget.initialLevel ?? currentLv;
  }

  Future<void> _openAdaptiveQuestTarget(AdaptiveQuest quest) async {
    final lv = quest.level;

    final Widget targetScreen = switch (quest.skillType) {
      'vocab' => const VocabularyScreen(),
      'kanji' => WritingPracticeScreen(
          level: lv,
          initialTargetType: 'kanji',
          title: 'Luyện viết Kanji $lv',
        ),
      'grammar' => const GrammarScreen(),
      'reading' => const ReadScreen(),
      'listening' => PronunciationPracticeScreen(
          level: lv,
          title: 'Luyện nghe & phát âm $lv',
        ),
      _ => WritingPracticeScreen(level: lv),
    };

    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => targetScreen),
    );
  }

  Future<void> _claimQuest(AdaptiveQuest quest) async {
    final progress = context.read<ProgressProvider>();
    final claimed = await progress.claimAdaptiveQuestReward(
      quest.id,
      levelOverride: quest.level,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          claimed
              ? 'Đã nhận +${quest.xpReward} XP và +${quest.coinReward} Xu từ nhiệm vụ "${quest.title}"!'
              : 'Nhiệm vụ này đã nhận thưởng hoặc chưa đủ tiến độ.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = context.watch<ProgressProvider>();
    final flashcard = context.watch<FlashcardProvider>();
    final palette = CozyPalette.of(context);
    final levelColor = AppTheme.jlptColor(_selectedLevel);
    final adaptiveQuests = progress.getAdaptiveQuests(
      levelOverride: _selectedLevel,
      dueSrsCount: flashcard.dueCount,
    );

    return Scaffold(
      backgroundColor: palette.background,
      appBar: AppBar(
        backgroundColor: palette.surface,
        surfaceTintColor: Colors.transparent,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppAssets.labAiPractice, size: 26),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                'AI Practice Lab',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: levelColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: levelColor.withValues(alpha: 0.28)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedLevel,
                isDense: true,
                borderRadius: BorderRadius.circular(12),
                dropdownColor: palette.surface,
                items: _levels
                    .map(
                      (lv) => DropdownMenuItem<String>(
                        value: lv,
                        child: Text(
                          'JLPT $lv',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: AppTheme.jlptColor(lv),
                          ),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (lv) {
                  if (lv == null) return;
                  setState(() => _selectedLevel = lv);
                  progress.setSelectedLevel(lv);
                },
              ),
            ),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 860),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
              children: [
                _buildHeroBanner(levelColor, progress),
                const SizedBox(height: 20),
                _buildSectionHeader(
                  palette: palette,
                  iconAsset: AppAssets.labAiPractice,
                  title: '4 Chế độ Luyện tập AI Trọng tâm',
                  subtitle:
                      'Luyện viết nét chữ, phát âm tiếng Nhật, hỏi đáp gia sư Quàng Thượng và thi thử RAG',
                ),
                const SizedBox(height: 12),
                _buildCoreFeaturesGrid(palette, levelColor),
                const SizedBox(height: 22),
                _buildSectionHeader(
                  palette: palette,
                  iconAsset: AppAssets.labAdaptiveQuest,
                  title: 'Nhiệm vụ Luyện tập Thích ứng ($_selectedLevel)',
                  subtitle:
                      'Gợi ý tự động theo tiến độ học thật, từ SRS đến hạn và kỹ năng cần củng cố',
                ),
                const SizedBox(height: 12),
                if (adaptiveQuests.isEmpty)
                  _buildEmptyQuestState(palette, levelColor)
                else
                  ...adaptiveQuests.map(
                    (quest) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: _buildAdaptiveQuestCard(palette, quest, levelColor),
                    ),
                  ),
                const SizedBox(height: 18),
                _buildSectionHeader(
                  palette: palette,
                  iconAsset: AppAssets.labAiDrill,
                  title: 'Kho Học liệu & Luyện kỹ năng Chuẩn ($_selectedLevel)',
                  subtitle:
                      'Truy cập trực tiếp Từ vựng, Kanji, Ngữ pháp, Đọc hiểu và Nghe hiểu',
                ),
                const SizedBox(height: 10),
                _buildSkillShortcutsRow(palette, levelColor),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeroBanner(Color levelColor, ProgressProvider progress) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            levelColor.withValues(alpha: 0.92),
            levelColor,
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: levelColor.withValues(alpha: 0.22),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.20),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Center(
              child: AppAssetIcon(AppAssets.labTutorCat, size: 48),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Phòng Thí Nghiệm AI • JLPT $_selectedLevel',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Đã thuộc ${progress.progress.learnedVocabIds.length} từ vựng • ${progress.progress.learnedKanjiIds.length} Kanji • Chuỗi ${progress.progress.currentStreak} ngày',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const QuangThuongTutorScreen(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: levelColor,
                    visualDensity: VisualDensity.compact,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                  icon: const AppAssetIcon(AppAssets.labChatbot, size: 18),
                  label: const Text(
                    'Hỏi Gia sư Quàng Thượng ngay',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader({
    required CozyPalette palette,
    required String iconAsset,
    required String title,
    required String subtitle,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppAssetIcon(iconAsset, size: 24),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 15.5,
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: palette.textSecondary,
                  height: 1.35,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCoreFeaturesGrid(CozyPalette palette, Color levelColor) {
    final cards = <_LabFeatureItem>[
      _LabFeatureItem(
        iconAsset: AppAssets.labWriting,
        title: 'Luyện viết tiếng Nhật',
        subtitle: 'Tập viết nét chữ Từ vựng & Kanji $_selectedLevel',
        badge: 'Viết tay & Chấm nét',
        color: const Color(0xFFD97080),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => WritingPracticeScreen(level: _selectedLevel),
            ),
          );
        },
      ),
      _LabFeatureItem(
        iconAsset: AppAssets.labPronunciation,
        title: 'Luyện đọc & Phát âm',
        subtitle: 'Nghe mẫu chuẩn, thu âm micro & kiểm tra mora',
        badge: 'Audio & Speech',
        color: const Color(0xFF52B788),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  PronunciationPracticeScreen(level: _selectedLevel),
            ),
          );
        },
      ),
      _LabFeatureItem(
        iconAsset: AppAssets.labTutorCat,
        title: 'Gia sư Quàng Thượng',
        subtitle: 'Chatbot Gemini + truy xuất dữ liệu chuẩn SQLite',
        badge: 'AI Tutor RAG',
        color: const Color(0xFF4A90E2),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const QuangThuongTutorScreen(),
            ),
          );
        },
      ),
      _LabFeatureItem(
        iconAsset: AppAssets.labAiDrill,
        title: 'Luyện tập & Đề thi AI',
        subtitle: 'Sinh đề đọc hiểu RAG từ từ vựng & ngữ pháp $_selectedLevel',
        badge: 'Gemini Exam',
        color: const Color(0xFFE59838),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const JLPTScreen(),
            ),
          );
        },
      ),
    ];

    Widget buildFeatureCard(_LabFeatureItem item) {
      return Material(
        color: palette.surface,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: item.onTap,
          child: Container(
            constraints: const BoxConstraints(minHeight: 138),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: item.color.withValues(alpha: 0.28)),
              boxShadow: palette.softCardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: item.color.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: AppAssetIcon(item.iconAsset, size: 26),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: item.color.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            item.badge,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: item.color,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        color: palette.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11.5,
                        color: palette.textSecondary,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 340) {
          return Column(
            children: [
              for (int i = 0; i < cards.length; i++) ...[
                if (i > 0) const SizedBox(height: 10),
                buildFeatureCard(cards[i]),
              ],
            ],
          );
        }
        return Column(
          children: [
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: buildFeatureCard(cards[0])),
                  const SizedBox(width: 12),
                  Expanded(child: buildFeatureCard(cards[1])),
                ],
              ),
            ),
            const SizedBox(height: 12),
            IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: buildFeatureCard(cards[2])),
                  const SizedBox(width: 12),
                  Expanded(child: buildFeatureCard(cards[3])),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildEmptyQuestState(CozyPalette palette, Color levelColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: palette.borderSubtle),
      ),
      child: Column(
        children: [
          const AppAssetIcon(AppAssets.labAdaptiveQuest, size: 42),
          const SizedBox(height: 8),
          Text(
            'Chưa có nhiệm vụ thích ứng cho cấp $_selectedLevel',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 14,
              color: palette.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Hãy chọn một bài học bên dưới để bắt đầu ghi nhận tiến trình.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: palette.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _buildAdaptiveQuestCard(
    CozyPalette palette,
    AdaptiveQuest quest,
    Color levelColor,
  ) {
    final statusColor = quest.isClaimed
        ? AppTheme.successGreen
        : switch (quest.status) {
            'completed' => AppTheme.successGreen,
            'in_progress' => AppTheme.accentBlue,
            _ => palette.textSecondary,
          };
    final statusLabel = quest.isClaimed
        ? 'Đã nhận thưởng'
        : quest.statusLabelVi;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: quest.isCompleted
              ? AppTheme.successGreen.withValues(alpha: 0.38)
              : levelColor.withValues(alpha: 0.22),
        ),
        boxShadow: palette.softCardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: levelColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: AppAssetIcon(quest.iconAsset, size: 28),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: levelColor.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            quest.level,
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w800,
                              color: levelColor,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: statusColor.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (quest.isCompleted) ...[
                                const AppAssetIcon(
                                  AppAssets.aiStateCompleted,
                                  size: 13,
                                ),
                                const SizedBox(width: 4),
                              ],
                              Text(
                                statusLabel,
                                style: TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w800,
                                  color: statusColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      quest.title,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14.5,
                        color: palette.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      quest.description,
                      style: TextStyle(
                        fontSize: 12,
                        color: palette.textSecondary,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: quest.progressRatio,
              minHeight: 7,
              backgroundColor: palette.surfaceSoft,
              valueColor: AlwaysStoppedAnimation(statusColor),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Wrap(
                spacing: 6,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    'Tiến độ: ${quest.currentProgress}/${quest.targetCount}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: palette.textPrimary,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: palette.primarySoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      '+${quest.xpReward} XP',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: palette.accent,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: palette.coinSoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppAssets.statusCoin, size: 13),
                        const SizedBox(width: 4),
                        Text(
                          '+${quest.coinReward} Xu',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: palette.coin,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (quest.isCompleted && !quest.isClaimed)
                ElevatedButton.icon(
                  onPressed: () => _claimQuest(quest),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.successGreen,
                    foregroundColor: Colors.white,
                    visualDensity: VisualDensity.compact,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const AppAssetIcon(AppAssets.aiStateCompleted, size: 16),
                  label: const Text('Nhận thưởng'),
                )
              else
                OutlinedButton.icon(
                  onPressed: () => _openAdaptiveQuestTarget(quest),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: levelColor,
                    side: BorderSide(color: levelColor.withValues(alpha: 0.4)),
                    visualDensity: VisualDensity.compact,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: AppAssetIcon(quest.iconAsset, size: 16),
                  label: Text(
                    quest.isClaimed
                        ? 'Luyện thêm'
                        : (quest.currentProgress > 0 ? 'Tiếp tục' : 'Thực hiện'),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSkillShortcutsRow(CozyPalette palette, Color levelColor) {
    final shortcuts = <({String label, String icon, Widget screen})>[
      (
        label: 'Từ vựng',
        icon: AppAssets.labVocab,
        screen: const VocabularyScreen(),
      ),
      (
        label: 'Kanji',
        icon: AppAssets.labKanji,
        screen: const KanjiScreen(),
      ),
      (
        label: 'Ngữ pháp',
        icon: AppAssets.labGrammar,
        screen: const GrammarScreen(),
      ),
      (
        label: 'Đọc hiểu',
        icon: AppAssets.labReadingBook,
        screen: const ReadScreen(),
      ),
      (
        label: 'Luyện nghe',
        icon: AppAssets.labListening,
        screen: ListeningPracticeScreen(level: _selectedLevel),
      ),
    ];

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: shortcuts.map((item) {
        return ActionChip(
          backgroundColor: palette.surface,
          side: BorderSide(color: palette.borderSubtle),
          avatar: AppAssetIcon(item.icon, size: 18),
          label: Text(
            item.label,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: palette.textPrimary,
            ),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => item.screen),
            );
          },
        );
      }).toList(),
    );
  }
}

class _LabFeatureItem {
  final String iconAsset;
  final String title;
  final String subtitle;
  final String badge;
  final Color color;
  final VoidCallback onTap;

  const _LabFeatureItem({
    required this.iconAsset,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.color,
    required this.onTap,
  });
}
