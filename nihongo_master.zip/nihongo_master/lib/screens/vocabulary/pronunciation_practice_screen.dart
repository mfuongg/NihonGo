import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../../models/vocabulary.dart';
import '../../providers/progress_provider.dart';
import '../../providers/vocabulary_provider.dart';
import '../../services/ai_practice_evaluator.dart';
import '../../services/feedback_audio_service.dart';
import '../../services/tts_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';

class PronunciationPracticeScreen extends StatefulWidget {
  final String level;
  final List<VocabularyWord>? words;
  final String? title;
  final String initialPracticeMode;

  const PronunciationPracticeScreen({
    super.key,
    required this.level,
    this.words,
    this.title,
    this.initialPracticeMode = 'word',
  });

  @override
  State<PronunciationPracticeScreen> createState() =>
      _PronunciationPracticeScreenState();
}

class _PronunciationPracticeScreenState
    extends State<PronunciationPracticeScreen>
    with SingleTickerProviderStateMixin {
  static const List<String> _levels = ['N5', 'N4', 'N3', 'N2', 'N1'];
  final SpeechToText _speech = SpeechToText();
  final AudioPlayer _samplePlayer = AudioPlayer();

  final List<Map<String, dynamic>> _speeds = const [
    {'label': '0.5×', 'rate': 0.5},
    {'label': '1.0×', 'rate': 1.0},
    {'label': '1.5×', 'rate': 1.5},
  ];

  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;

  late String _selectedLevel;
  late String _practiceMode; // 'word' | 'sentence'

  List<VocabularyWord> _words = [];
  int _currentIndex = 0;
  int _speedIndex = 1;

  bool _isLoading = true;
  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isChecking = false;
  bool _showMeaning = false;
  bool _speechReady = false;
  bool _micPermissionDenied = false;
  bool _selfPracticed = false;
  bool _handledAutoStop = false;

  String? _speechLocaleId;
  String _liveTranscript = '';
  String _speechStatus = 'Sẵn sàng';
  String? _speechError;

  PracticeCheckResult? _currentResult;

  int _correctCount = 0;
  int _selfPracticedCount = 0;
  int _incorrectCount = 0;
  int _skippedCount = 0;

  VocabularyWord? get _currentWord =>
      _words.isEmpty ? null : _words[_currentIndex];

  @override
  void initState() {
    super.initState();
    _selectedLevel = widget.level;
    _practiceMode = widget.initialPracticeMode;
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _pulseAnimation = Tween<double>(begin: 1, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      unawaited(_prepareSpeech());
      await _loadWords();
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _samplePlayer.dispose();
    _speech.stop();
    TtsService.instance.stop();
    super.dispose();
  }

  Future<void> _prepareSpeech() async {
    bool available = false;
    bool permissionDenied = false;
    try {
      available = await _speech.initialize(
        onStatus: (status) {
          if (!mounted) return;
          setState(() {
            _speechStatus = switch (status) {
              'listening' => 'Đang ghi âm...',
              'notListening' || 'done' => 'Kết thúc ghi âm',
              _ => status,
            };
          });
          if (_isListening &&
              !_handledAutoStop &&
              (status == 'done' || status == 'notListening')) {
            _handledAutoStop = true;
            _finishListeningAndEvaluate();
          }
        },
        onError: (error) {
          if (!mounted) return;
          final msg = error.errorMsg.toLowerCase();
          final denied = msg.contains('permission') ||
              msg.contains('not_allowed') ||
              msg.contains('denied');
          final hasTranscript = _liveTranscript.trim().isNotEmpty;
          setState(() {
            _speechError = error.errorMsg;
            _micPermissionDenied = denied;
            _isListening = false;
            _speechStatus = denied
                ? 'Quyền micro bị từ chối. Vui lòng cấp quyền micro hoặc dùng chế độ Nghe mẫu & Tự luyện đọc.'
                : (hasTranscript
                    ? 'Có bản ghi, đang chấm phát âm...'
                    : 'Không nhận diện được giọng nói từ micro');
          });
          if (hasTranscript && !_handledAutoStop) {
            _handledAutoStop = true;
            _finishListeningAndEvaluate();
          }
        },
      );
      if (!available) {
        final hasPerm = await _speech.hasPermission;
        if (!hasPerm) {
          permissionDenied = true;
        }
      }
    } catch (_) {
      available = false;
    }

    String? localeId;
    if (available) {
      try {
        final locales = await _speech.locales();
        for (final locale in locales) {
          final id = locale.localeId;
          if (id.toLowerCase().startsWith('ja')) {
            localeId = id;
            break;
          }
        }
        localeId ??= locales.isNotEmpty ? locales.first.localeId : 'ja_JP';
      } catch (_) {
        localeId = 'ja_JP';
      }
    }

    if (!mounted) return;
    setState(() {
      _speechReady = available;
      _micPermissionDenied = permissionDenied && !available;
      _speechLocaleId = localeId ?? 'ja_JP';
      _speechStatus = available
          ? 'Nhấn micro để ghi âm tiếng Nhật và chấm phát âm thực tế.'
          : (_micPermissionDenied
              ? 'Quyền micro bị từ chối — Đang bật chế độ Nghe mẫu & Tự luyện đọc.'
              : 'Thiết bị chưa hỗ trợ nhận diện giọng nói — Đang bật chế độ Nghe mẫu & Tự luyện đọc (không tạo điểm AI giả).');
    });
  }

  Future<void> _loadWords() async {
    List<VocabularyWord> source;
    if (widget.words != null && widget.words!.isNotEmpty) {
      source = List<VocabularyWord>.from(widget.words!).take(12).toList();
    } else {
      final vocab = context.read<VocabularyProvider>();
      await vocab.ensureLoaded();
      final rawWords = vocab.getQuizWords(_selectedLevel, 16);
      if (_practiceMode == 'sentence') {
        source = rawWords
            .where((w) => w.exampleSentences.isNotEmpty && w.exampleSentences.first.trim().isNotEmpty)
            .map(
              (w) => VocabularyWord(
                id: w.id,
                japanese: w.exampleSentences.first.trim(),
                hiragana: w.hiragana,
                romaji: w.romaji,
                vietnamese: (w.exampleTranslations.isNotEmpty &&
                        w.exampleTranslations.first.trim().isNotEmpty)
                    ? w.exampleTranslations.first.trim()
                    : w.vietnamese,
                english: w.english,
                jlptLevel: w.jlptLevel,
                category: w.category,
                exampleSentences: w.exampleSentences,
                exampleTranslations: w.exampleTranslations,
              ),
            )
            .take(12)
            .toList();
        if (source.isEmpty) {
          source = rawWords.take(12).toList();
        }
      } else {
        source = rawWords.take(12).toList();
      }
    }

    if (!mounted) return;
    setState(() {
      _words = source;
      _isLoading = false;
      _resetCurrentState();
    });

    if (_currentWord != null) {
      unawaited(_speakWord(_currentWord!));
    }
  }

  void _resetCurrentState() {
    _showMeaning = false;
    _selfPracticed = false;
    _liveTranscript = '';
    _speechError = null;
    _speechStatus = _speechReady
        ? 'Nhấn micro để ghi âm và kiểm tra phát âm'
        : 'Nghe mẫu và bấm xác nhận hoàn thành luyện đọc';
    _currentResult = null;
    _isListening = false;
    _pulseController.stop();
    _pulseController.value = 0;
    _isChecking = false;
    _handledAutoStop = false;
  }

  void _confirmSelfPracticeReading() {
    final word = _currentWord;
    if (word == null) return;
    setState(() {
      _isSpeaking = false;
      _selfPracticed = true;
      _showMeaning = true;
      _currentResult = null;
      _speechStatus =
          'Đã hoàn thành nghe mẫu & tự luyện đọc (Không chấm điểm AI giả).';
    });
    unawaited(_playResultSound(true));
  }

  Future<void> _playResultSound(bool isCorrect) async {
    try {
      final player = isCorrect
          ? FeedbackAudioService.instance.playCorrect()
          : FeedbackAudioService.instance.playWrong();
      await player.timeout(const Duration(seconds: 2));
    } catch (_) {
      
    }
  }

  Future<void> _speakWord(VocabularyWord word) async {
    if (_isSpeaking) {
      await _samplePlayer.stop();
      await TtsService.instance.stop();
      if (!mounted) return;
      setState(() => _isSpeaking = false);
      return;
    }

    setState(() => _isSpeaking = true);
    try {
      await TtsService.instance.speakJapanese(
        word.japanese,
        rate: _speeds[_speedIndex]['rate'] as double,
      );
    } finally {
      if (mounted) {
        setState(() => _isSpeaking = false);
      }
    }
  }

  Future<void> _startListening() async {
    if (!_speechReady || _currentWord == null) return;
    await _samplePlayer.stop();
    await TtsService.instance.stop();
    await _speech.stop();
    await Future<void>.delayed(const Duration(milliseconds: 160));
    setState(() {
      _handledAutoStop = false;
      _isListening = true;
      _pulseController.repeat(reverse: true);
      _selfPracticed = false;
      _liveTranscript = '';
      _speechError = null;
      _currentResult = null;
      _speechStatus = 'Đang ghi âm tiếng Nhật...';
    });

    try {
      await _speech.listen(
        localeId: _speechLocaleId ?? 'ja_JP',
        partialResults: true,
        listenFor: const Duration(seconds: 9),
        pauseFor: const Duration(seconds: 3),
        cancelOnError: true,
        onResult: (result) {
          if (!mounted) return;
          setState(() {
            _liveTranscript = result.recognizedWords.trim();
          });
          if (result.finalResult && _isListening && !_handledAutoStop) {
            _handledAutoStop = true;
            _finishListeningAndEvaluate();
          }
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isListening = false;
        _pulseController.stop();
        _pulseController.value = 0;
        _isChecking = false;
        _speechError = e.toString();
        _speechStatus = 'Không thể bắt đầu ghi âm. Hãy thử lại.';
      });
    }
  }

  Future<void> _stopListening() async {
    if (!_isListening) return;
    _handledAutoStop = true;
    await _speech.stop();
    await _finishListeningAndEvaluate();
  }

  Future<void> _finishListeningAndEvaluate() async {
    if (_isChecking) return;
    final word = _currentWord;
    if (word == null) return;

    if (mounted) {
      setState(() {
        _isListening = false;
        _pulseController.stop();
        _pulseController.value = 0;
        _isChecking = true;
        _speechStatus = 'AI đang kiểm tra phát âm...';
      });
    }

    try {
      final result = AiPracticeEvaluator.evaluatePronunciation(
        word: word,
        recognizedText: _liveTranscript,
      );

      if (!mounted) return;
      setState(() {
        _currentResult = result;
        _isChecking = false;
        _showMeaning = true;
        _speechStatus = result.isCorrect ? 'Phát âm đạt' : 'Cần thử lại';
      });
      unawaited(_playResultSound(result.isCorrect));
    } catch (_) {
      final fallback = AiPracticeEvaluator.evaluatePronunciation(
        word: word,
        recognizedText: '',
      );
      if (!mounted) return;
      setState(() {
        _currentResult = fallback;
        _isChecking = false;
        _showMeaning = true;
        _speechStatus = 'Chưa nhận được âm thanh, hãy thử lại hoặc tự luyện đọc.';
      });
      unawaited(_playResultSound(false));
    } finally {
      if (mounted && _isChecking) {
        setState(() => _isChecking = false);
      }
    }
  }

  Future<void> _retryCurrentWord() async {
    await _speech.stop();
    if (!mounted) return;
    setState(_resetCurrentState);
  }

  void _commitCurrentResult({required bool skipped}) {
    final word = _currentWord;
    if (skipped || (_currentResult == null && !_selfPracticed)) {
      _skippedCount++;
      return;
    }

    final progress = context.read<ProgressProvider>();
    if (_selfPracticed) {
      _selfPracticedCount++;
      if (word != null) {
        progress.markVocabLearned(word.id);
      }
      unawaited(
        progress.recordAdaptiveQuestProgress(
          'listening',
          levelOverride: _selectedLevel,
        ),
      );
    } else if (_currentResult?.isCorrect ?? false) {
      _correctCount++;
      if (word != null) {
        progress.markVocabLearned(word.id);
      }
      unawaited(
        progress.recordAdaptiveQuestProgress(
          'listening',
          levelOverride: _selectedLevel,
        ),
      );
    } else {
      _incorrectCount++;
    }
  }

  Future<void> _goToNext({bool skipped = false}) async {
    await _speech.stop();
    await _samplePlayer.stop();
    await TtsService.instance.stop();
    _commitCurrentResult(skipped: skipped);

    if (_currentIndex >= _words.length - 1) {
      _showResultDialog();
      return;
    }

    final nextWord = _words[_currentIndex + 1];
    if (!mounted) return;
    setState(() {
      _currentIndex++;
      _resetCurrentState();
    });
    await _speakWord(nextWord);
  }

  void _showResultDialog() {
    final total = _words.length;
    final completedTotal = _correctCount + _selfPracticedCount;
    final usedSpeech = _correctCount > 0 || (_speechReady && _selfPracticedCount == 0);
    context.read<ProgressProvider>().recordTestResult(
          _selectedLevel,
          completedTotal,
          total,
          mode: usedSpeech ? 'pronunciation_ai' : 'pronunciation_self_practice',
          title: widget.title ?? 'Luyện đọc & phát âm $_selectedLevel',
          playbackRate: _speeds[_speedIndex]['rate'] as double,
        );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const AppAssetIcon(AppAssets.aiStateCompleted, size: 30),
            const SizedBox(width: 8),
            const Flexible(
              child: Text(
                'Hoàn thành luyện đọc & phát âm',
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Đã hoàn thành $total mục của cấp $_selectedLevel.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                if (_correctCount > 0 || _speechReady)
                  _SummaryBox(
                    label: 'Đạt (Micro)',
                    value: '$_correctCount',
                    color: AppTheme.successGreen,
                    icon: Icons.mic_rounded,
                  ),
                if (_selfPracticedCount > 0 || !_speechReady)
                  _SummaryBox(
                    label: 'Tự luyện đọc',
                    value: '$_selfPracticedCount',
                    color: AppTheme.accentBlue,
                    icon: Icons.record_voice_over_rounded,
                  ),
                _SummaryBox(
                  label: 'Chưa đạt',
                  value: '$_incorrectCount',
                  color: AppTheme.errorRed,
                  icon: Icons.cancel_rounded,
                ),
                _SummaryBox(
                  label: 'Bỏ qua',
                  value: '$_skippedCount',
                  color: AppTheme.textMedium,
                  icon: Icons.skip_next_rounded,
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Đóng'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _currentIndex = 0;
                _correctCount = 0;
                _selfPracticedCount = 0;
                _incorrectCount = 0;
                _skippedCount = 0;
                _isLoading = true;
                _resetCurrentState();
              });
              _loadWords();
            },
            child: const Text('Luyện lại'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = CozyPalette.of(context);
    final levelColor = AppTheme.jlptColor(_selectedLevel);
    final word = _currentWord;
    final total = _words.length;
    final currentNum = total == 0 ? 0 : (_currentIndex + 1).clamp(1, total);

    return Scaffold(
      backgroundColor: palette.background,
      appBar: AppBar(
        backgroundColor: palette.surface,
        surfaceTintColor: Colors.transparent,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppAssets.labPronunciation, size: 24),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                widget.title ?? 'Luyện đọc & phát âm $_selectedLevel',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Làm lại',
            onPressed: () {
              setState(() {
                _currentIndex = 0;
                _correctCount = 0;
                _selfPracticedCount = 0;
                _incorrectCount = 0;
                _skippedCount = 0;
                _isLoading = true;
                _resetCurrentState();
              });
              _loadWords();
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : word == null
              ? const Center(child: Text('Không có dữ liệu luyện đọc'))
              : SafeArea(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 760),
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                        children: [
                          if (widget.words == null) ...[
                            _buildModeAndLevelBar(palette, levelColor),
                            const SizedBox(height: 10),
                          ],
                          _buildProgress(palette, currentNum, total, levelColor),
                          const SizedBox(height: 12),
                          _buildSpeedSelector(palette, levelColor),
                          const SizedBox(height: 12),
                          AnimatedSize(
                            duration: const Duration(milliseconds: 220),
                            curve: Curves.easeOut,
                            child: _buildWordCard(word, levelColor),
                          ),
                          const SizedBox(height: 12),
                          _buildRecognizerPanel(palette, levelColor),
                          const SizedBox(height: 12),
                          _buildActionButtons(palette, word, levelColor),
                        ],
                      ),
                    ),
                  ),
                ),
    );
  }

  Widget _buildModeAndLevelBar(CozyPalette palette, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: palette.borderSubtle),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 6,
        alignment: WrapAlignment.spaceBetween,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              ChoiceChip(
                label: const Text('Từ vựng'),
                avatar: const AppAssetIcon(AppAssets.labPronunciation, size: 16),
                selected: _practiceMode == 'word',
                onSelected: (v) {
                  if (!v || _practiceMode == 'word') return;
                  setState(() {
                    _practiceMode = 'word';
                    _currentIndex = 0;
                    _isLoading = true;
                  });
                  _loadWords();
                },
              ),
              ChoiceChip(
                label: const Text('Câu tiếng Nhật'),
                avatar: const AppAssetIcon(AppAssets.labReading, size: 16),
                selected: _practiceMode == 'sentence',
                onSelected: (v) {
                  if (!v || _practiceMode == 'sentence') return;
                  setState(() {
                    _practiceMode = 'sentence';
                    _currentIndex = 0;
                    _isLoading = true;
                  });
                  _loadWords();
                },
              ),
            ],
          ),
          DropdownButton<String>(
            value: _selectedLevel,
            underline: const SizedBox.shrink(),
            borderRadius: BorderRadius.circular(12),
            dropdownColor: palette.surface,
            items: _levels
                .map(
                  (lv) => DropdownMenuItem(
                    value: lv,
                    child: Text(
                      'JLPT $lv',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: palette.textPrimary,
                      ),
                    ),
                  ),
                )
                .toList(),
            onChanged: (lv) {
              if (lv == null || lv == _selectedLevel) return;
              setState(() {
                _selectedLevel = lv;
                _currentIndex = 0;
                _isLoading = true;
              });
              _loadWords();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProgress(
    CozyPalette palette,
    int curr,
    int total,
    Color color,
  ) {
    final completedTotal = _correctCount + _selfPracticedCount;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: palette.borderSubtle),
      ),
      child: Row(
        children: [
          Text(
            '$curr / $total',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: color,
              fontSize: 15,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: total == 0 ? 0 : curr / total,
                minHeight: 8,
                backgroundColor: palette.surfaceSoft,
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const AppAssetIcon(AppAssets.aiStateCompleted, size: 16),
              const SizedBox(width: 4),
              Text(
                '$completedTotal',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(width: 8),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const AppAssetIcon(AppAssets.aiStateError, size: 16),
              const SizedBox(width: 4),
              Text(
                '$_incorrectCount',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSpeedSelector(CozyPalette palette, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: palette.borderSubtle),
      ),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: List.generate(_speeds.length, (index) {
          final selected = _speedIndex == index;
          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () async {
                setState(() => _speedIndex = index);
                final w = _currentWord;
                if (w != null && _isSpeaking) {
                  await TtsService.instance.stop();
                  if (mounted) {
                    setState(() => _isSpeaking = false);
                    await _speakWord(w);
                  }
                }
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
                decoration: BoxDecoration(
                  color: selected ? color : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      'Tốc độ mẫu ${_speeds[index]['label'] as String}',
                      maxLines: 1,
                      style: TextStyle(
                        color: selected ? Colors.white : palette.textSecondary,
                        fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                        fontSize: 12.5,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildWordCard(VocabularyWord word, Color color) {
    final titleFontSize = word.japanese.length >= 10
        ? 24.0
        : word.japanese.length >= 6
            ? 32.0
            : word.japanese.length >= 4
                ? 38.0
                : word.japanese.length == 3
                    ? 46.0
                    : 52.0;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [color.withValues(alpha: 0.92), color],
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.22),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      constraints: const BoxConstraints(minHeight: 240),
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ScaleTransition(
            scale: _isListening
                ? _pulseAnimation
                : const AlwaysStoppedAnimation(1),
            child: Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.22),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: AppAssetIcon(
                  _isListening
                      ? AppAssets.labPronunciation
                      : _isSpeaking
                          ? AppAssets.labListening
                          : AppAssets.labReading,
                  size: 40,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          if (word.hiragana.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                word.hiragana,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 8),
          ],
          Text(
            word.japanese,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: titleFontSize,
              color: Colors.white,
              fontWeight: FontWeight.w900,
              height: 1.18,
            ),
          ),
          if (word.romaji.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              word.romaji,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14.5,
                color: Colors.white70,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Text(
                  word.displayMeaning(language: 'vi'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                if (_showMeaning && word.english.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    word.displayMeaning(language: 'en'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecognizerPanel(CozyPalette palette, Color color) {
    final result = _currentResult;
    final passed = _selfPracticed || (result?.isCorrect ?? false);
    final scorePercent = ((result?.score ?? 0) * 100).round();
    final statusColor = (result == null && !_selfPracticed)
        ? color
        : passed
            ? AppTheme.successGreen
            : AppTheme.errorRed;
    final stateBadgeText = _isListening
        ? 'Đang ghi âm'
        : _selfPracticed
            ? 'Đã tự luyện đọc (Không chấm AI)'
            : _isSpeaking
                ? 'Đang phát mẫu'
                : result != null
                    ? (passed ? 'Phát âm đạt' : 'Chưa khớp mẫu')
                    : _micPermissionDenied
                        ? 'Quyền micro bị từ chối'
                        : !_speechReady
                            ? 'Thiết bị không hỗ trợ micro AI'
                            : 'Sẵn sàng ghi âm';
    final stateIcon = _isChecking
        ? AppAssets.aiStateLoading
        : (result == null && !_selfPracticed)
            ? (_micPermissionDenied || !_speechReady
                ? AppAssets.aiStateError
                : AppAssets.labPronunciation)
            : passed
                ? AppAssets.aiStateCompleted
                : AppAssets.aiStateError;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: (result == null && !_selfPracticed)
              ? color.withValues(alpha: 0.18)
              : statusColor.withValues(alpha: 0.25),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AppAssetIcon(stateIcon, size: 20),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          stateBadgeText,
                          style: TextStyle(
                            color: statusColor,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (result != null && !_selfPracticed)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '$scorePercent%',
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            result == null ? _speechStatus : result.feedback,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: statusColor,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: palette.surfaceSoft,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _selfPracticed
                      ? 'Trạng thái luyện đọc:'
                      : 'Văn bản thu âm nhận diện:',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: palette.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _selfPracticed
                      ? 'Người học đã nghe audio mẫu và tự luyện đọc thành tiếng (không tạo điểm AI giả).'
                      : (_liveTranscript.isEmpty
                          ? 'Chưa có bản ghi âm.'
                          : _liveTranscript),
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.4,
                    color: palette.textPrimary,
                  ),
                ),
                if (_speechError != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _speechError!,
                    style: const TextStyle(
                      color: AppTheme.errorRed,
                      fontSize: 12,
                    ),
                  ),
                ],
                if (result != null && !_selfPracticed) ...[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.10),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'Mức khớp $scorePercent%',
                          style: TextStyle(
                            color: statusColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.10),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'Mục tiêu: ${result.matchedTarget}',
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (result != null && result.suggestions.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: statusColor.withValues(alpha: 0.18)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const AppAssetIcon(AppAssets.labPronunciation, size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Gợi ý chi tiết từ AI',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: statusColor,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ...result.suggestions.map(
                    (tip) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        tip,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.45,
                          color: palette.textPrimary,
                        ),
                      ),
                    ),
                  ),
                  if (result.encouragement.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: palette.coinSoft,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        result.encouragement,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: palette.coin,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActionButtons(
    CozyPalette palette,
    VocabularyWord word,
    Color color,
  ) {
    final lastCard = _currentIndex >= _words.length - 1;
    final canProceed = _currentResult != null || _selfPracticed;

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _speakWord(word),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  side: BorderSide(color: color.withValues(alpha: 0.35)),
                  foregroundColor: color,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                icon: _isSpeaking
                    ? const Icon(Icons.stop_rounded)
                    : const AppAssetIcon(AppAssets.learnAudio, size: 20),
                label: Text(
                  _isSpeaking ? 'Dừng phát mẫu' : 'Nghe mẫu (TTS)',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: !_speechReady || _isChecking
                    ? null
                    : _isListening
                        ? _stopListening
                        : _startListening,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  backgroundColor: _isListening ? AppTheme.errorRed : color,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                icon: _isChecking
                    ? const AppAssetIcon(AppAssets.aiStateLoading, size: 20)
                    : _isListening
                        ? const Icon(Icons.stop_rounded)
                        : const AppAssetIcon(AppAssets.labPronunciation, size: 20),
                label: Text(
                  _isChecking
                      ? 'Đang chấm...'
                      : _isListening
                          ? 'Dừng ghi âm'
                          : 'Ghi âm giọng nói',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (!_speechReady || _micPermissionDenied || !_selfPracticed)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _selfPracticed ? null : _confirmSelfPracticeReading,
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(44),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  foregroundColor: AppTheme.successGreen,
                  side: BorderSide(
                    color: AppTheme.successGreen.withValues(alpha: 0.45),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const AppAssetIcon(AppAssets.labReading, size: 18),
                label: Text(
                  _selfPracticed
                      ? 'Đã xác nhận tự luyện đọc'
                      : 'Đã nghe mẫu & tự luyện đọc (Không chấm AI)',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),
        Row(
          children: [
            Expanded(
              child: TextButton.icon(
                onPressed: _retryCurrentWord,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Thử lại'),
                style: TextButton.styleFrom(
                  foregroundColor: palette.textSecondary,
                ),
              ),
            ),
            Expanded(
              child: TextButton.icon(
                onPressed: () => setState(() => _showMeaning = !_showMeaning),
                icon: Icon(
                  _showMeaning
                      ? Icons.visibility_off_rounded
                      : Icons.visibility_rounded,
                ),
                label: Text(_showMeaning ? 'Ẩn nghĩa Anh' : 'Hiện nghĩa Anh'),
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.accentBlue,
                ),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _goToNext(skipped: true),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  foregroundColor: palette.textSecondary,
                  side: BorderSide(
                    color: palette.textSecondary.withValues(alpha: 0.28),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                icon: const Icon(Icons.skip_next_rounded),
                label: const Text(
                  'Bỏ qua',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: canProceed ? () => _goToNext() : null,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  backgroundColor: AppTheme.successGreen,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                icon: Icon(lastCard ? Icons.assessment_rounded : Icons.arrow_forward_rounded),
                label: Text(
                  lastCard ? 'Xem tổng kết' : 'Từ tiếp theo',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SummaryBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _SummaryBox({
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 12, color: AppTheme.textMedium),
        ),
      ],
    );
  }
}
