import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/kanji_data.dart';
import '../../models/vocabulary.dart';
import '../../providers/progress_provider.dart';
import '../../providers/vocabulary_provider.dart';
import '../../services/ai_practice_evaluator.dart';
import '../../services/feedback_audio_service.dart';
import '../../services/local_database_service.dart';
import '../../services/tts_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';

class WritingPracticeScreen extends StatefulWidget {
  final String level;
  final List<VocabularyWord>? words;
  final String? title;
  final String initialTargetType;

  const WritingPracticeScreen({
    super.key,
    required this.level,
    this.words,
    this.title,
    this.initialTargetType = 'vocab',
  });

  @override
  State<WritingPracticeScreen> createState() => _WritingPracticeScreenState();
}

class _WritingPracticeScreenState extends State<WritingPracticeScreen> {
  static const List<String> _levels = ['N5', 'N4', 'N3', 'N2', 'N1'];
  final GlobalKey _canvasKey = GlobalKey();
  final TextRecognizer _textRecognizer =
      TextRecognizer(script: TextRecognitionScript.japanese);
  final TextEditingController _typedAnswerController = TextEditingController();

  late String _selectedLevel;
  late String _targetType;
  final Map<String, int> _strokeCountByWordId = <String, int>{};

  List<VocabularyWord> _words = [];
  int _currentIndex = 0;
  bool _isLoading = true;
  bool _showGuide = true;
  bool _isSpeaking = false;
  bool _isChecking = false;
  bool _restoredFromSession = false;

  int _correctCount = 0;
  int _incorrectCount = 0;
  int _skippedCount = 0;
  final Set<int> _rewardedCardIndices = <int>{};
  final Set<int> _committedCardIndices = <int>{};

  final List<List<Offset>> _strokes = [];
  List<Offset> _currentStroke = [];

  PracticeCheckResult? _currentResult;
  String _recognizedText = '';

  String get _sessionPrefsKey =>
      'writing_practice_session_v1_${_selectedLevel}_$_targetType';

  VocabularyWord? get _currentWord =>
      _words.isEmpty ? null : _words[_currentIndex];

  @override
  void initState() {
    super.initState();
    _selectedLevel = widget.level;
    _targetType = widget.initialTargetType;
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadWords());
  }

  @override
  void dispose() {
    _typedAnswerController.dispose();
    TtsService.instance.stop();
    _textRecognizer.close();
    super.dispose();
  }

  Future<void> _loadWords({bool forceResetSession = false}) async {
    List<VocabularyWord> allCandidates = <VocabularyWord>[];
    List<VocabularyWord> source = <VocabularyWord>[];
    _strokeCountByWordId.clear();

    if (widget.words != null && widget.words!.isNotEmpty) {
      source = List<VocabularyWord>.from(widget.words!).take(10).toList();
    } else if (_targetType == 'kanji') {
      if (KanjiData.getAllKanji().isEmpty) {
        await LocalDatabaseService.instance
            .ensureVerifiedDatasetImportedAndLoaded();
      }
      final kanjiItems = KanjiData.getKanjiByLevel(_selectedLevel);
      for (final k in kanjiItems) {
        _strokeCountByWordId[k.id] = k.strokeCount;
        final reading = k.kunyomi.trim().isNotEmpty
            ? k.kunyomi.trim()
            : k.onyomi.trim();
        allCandidates.add(
          VocabularyWord(
            id: k.id,
            japanese: k.kanji,
            hiragana: reading,
            romaji: '${k.kunyomi} • ${k.onyomi}'.trim(),
            vietnamese: k.vietnamese,
            english: k.english,
            jlptLevel: k.jlptLevel,
            category: 'Kanji (${k.strokeCount} nét)',
          ),
        );
      }
      if (allCandidates.isEmpty) {
        if (!mounted) return;
        final vocab = context.read<VocabularyProvider>();
        await vocab.ensureLoaded();
        allCandidates = vocab.allWords
            .where((w) => w.jlptLevel == _selectedLevel)
            .toList();
        source = vocab.getQuizWords(_selectedLevel, 10);
      } else {
        source = allCandidates.take(12).toList();
      }
    } else {
      final vocab = context.read<VocabularyProvider>();
      await vocab.ensureLoaded();
      allCandidates = vocab.allWords
          .where((w) => w.jlptLevel == _selectedLevel)
          .toList();
      source = vocab.getQuizWords(_selectedLevel, 10);
    }

    int restoredIndex = 0;
    int restoredCorrect = 0;
    int restoredIncorrect = 0;
    int restoredSkipped = 0;
    final restoredRewarded = <int>{};
    final restoredCommitted = <int>{};

    if (widget.words == null && !forceResetSession && source.isNotEmpty) {
      try {
        final prefs = await SharedPreferences.getInstance();
        if (forceResetSession) {
          await prefs.remove(_sessionPrefsKey);
        } else {
          final raw = prefs.getString(_sessionPrefsKey);
          if (raw != null && raw.isNotEmpty) {
            final map = jsonDecode(raw);
            if (map is Map<String, dynamic>) {
              final savedIds = (map['wordIds'] as List?)
                      ?.map((e) => e.toString())
                      .toList() ??
                  const <String>[];
              final savedIdx = (map['currentIndex'] as num?)?.toInt() ?? 0;
              if (savedIds.isNotEmpty && savedIdx >= 0 && savedIdx < savedIds.length) {
                final lookupPool = <String, VocabularyWord>{
                  for (final w in allCandidates) w.id: w,
                  for (final w in source) w.id: w,
                };
                final matchedWords = <VocabularyWord>[];
                for (final id in savedIds) {
                  final found = lookupPool[id];
                  if (found != null) matchedWords.add(found);
                }
                if (matchedWords.length == savedIds.length) {
                  source = matchedWords;
                  restoredIndex = savedIdx;
                  restoredCorrect = (map['correctCount'] as num?)?.toInt() ?? 0;
                  restoredIncorrect =
                      (map['incorrectCount'] as num?)?.toInt() ?? 0;
                  restoredSkipped = (map['skippedCount'] as num?)?.toInt() ?? 0;
                  final rw = map['rewardedIndices'];
                  if (rw is List) {
                    restoredRewarded.addAll(
                      rw.map((e) => (e as num).toInt()),
                    );
                  }
                  final cm = map['committedIndices'];
                  if (cm is List) {
                    restoredCommitted.addAll(
                      cm.map((e) => (e as num).toInt()),
                    );
                  }
                }
              }
            }
          }
        }
      } catch (_) {}
    } else if (forceResetSession && widget.words == null) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove(_sessionPrefsKey);
      } catch (_) {}
    }

    if (!mounted) return;
    setState(() {
      _words = source;
      _currentIndex = restoredIndex;
      _correctCount = restoredCorrect;
      _incorrectCount = restoredIncorrect;
      _skippedCount = restoredSkipped;
      _rewardedCardIndices
        ..clear()
        ..addAll(restoredRewarded);
      _committedCardIndices
        ..clear()
        ..addAll(restoredCommitted);
      _restoredFromSession = !forceResetSession &&
          (restoredIndex > 0 ||
              restoredCorrect > 0 ||
              restoredIncorrect > 0 ||
              restoredSkipped > 0);
      _isLoading = false;
      _resetCanvasState();
    });
    await _saveSessionState();
    if (_currentWord != null) {
      unawaited(_speakWord(_currentWord!));
    }
  }

  Future<void> _saveSessionState() async {
    if (widget.words != null || _words.isEmpty) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final payload = jsonEncode(<String, Object?>{
        'wordIds': _words.map((w) => w.id).toList(),
        'currentIndex': _currentIndex,
        'correctCount': _correctCount,
        'incorrectCount': _incorrectCount,
        'skippedCount': _skippedCount,
        'rewardedIndices': _rewardedCardIndices.toList(),
        'committedIndices': _committedCardIndices.toList(),
      });
      await prefs.setString(_sessionPrefsKey, payload);
    } catch (_) {}
  }

  Future<void> _clearSessionState() async {
    if (widget.words != null) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_sessionPrefsKey);
    } catch (_) {}
  }

  void _recordLearnedWordImmediately(VocabularyWord word) {
    if (_rewardedCardIndices.contains(_currentIndex)) return;
    _rewardedCardIndices.add(_currentIndex);
    final progress = context.read<ProgressProvider>();
    if (_targetType == 'kanji' || _strokeCountByWordId.containsKey(word.id)) {
      progress.addKanjiProgress(word.id);
    } else {
      progress.markVocabLearned(word.id);
    }
  }

  void _resetCanvasState() {
    _showGuide = true;
    _strokes.clear();
    _currentStroke = [];
    _typedAnswerController.clear();
    _recognizedText = '';
    _currentResult = null;
    _isChecking = false;
  }

  Future<void> _playResultSound(bool isCorrect) async {
    try {
      final player = isCorrect
          ? FeedbackAudioService.instance.playCorrect()
          : FeedbackAudioService.instance.playWrong();
      await player.timeout(const Duration(seconds: 2));
    } catch (_) {
      
    }
  }

  Future<void> _speakWord(VocabularyWord word) async {
    setState(() => _isSpeaking = true);
    try {
      await TtsService.instance.speakJapanese(word.japanese, rate: 1.0);
    } finally {
      if (mounted) setState(() => _isSpeaking = false);
    }
  }

  void _startStroke(Offset pos) {
    setState(() {
      _currentStroke = [pos];
      _currentResult = null;
      _recognizedText = '';
    });
  }

  void _appendStroke(Offset pos) {
    setState(() => _currentStroke.add(pos));
  }

  void _endStroke() {
    if (_currentStroke.isEmpty) return;
    setState(() {
      _strokes.add(List.from(_currentStroke));
      _currentStroke = [];
    });
  }

  void _undoLastStroke() {
    if (_strokes.isEmpty) return;
    setState(() {
      _strokes.removeLast();
      _currentResult = null;
      _recognizedText = '';
    });
  }

  void _clearCanvas() {
    setState(_resetCanvasState);
  }

  Rect? _calculateStrokeBounds() {
    final points = <Offset>[
      for (final stroke in _strokes) ...stroke,
      ..._currentStroke,
    ];
    if (points.isEmpty) return null;

    double minX = points.first.dx;
    double maxX = points.first.dx;
    double minY = points.first.dy;
    double maxY = points.first.dy;

    for (final point in points.skip(1)) {
      if (point.dx < minX) minX = point.dx;
      if (point.dx > maxX) maxX = point.dx;
      if (point.dy < minY) minY = point.dy;
      if (point.dy > maxY) maxY = point.dy;
    }

    return Rect.fromLTRB(minX, minY, maxX, maxY);
  }

  Future<Uint8List> _renderStrokesAsPng() async {
    const double outputSize = 1600;
    const double padding = 180;
    final bounds = _calculateStrokeBounds();
    if (bounds == null) {
      throw Exception('Không có nét viết để xử lý');
    }

    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final backgroundPaint = Paint()..color = Colors.white;
    canvas.drawRect(
      Rect.fromLTWH(0, 0, outputSize, outputSize),
      backgroundPaint,
    );

    final gridPaint = Paint()
      ..color = const Color(0xFFF2F4F8)
      ..strokeWidth = 2;
    canvas.drawLine(Offset(outputSize / 2, 0), Offset(outputSize / 2, outputSize), gridPaint);
    canvas.drawLine(Offset(0, outputSize / 2), Offset(outputSize, outputSize / 2), gridPaint);

    final contentWidth = bounds.width <= 1 ? 1.0 : bounds.width;
    final contentHeight = bounds.height <= 1 ? 1.0 : bounds.height;
    final scale = math.min(
      (outputSize - padding * 2) / contentWidth,
      (outputSize - padding * 2) / contentHeight,
    );
    final dx = (outputSize - contentWidth * scale) / 2 - bounds.left * scale;
    final dy = (outputSize - contentHeight * scale) / 2 - bounds.top * scale;

    canvas.save();
    canvas.translate(dx, dy);
    canvas.scale(scale, scale);

    final strokePaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = 24 / scale;

    final allStrokes = <List<Offset>>[
      ..._strokes,
      if (_currentStroke.isNotEmpty) _currentStroke,
    ];

    for (final stroke in allStrokes) {
      if (stroke.isEmpty) continue;
      if (stroke.length == 1) {
        canvas.drawCircle(stroke.first, 10 / scale, strokePaint..style = PaintingStyle.fill);
        strokePaint.style = PaintingStyle.stroke;
        continue;
      }
      final path = Path()..moveTo(stroke.first.dx, stroke.first.dy);
      for (final point in stroke.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }
      canvas.drawPath(path, strokePaint);
    }
    canvas.restore();

    final image = await recorder.endRecording().toImage(outputSize.toInt(), outputSize.toInt());
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    if (byteData == null) {
      throw Exception('Không xuất được ảnh chữ viết');
    }
    return byteData.buffer.asUint8List();
  }

  Future<void> _checkWritingWithAi() async {
    final word = _currentWord;
    final typedAnswer = _typedAnswerController.text.trim();
    final hasStrokes = _strokes.isNotEmpty || _currentStroke.isNotEmpty;
    if (word == null || (!hasStrokes && typedAnswer.isEmpty)) return;

    setState(() {
      _isChecking = true;
      _currentResult = null;
      _recognizedText = '';
    });

    if (typedAnswer.isNotEmpty) {
      final result = AiPracticeEvaluator.evaluateWriting(
        word: word,
        recognizedText: typedAnswer,
        evaluationMode: 'typed_answer',
      );
      if (result.isCorrect) {
        _recordLearnedWordImmediately(word);
      }
      if (!mounted) return;
      setState(() {
        _recognizedText = typedAnswer;
        _currentResult = result;
        _isChecking = false;
      });
      unawaited(_saveSessionState());
      unawaited(_playResultSound(result.isCorrect));
      return;
    }

    final allStrokes = <List<Offset>>[
      ..._strokes,
      if (_currentStroke.isNotEmpty) _currentStroke,
    ];
    final canvasBox =
        _canvasKey.currentContext?.findRenderObject() as RenderBox?;
    final canvasSize = canvasBox?.size ?? const Size(320, 320);

    File? imageFile;
    try {
      final Uint8List pngBytes = await _renderStrokesAsPng();
      final tempDir = await getTemporaryDirectory();
      imageFile = File(
        '${tempDir.path}/nihongo_handwriting_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await imageFile.writeAsBytes(pngBytes, flush: true);

      final inputImage = InputImage.fromFilePath(imageFile.path);
      final recognized = await _textRecognizer
          .processImage(inputImage)
          .timeout(const Duration(seconds: 6));
      final extractedText = recognized.blocks
          .expand((block) => block.lines)
          .map((line) => line.text)
          .join(' ')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();

      final PracticeCheckResult result;
      if (extractedText.isNotEmpty) {
        result = AiPracticeEvaluator.evaluateWriting(
          word: word,
          recognizedText: extractedText,
          evaluationMode: 'ocr',
        );
      } else {
        result = AiPracticeEvaluator.evaluateWritingStrokes(
          word: word,
          strokes: allStrokes,
          canvasSize: canvasSize,
          explicitStrokeCount: _strokeCountByWordId[word.id],
        );
      }

      if (result.isCorrect) {
        _recordLearnedWordImmediately(word);
      }
      if (!mounted) return;
      setState(() {
        _recognizedText = result.recognizedText;
        _currentResult = result;
        _isChecking = false;
      });
      unawaited(_saveSessionState());
      unawaited(_playResultSound(result.isCorrect));
    } catch (_) {
      final result = AiPracticeEvaluator.evaluateWritingStrokes(
        word: word,
        strokes: allStrokes,
        canvasSize: canvasSize,
        explicitStrokeCount: _strokeCountByWordId[word.id],
      );
      if (result.isCorrect) {
        _recordLearnedWordImmediately(word);
      }
      if (!mounted) return;
      setState(() {
        _currentResult = result;
        _recognizedText = result.recognizedText;
        _isChecking = false;
      });
      unawaited(_saveSessionState());
      unawaited(_playResultSound(result.isCorrect));
    } finally {
      try {
        if (imageFile != null && await imageFile.exists()) {
          await imageFile.delete();
        }
      } catch (_) {}
      if (mounted && _isChecking) {
        setState(() => _isChecking = false);
      }
    }
  }

  void _commitCurrentResult({required bool skipped}) {
    if (_committedCardIndices.contains(_currentIndex)) return;
    _committedCardIndices.add(_currentIndex);
    final word = _currentWord;
    if (skipped || _currentResult == null) {
      _skippedCount++;
      return;
    }

    if (_currentResult!.isCorrect) {
      _correctCount++;
      if (word != null) {
        _recordLearnedWordImmediately(word);
      }
    } else {
      _incorrectCount++;
    }
  }

  Future<void> _nextWord({bool skipped = false}) async {
    _commitCurrentResult(skipped: skipped);
    if (_currentIndex >= _words.length - 1) {
      await TtsService.instance.stop();
      await _clearSessionState();
      _showResultDialog();
      return;
    }

    final next = _words[_currentIndex + 1];
    if (!mounted) return;
    setState(() {
      _currentIndex++;
      _resetCanvasState();
    });
    await _saveSessionState();
    await _speakWord(next);
  }

  void _showResultDialog() {
    final total = _words.length;
    context.read<ProgressProvider>().recordTestResult(
          _selectedLevel,
          _correctCount,
          total,
          mode: 'writing_ai',
          title: widget.title ?? 'Luyện viết $_selectedLevel',
        );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const AppAssetIcon(AppAssets.aiStateCompleted, size: 30),
            const SizedBox(width: 8),
            const Flexible(
              child: Text(
                'Hoàn thành luyện viết',
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Đã hoàn thành bài luyện viết $_selectedLevel với ${_words.length} mục.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _SummaryChip(
                  icon: Icons.check_circle_rounded,
                  color: AppTheme.successGreen,
                  label: 'Đúng',
                  value: '$_correctCount',
                ),
                _SummaryChip(
                  icon: Icons.cancel_rounded,
                  color: AppTheme.errorRed,
                  label: 'Sai',
                  value: '$_incorrectCount',
                ),
                _SummaryChip(
                  icon: Icons.skip_next_rounded,
                  color: AppTheme.textMedium,
                  label: 'Bỏ qua',
                  value: '$_skippedCount',
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Đóng'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _currentIndex = 0;
                _correctCount = 0;
                _incorrectCount = 0;
                _skippedCount = 0;
                _rewardedCardIndices.clear();
                _committedCardIndices.clear();
                _isLoading = true;
                _resetCanvasState();
              });
              _loadWords(forceResetSession: true);
            },
            child: const Text('Luyện lại'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final palette = CozyPalette.of(context);
    final levelColor = AppTheme.jlptColor(_selectedLevel);
    final word = _currentWord;
    final total = _words.length;
    final curr = total == 0 ? 0 : (_currentIndex + 1).clamp(1, total);
    final media = MediaQuery.of(context);
    final screenHeight = media.size.height;
    final keyboardOpen = media.viewInsets.bottom > 80;
    final canvasHeight = (keyboardOpen || screenHeight < 520)
        ? 230.0
        : screenHeight >= 900
            ? 380.0
            : screenHeight >= 760
                ? 330.0
                : 280.0;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: palette.background,
      appBar: AppBar(
        backgroundColor: palette.surface,
        surfaceTintColor: Colors.transparent,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppAssets.labWriting, size: 24),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                widget.title ?? 'Luyện viết $_selectedLevel',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: _showGuide ? 'Ẩn gợi ý' : 'Hiện gợi ý',
            onPressed: () => setState(() => _showGuide = !_showGuide),
            icon: Icon(
              _showGuide ? Icons.visibility_rounded : Icons.visibility_off_rounded,
            ),
          ),
          IconButton(
            tooltip: 'Tải lại',
            onPressed: () {
              setState(() {
                _currentIndex = 0;
                _correctCount = 0;
                _incorrectCount = 0;
                _skippedCount = 0;
                _rewardedCardIndices.clear();
                _committedCardIndices.clear();
                _restoredFromSession = false;
                _isLoading = true;
                _resetCanvasState();
              });
              _loadWords(forceResetSession: true);
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : word == null
              ? const Center(child: Text('Không có dữ liệu luyện viết cho cấp độ này'))
              : SafeArea(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 760),
                      child: ListView(
                        keyboardDismissBehavior:
                            ScrollViewKeyboardDismissBehavior.onDrag,
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                        children: [
                          if (widget.words == null) ...[
                            _buildDatasetFilterBar(palette, levelColor),
                            const SizedBox(height: 10),
                          ],
                          if (_restoredFromSession) ...[
                            _buildSessionRestoredBanner(
                              palette,
                              curr,
                              total,
                              levelColor,
                            ),
                            const SizedBox(height: 10),
                          ],
                          _buildProgress(palette, curr, total, levelColor),
                          const SizedBox(height: 12),
                          _buildWordInfoBar(palette, word, levelColor),
                          const SizedBox(height: 12),
                          SizedBox(
                            height: canvasHeight,
                            child: _buildCanvas(palette, word, levelColor),
                          ),
                          const SizedBox(height: 10),
                          _buildToolBar(palette, levelColor),
                          const SizedBox(height: 10),
                          _buildTypedAnswerBar(palette, word, levelColor),
                          const SizedBox(height: 12),
                          _buildActionRow(palette, levelColor),
                          const SizedBox(height: 12),
                          _buildAiPanel(palette, levelColor),
                        ],
                      ),
                    ),
                  ),
                ),
    );
  }

  Widget _buildSessionRestoredBanner(
    CozyPalette palette,
    int curr,
    int total,
    Color levelColor,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: levelColor.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: levelColor.withValues(alpha: 0.28)),
      ),
      child: Row(
        children: [
          const AppAssetIcon(AppAssets.aiStateCompleted, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Đã khôi phục phiên đang làm dở (câu $curr/$total)',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: palette.textPrimary,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _currentIndex = 0;
                _correctCount = 0;
                _incorrectCount = 0;
                _skippedCount = 0;
                _rewardedCardIndices.clear();
                _committedCardIndices.clear();
                _restoredFromSession = false;
                _isLoading = true;
                _resetCanvasState();
              });
              _loadWords(forceResetSession: true);
            },
            style: TextButton.styleFrom(
              visualDensity: VisualDensity.compact,
              foregroundColor: levelColor,
            ),
            child: const Text(
              'Làm mới',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDatasetFilterBar(CozyPalette palette, Color levelColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: palette.borderSubtle),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 6,
        alignment: WrapAlignment.spaceBetween,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              ChoiceChip(
                label: const Text('Từ vựng'),
                avatar: const AppAssetIcon(AppAssets.labVocab, size: 16),
                selected: _targetType == 'vocab',
                onSelected: (v) {
                  if (!v || _targetType == 'vocab') return;
                  setState(() {
                    _targetType = 'vocab';
                    _currentIndex = 0;
                    _isLoading = true;
                  });
                  _loadWords();
                },
              ),
              ChoiceChip(
                label: const Text('Kanji'),
                avatar: const AppAssetIcon(AppAssets.labKanji, size: 16),
                selected: _targetType == 'kanji',
                onSelected: (v) {
                  if (!v || _targetType == 'kanji') return;
                  setState(() {
                    _targetType = 'kanji';
                    _currentIndex = 0;
                    _isLoading = true;
                  });
                  _loadWords();
                },
              ),
            ],
          ),
          DropdownButton<String>(
            value: _selectedLevel,
            underline: const SizedBox.shrink(),
            borderRadius: BorderRadius.circular(12),
            dropdownColor: palette.surface,
            items: _levels
                .map(
                  (lv) => DropdownMenuItem(
                    value: lv,
                    child: Text(
                      'JLPT $lv',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: palette.textPrimary,
                      ),
                    ),
                  ),
                )
                .toList(),
            onChanged: (lv) {
              if (lv == null || lv == _selectedLevel) return;
              setState(() {
                _selectedLevel = lv;
                _currentIndex = 0;
                _isLoading = true;
              });
              _loadWords();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTypedAnswerBar(
    CozyPalette palette,
    VocabularyWord word,
    Color levelColor,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: levelColor.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          const AppAssetIcon(AppAssets.labWriting, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _typedAnswerController,
              onChanged: (_) => setState(() {}),
              onSubmitted: (_) => _checkWritingWithAi(),
              style: TextStyle(color: palette.textPrimary, fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText:
                    'Hoặc nhập câu trả lời (${word.hiragana.isNotEmpty ? word.hiragana : word.japanese} / romaji)...',
                hintStyle: TextStyle(fontSize: 13, color: palette.textSecondary),
              ),
            ),
          ),
          if (_typedAnswerController.text.isNotEmpty)
            IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: () {
                _typedAnswerController.clear();
                setState(() {});
              },
              icon: const Icon(Icons.clear_rounded, size: 18),
            ),
        ],
      ),
    );
  }

  Widget _buildProgress(
    CozyPalette palette,
    int curr,
    int total,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: palette.borderSubtle),
      ),
      child: Row(
        children: [
          Text(
            '$curr / $total từ',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: color,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: total == 0 ? 0 : curr / total,
                minHeight: 7,
                backgroundColor: palette.surfaceSoft,
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const AppAssetIcon(AppAssets.aiStateCompleted, size: 16),
              const SizedBox(width: 4),
              Text(
                '$_correctCount',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: palette.textPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWordInfoBar(
    CozyPalette palette,
    VocabularyWord word,
    Color color,
  ) {
    final expectedStrokes = AiPracticeEvaluator.expectedStrokeCountForWord(
      word,
      explicitStrokeCount: _strokeCountByWordId[word.id],
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  word.displayMeaning(language: 'vi'),
                  style: TextStyle(
                    fontSize: 17.5,
                    fontWeight: FontWeight.w800,
                    color: palette.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  word.displayMeaning(language: 'en'),
                  style: TextStyle(
                    fontSize: 13,
                    color: palette.textSecondary,
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    _MiniPill(label: word.japanese, color: color),
                    if (word.hiragana.isNotEmpty)
                      _MiniPill(
                        label: word.hiragana,
                        color: color.withValues(alpha: 0.9),
                      ),
                    if (word.romaji.isNotEmpty)
                      _MiniPill(
                        label: word.romaji,
                        color: palette.textSecondary,
                      ),
                    _MiniPill(
                      label: '$expectedStrokes nét chuẩn',
                      color: AppTheme.accentBlue,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: () => _speakWord(word),
            child: Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: _isSpeaking
                    ? Icon(Icons.graphic_eq_rounded, color: color, size: 28)
                    : const AppAssetIcon(AppAssets.learnAudio, size: 28),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCanvas(
    CozyPalette palette,
    VocabularyWord word,
    Color color,
  ) {
    final drawnCount = _strokes.length + (_currentStroke.isNotEmpty ? 1 : 0);
    return RepaintBoundary(
      key: _canvasKey,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: color.withValues(alpha: 0.32), width: 2),
          boxShadow: palette.softCardShadow,
        ),
        clipBehavior: Clip.hardEdge,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _GridPainter(color: color.withValues(alpha: 0.14)),
              ),
            ),
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Row(
                children: [
                  Flexible(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'Khung tập viết • Đã vẽ: $drawnCount nét',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_showGuide)
              Center(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 36, 20, 16),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      word.japanese,
                      style: TextStyle(
                        fontSize: word.japanese.length > 2 ? 118 : 138,
                        fontWeight: FontWeight.w900,
                        color: color.withValues(alpha: 0.08),
                        height: 1,
                      ),
                    ),
                  ),
                ),
              ),
            Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (e) => _startStroke(e.localPosition),
              onPointerMove: (e) => _appendStroke(e.localPosition),
              onPointerUp: (_) => _endStroke(),
              onPointerCancel: (_) => _endStroke(),
              child: GestureDetector(
                onPanUpdate: (_) {},
                child: CustomPaint(
                  painter: _StrokePainter(
                    strokes: _strokes,
                    currentStroke: _currentStroke,
                    strokeColor: AppTheme.textDark,
                  ),
                  child: const SizedBox.expand(),
                ),
              ),
            ),
            if (_strokes.isEmpty && _currentStroke.isEmpty)
              IgnorePointer(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 28, 20, 12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppAssets.labWriting, size: 42),
                        const SizedBox(height: 8),
                        Text(
                          'Viết chữ vào khung hoặc nhập đáp án bên dưới rồi bấm “Kiểm tra”.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.5,
                            color: Colors.grey.shade600,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Hỗ trợ nhận diện OCR (trên thiết bị di động) & kiểm tra nét vẽ chuẩn xác.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 11.5,
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAiPanel(CozyPalette palette, Color levelColor) {
    final result = _currentResult;
    final passed = result?.isCorrect ?? false;
    final isStrokeLayoutOnly = result?.evaluationMode == 'stroke_layout';
    final scorePercent = ((result?.score ?? 0) * 100).round();
    final statusColor = result == null
        ? levelColor
        : passed
            ? AppTheme.successGreen
            : AppTheme.errorRed;
    final modeLabel = switch (result?.evaluationMode) {
      'ocr' => 'Nhận diện chữ viết OCR (MLKit)',
      'typed_answer' => 'Kiểm tra đáp án nhập (Typed Check)',
      'stroke_layout' => 'Kiểm tra số nét & bố cục (Không OCR)',
      _ => 'Chế độ chấm tự động',
    };
    final statusText = result == null
        ? 'Chờ kiểm tra'
        : isStrokeLayoutOnly
            ? (passed ? 'Đủ nét & bố cục' : 'Chưa đủ nét / bố cục')
            : (passed ? 'Đạt' : 'Chưa đạt');
    final statusIconAsset = _isChecking
        ? AppAssets.aiStateLoading
        : result == null
            ? AppAssets.labAiPractice
            : passed
                ? AppAssets.aiStateCompleted
                : AppAssets.aiStateError;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: palette.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: result == null
              ? levelColor.withValues(alpha: 0.18)
              : statusColor.withValues(alpha: 0.28),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppAssetIcon(statusIconAsset, size: 20),
                    const SizedBox(width: 6),
                    Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
              _MiniPill(
                label: modeLabel,
                color: AppTheme.accentBlue,
              ),
              if (result != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    isStrokeLayoutOnly
                        ? result.recognizedText
                        : '$scorePercent%',
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            result?.feedback ??
                'Hệ thống phân biệt rõ nhận diện chữ viết OCR, kiểm tra đáp án nhập và kiểm tra số nét & bố cục khung viết.',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: statusColor,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: palette.surfaceSoft,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isStrokeLayoutOnly
                      ? 'Phân tích số nét & bố cục (Không nhận diện mặt chữ):'
                      : 'Kết quả nhận diện / đáp án:',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: palette.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _recognizedText.isEmpty
                      ? 'Chưa có kết quả kiểm tra.'
                      : _recognizedText,
                  style: TextStyle(
                    fontSize: 15,
                    height: 1.4,
                    color: palette.textPrimary,
                  ),
                ),
                if (result != null) ...[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _MiniPill(
                        label: isStrokeLayoutOnly
                            ? 'Số nét: ${result.recognizedText}'
                            : 'Mức khớp $scorePercent%',
                        color: statusColor,
                      ),
                      _MiniPill(
                        label: 'Mục tiêu: ${result.matchedTarget}',
                        color: levelColor,
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (result != null && result.suggestions.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: statusColor.withValues(alpha: 0.18)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const AppAssetIcon(AppAssets.labWriting, size: 18),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Gợi ý chi tiết',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: statusColor,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ...result.suggestions.map(
                    (tip) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        tip,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.45,
                          color: palette.textPrimary,
                        ),
                      ),
                    ),
                  ),
                  if (result.encouragement.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: palette.coinSoft,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        result.encouragement,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: palette.coin,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildToolBar(CozyPalette palette, Color levelColor) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _strokes.isEmpty ? null : _undoLastStroke,
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(44),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              side: BorderSide(color: palette.textSecondary.withValues(alpha: 0.4)),
              foregroundColor: palette.textPrimary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: const Icon(Icons.undo_rounded, size: 17),
            label: const Text(
              'Xóa nét',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: (_strokes.isEmpty &&
                    _currentStroke.isEmpty &&
                    _typedAnswerController.text.isEmpty)
                ? null
                : _clearCanvas,
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(44),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              foregroundColor: AppTheme.errorRed,
              side: BorderSide(color: AppTheme.errorRed.withValues(alpha: 0.4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: const Icon(Icons.delete_outline_rounded, size: 17),
            label: const Text(
              'Xóa tất cả',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => setState(() => _showGuide = !_showGuide),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(44),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              foregroundColor: levelColor,
              side: BorderSide(color: levelColor.withValues(alpha: 0.4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: Icon(
              _showGuide ? Icons.visibility_off_rounded : Icons.visibility_rounded,
              size: 17,
            ),
            label: Text(
              _showGuide ? 'Ẩn gợi ý' : 'Gợi ý',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionRow(CozyPalette palette, Color levelColor) {
    final lastCard = _currentIndex >= _words.length - 1;
    final canCheck = _strokes.isNotEmpty ||
        _currentStroke.isNotEmpty ||
        _typedAnswerController.text.trim().isNotEmpty;

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _nextWord(skipped: true),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  foregroundColor: palette.textSecondary,
                  side: BorderSide(
                    color: palette.textSecondary.withValues(alpha: 0.35),
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                icon: const Icon(Icons.skip_next_rounded),
                label: const Text(
                  'Bỏ qua',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: !canCheck || _isChecking ? null : _checkWritingWithAi,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  backgroundColor: levelColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                icon: _isChecking
                    ? const AppAssetIcon(AppAssets.aiStateLoading, size: 22)
                    : const AppAssetIcon(AppAssets.labWriting, size: 22),
                label: Text(
                  _isChecking ? 'Đang chấm...' : 'Kiểm tra kết quả',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextButton.icon(
                onPressed: !canCheck ? null : _clearCanvas,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Viết lại'),
                style: TextButton.styleFrom(foregroundColor: palette.textSecondary),
              ),
            ),
            Expanded(
              child: TextButton.icon(
                onPressed: _currentWord == null ? null : () => _speakWord(_currentWord!),
                icon: const AppAssetIcon(AppAssets.learnAudio, size: 18),
                label: const Text('Nghe lại'),
                style: TextButton.styleFrom(foregroundColor: AppTheme.accentBlue),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: _currentResult == null ? null : () => _nextWord(),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  backgroundColor: AppTheme.successGreen,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                icon: Icon(lastCard ? Icons.assessment_rounded : Icons.arrow_forward_rounded),
                label: Text(lastCard ? 'Xem tổng kết' : 'Sang từ tiếp theo'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _MiniPill extends StatelessWidget {
  final String label;
  final Color color;

  const _MiniPill({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String value;

  const _SummaryChip({
    required this.icon,
    required this.color,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: color,
            fontSize: 22,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 12, color: AppTheme.textMedium),
        ),
      ],
    );
  }
}

class _StrokePainter extends CustomPainter {
  final List<List<Offset>> strokes;
  final List<Offset> currentStroke;
  final Color strokeColor;

  _StrokePainter({
    required this.strokes,
    required this.currentStroke,
    required this.strokeColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = strokeColor
      ..strokeWidth = 7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    void drawStroke(List<Offset> points) {
      if (points.isEmpty) return;
      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (int i = 1; i < points.length; i++) {
        path.lineTo(points[i].dx, points[i].dy);
      }
      canvas.drawPath(path, paint);
    }

    for (final stroke in strokes) {
      drawStroke(stroke);
    }
    drawStroke(currentStroke);
  }

  @override
  bool shouldRepaint(covariant _StrokePainter oldDelegate) => true;
}

class _GridPainter extends CustomPainter {
  final Color color;

  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(size.width / 2, 0),
      Offset(size.width / 2, size.height),
      paint,
    );
    canvas.drawLine(
      Offset(0, size.height / 2),
      Offset(size.width, size.height / 2),
      paint,
    );

    paint.strokeWidth = 0.5;
    canvas.drawLine(Offset(0, 0), Offset(size.width, size.height), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(0, size.height), paint);
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) => false;
}
