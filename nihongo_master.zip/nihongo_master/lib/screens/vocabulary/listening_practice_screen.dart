import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../models/study_history.dart';
import '../../models/vocabulary.dart';
import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/study_history_provider.dart';
import '../../services/feedback_audio_service.dart';
import '../../services/local_database_service.dart';
import '../../services/tts_service.dart';
import '../../utils/constants.dart';
import '../../utils/content_fallback.dart';
import '../../utils/theme.dart';

abstract class ListeningAudioController {
  Future<bool> playItem(ListeningPracticeItem item, {double rate = 1.0});
  Future<void> pause();
  Future<bool> replayItem(ListeningPracticeItem item, {double rate = 1.0});
  Future<void> stop();
  void dispose();
}

class DefaultListeningAudioController implements ListeningAudioController {
  AudioPlayer? _audioPlayer;

  @override
  Future<bool> playItem(ListeningPracticeItem item, {double rate = 1.0}) async {
    if (!item.isPlayable ||
        item.audioStatus != 'available' ||
        item.audioPath.trim().isEmpty) {
      return false;
    }
    try {
      _audioPlayer ??= AudioPlayer();
      await _audioPlayer!.stop();
      await _audioPlayer!.setPlaybackRate(rate);
      final assetRelativePath = item.audioPath.startsWith('assets/')
          ? item.audioPath.substring('assets/'.length)
          : item.audioPath;
      await _audioPlayer!.play(AssetSource(assetRelativePath));
      return true;
    } catch (_) {
      try {
        await TtsService.instance.speakJapanese(
          item.transcriptNormalized,
          rate: rate,
        );
      } catch (_) {}
      return false;
    }
  }

  @override
  Future<void> pause() async {
    try {
      await _audioPlayer?.pause();
    } catch (_) {}
  }

  @override
  Future<bool> replayItem(ListeningPracticeItem item, {double rate = 1.0}) async {
    await stop();
    return playItem(item, rate: rate);
  }

  @override
  Future<void> stop() async {
    try {
      await _audioPlayer?.stop();
    } catch (_) {}
  }

  @override
  void dispose() {
    try {
      _audioPlayer?.dispose();
    } catch (_) {}
  }
}

class ListeningPracticeScreen extends StatefulWidget {
  final String level;
  final List<VocabularyWord>? words;
  final String? title;
  final ListeningAudioController? audioController;

  const ListeningPracticeScreen({
    super.key,
    required this.level,
    this.words,
    this.title,
    this.audioController,
  });

  @override
  State<ListeningPracticeScreen> createState() =>
      _ListeningPracticeScreenState();
}

class _ListeningPracticeScreenState extends State<ListeningPracticeScreen> {
  static const List<String> _levelFilters = <String>[
    'Tất cả',
    'N5',
    'N4',
    'N3',
    'N2',
    'N1',
  ];

  static const List<_SpeedOption> _speedOptions = [
    _SpeedOption(label: 'Chậm 0.75x', rate: 0.75, emoji: '🐢'),
    _SpeedOption(label: 'Chuẩn 1.0x', rate: 1.0, emoji: '🚶'),
    _SpeedOption(label: 'Nhanh 1.25x', rate: 1.25, emoji: '🚀'),
  ];

  late String _selectedLevel;
  List<ListeningPracticeItem> _listeningItems = [];
  List<VocabularyWord> _words = [];
  List<VocabularyWord> _options = [];
  int _correctIndex = 0;
  int _currentIndex = 0;
  int? _selectedIndex;
  int _score = 0;
  int _speedIndex = 1;
  bool _answered = false;
  bool _isLoading = true;
  final bool _autoPlay = false;
  bool _isPlayingAudio = false;
  bool _showTranscript = false;
  bool _showReading = false;
  DateTime _startedAt = DateTime.now();
  late final ListeningAudioController _audioController;

  @override
  void initState() {
    super.initState();
    _audioController =
        widget.audioController ?? DefaultListeningAudioController();
    _selectedLevel = _levelFilters.contains(widget.level) ? widget.level : 'N5';
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadPractice());
  }

  @override
  void dispose() {
    _audioController.dispose();
    if (_isPlayingAudio) {
      TtsService.instance.stop();
    }
    super.dispose();
  }

  bool get _useDatasetItems => _listeningItems.isNotEmpty;
  ListeningPracticeItem get _currentItem => _listeningItems[_currentIndex];
  VocabularyWord get _currentWord => _words[_currentIndex];
  double get _currentRate => _speedOptions[_speedIndex].rate;

  Future<void> _loadPractice() async {
    setState(() {
      _isLoading = true;
    });

    int totalPlayableCount = 0;
    List<ListeningPracticeItem> itemsForLevel = const [];
    try {
      if (LocalDatabaseService.listeningCountInitialized) {
        totalPlayableCount = LocalDatabaseService.loadedListeningCount;
        if (totalPlayableCount > 0 &&
            LocalDatabaseService.loadedPlayableListeningItems.isNotEmpty) {
          itemsForLevel = LocalDatabaseService.getLoadedListeningItemsByLevel(
            _selectedLevel,
          );
        } else if (totalPlayableCount > 0) {
          itemsForLevel = await LocalDatabaseService.instance
              .getPlayableListeningItems(level: _selectedLevel);
        }
      } else {
        totalPlayableCount = await LocalDatabaseService.instance
            .getListeningMaterialCount(playableOnly: true);
        if (totalPlayableCount > 0) {
          itemsForLevel = await LocalDatabaseService.instance
              .getPlayableListeningItems(level: _selectedLevel);
        }
      }
    } catch (_) {
      totalPlayableCount = 0;
      itemsForLevel = const [];
    }

    if (!mounted) return;
    if (totalPlayableCount <= 0) {
      setState(() {
        _listeningItems = [];
        _words = [];
        _options = [];
        _isLoading = false;
      });
      return;
    }

    // Filter strictly to playable items (audio_status == 'available')
    final playableItems =
        itemsForLevel.where((it) => it.isPlayable).toList(growable: false);

    if (playableItems.isNotEmpty) {
      setState(() {
        _listeningItems = playableItems;
        _words = [];
        _options = [];
        _currentIndex = 0;
        _selectedIndex = null;
        _answered = false;
        _score = 0;
        _showTranscript = false;
        _showReading = false;
        _correctIndex = playableItems.first.correctIndex;
        _startedAt = DateTime.now();
        _isLoading = false;
      });
      if (_autoPlay) {
        WidgetsBinding.instance
            .addPostFrameCallback((_) => _playCurrentAudio());
      }
      return;
    }

    // If a specific level filter was selected and has 0 playable items in DB, show Empty State
    setState(() {
      _listeningItems = [];
      _words = [];
      _options = [];
      _isLoading = false;
    });
  }

  void _onSelectLevelFilter(String level) {
    if (_selectedLevel == level) return;
    setState(() {
      _selectedLevel = level;
    });
    _loadPractice();
  }

  Future<void> _playCurrentAudio() async {
    if (_useDatasetItems) {
      final item = _currentItem;
      if (!item.isPlayable) return;
      setState(() => _isPlayingAudio = true);
      try {
        await _audioController.playItem(item, rate: _currentRate);
      } finally {
        if (mounted) {
          setState(() => _isPlayingAudio = false);
        }
      }
      return;
    }

    if (_words.isEmpty) return;
    await _speak(_currentWord.japanese, rate: _currentRate);
  }

  Future<void> _pauseCurrentAudio() async {
    await _audioController.pause();
    if (mounted) {
      setState(() => _isPlayingAudio = false);
    }
  }

  Future<void> _replayCurrentAudio() async {
    if (_useDatasetItems) {
      final item = _currentItem;
      if (!item.isPlayable) return;
      setState(() => _isPlayingAudio = true);
      try {
        await _audioController.replayItem(item, rate: _currentRate);
      } finally {
        if (mounted) {
          setState(() => _isPlayingAudio = false);
        }
      }
      return;
    }

    if (_words.isEmpty) return;
    await _speak(_currentWord.japanese, rate: _currentRate);
  }

  Future<void> _speak(String text, {double? rate}) async {
    if (text.trim().isEmpty) return;
    if (_isPlayingAudio) {
      await TtsService.instance.stop();
      await Future.delayed(const Duration(milliseconds: 100));
    }
    setState(() => _isPlayingAudio = true);
    try {
      await TtsService.instance.speakJapanese(text, rate: rate ?? _currentRate);
    } finally {
      if (mounted) setState(() => _isPlayingAudio = false);
    }
  }

  void _select(int index) {
    if (_answered) return;
    setState(() => _selectedIndex = index);
  }

  void _checkAnswer() {
    if (_selectedIndex == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hãy chọn một đáp án trước nhé. 👆')),
      );
      return;
    }

    final targetCorrect =
        _useDatasetItems ? _currentItem.correctIndex : _correctIndex;

    setState(() {
      _answered = true;
      if (_useDatasetItems) {
        _showTranscript = true;
        _showReading = true;
      }
      if (_selectedIndex == targetCorrect) {
        _score++;
        context.read<ProgressProvider>().addXP(AppConstants.xpVocabQuiz);
      }
    });

    if (_selectedIndex == targetCorrect) {
      FeedbackAudioService.instance.playCorrect();
    } else {
      FeedbackAudioService.instance.playWrong();
    }
  }

  Future<void> _next() async {
    final total = _useDatasetItems ? _listeningItems.length : _words.length;
    if (_currentIndex >= total - 1) {
      await _showResults();
      return;
    }

    setState(() {
      _currentIndex++;
      _selectedIndex = null;
      _answered = false;
      _showTranscript = false;
      _showReading = false;
      if (_useDatasetItems) {
        _correctIndex = _listeningItems[_currentIndex].correctIndex;
      }
    });

    if (_autoPlay) {
      await _playCurrentAudio();
    }
  }

  void _restart() {
    setState(() {
      _currentIndex = 0;
      _score = 0;
      _selectedIndex = null;
      _answered = false;
      _showTranscript = false;
      _showReading = false;
      _startedAt = DateTime.now();
      if (_useDatasetItems && _listeningItems.isNotEmpty) {
        _correctIndex = _listeningItems.first.correctIndex;
      }
    });
    if (_autoPlay) {
      _playCurrentAudio();
    }
  }

  Future<void> _showResults() async {
    final total = _useDatasetItems ? _listeningItems.length : _words.length;
    final percent = total == 0 ? 0 : (_score / total * 100).round();
    final effectiveLvl =
        _selectedLevel == 'Tất cả' ? widget.level : _selectedLevel;
    final auth = context.read<AuthProvider>();
    final historyProvider = context.read<StudyHistoryProvider>();
    final progressProvider = context.read<ProgressProvider>();
    final history = StudyHistory(
      id: const Uuid().v4(),
      userId: auth.currentUser?.uid ?? 'guest',
      testId:
          'listening_${effectiveLvl}_${DateTime.now().millisecondsSinceEpoch}',
      title: widget.title ?? 'Luyện nghe $effectiveLvl',
      jlptLevel: effectiveLvl,
      totalQuestions: total,
      correctAnswers: _score,
      wrongAnswers: total - _score,
      scorePercent: percent.toDouble(),
      timeTakenSeconds: DateTime.now().difference(_startedAt).inSeconds,
      completedAt: DateTime.now(),
    );

    await historyProvider.addHistory(history);
    progressProvider.recordTestResult(
          effectiveLvl,
          _score,
          total,
          title: history.title,
          mode: 'listening',
          playbackRate: _currentRate,
        );

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title:
            const Text('🎧 Kết quả luyện nghe', textAlign: TextAlign.center),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '$percent%',
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.w900,
                color:
                    percent >= 60 ? AppTheme.successGreen : AppTheme.errorRed,
              ),
            ),
            const SizedBox(height: 8),
            Text('$_score / $total câu đúng'),
            const SizedBox(height: 14),
            Text(
              percent >= 80
                  ? '🎉 Bạn nghe rất tốt! Thử tốc độ Nhanh nhé.'
                  : percent >= 60
                      ? '👍 Ổn rồi, thử tăng tốc độ để thử thách hơn.'
                      : '💪 Luyện thêm ở tốc độ Chậm để bắt kịp nhịp.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Thoát'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _restart();
            },
            child: const Text('Luyện lại'),
          ),
        ],
      ),
    );
  }

  Widget _buildLevelFilterBar(Color levelColor) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: _levelFilters.map((lvl) {
          final isSelected = _selectedLevel == lvl;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(lvl),
              selected: isSelected,
              selectedColor: levelColor.withValues(alpha: 0.18),
              labelStyle: TextStyle(
                color: isSelected ? levelColor : AppTheme.textDark,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
              ),
              onSelected: (_) => _onSelectLevelFilter(lvl),
            ),
          );
        }).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final effectiveColorLevel =
        _selectedLevel == 'Tất cả' ? widget.level : _selectedLevel;
    final levelColor = AppTheme.jlptColor(effectiveColorLevel);

    if (_isLoading) {
      return Scaffold(
        appBar:
            AppBar(title: Text(widget.title ?? 'Luyện nghe $_selectedLevel')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (!_useDatasetItems && (_words.isEmpty || _options.isEmpty)) {
      final settings = Provider.of<SettingsProvider?>(context);
      final language = settings?.effectiveLanguage ?? 'vi';
      final emptyMessage = ContentFallback.listeningEmptyStateText(
        language: language,
      );
      return Scaffold(
        appBar:
            AppBar(title: Text(widget.title ?? 'Luyện nghe $_selectedLevel')),
        body: Column(
          children: [
            _buildLevelFilterBar(levelColor),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.headphones_outlined,
                          size: 56, color: levelColor),
                      const SizedBox(height: 12),
                      Text(
                        emptyMessage,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    final item = _currentItem;
    final totalCount = _listeningItems.length;
    final progressValue = (_currentIndex + 1) / totalCount;
    final estLvl = item.estimatedLevel ?? 'Chưa phân cấp';

    return Scaffold(
      appBar: AppBar(title: Text(widget.title ?? 'Luyện nghe $_selectedLevel')),
      body: SafeArea(
        child: Column(
          children: [
            _buildLevelFilterBar(levelColor),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                children: [
                  // Progress & Estimated Difficulty Badge Card
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Câu ${_currentIndex + 1}/$totalCount • Điểm $_score',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: levelColor.withValues(alpha: 0.14),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                'Độ khó ước lượng: $estLvl (${item.levelSource})',
                                style: TextStyle(
                                  color: levelColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: progressValue,
                            minHeight: 8,
                            backgroundColor: Colors.grey.shade200,
                            valueColor: AlwaysStoppedAnimation(levelColor),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Audio Player & Transcript/Reading Controls Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [levelColor, levelColor.withValues(alpha: 0.76)],
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: levelColor.withValues(alpha: 0.28),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '🎧 ${item.title}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Nguồn: Kokoro Speech Dataset (${item.speakerName}) • ${(item.durationMs / 1000).toStringAsFixed(1)}s',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Tốc độ phát:',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children:
                              List.generate(_speedOptions.length, (index) {
                            final option = _speedOptions[index];
                            final isSelected = _speedIndex == index;
                            return Expanded(
                              child: GestureDetector(
                                onTap: () =>
                                    setState(() => _speedIndex = index),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  margin: EdgeInsets.only(
                                      right: index < 2 ? 8 : 0),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 8, horizontal: 6),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.white.withValues(alpha: 0.15),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(
                                      color: isSelected
                                          ? Colors.white
                                          : Colors.white.withValues(alpha: 0.35),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      Text(option.emoji,
                                          style:
                                              const TextStyle(fontSize: 16)),
                                      const SizedBox(height: 2),
                                      Text(
                                        option.label,
                                        style: TextStyle(
                                          color: isSelected
                                              ? levelColor
                                              : Colors.white,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            ElevatedButton.icon(
                              onPressed: _playCurrentAudio,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,
                                foregroundColor: levelColor,
                                minimumSize: const Size(0, 42),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 14),
                              ),
                              icon: Icon(
                                _isPlayingAudio
                                    ? Icons.graphic_eq_rounded
                                    : Icons.play_circle_fill_rounded,
                                size: 18,
                              ),
                              label: const Text(
                                'Phát audio',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                            ElevatedButton.icon(
                              onPressed: _pauseCurrentAudio,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white.withValues(alpha: 0.92),
                                foregroundColor: levelColor,
                                minimumSize: const Size(0, 42),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 14),
                              ),
                              icon: const Icon(Icons.pause_rounded, size: 18),
                              label: const Text(
                                'Tạm dừng',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                            ElevatedButton.icon(
                              onPressed: _replayCurrentAudio,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white.withValues(alpha: 0.92),
                                foregroundColor: levelColor,
                                minimumSize: const Size(0, 42),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 14),
                              ),
                              icon: const Icon(Icons.replay_rounded, size: 18),
                              label: const Text(
                                'Nghe lại',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => setState(
                                  () => _showTranscript = !_showTranscript),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Colors.white,
                                side: BorderSide(
                                    color: Colors.white.withValues(alpha: 0.6)),
                                minimumSize: const Size(0, 42),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                              ),
                              icon: Icon(
                                _showTranscript
                                    ? Icons.visibility_off_outlined
                                    : Icons.subtitles_outlined,
                                size: 18,
                              ),
                              label: Text(
                                _showTranscript
                                    ? 'Ẩn transcript'
                                    : 'Hiện transcript',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                            if (item.reading.isNotEmpty)
                              OutlinedButton.icon(
                                onPressed: () => setState(
                                    () => _showReading = !_showReading),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  side: BorderSide(
                                      color: Colors.white.withValues(alpha: 0.6)),
                                  minimumSize: const Size(0, 42),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12),
                                ),
                                icon: const Icon(Icons.translate_rounded,
                                    size: 18),
                                label: Text(
                                  _showReading
                                      ? 'Ẩn cách đọc'
                                      : 'Hiện cách đọc',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700),
                                ),
                              ),
                          ],
                        ),
                        if (_showTranscript || _showReading) ...[
                          const SizedBox(height: 12),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.22),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (_showTranscript) ...[
                                  Text(
                                    'Transcript: ${item.transcriptNormalized}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 15,
                                    ),
                                  ),
                                  if (item.transcriptOriginal !=
                                      item.transcriptNormalized)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        'Bản gốc: ${item.transcriptOriginal}',
                                        style: const TextStyle(
                                          color: Colors.white70,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                ],
                                if (_showReading &&
                                    item.reading.isNotEmpty) ...[
                                  if (_showTranscript)
                                    const SizedBox(height: 6),
                                  Text(
                                    'Cách đọc (Hiragana): ${item.reading}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Comprehension Question Prompt
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(
                      item.promptVi,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),

                  // 4 Options
                  ...List.generate(item.options.length, (index) {
                    final optionText = item.options[index];
                    final isCorrect = index == item.correctIndex;
                    final isSelected = index == _selectedIndex;

                    Color borderColor = Colors.grey.shade200;
                    Color background = Theme.of(context).cardColor;
                    Color textColor = AppTheme.textDark;

                    if (_answered) {
                      if (isCorrect) {
                        borderColor = AppTheme.successGreen;
                        background = AppTheme.successGreen.withValues(alpha: 0.1);
                        textColor = AppTheme.successGreen;
                      } else if (isSelected) {
                        borderColor = AppTheme.errorRed;
                        background = AppTheme.errorRed.withValues(alpha: 0.1);
                        textColor = AppTheme.errorRed;
                      }
                    } else if (isSelected) {
                      borderColor = levelColor;
                      background = levelColor.withValues(alpha: 0.08);
                      textColor = levelColor;
                    }

                    return GestureDetector(
                      onTap: () => _select(index),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: background,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: borderColor, width: 1.6),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 34,
                              height: 34,
                              decoration: BoxDecoration(
                                color: borderColor.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Text(
                                  String.fromCharCode(65 + index),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: textColor,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                optionText,
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: textColor,
                                ),
                              ),
                            ),
                            if (_answered && isCorrect)
                              const Icon(Icons.check_circle,
                                  color: AppTheme.successGreen)
                            else if (_answered && isSelected && !isCorrect)
                              const Icon(Icons.cancel,
                                  color: AppTheme.errorRed),
                          ],
                        ),
                      ),
                    );
                  }),

                  if (_answered)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: levelColor.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(16),
                        border:
                            Border.all(color: levelColor.withValues(alpha: 0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Đáp án đúng: ${item.transcriptNormalized}',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: levelColor,
                            ),
                          ),
                          if (item.reading.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              'Cách đọc: ${item.reading}',
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ],
                          const SizedBox(height: 6),
                          Text(
                            'Phân loại độ khó: $estLvl (${item.levelSource}) • Điểm độ khó: ${item.difficultyScore} • Độ tin cậy: ${(item.classificationConfidence * 100).round()}%',
                            style: TextStyle(
                              color: AppTheme.textMedium,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _answered ? _next : _checkAnswer,
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    backgroundColor:
                        _answered ? levelColor : AppTheme.primaryRed,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  icon: Icon(_answered
                      ? Icons.arrow_forward_rounded
                      : Icons.verified_rounded),
                  label: Text(
                    _answered
                        ? (_currentIndex == totalCount - 1
                            ? 'Xem kết quả 🎯'
                            : 'Câu tiếp theo →')
                        : 'Kiểm tra đáp án ✔',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SpeedOption {
  final String label;
  final double rate;
  final String emoji;

  const _SpeedOption({
    required this.label,
    required this.rate,
    required this.emoji,
  });
}
