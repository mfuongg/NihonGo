import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/grammar_data.dart';
import '../../models/grammar.dart';
import '../../providers/progress_provider.dart';
import '../../services/local_database_service.dart';
import '../../theme/cozy_palette.dart';
import '../../widgets/cozy_common_widgets.dart';

class GrammarScreen extends StatefulWidget {
  final bool allowBack;

  const GrammarScreen({super.key, this.allowBack = true});

  @override
  State<GrammarScreen> createState() => _GrammarScreenState();
}

class _GrammarScreenState extends State<GrammarScreen> {
  String _selectedLevel = 'N5';
  final Set<String> _recordedLessonIds = <String>{};

  @override
  void initState() {
    super.initState();
    if (GrammarData.getAllLessons().isEmpty) {
      LocalDatabaseService.instance
          .ensureVerifiedDatasetImportedAndLoaded()
          .then((_) {
        if (mounted) setState(() {});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final lessons = GrammarData.getLessonsByLevel(_selectedLevel);

    return CozyScaffold(
      appBar: CozyAppBar(
        title: 'Ngữ pháp $_selectedLevel',
        subtitle: 'Hệ thống mẫu câu chuẩn JLPT N5 – N1',
        allowBack: widget.allowBack,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: CozyResourcePill(
                icon: Icons.menu_book_rounded,
                label: '${lessons.length} mẫu',
              ),
            ),
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: CozySurfaceCard(
                borderRadius: 20,
                padding: const EdgeInsets.all(18),
                backgroundColor: cozy.surface,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: cozy.primary.withValues(alpha: 0.14),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            '${_levelEmoji(_selectedLevel)} Cấp độ $_selectedLevel',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: cozy.primary,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          'Tổng ${GrammarData.getAllLessons().length} mẫu N5–N1',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: cozy.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Mở rộng ngữ pháp từ N5 đến N1',
                      style: TextStyle(
                        color: cozy.textPrimary,
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Mỗi cấp độ kèm giải thích dễ nhớ, ví dụ câu thực tế và lưu ý trọng tâm cho kỳ thi JLPT.',
                      style: TextStyle(
                        color: cozy.textSecondary,
                        fontSize: 13.5,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: GrammarData.levels.map((level) {
                    final selected = level == _selectedLevel;
                    final count = GrammarData.getLessonsByLevel(level).length;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedLevel = level),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: selected ? cozy.primary : cozy.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? cozy.primary
                                  : cozy.borderSubtle,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_levelEmoji(level)),
                              const SizedBox(width: 6),
                              Text(
                                level,
                                style: TextStyle(
                                  color: selected
                                      ? cozy.onPrimary
                                      : cozy.textPrimary,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                '$count',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: selected
                                      ? cozy.onPrimary.withValues(alpha: 0.85)
                                      : cozy.textSecondary,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
              child: CozySectionHeader(
                title: 'Danh sách mẫu $_selectedLevel',
                subtitle: 'Chọn một mẫu câu để xem cấu trúc & ví dụ chi tiết',
                icon: Icons.auto_stories_rounded,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 80),
            sliver: SliverList.builder(
              itemCount: lessons.length,
              itemBuilder: (context, index) {
                final lesson = lessons[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _GrammarCard(
                    lesson: lesson,
                    index: index + 1,
                    onTap: () {
                      if (_recordedLessonIds.add(lesson.id)) {
                        Provider.of<ProgressProvider?>(context, listen: false)
                            ?.recordAdaptiveQuestProgress(
                          'grammar',
                          levelOverride: lesson.jlptLevel,
                        );
                      }
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => GrammarDetailScreen(lesson: lesson),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _levelEmoji(String level) {
    switch (level) {
      case 'N5':
        return '🌱';
      case 'N4':
        return '📗';
      case 'N3':
        return '📘';
      case 'N2':
        return '📙';
      case 'N1':
        return '🏯';
      default:
        return '🧩';
    }
  }
}

class _GrammarCard extends StatelessWidget {
  final GrammarLesson lesson;
  final int index;
  final VoidCallback onTap;

  const _GrammarCard({
    required this.lesson,
    required this.index,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;

    return CozySurfaceCard(
      borderRadius: 20,
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 54,
            height: 68,
            decoration: BoxDecoration(
              color: cozy.surfaceSoft,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: cozy.borderSubtle),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '$index',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: cozy.primary,
                  ),
                ),
                const SizedBox(height: 3),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: cozy.primary,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    lesson.jlptLevel,
                    style: TextStyle(
                      color: cozy.onPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 10.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  lesson.pattern,
                  style: TextStyle(
                    color: cozy.primary,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  lesson.displayTitle(language: 'vi'),
                  style: TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                    color: cozy.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  lesson.displayExplanation(language: 'vi'),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: cozy.textSecondary,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    _MiniTag(
                      label: '${lesson.examples.length} ví dụ',
                      color: cozy.primary,
                    ),
                    if (lesson.notes.isNotEmpty)
                      _MiniTag(
                        label: '${lesson.notes.length} lưu ý',
                        color: cozy.secondary,
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Padding(
            padding: const EdgeInsets.only(top: 18),
            child: Icon(
              Icons.chevron_right_rounded,
              color: cozy.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  final String label;
  final Color color;

  const _MiniTag({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w700,
          fontSize: 11.5,
        ),
      ),
    );
  }
}

class GrammarDetailScreen extends StatelessWidget {
  final GrammarLesson lesson;

  const GrammarDetailScreen({super.key, required this.lesson});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;

    return CozyScaffold(
      appBar: CozyAppBar(
        title: lesson.pattern,
        subtitle: 'Ngữ pháp JLPT ${lesson.jlptLevel}',
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 36),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CozySurfaceCard(
              borderRadius: 20,
              padding: const EdgeInsets.all(22),
              backgroundColor: cozy.surface,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: cozy.primary.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'JLPT ${lesson.jlptLevel}',
                      style: TextStyle(
                        color: cozy.primary,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    lesson.pattern,
                    style: TextStyle(
                      fontSize: 28,
                      color: cozy.textPrimary,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    lesson.displayTitle(language: 'vi'),
                    style: TextStyle(
                      color: cozy.textSecondary,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const CozySectionHeader(
              title: 'Giải thích cách dùng',
              icon: Icons.menu_book_rounded,
            ),
            const SizedBox(height: 10),
            Text(
              lesson.displayExplanation(language: 'vi'),
              style: TextStyle(
                fontSize: 15.5,
                height: 1.7,
                color: cozy.textPrimary,
              ),
            ),
            const SizedBox(height: 20),
            Divider(color: cozy.borderSubtle, height: 1),
            const SizedBox(height: 20),
            const CozySectionHeader(
              title: 'Ví dụ thực chiến',
              icon: Icons.format_quote_rounded,
            ),
            const SizedBox(height: 12),
            ...List.generate(lesson.examples.length, (idx) {
              final example = lesson.examples[idx];
              final isLast = idx == lesson.examples.length - 1;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 4,
                          height: 52,
                          margin: const EdgeInsets.only(top: 4, right: 12),
                          decoration: BoxDecoration(
                            color: cozy.primary,
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                example.japanese,
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                  color: cozy.textPrimary,
                                  height: 1.5,
                                ),
                              ),
                              if (example.hiragana.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  example.hiragana,
                                  style: TextStyle(
                                    fontSize: 13.5,
                                    color: cozy.textSecondary,
                                    height: 1.5,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 6),
                              Text(
                                example.displayTranslation(language: 'vi'),
                                style: TextStyle(
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w700,
                                  color: cozy.primary,
                                  height: 1.55,
                                ),
                              ),
                              if (example
                                  .displayTranslation(language: 'en')
                                  .isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Text(
                                  example.displayTranslation(language: 'en'),
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: cozy.textSecondary,
                                    height: 1.5,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!isLast)
                    Divider(
                      color: cozy.borderSubtle,
                      height: 12,
                    ),
                ],
              );
            }),
            if (lesson.notes.isNotEmpty) ...[
              const SizedBox(height: 20),
              Divider(color: cozy.borderSubtle, height: 1),
              const SizedBox(height: 20),
              const CozySectionHeader(
                title: 'Mẹo nhớ nhanh',
                icon: Icons.lightbulb_outline_rounded,
              ),
              const SizedBox(height: 10),
              ...lesson.notes.map((note) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 3, right: 8),
                        child: Icon(
                          Icons.check_circle_outline_rounded,
                          size: 16,
                          color: cozy.secondary,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          note,
                          style: TextStyle(
                            fontSize: 14.5,
                            height: 1.65,
                            color: cozy.textPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ],
        ),
      ),
    );
  }
}
