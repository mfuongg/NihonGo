import 'package:flutter/material.dart';
import '../../data/vocabulary_data.dart';
import '../../data/kanji_data.dart';
import '../../models/vocabulary.dart';
import '../../models/kanji.dart';
import '../../services/local_database_service.dart';
import '../../theme/cozy_palette.dart';
import '../../widgets/cozy_common_widgets.dart';

class DictionaryScreen extends StatefulWidget {
  final bool allowBack;

  const DictionaryScreen({super.key, this.allowBack = true});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  List<VocabularyWord> _vocabResults = [];
  List<KanjiItem> _kanjiResults = [];
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    if (VocabularyData.getAllWords().isEmpty ||
        KanjiData.getAllKanji().isEmpty) {
      LocalDatabaseService.instance
          .ensureVerifiedDatasetImportedAndLoaded()
          .then((_) {
        if (mounted && _query.isNotEmpty) _search(_query);
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _search(String query) {
    setState(() {
      _query = query;
      if (query.isEmpty) {
        _vocabResults = [];
        _kanjiResults = [];
      } else {
        _vocabResults = VocabularyData.search(query);
        _kanjiResults = KanjiData.search(query);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return CozyScaffold(
      appBar: CozyAppBar(
        title: 'Từ điển Nhật – Việt',
        subtitle: 'Tra cứu nhanh Từ vựng & Kanji JLPT',
        allowBack: widget.allowBack,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(54),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Container(
              height: 40,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: cozy.surface,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: cozy.borderSubtle),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: cozy.primary,
                  borderRadius: BorderRadius.circular(999),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: cozy.onPrimary,
                unselectedLabelColor: cozy.textSecondary,
                labelStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
                unselectedLabelStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
                tabs: [
                  Tab(
                    text:
                        'Từ vựng ${_vocabResults.isNotEmpty ? "(${_vocabResults.length})" : ""}',
                  ),
                  Tab(
                    text:
                        'Kanji ${_kanjiResults.isNotEmpty ? "(${_kanjiResults.length})" : ""}',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _searchController,
              onChanged: _search,
              style: TextStyle(color: cozy.textPrimary),
              decoration: InputDecoration(
                hintText: '日本語、romaji, tiếng Việt...',
                hintStyle: TextStyle(color: cozy.textSecondary),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: cozy.textSecondary,
                ),
                suffixIcon: _query.isNotEmpty
                    ? IconButton(
                        icon: Icon(
                          Icons.clear_rounded,
                          color: cozy.textSecondary,
                        ),
                        onPressed: () {
                          _searchController.clear();
                          _search('');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: cozy.borderSubtle),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: cozy.borderSubtle),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: cozy.primary, width: 1.4),
                ),
                filled: true,
                fillColor: cozy.surface,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
            ),
          ),
          Divider(color: cozy.borderSubtle, height: 1),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _query.isEmpty
                    ? const _EmptyDictState()
                    : _vocabResults.isEmpty
                        ? Center(
                            child: Text(
                              'Không tìm thấy từ vựng',
                              style: TextStyle(
                                color: cozy.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                            itemCount: _vocabResults.length,
                            separatorBuilder: (_, __) => Divider(
                              color: cozy.borderSubtle,
                              height: 1,
                            ),
                            itemBuilder: (context, index) {
                              return _DictVocabRow(word: _vocabResults[index]);
                            },
                          ),
                _query.isEmpty
                    ? const _EmptyDictState()
                    : _kanjiResults.isEmpty
                        ? Center(
                            child: Text(
                              'Không tìm thấy kanji',
                              style: TextStyle(
                                color: cozy.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                            itemCount: _kanjiResults.length,
                            separatorBuilder: (_, __) => Divider(
                              color: cozy.borderSubtle,
                              height: 1,
                            ),
                            itemBuilder: (context, index) {
                              return _DictKanjiRow(kanji: _kanjiResults[index]);
                            },
                          ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyDictState extends StatelessWidget {
  const _EmptyDictState();

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(
                color: cozy.surface,
                shape: BoxShape.circle,
                border: Border.all(color: cozy.borderSubtle),
              ),
              child: Icon(
                Icons.search_rounded,
                size: 32,
                color: cozy.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Nhập từ khóa để tìm kiếm',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: cozy.textPrimary,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Hỗ trợ tìm kiếm bằng:\n日本語 • Hiragana • Romaji • Tiếng Việt',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: cozy.textSecondary,
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DictVocabRow extends StatelessWidget {
  final VocabularyWord word;
  const _DictVocabRow({required this.word});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            constraints: const BoxConstraints(minWidth: 64),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: cozy.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cozy.borderSubtle),
            ),
            child: Text(
              word.japanese,
              style: TextStyle(
                fontSize: word.japanese.length > 3 ? 15 : 19,
                fontWeight: FontWeight.w800,
                color: cozy.primary,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      word.hiragana,
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        color: cozy.textSecondary,
                      ),
                    ),
                    if (word.romaji.isNotEmpty)
                      Text(
                        '(${word.romaji})',
                        style: TextStyle(
                          fontSize: 12,
                          color: cozy.textSecondary,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  word.displayMeaning(language: 'vi'),
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: cozy.textPrimary,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  word.displayMeaning(language: 'en'),
                  style: TextStyle(
                    fontSize: 12.5,
                    color: cozy.textSecondary,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: cozy.primary.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              word.jlptLevel,
              style: TextStyle(
                color: cozy.primary,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DictKanjiRow extends StatelessWidget {
  final KanjiItem kanji;
  const _DictKanjiRow({required this.kanji});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: cozy.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: cozy.borderSubtle),
            ),
            child: Center(
              child: Text(
                kanji.kanji,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: cozy.primary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  kanji.displayMeaning(language: 'vi'),
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: cozy.textPrimary,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'On: ${kanji.onyomi.isEmpty ? "-" : kanji.onyomi}  •  Kun: ${kanji.kunyomi.isEmpty ? "-" : kanji.kunyomi}',
                  style: TextStyle(
                    fontSize: 12.5,
                    color: cozy.textSecondary,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  kanji.displayMeaning(language: 'en'),
                  style: TextStyle(
                    fontSize: 12.5,
                    color: cozy.textSecondary,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: cozy.primary.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  kanji.jlptLevel,
                  style: TextStyle(
                    color: cozy.primary,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${kanji.strokeCount} nét',
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color: cozy.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
