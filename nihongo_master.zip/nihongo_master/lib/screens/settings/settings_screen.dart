import 'package:flutter/material.dart';

import '../profile/profile_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ProfileScreen(initialTabIndex: 1);
  }
}
