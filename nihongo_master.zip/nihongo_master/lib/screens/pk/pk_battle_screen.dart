import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import 'package:provider/provider.dart';

import '../../providers/progress_provider.dart';
import '../../widgets/app_asset_icon.dart';
import 'pk_models.dart';
import 'pk_result_screen.dart';

enum _BattlePhase {
  playerQuestion,
  playerDraw,
  resolvingCard,
  botTurn,
  finished,
}

class PKBattleScreen extends StatefulWidget {
  final PkGameMode mode;
  final String jlptLevel;

  const PKBattleScreen({
    super.key,
    required this.mode,
    required this.jlptLevel,
  });

  @override
  State<PKBattleScreen> createState() => _PKBattleScreenState();
}

class _PKBattleScreenState extends State<PKBattleScreen> {
  final Random _rng = Random();

  late List<PkCardSlot> _cards;
  late List<PkQuestion> _questionPool;
  int _questionCursor = 0;

  _BattlePhase _phase = _BattlePhase.playerQuestion;
  int _turnNumber = 1;
  int _playerShield = 0;
  int _botShield = 0;
  int _questionsAsked = 0;
  int _questionsCorrect = 0;
  int _shieldsUsed = 0;

  int _secondsLeft = 15;
  Timer? _questionTimer;

  int? _selectedOptionIndex;
  bool _questionAnswered = false;
  String _statusBannerText =
      'Trả lời đúng câu hỏi trong 15s để nhận 1 Khiên Bảo Hộ 🛡️!';
  Color _statusBannerColor = const Color(0xFF6366F1);

  int? _animatingCardIndex;
  bool _showShieldDefuseBanner = false;
  bool _showExplosionBanner = false;

  final List<PkReviewedQuestion> _reviewedQuestions = <PkReviewedQuestion>[];

  @override
  void initState() {
    super.initState();
    _initMatch();
  }

  @override
  void dispose() {
    _questionTimer?.cancel();
    super.dispose();
  }

  void _initMatch() {
    _questionPool = PkQuestionBankService.buildQuestionPool(
      widget.jlptLevel,
      random: _rng,
      deterministicSolo: widget.mode == PkGameMode.solo,
    );
    _questionCursor = 0;

    // Build 16 cards: 14 Safe + 2 Exploding Cats
    final explodingIndices = <int>{};
    if (widget.mode == PkGameMode.solo) {
      // Deterministic initial layout for Solo practice so Slot #1 (idx 0) is Safe
      // and Slot #2 (idx 1) is Exploding Cat, plus a second Exploding Cat at idx 9.
      explodingIndices.addAll(const [1, 9]);
    } else {
      while (explodingIndices.length < 2) {
        explodingIndices.add(_rng.nextInt(16));
      }
    }

    _cards = List<PkCardSlot>.generate(
      16,
      (index) => PkCardSlot(
        index: index,
        isExploding: explodingIndices.contains(index),
      ),
    );

    _startPlayerQuestionTurn();
  }

  PkQuestion get _currentQuestion {
    if (_questionPool.isEmpty) {
      _questionPool = PkQuestionBankService.buildQuestionPool('N5');
    }
    return _questionPool[_questionCursor % _questionPool.length];
  }

  void _startPlayerQuestionTurn() {
    _questionTimer?.cancel();
    if (!mounted) return;
    setState(() {
      _phase = _BattlePhase.playerQuestion;
      _selectedOptionIndex = null;
      _questionAnswered = false;
      _secondsLeft = 15;
      _statusBannerText =
          'Lượt $_turnNumber của bạn: Trả lời câu hỏi 15s để lấy Khiên Bảo Hộ!';
      _statusBannerColor = const Color(0xFF4F46E5);
    });

    _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _phase != _BattlePhase.playerQuestion) {
        timer.cancel();
        return;
      }
      if (_secondsLeft <= 1) {
        timer.cancel();
        _handleAnswerSelected(-1);
      } else {
        setState(() {
          _secondsLeft--;
        });
      }
    });
  }

  void _handleAnswerSelected(int optionIndex) {
    if (_questionAnswered || _phase != _BattlePhase.playerQuestion) return;
    _questionTimer?.cancel();

    final q = _currentQuestion;
    final isCorrect = optionIndex == q.correctIndex;

    _questionsAsked++;
    if (isCorrect) {
      _questionsCorrect++;
    }
    _reviewedQuestions.add(
      PkReviewedQuestion(
        question: q,
        selectedIndex: optionIndex,
        isCorrect: isCorrect,
      ),
    );

    final gainedShield = isCorrect && _playerShield < 1;
    if (isCorrect) {
      _playerShield = 1;
    }

    setState(() {
      _selectedOptionIndex = optionIndex;
      _questionAnswered = true;
      _phase = _BattlePhase.playerDraw;
      if (isCorrect) {
        _statusBannerText = gainedShield
            ? '✓ Chính xác! Bạn nhận +1 Khiên Bảo Hộ (1/1). Hãy chọn lật 1 lá bài trên bàn 4x4!'
            : '✓ Chính xác! Khiên Bảo Hộ đã đầy (1/1). Hãy chọn lật 1 lá bài trên bàn 4x4!';
        _statusBannerColor = const Color(0xFF15803D);
      } else if (optionIndex == -1) {
        _statusBannerText =
            '⏰ Hết 15 giây! Không nhận được Khiên. Hãy cẩn thận lật 1 lá bài trên bàn 4x4!';
        _statusBannerColor = const Color(0xFFD97706);
      } else {
        _statusBannerText =
            '✗ Chưa chính xác! Không nhận được Khiên. Hãy lật 1 lá bài trên bàn 4x4!';
        _statusBannerColor = const Color(0xFFDC2626);
      }
    });
  }

  Future<void> _handlePlayerCardTap(int cardIndex) async {
    if (_phase != _BattlePhase.playerDraw) return;
    final slot = _cards[cardIndex];
    if (slot.isRevealed) return;

    setState(() {
      _phase = _BattlePhase.resolvingCard;
      _animatingCardIndex = cardIndex;
      slot.isRevealed = true;
      slot.revealedByPlayer = true;
    });

    await Future<void>.delayed(const Duration(milliseconds: 420));
    if (!mounted) return;

    if (!slot.isExploding) {
      // Safe Cat!
      setState(() {
        _statusBannerText =
            '🐾 An toàn! Bạn vừa lật được Mèo An Toàn. Chuyển lượt sang ${widget.mode.defaultOpponentName}...';
        _statusBannerColor = const Color(0xFF0D9488);
      });
      await Future<void>.delayed(const Duration(milliseconds: 550));
      if (!mounted) return;
      _questionCursor++;
      await _runBotTurn();
      return;
    }

    // Exploding Cat!
    if (_playerShield > 0) {
      // Shield blocks the explosion and reshuffles the Exploding Cat back into face-down cards
      setState(() {
        _playerShield = 0;
        _shieldsUsed++;
        slot.defusedCount++;
        _showShieldDefuseBanner = true;
        _statusBannerText =
            '🛡️ KHIÊN BẢO HỘ ĐỠ ĐÒN! Đã chặn Mèo Nổ và xáo lại lá Mèo Nổ vào bàn cờ!';
        _statusBannerColor = const Color(0xFF0284C7);
      });

      await Future<void>.delayed(const Duration(milliseconds: 850));
      if (!mounted) return;

      _reshuffleExplodingCard(slot);

      setState(() {
        _showShieldDefuseBanner = false;
      });

      _questionCursor++;
      await _runBotTurn();
    } else {
      // Player has no shield -> Eliminated!
      setState(() {
        _showExplosionBanner = true;
        _statusBannerText =
            '💥 BÙM! Bạn lật trúng Mèo Nổ khi không có Khiên Bảo Hộ!';
        _statusBannerColor = const Color(0xFFBE123C);
      });

      await Future<void>.delayed(const Duration(milliseconds: 850));
      if (!mounted) return;

      await _finishMatch(
        isWin: false,
        quitEarly: false,
        reasonText:
            'Bạn đã lật trúng lá Mèo Nổ 💥 ở lượt $_turnNumber khi không có Khiên Bảo Hộ (0/1).',
      );
    }
  }

  void _reshuffleExplodingCard(PkCardSlot defusedSlot) {
    // Flip the defused slot back face-down and move its exploding state to one of the unrevealed slots
    defusedSlot.isRevealed = false;
    defusedSlot.isExploding = false;

    final candidateSlots = _cards
        .where((c) => !c.isRevealed && !c.isExploding)
        .toList();

    if (candidateSlots.isEmpty) {
      defusedSlot.isExploding = true;
      return;
    }

    // Prefer moving it to another face-down slot if available
    final otherSlots =
        candidateSlots.where((c) => c.index != defusedSlot.index).toList();
    final target = otherSlots.isNotEmpty
        ? otherSlots[_rng.nextInt(otherSlots.length)]
        : candidateSlots.first;
    target.isExploding = true;
  }

  Future<void> _runBotTurn() async {
    if (!mounted) return;

    final unrevealed = _cards.where((c) => !c.isRevealed).toList();
    if (unrevealed.isEmpty) {
      await _finishMatch(
        isWin: true,
        quitEarly: false,
        reasonText: 'Bạn đã sống sót qua toàn bộ bàn cờ 16 lá!',
      );
      return;
    }

    setState(() {
      _phase = _BattlePhase.botTurn;
      _statusBannerText =
          '🤖 Lượt của ${widget.mode.defaultOpponentName}: Đang trả lời câu hỏi 15s...';
      _statusBannerColor = const Color(0xFF7C3AED);
    });

    await Future<void>.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    // In Solo AI mode, after the player has demonstrated blocking an Exploding Cat with a Shield,
    // let the Bot miss its shield and draw an Exploding Cat so the match finishes cleanly!
    final forceBotExplodeForSoloDemo =
        widget.mode == PkGameMode.solo && _shieldsUsed >= 1;

    final botAnsweredRight = forceBotExplodeForSoloDemo
        ? false
        : (_rng.nextDouble() < widget.mode.botAnswerAccuracy);

    if (botAnsweredRight && _botShield < 1) {
      _botShield = 1;
    } else if (forceBotExplodeForSoloDemo) {
      _botShield = 0;
    }

    setState(() {
      _statusBannerText = botAnsweredRight
          ? '🤖 ${widget.mode.defaultOpponentName} trả lời đúng (+1 Khiên 🛡️) và đang chọn lật bài...'
          : '🤖 ${widget.mode.defaultOpponentName} trả lời sai (0 Khiên) và đang chọn lật bài...';
    });

    await Future<void>.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    PkCardSlot chosenSlot;
    if (forceBotExplodeForSoloDemo) {
      final explodingUnrevealed =
          unrevealed.where((c) => c.isExploding).toList();
      chosenSlot = explodingUnrevealed.isNotEmpty
          ? explodingUnrevealed.first
          : unrevealed.first;
    } else if (widget.mode == PkGameMode.solo && _shieldsUsed == 0) {
      // On Turn 1 in Solo mode, Bot picks a Safe card (keeping slot #2 exploding for player to test shield)
      final safeUnrevealed = unrevealed
          .where((c) => !c.isExploding && c.index != 1)
          .toList();
      chosenSlot = safeUnrevealed.isNotEmpty
          ? safeUnrevealed.first
          : unrevealed.first;
    } else {
      chosenSlot = unrevealed[_rng.nextInt(unrevealed.length)];
    }

    setState(() {
      _animatingCardIndex = chosenSlot.index;
      chosenSlot.isRevealed = true;
      chosenSlot.revealedByPlayer = false;
    });

    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (!mounted) return;

    if (!chosenSlot.isExploding) {
      setState(() {
        _turnNumber++;
        _statusBannerText =
            '🤖 ${widget.mode.defaultOpponentName} lật trúng Mèo An Toàn (Lá #${chosenSlot.index + 1}). Tới lượt bạn!';
      });
      await Future<void>.delayed(const Duration(milliseconds: 450));
      if (!mounted) return;
      _startPlayerQuestionTurn();
      return;
    }

    // Bot hit Exploding Cat!
    if (_botShield > 0) {
      setState(() {
        _botShield = 0;
        chosenSlot.defusedCount++;
        _statusBannerText =
            '🛡️ ${widget.mode.defaultOpponentName} lật trúng Mèo Nổ nhưng đã dùng Khiên đỡ và xáo lại bài!';
        _statusBannerColor = const Color(0xFFD97706);
      });
      await Future<void>.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;

      _reshuffleExplodingCard(chosenSlot);
      _turnNumber++;
      _startPlayerQuestionTurn();
    } else {
      setState(() {
        _showExplosionBanner = true;
        _statusBannerText =
            '💥 BÙM! ${widget.mode.defaultOpponentName} lật trúng Mèo Nổ khi không có Khiên! Bạn CHIẾN THẮNG!';
        _statusBannerColor = const Color(0xFF15803D);
      });

      await Future<void>.delayed(const Duration(milliseconds: 800));
      if (!mounted) return;

      await _finishMatch(
        isWin: true,
        quitEarly: false,
        reasonText:
            'Đối thủ ${widget.mode.defaultOpponentName} đã lật trúng Mèo Nổ 💥 ở lá #${chosenSlot.index + 1} khi không có Khiên Bảo Hộ!',
      );
    }
  }

  Future<void> _finishMatch({
    required bool isWin,
    required bool quitEarly,
    required String reasonText,
  }) async {
    _questionTimer?.cancel();
    if (_phase == _BattlePhase.finished) return;
    _phase = _BattlePhase.finished;

    final progressProvider = context.read<ProgressProvider>();
    final mrDelta = await progressProvider.recordPkMatchResult(
      mode: widget.mode.name,
      isWin: isWin,
      quitEarly: quitEarly,
    );

    if (!mounted) return;
    final progress = progressProvider.userProgress;

    final result = PkMatchResult(
      isWin: isWin,
      quitEarly: quitEarly,
      mode: widget.mode,
      jlptLevel: widget.jlptLevel,
      opponentName: widget.mode.defaultOpponentName,
      turns: _turnNumber,
      questionsAsked: _questionsAsked,
      questionsCorrect: _questionsCorrect,
      shieldsUsed: _shieldsUsed,
      mrDelta: mrDelta,
      newMr: progress.pkRating,
      newRankTitle: progress.pkRankTitle,
      reasonText: reasonText,
      reviewedQuestions: List<PkReviewedQuestion>.unmodifiable(
        _reviewedQuestions,
      ),
    );

    await Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => PKResultScreen(result: result),
      ),
    );
  }

  Future<void> _confirmExitMatch() async {
    final shouldQuit = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        title: Row(
          children: [
            AppAssetIcon(AppIcons.bomb, size: 26),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Cảnh báo thoát trận PK',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          'Nếu bạn rời bàn đấu ngay bây giờ, hệ thống sẽ xử thua và trừ -15 MR điểm xếp hạng.\n\nBạn có chắc chắn muốn thoát trận không?',
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 13.5,
            height: 1.45,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(
              'Ở lại đấu tiếp',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          ElevatedButton(
            key: const ValueKey('pk_confirm_quit_btn'),
            onPressed: () => Navigator.of(ctx).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE11D48),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: const Text(
              'Thoát trận (-15 MR)',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );

    if (shouldQuit == true && mounted) {
      await _finishMatch(
        isWin: false,
        quitEarly: true,
        reasonText: 'Bạn đã rời trận đấu sớm và bị phạt -15 MR.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final remainingCards = _cards.where((c) => !c.isRevealed).length;
    final remainingBombs =
        _cards.where((c) => !c.isRevealed && c.isExploding).length;
    final q = _currentQuestion;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _confirmExitMatch();
        }
      },
      child: Scaffold(
        backgroundColor: AppTheme.background,
        body: SafeArea(
          child: Column(
            children: [
              // ZONE 1: Top Opponent Bar + Exit Button
              _buildOpponentTopBar(remainingCards, remainingBombs),

              // Status Banner & Shield Defuse / Explosion FX Alert
              _buildStatusBanner(),

              // Main Scrollable / Responsive Arena: Question Zone (Top Half) + 4x4 Card Grid (Bottom Half)
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
                  child: Column(
                    children: [
                      // ZONE 2: Upper Half — 15s Japanese Question Card
                      _buildQuestionZone(q),
                      const SizedBox(height: 10),

                      // ZONE 3: Lower Half — 16-Card 4x4 3D Flip Grid
                      _buildCardBoardSection(remainingCards, remainingBombs),
                    ],
                  ),
                ),
              ),

              // ZONE 4: Bottom Player Bar with Shield Status (🛡️ 0/1 or 🛡️ 1/1)
              _buildPlayerBottomBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOpponentTopBar(int remainingCards, int remainingBombs) {
    final isBotTurn = _phase == _BattlePhase.botTurn;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          bottom: BorderSide(color: AppTheme.borderSubtle),
        ),
      ),
      child: Row(
        children: [
          InkWell(
            key: const ValueKey('pk_battle_exit_btn'),
            onTap: _confirmExitMatch,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF1F2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFECDD3)),
              ),
              child: const Icon(
                Icons.close_rounded,
                size: 18,
                color: Color(0xFFBE123C),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFFF3E8FF),
              shape: BoxShape.circle,
              border: Border.all(
                color: isBotTurn
                    ? const Color(0xFF7C3AED)
                    : const Color(0xFFD8B4FE),
                width: 2,
              ),
            ),
            padding: const EdgeInsets.all(4),
            child: const AppAssetIcon(AppAssets.kawaiiCatAvatar, size: 28),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        widget.mode.defaultOpponentName,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: isBotTurn
                            ? const Color(0xFFEDE9FE)
                            : const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        isBotTurn ? 'Đang rút bài...' : 'Chờ lượt',
                        style: TextStyle(
                          color: isBotTurn
                              ? const Color(0xFF6D28D9)
                              : const Color(0xFF64748B),
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  '${widget.mode.defaultOpponentTitle} • Cấp ${widget.jlptLevel}',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // Opponent Shield indicator
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _botShield > 0
                  ? const Color(0xFFE0F2FE)
                  : const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _botShield > 0
                    ? const Color(0xFF7DD3FC)
                    : const Color(0xFFE2E8F0),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const AppAssetIcon(AppAssets.badgeShieldCat, size: 18),
                const SizedBox(width: 4),
                Text(
                  '🛡️ $_botShield/1',
                  style: TextStyle(
                    color: _botShield > 0
                        ? const Color(0xFF0369A1)
                        : const Color(0xFF64748B),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBanner() {
    final showShieldCatIcon = _showShieldDefuseBanner ||
        (_phase == _BattlePhase.playerDraw && _playerShield > 0);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      color: _statusBannerColor.withValues(alpha: 0.12),
      child: Row(
        children: [
          if (showShieldCatIcon) ...[
            const AppAssetIcon(
              AppAssets.badgeShieldCat,
              size: 24,
            ),
            const SizedBox(width: 8),
          ] else if (_showExplosionBanner) ...[
            Image.asset(
              AppAssets.pkExplosionFx,
              width: 24,
              height: 24,
              errorBuilder: (_, __, ___) =>
                  const AppAssetIcon(AppIcons.bomb, size: 20),
            ),
            const SizedBox(width: 8),
          ] else ...[
            Icon(
              _phase == _BattlePhase.playerDraw
                  ? Icons.touch_app_rounded
                  : Icons.bolt_rounded,
              size: 17,
              color: _statusBannerColor,
            ),
            const SizedBox(width: 6),
          ],
          Expanded(
            child: Text(
              _statusBannerText,
              key: const ValueKey('pk_battle_status_banner'),
              style: TextStyle(
                color: _statusBannerColor,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionZone(PkQuestion q) {
    final timerRatio = (_secondsLeft / 15.0).clamp(0.0, 1.0);
    final isUrgent = _secondsLeft <= 5 && !_questionAnswered;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _phase == _BattlePhase.playerQuestion
              ? const Color(0xFFC7D2FE)
              : AppTheme.borderSubtle,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Row: Category + 15s Countdown Timer
          Row(
            children: [
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEF2FF),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '${q.category} • Thử thách lấy Khiên 🛡️',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF4338CA),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: isUrgent
                      ? const Color(0xFFFEE2E2)
                      : const Color(0xFFFFF7ED),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const AppAssetIcon(AppIcons.timer, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      '${_secondsLeft}s',
                      key: const ValueKey('pk_question_timer_text'),
                      style: TextStyle(
                        color: isUrgent
                            ? const Color(0xFFDC2626)
                            : const Color(0xFFC2410C),
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: timerRatio,
              minHeight: 5,
              backgroundColor: const Color(0xFFF1F5F9),
              color: isUrgent
                  ? const Color(0xFFEF4444)
                  : const Color(0xFF6366F1),
            ),
          ),
          const SizedBox(height: 8),

          // Prompt & Japanese Word
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      q.prompt,
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      q.word,
                      key: const ValueKey('pk_question_word'),
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              if (widget.mode == PkGameMode.solo && !_questionAnswered)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0FDF4),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFFBBF7D0)),
                  ),
                  child: Text(
                    'Gợi ý Solo: Đáp án ${String.fromCharCode(65 + q.correctIndex)}',
                    style: const TextStyle(
                      color: Color(0xFF15803D),
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),

          // 4 Answer Options Grid (2x2 compact for zero overflow and fast tapping)
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: q.options.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 7,
              crossAxisSpacing: 8,
              childAspectRatio: 3.1,
            ),
            itemBuilder: (context, idx) {
              final letter = String.fromCharCode(65 + idx);
              final isCorrectOpt = idx == q.correctIndex;
              final isSelectedOpt = _selectedOptionIndex == idx;

              Color bgColor = AppTheme.surfaceSoft;
              Color borderColor = AppTheme.borderSubtle;
              Color textColor = AppTheme.textPrimary;

              if (_questionAnswered) {
                if (isCorrectOpt) {
                  bgColor = const Color(0xFFDCFCE7);
                  borderColor = const Color(0xFF22C55E);
                  textColor = const Color(0xFF14532D);
                } else if (isSelectedOpt) {
                  bgColor = const Color(0xFFFEE2E2);
                  borderColor = const Color(0xFFEF4444);
                  textColor = const Color(0xFF7F1D1D);
                }
              }

              return Semantics(
                button: true,
                label: isCorrectOpt
                    ? 'Đáp án $letter (Đúng): ${q.options[idx]}'
                    : 'Đáp án $letter: ${q.options[idx]}',
                child: InkWell(
                  key: ValueKey(
                    isCorrectOpt
                        ? 'pk_option_correct'
                        : 'pk_option_$idx',
                  ),
                  onTap: _questionAnswered
                      ? null
                      : () => _handleAnswerSelected(idx),
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: bgColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderColor, width: 1.4),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppTheme.surface,
                            shape: BoxShape.circle,
                            border: Border.all(color: borderColor),
                          ),
                          child: Text(
                            letter,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: Text(
                            q.options[idx],
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),

          if (_questionAnswered) ...[
            const SizedBox(height: 7),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Text(
                '💡 ${q.explanation}',
                style: const TextStyle(
                  color: Color(0xFF475569),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCardBoardSection(int remainingCards, int remainingBombs) {
    final canDraw = _phase == _BattlePhase.playerDraw;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: canDraw ? const Color(0xFFF59E0B) : AppTheme.borderSubtle,
          width: canDraw ? 1.8 : 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              const AppAssetIcon(AppIcons.cards, size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Bàn đấu 16 lá (4×4) • Lượt $_turnNumber',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1F2),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  'Còn $remainingCards lá • 💣 $remainingBombs Mèo Nổ',
                  style: const TextStyle(
                    color: Color(0xFFBE123C),
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // 4x4 Grid of 16 Cards with 3D Flip Animation
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _cards.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 0.82,
            ),
            itemBuilder: (context, index) {
              final slot = _cards[index];
              return _FlipCardTile(
                key: ValueKey('pk_card_slot_$index'),
                slot: slot,
                canTap: canDraw && !slot.isRevealed,
                isAnimating: _animatingCardIndex == index,
                showSoloHint: widget.mode == PkGameMode.solo && !slot.isRevealed,
                onTap: () => _handlePlayerCardTap(index),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerBottomBar() {
    final progress = context.watch<ProgressProvider>().userProgress;
    final hasShield = _playerShield > 0;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          top: BorderSide(color: AppTheme.borderSubtle),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.primarySoft,
              shape: BoxShape.circle,
              border: Border.all(
                color: AppTheme.primary,
                width: 2,
              ),
            ),
            padding: const EdgeInsets.all(4),
            child: const AppAssetIcon(AppAssets.catHeroIdle, size: 28),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppAssetIcon(progress.pkRankIcon, size: 17),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        'Bạn (${progress.pkRankTitle})',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  _phase == _BattlePhase.playerDraw
                      ? '👉 Chạm vào 1 lá bài úp trên bàn 4x4 để lật!'
                      : _phase == _BattlePhase.playerQuestion
                          ? '⚡ Hãy chọn đáp án đúng phía trên'
                          : '⏳ Đang xử lý lượt đấu...',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // Player Shield Status Badge (🛡️ 0/1 or 🛡️ 1/1) với badge_shield_cat.png
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            key: const ValueKey('pk_player_shield_badge'),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: hasShield
                  ? const Color(0xFFDCFCE7)
                  : const Color(0xFFF1F5F9),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: hasShield
                    ? const Color(0xFF22C55E)
                    : const Color(0xFFCBD5E1),
                width: 1.5,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const AppAssetIcon(
                  AppAssets.badgeShieldCat,
                  size: 22,
                ),
                const SizedBox(width: 6),
                Text(
                  'Khiên 🛡️ $_playerShield/1',
                  style: TextStyle(
                    color: hasShield
                        ? const Color(0xFF15803D)
                        : const Color(0xFF475569),
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FlipCardTile extends StatelessWidget {
  final PkCardSlot slot;
  final bool canTap;
  final bool isAnimating;
  final bool showSoloHint;
  final VoidCallback onTap;

  const _FlipCardTile({
    super.key,
    required this.slot,
    required this.canTap,
    required this.isAnimating,
    required this.showSoloHint,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final targetAngle = slot.isRevealed ? pi : 0.0;

    return Semantics(
      button: true,
      label: slot.isRevealed
          ? (slot.isExploding
              ? 'Lá #${slot.index + 1} Đã mở: Mèo Nổ'
              : 'Lá #${slot.index + 1} Đã mở: An Toàn')
          : 'Lá bài úp #${slot.index + 1}',
      child: GestureDetector(
        onTap: canTap ? onTap : null,
        child: TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.0, end: targetAngle),
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeInOutBack,
          builder: (context, angle, _) {
            final isShowingFront = angle >= (pi / 2);
            final transform = Matrix4.identity()
              ..setEntry(3, 2, 0.0012)
              ..rotateY(angle);

            return Transform(
              alignment: Alignment.center,
              transform: transform,
              child: isShowingFront
                  ? Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.identity()..rotateY(pi),
                      child: _buildRevealedFace(),
                    )
                  : _buildCardBackFace(),
            );
          },
        ),
      ),
    );
  }

  Widget _buildCardBackFace() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: canTap ? const Color(0xFFF59E0B) : AppTheme.borderSubtle,
          width: canTap ? 1.8 : 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: canTap
                ? const Color(0xFFF59E0B).withValues(alpha: 0.18)
                : Colors.black.withValues(alpha: 0.05),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              AppAssets.cardBackDeck,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFF312E81),
                alignment: Alignment.center,
                child: const AppAssetIcon(AppIcons.cards, size: 28),
              ),
            ),
            Positioned(
              top: 4,
              left: 5,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.55),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '#${slot.index + 1}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            if (slot.defusedCount > 0)
              Positioned(
                bottom: 4,
                right: 4,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0284C7),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'Đã xáo 🛡️',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRevealedFace() {
    final isBomb = slot.isExploding;
    final asset =
        isBomb ? AppAssets.cardExplodingCat : AppAssets.cardSafeCat;

    return Container(
      decoration: BoxDecoration(
        color: isBomb ? const Color(0xFFFFF1F2) : const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isBomb ? const Color(0xFFEF4444) : const Color(0xFF22C55E),
          width: 2,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              asset,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Center(
                child: AppAssetIcon(
                  isBomb ? AppIcons.bomb : AppIcons.check,
                  size: 30,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 3),
                color: (isBomb
                        ? const Color(0xFFBE123C)
                        : const Color(0xFF15803D))
                    .withValues(alpha: 0.85),
                child: Text(
                  isBomb ? '💥 MÈO NỔ!' : '🐾 AN TOÀN',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
