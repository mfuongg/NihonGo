import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import 'package:provider/provider.dart';

import '../../providers/progress_provider.dart';
import '../../widgets/app_asset_icon.dart';
import 'pk_battle_screen.dart';
import 'pk_models.dart';

class PKLobbyScreen extends StatefulWidget {
  final String initialLevel;

  const PKLobbyScreen({
    super.key,
    this.initialLevel = 'N5',
  });

  @override
  State<PKLobbyScreen> createState() => _PKLobbyScreenState();
}

class _PKLobbyScreenState extends State<PKLobbyScreen> {
  static const List<String> _levels = <String>['N5', 'N4', 'N3', 'N2', 'N1'];
  late String _selectedLevel;

  @override
  void initState() {
    super.initState();
    _selectedLevel =
        _levels.contains(widget.initialLevel) ? widget.initialLevel : 'N5';
  }

  void _startMode(PkGameMode mode) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PKBattleScreen(
          mode: mode,
          jlptLevel: _selectedLevel,
        ),
      ),
    );
  }

  void _showRulesBottomSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.borderSubtle,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                AppAssetIcon(AppIcons.cards, size: 26),
                SizedBox(width: 10),
                Text(
                  'Luật Chơi Mèo Nổ PK (16 Lá 4×4)',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const _RuleBullet(
              icon: AppIcons.cards,
              title: '1. Bộ bài 16 lá (Lưới 4×4):',
              text:
                  'Gồm 14 lá Mèo An Toàn và 2 lá Mèo Nổ úp ngẫu nhiên trên bàn đấu 4×4.',
            ),
            const _RuleBullet(
              icon: AppIcons.timer,
              title: '2. Câu hỏi tiếng Nhật 15 giây:',
              text:
                  'Đầu mỗi lượt, trả lời 1 câu hỏi tiếng Nhật trong 15s. Trả lời đúng nhận 1 Khiên Bảo Hộ 🛡️ (tối đa tích trữ 1 Khiên).',
            ),
            const _RuleBullet(
              icon: AppAssets.cardShieldProtect,
              title: '3. Cơ chế Khiên đỡ Mèo Nổ & Xáo bài:',
              text:
                  'Khi lật trúng Mèo Nổ: nếu có Khiên (1/1), Khiên sẽ vỡ để cứu bạn sống sót và lá Mèo Nổ được xáo trộn ngẫu nhiên trở lại vào các lá đang úp!',
            ),
            const _RuleBullet(
              icon: AppIcons.trophy,
              title: '4. Điểm Xếp Hạng Match Rating (MR):',
              text:
                  'Chế độ Đấu Hạng: Thắng +20 MR, Thua 0 MR (tân thủ thân thiện), Thoát trận giữa chừng phạt -15 MR.',
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(ctx).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'Đã hiểu luật chơi!',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = context.watch<ProgressProvider>().userProgress;
    final tier = PkRankSystem.tierForMr(progress.pkRating);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.background,
        elevation: 0,
        leading: IconButton(
          key: const ValueKey('pk_lobby_back_btn'),
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(Icons.arrow_back_rounded, color: AppTheme.textPrimary),
          tooltip: 'Quay lại Bảng xếp hạng',
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sảnh Đấu Mèo Nổ PK',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 16.5,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              'Đấu Trí Ngôn Ngữ cùng AI',
              key: const ValueKey('pk_academic_subtitle'),
              style: TextStyle(
                color: AppTheme.primary,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        actions: [
          TextButton.icon(
            onPressed: _showRulesBottomSheet,
            icon: Icon(
              Icons.help_outline_rounded,
              size: 18,
              color: AppTheme.primary,
            ),
            label: Text(
              'Luật chơi',
              style: TextStyle(
                color: AppTheme.primary,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            // 1. User Current PK Rank & MR Strip
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.borderSubtle),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Color(tier.accentColorValue).withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    alignment: Alignment.center,
                    child: AppAssetIcon(tier.iconAsset, size: 28),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          progress.pkRankTitle,
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          'Thắng ${progress.pkWins}/${progress.pkMatches} trận (${progress.pkWinRatePercent}%)',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.primarySoft,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: const Color(0xFFF5CBE2)),
                    ),
                    child: Text(
                      '${progress.pkRating} MR',
                      style: const TextStyle(
                        color: Color(0xFFD97706),
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // 2. Hero Poster Banner (pk_lobby_hero_banner.png) + 4 Rule Summary Badges
            Container(
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppTheme.borderSubtle),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primary.withValues(alpha: 0.12),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset(
                      AppAssets.pkLobbyHeroBanner,
                      height: 176,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        height: 150,
                        color: const Color(0xFF312E81),
                        alignment: Alignment.center,
                        child: const AppAssetIcon(AppIcons.bomb, size: 54),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // 4 Rule Summary Badges: 16 Lá | 2 Mèo Nổ | 15s/Câu | Max 1 Khiên
                  const Row(
                    children: [
                      Expanded(
                        child: _RuleMiniBadge(
                          iconAsset: AppIcons.cards,
                          label: '16 Lá',
                          subLabel: 'Lưới 4×4',
                          color: Color(0xFF6366F1),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: _RuleMiniBadge(
                          iconAsset: AppIcons.bomb,
                          label: '2 Mèo Nổ',
                          subLabel: '14 An Toàn',
                          color: Color(0xFFE11D48),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: _RuleMiniBadge(
                          iconAsset: AppIcons.timer,
                          label: '15s/Câu',
                          subLabel: 'Phản xạ nhanh',
                          color: Color(0xFFD97706),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: _RuleMiniBadge(
                          iconAsset: AppIcons.shield,
                          label: 'Max 1 Khiên',
                          subLabel: 'Đỡ nổ & xáo',
                          color: Color(0xFF0EA5E9),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 3. JLPT Level Selector (N5 - N1)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppTheme.borderSubtle),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      AppAssetIcon(AppIcons.jlptBadge, size: 20),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Chọn cấp độ câu hỏi tiếng Nhật',
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: _levels.map((lvl) {
                      final isSelected = _selectedLevel == lvl;
                      return Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 3),
                          child: InkWell(
                            key: ValueKey('pk_level_chip_$lvl'),
                            onTap: () => setState(() => _selectedLevel = lvl),
                            borderRadius: BorderRadius.circular(14),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppTheme.primary
                                    : AppTheme.surfaceSoft,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: isSelected
                                      ? AppTheme.primary
                                      : AppTheme.borderSubtle,
                                  width: 1.5,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                lvl,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white
                                      : AppTheme.textPrimary,
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 4. 3 Mode Selection Cards
            Padding(
              padding: EdgeInsets.only(left: 4, bottom: 10),
              child: Text(
                'Chọn chế độ thi đấu',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 15.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            _ModeSelectCard(
              cardKey: const ValueKey('pk_mode_solo_card'),
              mode: PkGameMode.solo,
              iconAsset: AppAssets.catHeroIdle,
              accentColor: const Color(0xFF10B981),
              selectedLevel: _selectedLevel,
              onTap: () => _startMode(PkGameMode.solo),
            ),
            const SizedBox(height: 12),
            _ModeSelectCard(
              cardKey: const ValueKey('pk_mode_casual_card'),
              mode: PkGameMode.casual,
              iconAsset: AppIcons.cards,
              accentColor: const Color(0xFF6366F1),
              selectedLevel: _selectedLevel,
              onTap: () => _startMode(PkGameMode.casual),
            ),
            const SizedBox(height: 12),
            _ModeSelectCard(
              cardKey: const ValueKey('pk_mode_ranked_card'),
              mode: PkGameMode.ranked,
              iconAsset: AppIcons.trophy,
              accentColor: const Color(0xFFE11D48),
              selectedLevel: _selectedLevel,
              onTap: () => _startMode(PkGameMode.ranked),
            ),
          ],
        ),
      ),
    );
  }
}

class _RuleMiniBadge extends StatelessWidget {
  final String iconAsset;
  final String label;
  final String subLabel;
  final Color color;

  const _RuleMiniBadge({
    required this.iconAsset,
    required this.label,
    required this.subLabel,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Column(
        children: [
          AppAssetIcon(iconAsset, size: 22),
          const SizedBox(height: 5),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 11.5,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            subLabel,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeSelectCard extends StatelessWidget {
  final Key cardKey;
  final PkGameMode mode;
  final String iconAsset;
  final Color accentColor;
  final String selectedLevel;
  final VoidCallback onTap;

  const _ModeSelectCard({
    required this.cardKey,
    required this.mode,
    required this.iconAsset,
    required this.accentColor,
    required this.selectedLevel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: '${mode.title} ($selectedLevel)',
      child: InkWell(
        key: cardKey,
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: accentColor.withValues(alpha: 0.35),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: accentColor.withValues(alpha: 0.08),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: accentColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                alignment: Alignment.center,
                child: AppAssetIcon(iconAsset, size: 34),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            mode.title,
                            style: TextStyle(
                              color: AppTheme.textPrimary,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      mode.subtitle,
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: accentColor.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            mode.badgeText,
                            style: TextStyle(
                              color: accentColor,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.primarySoft,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'Bộ đề $selectedLevel',
                            style: const TextStyle(
                              color: Color(0xFFD97706),
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: accentColor,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Icon(
                  Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RuleBullet extends StatelessWidget {
  final String icon;
  final String title;
  final String text;

  const _RuleBullet({
    required this.icon,
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppAssetIcon(icon, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  text,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
