import 'package:flutter/material.dart';
import '../../utils/theme.dart';

import '../../widgets/app_asset_icon.dart';
import 'pk_battle_screen.dart';
import 'pk_models.dart';

class PKResultScreen extends StatelessWidget {
  final PkMatchResult result;

  const PKResultScreen({
    super.key,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final isWin = result.isWin;
    final badgeHeroAsset =
        isWin ? AppAssets.badgeTrophyCat : AppAssets.badgeDefeatGhost;
    final bannerHeroAsset =
        isWin ? AppAssets.pkVictoryBanner : AppAssets.pkDefeatBanner;
    final rankTier = PkRankSystem.tierForMr(result.newMr);
    final headerGradient = isWin
        ? const [Color(0xFFFFF8E1), Color(0xFFFFECB3)]
        : const [Color(0xFFF3E8FF), Color(0xFFFCE7F3)];
    final accentColor =
        isWin ? const Color(0xFFD97706) : const Color(0xFF7C3AED);
    final mrSign = result.mrDelta > 0 ? '+${result.mrDelta}' : '${result.mrDelta}';

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.background,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(Icons.arrow_back_rounded, color: AppTheme.textPrimary),
          tooltip: 'Về Sảnh Đấu',
        ),
        title: Text(
          'Kết Quả Trận Đấu PK',
          style: TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 17,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                children: [
                  // 1. Victory / Defeat Hero Card
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: headerGradient,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: accentColor.withValues(alpha: 0.35),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accentColor.withValues(alpha: 0.14),
                          blurRadius: 18,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Stack(
                          alignment: Alignment.topRight,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: Image.asset(
                                bannerHeroAsset,
                                key: ValueKey(
                                  isWin
                                      ? 'pk_result_victory_banner'
                                      : 'pk_result_defeat_banner',
                                ),
                                height: 132,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => SizedBox(
                                  width: 136,
                                  height: 136,
                                  child: Center(
                                    child: AppAssetIcon(
                                      badgeHeroAsset,
                                      size: 112,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              top: 4,
                              right: 4,
                              child: Container(
                                width: 38,
                                height: 38,
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.92),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: accentColor.withValues(alpha: 0.35),
                                  ),
                                ),
                                child: AppAssetIcon(
                                  badgeHeroAsset,
                                  key: ValueKey(
                                    isWin
                                        ? 'pk_result_badge_trophy_cat'
                                        : 'pk_result_badge_defeat_ghost',
                                  ),
                                  size: 26,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.9),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            isWin ? 'CHIẾN THẮNG! 🏆' : 'BỊ LOẠI 💥',
                            style: TextStyle(
                              color: accentColor,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          result.reasonText,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 14),
                        // MR Rating Change Pill
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: AppTheme.borderSubtle,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AppAssetIcon(
                                rankTier.iconAsset,
                                size: 28,
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${result.newRankTitle} • ${result.newMr} MR',
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: AppTheme.textPrimary,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    Text(
                                      'Chế độ: ${result.mode.shortLabel} (${result.jlptLevel})',
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: AppTheme.textSecondary,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: result.mrDelta > 0
                                      ? const Color(0xFFDCFCE7)
                                      : result.mrDelta < 0
                                          ? const Color(0xFFFEE2E2)
                                          : const Color(0xFFF1F5F9),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  '$mrSign MR',
                                  key: const ValueKey('pk_result_mr_delta'),
                                  style: TextStyle(
                                    color: result.mrDelta > 0
                                        ? const Color(0xFF15803D)
                                        : result.mrDelta < 0
                                            ? const Color(0xFFB91C1C)
                                            : const Color(0xFF475569),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 2. Match Statistics 4 Cards
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppTheme.borderSubtle),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            AppAssetIcon(AppIcons.analytics, size: 20),
                            SizedBox(width: 8),
                            Text(
                              'Thống kê trận đấu',
                              style: TextStyle(
                                color: AppTheme.textPrimary,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _StatTile(
                                iconAsset: AppIcons.timer,
                                label: 'Số lượt đấu',
                                value: '${result.turns} lượt',
                                color: const Color(0xFF6366F1),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _StatTile(
                                iconAsset: AppIcons.check,
                                label: 'Trả lời đúng',
                                value:
                                    '${result.questionsCorrect}/${result.questionsAsked} (${result.accuracyPercent}%)',
                                color: const Color(0xFF10B981),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _StatTile(
                                iconAsset: AppAssets.badgeShieldCat,
                                label: 'Khiên đã dùng',
                                value: '${result.shieldsUsed} lần đỡ nổ',
                                color: const Color(0xFF0EA5E9),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _StatTile(
                                iconAsset: AppAssets.badgeTrophyCat,
                                label: 'Điểm Xếp hạng',
                                value: '$mrSign MR',
                                color: const Color(0xFFF59E0B),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 3. Question Review Section
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const AppAssetIcon(AppIcons.book, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Xem lại câu hỏi đã gặp (${result.reviewedQuestions.length})',
                                style: TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (result.reviewedQuestions.isEmpty)
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Text(
                              'Trận đấu kết thúc trước khi có câu hỏi nào được ghi nhận.',
                              style: TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 13,
                              ),
                            ),
                          )
                        else
                          ...result.reviewedQuestions.map(
                            (rev) => _ReviewedQuestionCard(item: rev),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // 4. Bottom Action Buttons: [Chơi tiếp] & [Về Sảnh Đấu]
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                border: Border(
                  top: BorderSide(color: AppTheme.borderSubtle),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 12,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      key: const ValueKey('pk_result_back_lobby_btn'),
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.textPrimary,
                        side: BorderSide(
                          color: AppTheme.borderSubtle,
                          width: 1.5,
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      icon: const Icon(Icons.meeting_room_outlined, size: 19),
                      label: const Text(
                        'Về Sảnh Đấu',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      key: const ValueKey('pk_result_play_again_btn'),
                      onPressed: () {
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (_) => PKBattleScreen(
                              mode: result.mode,
                              jlptLevel: result.jlptLevel,
                            ),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      icon: const Icon(Icons.replay_rounded, size: 19),
                      label: const Text(
                        'Chơi tiếp',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final String iconAsset;
  final String label;
  final String value;
  final Color color;

  const _StatTile({
    required this.iconAsset,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Row(
        children: [
          AppAssetIcon(iconAsset, size: 26),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviewedQuestionCard extends StatelessWidget {
  final PkReviewedQuestion item;

  const _ReviewedQuestionCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final q = item.question;
    final correctText = q.options[q.correctIndex];
    final selectedText =
        item.selectedIndex >= 0 && item.selectedIndex < q.options.length
            ? q.options[item.selectedIndex]
            : 'Hết giờ (15s)';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: item.isCorrect
            ? const Color(0xFFF0FDF4)
            : const Color(0xFFFFF1F2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: item.isCorrect
              ? const Color(0xFFBBF7D0)
              : const Color(0xFFFECDD3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  q.category,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                item.isCorrect ? '✓ Đúng (+1 Khiên)' : '✗ Sai',
                style: TextStyle(
                  color: item.isCorrect
                      ? const Color(0xFF15803D)
                      : const Color(0xFFBE123C),
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            '${q.prompt}  ${q.word}',
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          if (!item.isCorrect)
            Text(
              'Bạn chọn: $selectedText',
              style: const TextStyle(
                color: Color(0xFFBE123C),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          Text(
            'Đáp án đúng: $correctText',
            style: const TextStyle(
              color: Color(0xFF15803D),
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            q.explanation,
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 11.5,
            ),
          ),
        ],
      ),
    );
  }
}
