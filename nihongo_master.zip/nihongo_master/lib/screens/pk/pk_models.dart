import 'dart:math';

import '../../data/grammar_data.dart';
import '../../data/kanji_data.dart';
import '../../data/vocabulary_data.dart';
import '../../widgets/app_asset_icon.dart';

enum PkGameMode {
  solo,
  casual,
  ranked,
}

extension PkGameModeExtension on PkGameMode {
  String get title {
    switch (this) {
      case PkGameMode.solo:
        return 'Solo với Máy (Luyện tập)';
      case PkGameMode.casual:
        return 'PK Thường (Bạn bè)';
      case PkGameMode.ranked:
        return 'Đấu Hạng (Ranked Match)';
    }
  }

  String get shortLabel {
    switch (this) {
      case PkGameMode.solo:
        return 'Solo AI';
      case PkGameMode.casual:
        return 'PK Thường';
      case PkGameMode.ranked:
        return 'Đấu Hạng MR';
    }
  }

  String get subtitle {
    switch (this) {
      case PkGameMode.solo:
        return 'Đấu 1v1 với Mèo Hộ Pháp AI • Luyện phản xạ 15s & làm quen luật Khiên';
      case PkGameMode.casual:
        return 'Ghép phòng nhanh hoặc đấu giao hữu • Giải trí vui vẻ không mất điểm MR';
      case PkGameMode.ranked:
        return 'Tính điểm Match Rating • Leo 8 bậc Rank Mèo Học Thuật';
    }
  }

  String get badgeText {
    switch (this) {
      case PkGameMode.solo:
        return '0 MR • Vào ngay';
      case PkGameMode.casual:
        return '0 MR • Giao hữu';
      case PkGameMode.ranked:
        return '+20 MR Thắng';
    }
  }

  String get defaultOpponentName {
    switch (this) {
      case PkGameMode.solo:
        return 'Mèo Hộ Pháp AI';
      case PkGameMode.casual:
        return 'Haruka_JP';
      case PkGameMode.ranked:
        return 'KuroNeko_N4';
    }
  }

  String get defaultOpponentTitle {
    switch (this) {
      case PkGameMode.solo:
        return 'Bot Huấn Luyện • Phản xạ chuẩn';
      case PkGameMode.casual:
        return 'Mèo Tinh Anh • Giao hữu';
      case PkGameMode.ranked:
        return 'Mèo Tinh Anh • 745 MR';
    }
  }

  double get botAnswerAccuracy {
    switch (this) {
      case PkGameMode.solo:
        return 0.65;
      case PkGameMode.casual:
        return 0.70;
      case PkGameMode.ranked:
        return 0.78;
    }
  }
}

class PkRankTier {
  final int index;
  final String name;
  final int minMr;
  final int? maxMr;
  final String iconAsset;
  final int accentColorValue;

  const PkRankTier({
    required this.index,
    required this.name,
    required this.minMr,
    required this.maxMr,
    required this.iconAsset,
    required this.accentColorValue,
  });

  String get rangeLabel =>
      maxMr == null ? '$minMr+ MR' : '$minMr - $maxMr MR';
}

class PkRankSystem {
  static const List<PkRankTier> tiers = <PkRankTier>[
    PkRankTier(
      index: 1,
      name: 'Mèo Tập Sự',
      minMr: 0,
      maxMr: 199,
      iconAsset: AppAssets.rank01Bronze,
      accentColorValue: 0xFFB4694E,
    ),
    PkRankTier(
      index: 2,
      name: 'Mèo Nhanh Trí',
      minMr: 200,
      maxMr: 399,
      iconAsset: AppAssets.rank02Silver,
      accentColorValue: 0xFF64748B,
    ),
    PkRankTier(
      index: 3,
      name: 'Mèo Phản Xạ',
      minMr: 400,
      maxMr: 649,
      iconAsset: AppAssets.rank03Gold,
      accentColorValue: 0xFFD97706,
    ),
    PkRankTier(
      index: 4,
      name: 'Mèo Tinh Anh',
      minMr: 650,
      maxMr: 899,
      iconAsset: AppAssets.rank04Purple,
      accentColorValue: 0xFF8B5CF6,
    ),
    PkRankTier(
      index: 5,
      name: 'Cao Thủ Mèo Nổ',
      minMr: 900,
      maxMr: 1199,
      iconAsset: AppAssets.rank05Diamond,
      accentColorValue: 0xFF0EA5E9,
    ),
    PkRankTier(
      index: 6,
      name: 'Chiến Thần Học Thuật',
      minMr: 1200,
      maxMr: 1599,
      iconAsset: AppAssets.rank06Master,
      accentColorValue: 0xFFE11D48,
    ),
    PkRankTier(
      index: 7,
      name: 'Đại Sư Ngôn Ngữ',
      minMr: 1600,
      maxMr: 1999,
      iconAsset: AppAssets.rank06Master,
      accentColorValue: 0xFF9333EA,
    ),
    PkRankTier(
      index: 8,
      name: 'Thần Mèo Đại Chiến',
      minMr: 2000,
      maxMr: null,
      iconAsset: AppAssets.rank07Mythic,
      accentColorValue: 0xFF7C3AED,
    ),
  ];

  static PkRankTier tierForMr(int mr) {
    for (var i = tiers.length - 1; i >= 0; i--) {
      if (mr >= tiers[i].minMr) {
        return tiers[i];
      }
    }
    return tiers.first;
  }
}

class PkQuestion {
  final String id;
  final String level;
  final String category;
  final String prompt;
  final String word;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  const PkQuestion({
    required this.id,
    required this.level,
    required this.category,
    required this.prompt,
    required this.word,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });
}

class PkReviewedQuestion {
  final PkQuestion question;
  final int selectedIndex;
  final bool isCorrect;

  const PkReviewedQuestion({
    required this.question,
    required this.selectedIndex,
    required this.isCorrect,
  });
}

class PkCardSlot {
  final int index;
  bool isExploding;
  bool isRevealed;
  bool revealedByPlayer;
  int defusedCount;

  PkCardSlot({
    required this.index,
    required this.isExploding,
    this.isRevealed = false,
    this.revealedByPlayer = true,
    this.defusedCount = 0,
  });
}

class PkMatchResult {
  final bool isWin;
  final bool quitEarly;
  final PkGameMode mode;
  final String jlptLevel;
  final String opponentName;
  final int turns;
  final int questionsAsked;
  final int questionsCorrect;
  final int shieldsUsed;
  final int mrDelta;
  final int newMr;
  final String newRankTitle;
  final String reasonText;
  final List<PkReviewedQuestion> reviewedQuestions;

  const PkMatchResult({
    required this.isWin,
    this.quitEarly = false,
    required this.mode,
    required this.jlptLevel,
    required this.opponentName,
    required this.turns,
    required this.questionsAsked,
    required this.questionsCorrect,
    required this.shieldsUsed,
    required this.mrDelta,
    required this.newMr,
    required this.newRankTitle,
    required this.reasonText,
    required this.reviewedQuestions,
  });

  int get accuracyPercent {
    if (questionsAsked <= 0) return 0;
    return ((questionsCorrect / questionsAsked) * 100).round();
  }
}

class PkQuestionBankService {
  static List<PkQuestion> buildQuestionPool(
    String jlptLevel, {
    int maxCount = 24,
    Random? random,
    bool deterministicSolo = false,
  }) {
    final rng = random ?? Random();
    final normalizedLevel =
        const ['N5', 'N4', 'N3', 'N2', 'N1'].contains(jlptLevel)
            ? jlptLevel
            : 'N5';

    final generated = <PkQuestion>[];

    // If deterministicSolo is enabled, put verified Vietnamese fallback questions first
    // so Solo AI practice always has crystal-clear Vietnamese questions with Option A correct.
    if (deterministicSolo) {
      final fallback = _fallbackQuestionsByLevel[normalizedLevel] ??
          _fallbackQuestionsByLevel['N5']!;
      generated.addAll(fallback);
    }

    // 1. Build questions from SQLite-backed VocabularyData
    final allVocab = VocabularyData.getWordsByLevel(normalizedLevel);
    final viVocab =
        allVocab.where((w) => w.vietnamese.trim().isNotEmpty).toList();
    final vocabList = viVocab.length >= 4 ? viVocab : allVocab;
    if (vocabList.length >= 4) {
      final pool = List.of(vocabList)..shuffle(rng);
      final count = min(12, pool.length);
      for (var i = 0; i < count; i++) {
        final target = pool[i];
        final targetMeaning = target.displayMeaning(language: 'vi').trim();
        if (targetMeaning.isEmpty) continue;

        final distractors = <String>[];
        for (final candidate in pool) {
          if (candidate.id == target.id) continue;
          final meaning = candidate.displayMeaning(language: 'vi').trim();
          if (meaning.isNotEmpty &&
              meaning != targetMeaning &&
              !distractors.contains(meaning)) {
            distractors.add(meaning);
            if (distractors.length == 3) break;
          }
        }
        if (distractors.length < 3) continue;

        final options = <String>[targetMeaning, ...distractors];
        if (!deterministicSolo) {
          options.shuffle(rng);
        }
        final correctIdx = options.indexOf(targetMeaning);
        final reading = target.hiragana.isNotEmpty &&
                target.hiragana != target.japanese
            ? '${target.japanese} (${target.hiragana})'
            : target.japanese;

        generated.add(
          PkQuestion(
            id: 'vocab_${target.id}',
            level: normalizedLevel,
            category: 'Từ vựng $normalizedLevel',
            prompt: 'Chọn nghĩa đúng của từ vựng sau:',
            word: reading,
            options: options,
            correctIndex: correctIdx,
            explanation:
                '$reading có nghĩa là "$targetMeaning" (${target.romaji}).',
          ),
        );
      }
    }

    // 2. Build questions from SQLite-backed KanjiData
    final kanjiList = KanjiData.getKanjiByLevel(normalizedLevel);
    if (kanjiList.length >= 4) {
      final pool = List.of(kanjiList)..shuffle(rng);
      final count = min(6, pool.length);
      for (var i = 0; i < count; i++) {
        final target = pool[i];
        final targetMeaning = target.displayMeaning(language: 'vi').trim();
        if (targetMeaning.isEmpty) continue;

        final distractors = <String>[];
        for (final candidate in pool) {
          if (candidate.id == target.id) continue;
          final meaning = candidate.displayMeaning(language: 'vi').trim();
          if (meaning.isNotEmpty &&
              meaning != targetMeaning &&
              !distractors.contains(meaning)) {
            distractors.add(meaning);
            if (distractors.length == 3) break;
          }
        }
        if (distractors.length < 3) continue;

        final options = <String>[targetMeaning, ...distractors]..shuffle(rng);
        final correctIdx = options.indexOf(targetMeaning);
        final readingInfo = [
          if (target.onyomi.isNotEmpty) 'On: ${target.onyomi}',
          if (target.kunyomi.isNotEmpty) 'Kun: ${target.kunyomi}',
        ].join(' • ');

        generated.add(
          PkQuestion(
            id: 'kanji_${target.id}',
            level: normalizedLevel,
            category: 'Kanji $normalizedLevel',
            prompt: 'Hán tự dưới đây mang ý nghĩa là gì?',
            word: target.kanji,
            options: options,
            correctIndex: correctIdx,
            explanation:
                'Kanji ${target.kanji} nghĩa là "$targetMeaning"${readingInfo.isNotEmpty ? ' ($readingInfo)' : ''}.',
          ),
        );
      }
    }

    // 3. Build questions from SQLite-backed GrammarData
    final grammarList = GrammarData.getLessonsByLevel(normalizedLevel);
    if (grammarList.length >= 4) {
      final pool = List.of(grammarList)..shuffle(rng);
      final count = min(6, pool.length);
      for (var i = 0; i < count; i++) {
        final target = pool[i];
        final targetTitle = target.displayTitle(language: 'vi').trim();
        if (targetTitle.isEmpty) continue;

        final distractors = <String>[];
        for (final candidate in pool) {
          if (candidate.id == target.id) continue;
          final title = candidate.displayTitle(language: 'vi').trim();
          if (title.isNotEmpty &&
              title != targetTitle &&
              !distractors.contains(title)) {
            distractors.add(title);
            if (distractors.length == 3) break;
          }
        }
        if (distractors.length < 3) continue;

        final options = <String>[targetTitle, ...distractors]..shuffle(rng);
        final correctIdx = options.indexOf(targetTitle);

        generated.add(
          PkQuestion(
            id: 'grammar_${target.id}',
            level: normalizedLevel,
            category: 'Ngữ pháp $normalizedLevel',
            prompt: 'Mẫu ngữ pháp sau dùng để diễn tả ý nghĩa nào?',
            word: target.pattern,
            options: options,
            correctIndex: correctIdx,
            explanation:
                'Mẫu "${target.pattern}": $targetTitle — ${target.displayExplanation(language: 'vi')}',
          ),
        );
      }
    }

    // 4. Add verified fallback questions for the level so pool is always rich
    final fallback = _fallbackQuestionsByLevel[normalizedLevel] ??
        _fallbackQuestionsByLevel['N5']!;
    generated.addAll(fallback);

    if (generated.length > maxCount) {
      return generated.sublist(0, maxCount);
    }
    return generated;
  }

  static const Map<String, List<PkQuestion>> _fallbackQuestionsByLevel = {
    'N5': <PkQuestion>[
      PkQuestion(
        id: 'fb_n5_1',
        level: 'N5',
        category: 'Từ vựng N5',
        prompt: 'Chọn nghĩa đúng của từ sau:',
        word: '食べる (たべる)',
        options: ['Ăn', 'Uống', 'Ngủ', 'Đi bộ'],
        correctIndex: 0,
        explanation: '食べる (taberu) có nghĩa là "Ăn".',
      ),
      PkQuestion(
        id: 'fb_n5_2',
        level: 'N5',
        category: 'Kanji N5',
        prompt: 'Cách đọc Hiragana đúng của chữ Hán sau là:',
        word: '水曜日',
        options: ['すいようび', 'かようび', '목ようび', 'きんようび'],
        correctIndex: 0,
        explanation: '水曜日 (suiyoubi) là Thứ Tư.',
      ),
      PkQuestion(
        id: 'fb_n5_3',
        level: 'N5',
        category: 'Ngữ pháp N5',
        prompt: 'Điền trợ từ đúng vào chỗ trống:',
        word: '毎日、電車（ ___ ）学校へ行きます。',
        options: ['で', 'に', 'を', '가'],
        correctIndex: 0,
        explanation: 'Trợ từ で chỉ phương tiện di chuyển (bằng tàu điện).',
      ),
      PkQuestion(
        id: 'fb_n5_4',
        level: 'N5',
        category: 'Từ vựng N5',
        prompt: 'Chọn nghĩa đúng của tính từ sau:',
        word: '新しい (あたらしい)',
        options: ['Mới', 'Cũ', 'Đắt', 'Rẻ'],
        correctIndex: 0,
        explanation: '新しい (atarashii) nghĩa là "Mới".',
      ),
      PkQuestion(
        id: 'fb_n5_5',
        level: 'N5',
        category: 'Từ vựng N5',
        prompt: 'Từ nào dưới đây có nghĩa là "Thư viện"?',
        word: 'Thư viện',
        options: ['図書館 (としょかん)', '体育館 (たいいくかん)', '映画館 (えいがかん)', '美術館 (びじゅつかん)'],
        correctIndex: 0,
        explanation: '図書館 (toshokan) là Thư viện.',
      ),
      PkQuestion(
        id: 'fb_n5_6',
        level: 'N5',
        category: 'Ngữ pháp N5',
        prompt: 'Chọn cách chia quá khứ lịch sự của 飲む (Uống):',
        word: 'きのう、お茶を（ ___ ）。',
        options: ['飲みました', '飲みます', '飲んでいます', '飲みましょう'],
        correctIndex: 0,
        explanation: 'きのう (hôm qua) đi với quá khứ khẳng định 飲みました.',
      ),
    ],
    'N4': <PkQuestion>[
      PkQuestion(
        id: 'fb_n4_1',
        level: 'N4',
        category: 'Từ vựng N4',
        prompt: 'Chọn nghĩa đúng của từ sau:',
        word: '約束 (やくそく)',
        options: ['Lời hứa / Cuộc hẹn', 'Kinh nghiệm', 'Chuẩn bị', 'Thói quen'],
        correctIndex: 0,
        explanation: '約束 (yakusoku) có nghĩa là "Lời hứa, cuộc hẹn".',
      ),
      PkQuestion(
        id: 'fb_n4_2',
        level: 'N4',
        category: 'Ngữ pháp N4',
        prompt: 'Chọn mẫu câu diễn tả "Dự định sẽ làm gì":',
        word: '来年、日本へ行く（ ___ ）です。',
        options: ['つもり', 'ところ', 'ばかり', 'はず'],
        correctIndex: 0,
        explanation: 'V-る + つもりです diễn tả dự định chắc chắn của người nói.',
      ),
      PkQuestion(
        id: 'fb_n4_3',
        level: 'N4',
        category: 'Kanji N4',
        prompt: 'Chọn cách đọc đúng của từ Hán tự sau:',
        word: '特別',
        options: ['とくべつ', 'とっべつ', 'どくべつ', 'とくへつ'],
        correctIndex: 0,
        explanation: '特別 (tokubetsu) nghĩa là "Đặc biệt".',
      ),
      PkQuestion(
        id: 'fb_n4_4',
        level: 'N4',
        category: 'Từ vựng N4',
        prompt: 'Chọn nghĩa đúng của động từ sau:',
        word: '間に合う (まにあう)',
        options: ['Kịp giờ', 'Trễ giờ', 'Gặp gỡ', 'Đồng ý'],
        correctIndex: 0,
        explanation: '間に合う (maniau) nghĩa là "Kịp giờ, đúng lúc".',
      ),
    ],
    'N3': <PkQuestion>[
      PkQuestion(
        id: 'fb_n3_1',
        level: 'N3',
        category: 'Ngữ pháp N3',
        prompt: 'Chọn cấu trúc phù hợp với nghĩa "Nhờ có... nên kết quả tốt":',
        word: '先生のご指導の（ ___ ）、合格できました。',
        options: ['おかげで', 'せいで', 'くせに', 'わりに'],
        correctIndex: 0,
        explanation: 'おかげで dùng để cảm ơn nguyên nhân mang lại kết quả tích cực.',
      ),
      PkQuestion(
        id: 'fb_n3_2',
        level: 'N3',
        category: 'Từ vựng N3',
        prompt: 'Chọn nghĩa đúng của từ sau:',
        word: '影響 (えいきょう)',
        options: ['Ảnh hưởng', 'Ấn tượng', 'Hiện tượng', 'Tưởng tượng'],
        correctIndex: 0,
        explanation: '影響 (eikyou) nghĩa là "Ảnh hưởng".',
      ),
      PkQuestion(
        id: 'fb_n3_3',
        level: 'N3',
        category: 'Kanji N3',
        prompt: 'Chọn nghĩa đúng của từ Hán tự sau:',
        word: '解決 (かいけつ)',
        options: ['Giải quyết', 'Giải thích', 'Giải tán', 'Quyết định'],
        correctIndex: 0,
        explanation: '解決 (kaiketsu) nghĩa là "Giải quyết vấn đề".',
      ),
      PkQuestion(
        id: 'fb_n3_4',
        level: 'N3',
        category: 'Ngữ pháp N3',
        prompt: 'Mẫu câu nào mang nghĩa "Ngay sau khi vừa mới...":',
        word: 'ベッドに入った（ ___ ）、眠ってしまった。',
        options: ['とたんに', 'うちに', 'ついでに', '最中に'],
        correctIndex: 0,
        explanation: 'V-た + とたん（に） diễn tả hành động xảy ra ngay lập tức sau một hành động khác.',
      ),
    ],
    'N2': <PkQuestion>[
      PkQuestion(
        id: 'fb_n2_1',
        level: 'N2',
        category: 'Ngữ pháp N2',
        prompt: 'Chọn mẫu ngữ pháp nghĩa là "Bất kể / Không màng đến...":',
        word: '天候に（ ___ ）、明日の試合は行われます。',
        options: ['かかわらず', '応じて', '伴って', 'わたって'],
        correctIndex: 0,
        explanation: '〜にかかわらず nghĩa là "Bất kể / Không phụ thuộc vào...".',
      ),
      PkQuestion(
        id: 'fb_n2_2',
        level: 'N2',
        category: 'Từ vựng N2',
        prompt: 'Chọn nghĩa đúng của từ sau:',
        word: '妥協 (だきょう)',
        options: ['Thỏa hiệp', 'Đàm phán', 'Từ chối', 'Hợp tác'],
        correctIndex: 0,
        explanation: '妥協 (dakyou) có nghĩa là "Thỏa hiệp, nhượng bộ".',
      ),
      PkQuestion(
        id: 'fb_n2_3',
        level: 'N2',
        category: 'Kanji N2',
        prompt: 'Chọn cách đọc đúng của từ Hán tự sau:',
        word: '貢献',
        options: ['こうけん', 'くうけん', 'こうげん', 'こけん'],
        correctIndex: 0,
        explanation: '貢献 (kouken) nghĩa là "Cống hiến, đóng góp".',
      ),
      PkQuestion(
        id: 'fb_n2_4',
        level: 'N2',
        category: 'Ngữ pháp N2',
        prompt: 'Mẫu câu diễn tả "Chính vì... nên lại càng...":',
        word: '親しい仲（ ___ ）、礼儀が大切だ。',
        options: ['だからこそ', 'どころか', 'ばかりに', 'ものの'],
        correctIndex: 0,
        explanation: '〜からこそ nhấn mạnh nguyên nhân ("Chính vì...").',
      ),
    ],
    'N1': <PkQuestion>[
      PkQuestion(
        id: 'fb_n1_1',
        level: 'N1',
        category: 'Ngữ pháp N1',
        prompt: 'Chọn mẫu ngữ pháp nghĩa là "Cực kỳ / Không gì sánh bằng":',
        word: '本日の栄誉は、私にとって光栄の（ ___ ）です。',
        options: ['極み', '始末', '限り', '手前'],
        correctIndex: 0,
        explanation: 'N + の極み (no kiwami) diễn tả mức độ tột cùng của cảm xúc.',
      ),
      PkQuestion(
        id: 'fb_n1_2',
        level: 'N1',
        category: 'Từ vựng N1',
        prompt: 'Chọn nghĩa đúng của từ vựng N1 sau:',
        word: '迅速 (じんそく)',
        options: ['Nhanh chóng, thần tốc', 'Thận trọng, tỉ mỉ', 'Kiên trì, bền bỉ', 'Linh hoạt, mềm dẻo'],
        correctIndex: 0,
        explanation: '迅速 (jinsoku) nghĩa là "Nhanh chóng, mau lẹ".',
      ),
      PkQuestion(
        id: 'fb_n1_3',
        level: 'N1',
        category: 'Kanji N1',
        prompt: 'Chọn cách đọc đúng của từ Hán tự sau:',
        word: '網羅',
        options: ['もうら', 'ぼうら', 'あみら', 'مうろ'],
        correctIndex: 0,
        explanation: '網羅 (moura) nghĩa là "Bao quát toàn bộ".',
      ),
      PkQuestion(
        id: 'fb_n1_4',
        level: 'N1',
        category: 'Ngữ pháp N1',
        prompt: 'Mẫu câu nào mang nghĩa "Dù cho... đi chăng nữa":',
        word: 'いかなる理由があろう（ ___ ）、暴力は許されない。',
        options: ['とも', 'ゆえに', 'なりとも', 'がてら'],
        correctIndex: 0,
        explanation: 'V-う/よう + とも nghĩa là "Cho dù... đi nữa".',
      ),
    ],
  };
}
