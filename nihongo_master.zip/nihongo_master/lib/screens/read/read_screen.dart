import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/reading_material_data.dart';
import '../../models/reading_material.dart';
import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/local_database_service.dart';
import '../../theme/cozy_palette.dart';
import '../../widgets/cozy_common_widgets.dart';

class ReadScreen extends StatefulWidget {
  final bool allowBack;

  const ReadScreen({super.key, this.allowBack = true});

  @override
  State<ReadScreen> createState() => _ReadScreenState();
}

class _ReadScreenState extends State<ReadScreen> {
  final TextEditingController _searchController = TextEditingController();

  List<ReadingMaterial> _materials = [];
  late final List<CultureTopic> _cultureTopics;

  String _selectedLevel = 'Tất cả';
  String _selectedCategory = 'Tất cả';
  String _query = '';
  final Set<String> _recordedMaterialIds = <String>{};
  bool _isLoadingCulture = true;
  bool _isSpinning = false;
  bool _hasSpunToday = false;
  double _turns = 0;
  CultureTopic? _todayCulture;

  @override
  void initState() {
    super.initState();
    _materials = buildReadingMaterials();
    _cultureTopics = buildCultureTopics();
    _loadCultureState();
    if (_materials.isEmpty) {
      LocalDatabaseService.instance
          .ensureVerifiedDatasetImportedAndLoaded()
          .then((_) {
        if (mounted) {
          setState(() {
            _materials = buildReadingMaterials();
          });
        }
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<String> get _levels => [
        'Tất cả',
        'N5',
        'N4',
        'N3',
        'N2',
        'N1',
        'Chưa phân cấp JLPT',
      ];

  List<String> get _categories {
    final dynamicCats = _materials
        .map((m) => m.category.trim())
        .where((c) => c.isNotEmpty)
        .toSet()
        .toList();
    if (dynamicCats.isNotEmpty) {
      return ['Tất cả', ...dynamicCats];
    }
    return [
      'Tất cả',
      'Truyện đọc phân cấp',
      'Văn học cổ điển',
    ];
  }

  String get _todayKey {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  Future<void> _loadCultureState() async {
    final prefs = await SharedPreferences.getInstance();
    final savedDate = prefs.getString('culture_spin_date');
    final savedIndex = prefs.getInt('culture_spin_index');

    if (savedDate == _todayKey &&
        savedIndex != null &&
        savedIndex >= 0 &&
        savedIndex < _cultureTopics.length) {
      _todayCulture = _cultureTopics[savedIndex];
      _hasSpunToday = true;
    }

    if (mounted) {
      setState(() => _isLoadingCulture = false);
    }
  }

  Future<void> _spinCulture() async {
    if (_cultureTopics.isEmpty) {
      return;
    }
    if (_hasSpunToday || _isSpinning) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Hôm nay bạn đã quay rồi. Hãy quay lại vào ngày mai nhé 🌸',
          ),
        ),
      );
      return;
    }

    setState(() {
      _isSpinning = true;
      _turns += 6.5;
    });

    await Future.delayed(const Duration(milliseconds: 1400));
    final index = Random().nextInt(_cultureTopics.length);
    final topic = _cultureTopics[index];

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('culture_spin_date', _todayKey);
    await prefs.setInt('culture_spin_index', index);

    if (!mounted) return;
    setState(() {
      _todayCulture = topic;
      _hasSpunToday = true;
      _isSpinning = false;
    });
  }

  List<ReadingMaterial> get _filteredMaterials {
    return _materials.where((item) {
      final bool matchesLevel;
      if (_selectedLevel == 'Tất cả') {
        matchesLevel = true;
      } else if (_selectedLevel == 'Chưa phân cấp JLPT' ||
          _selectedLevel == 'Not classified by JLPT') {
        matchesLevel = item.isUnclassified;
      } else {
        matchesLevel =
            !item.isUnclassified && item.originalLevel == _selectedLevel;
      }
      final matchesCategory =
          _selectedCategory == 'Tất cả' || item.category == _selectedCategory;
      final q = _query.trim().toLowerCase();
      final matchesQuery = q.isEmpty ||
          item.title.toLowerCase().contains(q) ||
          item.japaneseTitle.toLowerCase().contains(q) ||
          item.summary.toLowerCase().contains(q) ||
          (item.author ?? '').toLowerCase().contains(q) ||
          item.tags.join(' ').toLowerCase().contains(q);
      return matchesLevel && matchesCategory && matchesQuery;
    }).toList();
  }

  List<ReadingMaterial> get _featuredMaterials =>
      _filteredMaterials.where((item) => item.isFeatured).take(8).toList();

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final filtered = _filteredMaterials;
    final featured = _featuredMaterials;

    return CozyScaffold(
      appBar: CozyAppBar(
        title: 'Thư viện Đọc hiểu',
        subtitle: 'Truyện ngắn phân cấp & Văn học Nhật Bản',
        allowBack: widget.allowBack,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: CozyResourcePill(
                icon: Icons.auto_stories_rounded,
                label: '${_materials.length} bài',
              ),
            ),
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CozySurfaceCard(
                    borderRadius: 20,
                    padding: const EdgeInsets.all(16),
                    backgroundColor: cozy.surface,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: cozy.primary.withValues(alpha: 0.14),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Icon(
                                Icons.menu_book_rounded,
                                color: cozy.primary,
                                size: 22,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Read Library',
                                    style: TextStyle(
                                      color: cozy.textPrimary,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Kho bài đọc từ N5 đến N1 với truyện đọc phân cấp và văn học cổ điển.',
                                    style: TextStyle(
                                      color: cozy.textSecondary,
                                      fontSize: 13,
                                      height: 1.45,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Expanded(
                              child: _HeroStat(
                                value: '${_materials.length}',
                                label: 'Tài liệu',
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: _HeroStat(
                                value: '5',
                                label: 'Cấp độ',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _HeroStat(
                                value: '${_categories.length - 1}',
                                label: 'Thể loại',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _searchController,
                    onChanged: (value) => setState(() => _query = value),
                    style: TextStyle(color: cozy.textPrimary),
                    decoration: InputDecoration(
                      hintText:
                          'Tìm theo tiêu đề, chủ đề, cấp độ, từ khóa...',
                      hintStyle: TextStyle(color: cozy.textSecondary),
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        color: cozy.textSecondary,
                      ),
                      suffixIcon: _query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _query = '');
                              },
                              icon: Icon(
                                Icons.close_rounded,
                                color: cozy.textSecondary,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const _SectionTitle(title: 'Lọc theo cấp độ'),
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _levels
                          .map(
                            (level) => Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(level),
                                selected: _selectedLevel == level,
                                selectedColor: cozy.primary,
                                backgroundColor: cozy.surface,
                                side: BorderSide(
                                  color: _selectedLevel == level
                                      ? cozy.primary
                                      : cozy.borderSubtle,
                                ),
                                labelStyle: TextStyle(
                                  color: _selectedLevel == level
                                      ? cozy.onPrimary
                                      : cozy.textPrimary,
                                  fontWeight: _selectedLevel == level
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                ),
                                onSelected: (_) =>
                                    setState(() => _selectedLevel = level),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const _SectionTitle(title: 'Lọc theo thể loại'),
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _categories
                          .map(
                            (category) => Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(category),
                                selected: _selectedCategory == category,
                                selectedColor: cozy.secondary,
                                backgroundColor: cozy.surface,
                                side: BorderSide(
                                  color: _selectedCategory == category
                                      ? cozy.secondary
                                      : cozy.borderSubtle,
                                ),
                                labelStyle: TextStyle(
                                  color: _selectedCategory == category
                                      ? cozy.onPrimary
                                      : cozy.textPrimary,
                                  fontWeight: _selectedCategory == category
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                ),
                                onSelected: (_) => setState(
                                    () => _selectedCategory = category),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildCultureCard(),
                  const SizedBox(height: 20),
                  if (featured.isNotEmpty) ...[
                    const _SectionTitle(title: 'Gợi ý nổi bật hôm nay'),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 175,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: featured.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final item = featured[index];
                          return _FeaturedReadCard(
                            material: item,
                            onTap: () => _openDetail(item),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                  _SectionTitle(
                    title: 'Danh sách bài đọc',
                    trailing: Text(
                      '${filtered.length} tài liệu',
                      style: TextStyle(
                        color: cozy.textSecondary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Divider(color: cozy.borderSubtle, height: 1),
                ],
              ),
            ),
          ),
          if (filtered.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: _EmptyReadState(),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final item = filtered[index];
                    final isLast = index == filtered.length - 1;
                    return Column(
                      children: [
                        _ReadingCard(
                          material: item,
                          onTap: () => _openDetail(item),
                        ),
                        if (!isLast)
                          Divider(
                            color: cozy.borderSubtle,
                            height: 1,
                          ),
                      ],
                    );
                  },
                  childCount: filtered.length,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCultureCard() {
    final cozy = context.cozy;
    return CozySurfaceCard(
      borderRadius: 20,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: cozy.accent.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(Icons.casino_rounded, color: cozy.primary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Khám phá văn hóa Nhật mỗi ngày',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: cozy.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Mỗi ngày 1 lượt quay mở ra nét văn hóa đặc trưng của Nhật Bản.',
                      style: TextStyle(
                        color: cozy.textSecondary,
                        fontSize: 12.5,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              AnimatedRotation(
                turns: _turns,
                duration: const Duration(milliseconds: 1300),
                curve: Curves.easeOutCubic,
                child: Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    color: cozy.surfaceSoft,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: cozy.borderSubtle),
                  ),
                  child: Center(
                    child: Text(
                      _todayCulture?.icon ?? '🎌',
                      style: const TextStyle(fontSize: 30),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: _isLoadingCulture
                    ? const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: LinearProgressIndicator(minHeight: 6),
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _todayCulture?.title ?? 'Chưa quay hôm nay',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: cozy.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _todayCulture?.subtitle ??
                                'Bấm nút quay để nhận chủ đề văn hóa Nhật Bản trong ngày.',
                            style: TextStyle(
                              color: cozy.textSecondary,
                              fontSize: 13,
                              height: 1.45,
                            ),
                          ),
                        ],
                      ),
              ),
            ],
          ),
          if (_todayCulture != null) ...[
            const SizedBox(height: 12),
            Divider(color: cozy.borderSubtle, height: 1),
            const SizedBox(height: 12),
            Text(
              _todayCulture!.content,
              style: TextStyle(
                height: 1.6,
                fontSize: 13.5,
                color: cozy.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: _todayCulture!.keywords
                  .map(
                    (tag) => Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: cozy.surfaceSoft,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: cozy.borderSubtle),
                      ),
                      child: Text(
                        '#$tag',
                        style: TextStyle(
                          color: cozy.primary,
                          fontWeight: FontWeight.w700,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ],
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _isLoadingCulture || _isSpinning ? null : _spinCulture,
            icon: Icon(
              _hasSpunToday
                  ? Icons.check_circle_rounded
                  : Icons.casino_rounded,
            ),
            label: Text(
              _hasSpunToday ? 'Đã quay hôm nay' : 'Quay 1 lần hôm nay',
            ),
          ),
        ],
      ),
    );
  }

  void _openDetail(ReadingMaterial material) {
    if (_recordedMaterialIds.add(material.id)) {
      const validLevels = <String>{'N5', 'N4', 'N3', 'N2', 'N1'};
      final orig = material.originalLevel?.trim().toUpperCase();
      final sel = _selectedLevel.trim().toUpperCase();
      final String? lv = (orig != null && validLevels.contains(orig))
          ? orig
          : (validLevels.contains(sel) ? sel : null);
      Provider.of<ProgressProvider?>(context, listen: false)
          ?.recordAdaptiveQuestProgress('reading', levelOverride: lv);
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReadDetailScreen(material: material),
      ),
    );
  }
}

class ReadDetailScreen extends StatelessWidget {
  final ReadingMaterial material;

  const ReadDetailScreen({super.key, required this.material});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final settings = Provider.of<SettingsProvider?>(context);
    final language = settings?.effectiveLanguage ?? 'vi';
    final levelLabel = material.displayLevelLabel(language: language);
    final sections = material.content
        .split('\n\n')
        .where((element) => element.trim().isNotEmpty)
        .toList();

    return CozyScaffold(
      appBar: CozyAppBar(
        title: material.displayTitle(language: language),
        subtitle: '$levelLabel · ${material.category}',
        showBottomBorder: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _InfoPill(
                icon: Icons.school_rounded,
                text: levelLabel,
                highlight: true,
              ),
              _InfoPill(
                icon: Icons.folder_open_rounded,
                text: material.category,
              ),
              _InfoPill(
                icon: Icons.schedule_rounded,
                text: '${material.estimatedMinutes} phút',
              ),
              ...material.tags
                  .take(3)
                  .map((tag) => _InfoPill(icon: Icons.sell_rounded, text: tag)),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            material.displayTitle(language: language),
            style: TextStyle(
              color: cozy.textPrimary,
              fontSize: 24,
              fontWeight: FontWeight.w900,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            material.japaneseTitle,
            style: TextStyle(
              color: cozy.primary,
              fontSize: 18,
              fontWeight: FontWeight.w700,
              height: 1.4,
            ),
          ),
          if (material.author != null &&
              material.author!.trim().isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              '✍️ ${material.author}',
              style: TextStyle(
                color: cozy.textSecondary,
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
          if (material.summary.trim().isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              material.summary,
              style: TextStyle(
                color: cozy.textSecondary,
                fontSize: 14,
                height: 1.6,
              ),
            ),
          ],
          const SizedBox(height: 20),
          Divider(color: cozy.borderSubtle, height: 1),
          const SizedBox(height: 20),
          ...sections.map(
            (section) => Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: SelectableText(
                section,
                style: TextStyle(
                  color: cozy.textPrimary,
                  height: 1.75,
                  fontSize: 16.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Divider(color: cozy.borderSubtle, height: 1),
          const SizedBox(height: 20),
          Text(
            'Bản dịch / Tóm tắt',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: cozy.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          SelectableText(
            material.displayTranslation(language: language),
            style: TextStyle(
              color: cozy.textSecondary,
              fontSize: 15,
              height: 1.65,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final Widget? trailing;

  const _SectionTitle({required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Row(
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: cozy.textPrimary,
          ),
        ),
        const Spacer(),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String label;

  const _HeroStat({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: cozy.surfaceSoft,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cozy.borderSubtle),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              color: cozy.primary,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: cozy.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _FeaturedReadCard extends StatelessWidget {
  final ReadingMaterial material;
  final VoidCallback onTap;

  const _FeaturedReadCard({required this.material, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final settings = Provider.of<SettingsProvider?>(context);
    final language = settings?.effectiveLanguage ?? 'vi';
    final levelLabel = material.displayLevelLabel(language: language);
    return SizedBox(
      width: 245,
      child: CozySurfaceCard(
        borderRadius: 20,
        padding: const EdgeInsets.all(16),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: cozy.primary.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    levelLabel,
                    style: TextStyle(
                      color: cozy.primary,
                      fontWeight: FontWeight.w800,
                      fontSize: 11.5,
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  '${material.estimatedMinutes} phút',
                  style: TextStyle(
                    color: cozy.textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              material.displayTitle(language: language),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: cozy.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              material.preview,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: cozy.textSecondary,
                fontSize: 13,
                height: 1.45,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReadingCard extends StatelessWidget {
  final ReadingMaterial material;
  final VoidCallback onTap;

  const _ReadingCard({required this.material, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final settings = Provider.of<SettingsProvider?>(context);
    final language = settings?.effectiveLanguage ?? 'vi';
    final levelLabel = material.displayLevelLabel(language: language);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: cozy.primary.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    levelLabel,
                    style: TextStyle(
                      color: cozy.primary,
                      fontWeight: FontWeight.w800,
                      fontSize: 11.5,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: cozy.surfaceSoft,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: cozy.borderSubtle),
                  ),
                  child: Text(
                    material.category,
                    style: TextStyle(
                      color: cozy.textSecondary,
                      fontWeight: FontWeight.w700,
                      fontSize: 11.5,
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  '${material.estimatedMinutes} phút',
                  style: TextStyle(
                    color: cozy.textSecondary,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              material.displayTitle(language: language),
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: cozy.textPrimary,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              material.japaneseTitle,
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w700,
                color: cozy.primary,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              material.preview,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                height: 1.6,
                fontSize: 14,
                color: cozy.textSecondary,
              ),
            ),
            if (material.tags.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: material.tags.take(4).map((tag) {
                  return Text(
                    '#$tag',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: cozy.textSecondary,
                    ),
                  );
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _EmptyReadState extends StatelessWidget {
  const _EmptyReadState();

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return CozySurfaceCard(
      borderRadius: 20,
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Icon(
            Icons.search_off_rounded,
            size: 42,
            color: cozy.textSecondary,
          ),
          const SizedBox(height: 12),
          Text(
            'Không tìm thấy bài đọc phù hợp',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: cozy.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Hãy đổi từ khóa tìm kiếm hoặc bỏ bớt bộ lọc để xem nhiều tài liệu hơn.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: cozy.textSecondary,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool highlight;

  const _InfoPill({
    required this.icon,
    required this.text,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: highlight
            ? cozy.primary.withValues(alpha: 0.14)
            : cozy.surfaceSoft,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: highlight
              ? cozy.primary.withValues(alpha: 0.3)
              : cozy.borderSubtle,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 13.5,
            color: highlight ? cozy.primary : cozy.textSecondary,
          ),
          const SizedBox(width: 5),
          Text(
            text,
            style: TextStyle(
              color: highlight ? cozy.primary : cozy.textSecondary,
              fontWeight: FontWeight.w700,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
