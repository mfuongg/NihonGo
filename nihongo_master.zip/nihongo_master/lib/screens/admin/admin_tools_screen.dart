import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/grammar_data.dart';
import '../../data/jlpt_test_data.dart';
import '../../data/kanji_data.dart';
import '../../data/reading_material_data.dart';
import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/vocabulary_provider.dart';
import '../../services/local_database_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/cozy_common_widgets.dart';
import '../map/map_level_catalog.dart';
import '../map/world_map_screen.dart';

class AdminToolsScreen extends StatelessWidget {
  const AdminToolsScreen({super.key});

  void _snack(BuildContext context, String text) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppTheme.accent,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final progressProvider = context.watch<ProgressProvider>();
    final vocab = context.watch<VocabularyProvider>();
    final p = progressProvider.progress;

    final allWords = vocab.allWords;
    final allKanji = KanjiData.getAllKanji();
    final allGrammar = GrammarData.getAllLessons();
    final allReading = ReadingMaterialData.getAllMaterials();
    final allListening = LocalDatabaseService.loadedPlayableListeningItems;
    final allExams = JLPTTestData.getAllTests();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.surface,
        surfaceTintColor: Colors.transparent,
        title: Text(
          'Bảng điều khiển Admin (Dev)',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          CozySurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: AppTheme.accent.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(Icons.admin_panel_settings_rounded, color: AppTheme.accent, size: 26),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            auth.currentUser?.displayName ?? 'Admin NihonGo',
                            style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            auth.currentUser?.email ?? 'admin.nihongomaster@example.com',
                            style: TextStyle(fontSize: 12.5, color: AppTheme.textSecondary),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppTheme.accent,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: const Text(
                        'DEV MODE',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.background,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppTheme.borderSubtle),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.shield_outlined, size: 18, color: AppTheme.accent),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Chế độ Admin chỉ hoạt động trong bản Debug/Dev và tách biệt khỏi dữ liệu người dùng thật trên Cloud.',
                          style: TextStyle(fontSize: 12, color: AppTheme.textSecondary, height: 1.35),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  activeThumbColor: AppTheme.accent,
                  title: Text(
                    'Truy cập không giới hạn (Unlimited Mode)',
                    style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
                  ),
                  subtitle: Text(
                    '999.999 Coin & Gem · Mở khóa cả 5 Thế giới N5–N1 và mọi màn chơi',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  ),
                  value: progressProvider.adminUnlimitedOverride,
                  onChanged: (v) {
                    progressProvider.setAdminUnlimitedOverride(v);
                    _snack(context, v ? 'Đã bật chế độ Không giới hạn' : 'Đã tắt chế độ Không giới hạn (hiển thị số dư thực)');
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          CozySurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Truy cập nhanh 5 Thế giới (N5 → N1)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                ),
                const SizedBox(height: 4),
                Text(
                  'Mở trực tiếp bất kỳ thế giới nào ở chế độ Từ vựng hoặc Kanji:',
                  style: TextStyle(fontSize: 12.5, color: AppTheme.textSecondary),
                ),
                const SizedBox(height: 12),
                for (final world in JlptWorld.all)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: world.gradient),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Icon(world.icon, color: const Color(0xFF3F7F8C), size: 24),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Thế giới ${world.number} · ${world.level}',
                                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppTheme.textSecondary),
                                ),
                                Text(
                                  world.name,
                                  style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            style: TextButton.styleFrom(
                              backgroundColor: Colors.white.withValues(alpha: 0.85),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            onPressed: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => WorldRoadmapScreen(
                                  world: world,
                                  initialMode: MapLearningMode.vocabulary,
                                ),
                              ),
                            ),
                            child: Text(
                              'Từ vựng',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppTheme.primary),
                            ),
                          ),
                          const SizedBox(width: 6),
                          TextButton(
                            style: TextButton.styleFrom(
                              backgroundColor: Colors.white.withValues(alpha: 0.85),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            onPressed: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => WorldRoadmapScreen(
                                  world: world,
                                  initialMode: MapLearningMode.kanji,
                                ),
                              ),
                            ),
                            child: Text(
                              'Kanji',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppTheme.accent),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          CozySurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Công cụ Sandbox Tài nguyên & Tiến độ',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                ),
                const SizedBox(height: 6),
                Text(
                  'Hiển thị: ${p.coins} Coin · ${p.gems} Gem · ${p.totalXP} EXP · Streak ${p.currentStreak} ngày\n'
                  'Số dư thực (khi tắt Unlimited): ${p.rawCoins} Coin · ${p.rawGems} Gem',
                  style: TextStyle(fontSize: 12.5, color: AppTheme.textSecondary, height: 1.4),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ActionChipButton(
                      icon: AppAssets.statusCoin,
                      label: '+1.000 Coin thực',
                      onTap: () async {
                        await progressProvider.adminGrantResources(coins: 1000);
                        if (context.mounted) _snack(context, 'Đã cộng +1.000 Coin thực');
                      },
                    ),
                    _ActionChipButton(
                      icon: AppAssets.statusGem,
                      label: '+100 Gem thực',
                      onTap: () async {
                        await progressProvider.adminGrantResources(gems: 100);
                        if (context.mounted) _snack(context, 'Đã cộng +100 Gem thực');
                      },
                    ),
                    _ActionChipButton(
                      icon: AppAssets.achStar,
                      label: '+200 EXP & +1 Streak',
                      onTap: () async {
                        await progressProvider.adminGrantResources(xp: 200, streak: 1);
                        if (context.mounted) _snack(context, 'Đã cộng +200 EXP & +1 Streak');
                      },
                    ),
                    _ActionChipButton(
                      icon: AppAssets.achTrophy,
                      label: 'Đạt 3★ toàn bộ 5 Thế giới',
                      onTap: () async {
                        await progressProvider.adminSetAllMapStars(stars: 3);
                        if (context.mounted) _snack(context, 'Đã gán 3 sao cho toàn bộ màn chơi N5–N1');
                      },
                    ),
                    _ActionChipButton(
                      icon: AppAssets.achMedal,
                      label: 'Mở khóa mọi Thành tích',
                      onTap: () async {
                        await progressProvider.adminUnlockAllAchievements();
                        if (context.mounted) _snack(context, 'Đã mở khóa toàn bộ thành tích');
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      progressProvider.resetProgress();
                      _snack(context, 'Đã đặt lại tiến độ cục bộ về mặc định');
                    },
                    icon: const Icon(Icons.restart_alt_rounded, size: 18),
                    label: const Text('Reset tiến độ cục bộ về 0 (giữ nguyên quyền Admin)'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.error,
                      side: const BorderSide(color: AppTheme.error),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          CozySurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Thống kê Kho dữ liệu Verified v2',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                ),
                const SizedBox(height: 10),
                _StatRow(label: 'Từ vựng (Vocabularies)', value: '${allWords.length} từ'),
                _StatRow(label: 'Chữ Hán (Kanji Entries)', value: '${allKanji.length} chữ'),
                _StatRow(label: 'Ngữ pháp (Grammar Points)', value: '${allGrammar.length} mẫu'),
                _StatRow(label: 'Đọc hiểu (Reading Materials)', value: '${allReading.length} bài'),
                _StatRow(label: 'Nghe hiểu (Playable Audio)', value: '${allListening.length} bài'),
                _StatRow(label: 'Đề thi JLPT (Official Exams)', value: '${allExams.length} đề'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionChipButton extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;

  const _ActionChipButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.background,
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: AppTheme.borderSubtle),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppAssetIcon(icon, size: 18),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;

  const _StatRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 13, color: AppTheme.textSecondary, fontWeight: FontWeight.w600),
            ),
          ),
          Text(
            value,
            style: TextStyle(fontSize: 13.5, color: AppTheme.textPrimary, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }
}
