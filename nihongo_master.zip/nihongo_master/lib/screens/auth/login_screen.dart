import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/study_history_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/bgm_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/mock_email_dialog.dart';
import '../shell/main_shell.dart';

enum _AuthMode { login, register, forgot }

enum _ForgotStep { email, otp }

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  static const String backgroundAsset = 'assets/images/auth/login_bg.gif';
  static const String mascotAsset = 'assets/images/auth/kawaii_cat_icon.png';

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with TickerProviderStateMixin {
  static const _rememberKey = 'auth_remember_login';
  static const _rememberedEmailKey = 'auth_remembered_email';
  static Color get _ctaColor => AppTheme.activeSpec.primary;
  static const Duration _otpLifetime = Duration(minutes: 10);

  final _loginFormKey = GlobalKey<FormState>();
  final _registerFormKey = GlobalKey<FormState>();
  final _forgotEmailFormKey = GlobalKey<FormState>();
  final _forgotOtpFormKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  final _otpController = TextEditingController();
  final _newPasswordController = TextEditingController();

  late final AnimationController _bounceController;
  late final AnimationController _petalController;

  _AuthMode _mode = _AuthMode.login;
  _ForgotStep _forgotStep = _ForgotStep.email;
  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _rememberLogin = true;
  bool? _lastSoundEnabled;
  bool _redirecting = false;
  String? _otpCode;
  DateTime? _otpExpiresAt;

  @override
  void initState() {
    super.initState();
    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _petalController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
    _loadRememberedLogin();
  }

  @override
  void dispose() {
    _bounceController.dispose();
    _petalController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    _otpController.dispose();
    _newPasswordController.dispose();
    super.dispose();
  }

  Future<void> _loadRememberedLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final remember = prefs.getBool(_rememberKey) ?? true;
    final email = prefs.getString(_rememberedEmailKey);
    if (!mounted) return;
    setState(() {
      _rememberLogin = remember;
      if (remember && email != null && _emailController.text.isEmpty) {
        _emailController.text = email;
      }
    });
  }

  Future<void> _persistRememberedLogin(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_rememberKey, _rememberLogin);
    if (_rememberLogin) {
      await prefs.setString(_rememberedEmailKey, email);
    } else {
      await prefs.remove(_rememberedEmailKey);
    }
  }

  void _switchMode(_AuthMode mode) {
    FocusScope.of(context).unfocus();
    setState(() {
      _mode = mode;
      _forgotStep = _ForgotStep.email;
      _obscurePassword = true;
      _obscureConfirm = true;
      _passwordController.clear();
      _confirmController.clear();
      _otpController.clear();
      _newPasswordController.clear();
      _otpCode = null;
      _otpExpiresAt = null;
    });
  }

  void _showSnack(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          backgroundColor: isError ? AppTheme.error : AppTheme.accent,
        ),
      );
  }

  Future<void> _goHome() async {
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }

  Future<void> _completeSignIn(String message) async {
    final auth = context.read<AuthProvider>();
    final progress = context.read<ProgressProvider>();
    final history = context.read<StudyHistoryProvider>();
    _redirecting = true;
    await progress.reloadForCurrentUser(preferRemote: true, isAdmin: auth.isAdmin);
    await history.init(userId: auth.currentUser?.uid ?? 'guest');
    if (!mounted) return;
    _showSnack(message);
    await Future.delayed(const Duration(milliseconds: 320));
    await _goHome();
  }

  Future<void> _submitLogin() async {
    if (!_loginFormKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final email = _emailController.text.trim();
    _redirecting = true;
    final ok = await auth.signIn(email: email, password: _passwordController.text);
    if (!mounted) return;
    if (!ok) {
      _redirecting = false;
      _showSnack(auth.errorMessage ?? 'Đăng nhập thất bại.', isError: true);
      return;
    }
    await _persistRememberedLogin(email);
    if (!mounted) return;
    await _completeSignIn('Đăng nhập thành công');
  }

  Future<void> _submitRegister() async {
    if (!_registerFormKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final email = _emailController.text.trim();
    _redirecting = true;
    final ok = await auth.register(
      email: email,
      password: _passwordController.text,
      displayName: _nameController.text.trim(),
    );
    if (!mounted) return;
    if (!ok) {
      _redirecting = false;
      _showSnack(auth.errorMessage ?? 'Đăng ký thất bại.', isError: true);
      return;
    }
    await _persistRememberedLogin(email);
    if (!mounted) return;
    await _completeSignIn('Tạo tài khoản thành công. Chào mừng bạn!');
  }

  Future<void> _submitGoogle() async {
    final auth = context.read<AuthProvider>();
    _redirecting = true;
    final ok = await auth.signInWithGoogle();
    if (!mounted) return;
    if (!ok) {
      _redirecting = false;
      _showSnack(auth.errorMessage ?? 'Không thể đăng nhập Google.', isError: true);
      return;
    }
    await _completeSignIn('Đăng nhập Google thành công');
  }

  Future<void> _submitForgotEmail() async {
    if (!_forgotEmailFormKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final email = _emailController.text.trim();
    final ok = await auth.sendResetPassword(email);
    if (!mounted) return;
    if (!ok) {
      _showSnack(auth.errorMessage ?? 'Không thể gửi yêu cầu đặt lại mật khẩu.', isError: true);
      return;
    }

    if (!auth.usesLocalAuth) {
      _showSnack('Đã gửi email hướng dẫn đặt lại mật khẩu. Hãy kiểm tra hộp thư.');
      _switchMode(_AuthMode.login);
      return;
    }

    final random = math.Random.secure();
    final code = List.generate(6, (_) => random.nextInt(10)).join();
    setState(() {
      _otpCode = code;
      _otpExpiresAt = DateTime.now().add(_otpLifetime);
      _forgotStep = _ForgotStep.otp;
    });
    await MockEmailDialog.show(context, email: email, otp: code);
  }

  Future<void> _submitForgotOtp() async {
    if (!_forgotOtpFormKey.currentState!.validate()) return;
    final expiresAt = _otpExpiresAt;
    if (_otpCode == null || expiresAt == null || DateTime.now().isAfter(expiresAt)) {
      _showSnack('Mã OTP đã hết hạn. Vui lòng gửi lại mã mới.', isError: true);
      setState(() => _forgotStep = _ForgotStep.email);
      return;
    }
    if (_otpController.text.trim() != _otpCode) {
      _showSnack('Mã OTP chưa đúng. Vui lòng kiểm tra lại.', isError: true);
      return;
    }
    final auth = context.read<AuthProvider>();
    final ok = await auth.resetLocalPassword(
      email: _emailController.text.trim(),
      newPassword: _newPasswordController.text,
    );
    if (!mounted) return;
    if (!ok) {
      _showSnack(auth.errorMessage ?? 'Không thể đặt lại mật khẩu.', isError: true);
      return;
    }
    _switchMode(_AuthMode.login);
    _showSnack('Đặt lại mật khẩu thành công. Hãy đăng nhập bằng mật khẩu mới.');
  }

  void _syncMusic(bool enabled) {
    if (_lastSoundEnabled == enabled) return;
    final wasPlaying = _lastSoundEnabled == true;
    _lastSoundEnabled = enabled;
    if (!enabled && !wasPlaying) return;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (enabled) {
        await BgmService.instance.playAuthMusic();
      } else {
        await BgmService.instance.stop();
      }
    });
  }

  String? _validateEmail(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'Vui lòng nhập email';
    final pattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    if (!pattern.hasMatch(text)) return 'Email chưa đúng định dạng';
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) return 'Vui lòng nhập mật khẩu';
    if (value.length < 6) return 'Mật khẩu tối thiểu 6 ký tự';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final progress = context.watch<ProgressProvider>().progress;
    final themeProvider = context.watch<ThemeProvider?>();
    final soundEnabled = context.watch<SettingsProvider>().soundEnabled;
    _syncMusic(soundEnabled);

    final activeThemeId = themeProvider?.selectedThemeId.isNotEmpty == true
        ? themeProvider!.selectedThemeId
        : progress.selectedThemeId;
    AppTheme.setActiveTheme(activeThemeId);
    final spec = AppTheme.activeSpec;

    if (auth.isLoggedIn && !_redirecting) {
      _redirecting = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _completeSignIn('Chào mừng trở lại!');
      });
    }

    return Scaffold(
      backgroundColor: spec.background,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            LoginScreen.backgroundAsset,
            fit: BoxFit.cover,
            gaplessPlayback: true,
            errorBuilder: (_, __, ___) => ColoredBox(color: spec.background),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  spec.background.withValues(alpha: 0.22),
                  spec.primarySoft.withValues(alpha: 0.45),
                  spec.background.withValues(alpha: 0.82),
                ],
                stops: const [0, 0.55, 1],
              ),
            ),
          ),
          IgnorePointer(
            child: AnimatedBuilder(
              animation: _petalController,
              builder: (_, __) => CustomPaint(
                painter: _PetalPainter(progress: _petalController.value),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 440),
                  child: Stack(
                    alignment: Alignment.topCenter,
                    clipBehavior: Clip.none,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 104),
                        child: _buildAuthCard(auth.isLoading),
                      ),
                      _BouncingMascot(animation: _bounceController),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthCard(bool busy) {
    final spec = AppTheme.activeSpec;
    return Container(
      key: ValueKey('login-auth-card-${spec.id}'),
      padding: const EdgeInsets.fromLTRB(22, 44, 22, 24),
      decoration: BoxDecoration(
        color: spec.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: spec.primary.withValues(alpha: 0.55), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: spec.textPrimary.withValues(alpha: 0.10),
            blurRadius: 30,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: AnimatedSize(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        alignment: Alignment.topCenter,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_mode != _AuthMode.forgot) ...[
              _AuthTabs(
                isLogin: _mode == _AuthMode.login,
                onChanged: busy
                    ? null
                    : (isLogin) => _switchMode(isLogin ? _AuthMode.login : _AuthMode.register),
              ),
              const SizedBox(height: 20),
            ],
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) => FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0.04, 0),
                    end: Offset.zero,
                  ).animate(animation),
                  child: child,
                ),
              ),
              layoutBuilder: (current, previous) => Stack(
                alignment: Alignment.topCenter,
                children: [...previous, if (current != null) current],
              ),
              child: KeyedSubtree(
                key: ValueKey('${_mode.name}-${_forgotStep.name}'),
                child: switch (_mode) {
                  _AuthMode.login => _buildLoginForm(busy),
                  _AuthMode.register => _buildRegisterForm(busy),
                  _AuthMode.forgot => _forgotStep == _ForgotStep.email
                      ? _buildForgotEmailForm(busy)
                      : _buildForgotOtpForm(busy),
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginForm(bool busy) {
    return Form(
      key: _loginFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const _Greeting(
            title: 'Xin chào!',
            subtitle: 'Cùng bắt đầu hành trình chinh phục tiếng Nhật nhé!',
          ),
          const SizedBox(height: 18),
          _CozyField(
            controller: _emailController,
            hint: 'Email',
            iconAsset: AppAssets.navMail,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            validator: _validateEmail,
          ),
          const SizedBox(height: 14),
          _CozyField(
            controller: _passwordController,
            hint: 'Mật khẩu',
            iconAsset: AppAssets.achRankShield,
            obscureText: _obscurePassword,
            autofillHints: const [AutofillHints.password],
            validator: _validatePassword,
            onSubmitted: busy ? null : (_) => _submitLogin(),
            suffix: _EyeToggle(
              obscured: _obscurePassword,
              onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              SizedBox(
                width: 32,
                height: 32,
                child: Checkbox(
                  value: _rememberLogin,
                  activeColor: _ctaColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                  onChanged: (v) => setState(() => _rememberLogin = v ?? false),
                ),
              ),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _rememberLogin = !_rememberLogin),
                  child: Text(
                    'Ghi nhớ đăng nhập',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.activeSpec.textPrimary,
                    ),
                  ),
                ),
              ),
              TextButton(
                onPressed: busy ? null : () => _switchMode(_AuthMode.forgot),
                style: TextButton.styleFrom(foregroundColor: _ctaColor),
                child: const Text(
                  'Quên mật khẩu?',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _PrimaryButton(label: 'Đăng nhập', busy: busy, onPressed: _submitLogin),
          const SizedBox(height: 18),
          const _OrDivider(),
          const SizedBox(height: 16),
          _GoogleButton(onPressed: busy ? null : _submitGoogle),
          const SizedBox(height: 14),
          _SwitchRow(
            question: 'Chưa có tài khoản?',
            action: 'Đăng ký',
            onTap: busy ? null : () => _switchMode(_AuthMode.register),
          ),
        ],
      ),
    );
  }

  Widget _buildRegisterForm(bool busy) {
    return Form(
      key: _registerFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const _Greeting(
            title: 'Tạo tài khoản',
            subtitle: 'Lưu tiến độ học và đồng hành cùng Mèo Hộ Pháp.',
          ),
          const SizedBox(height: 18),
          _CozyField(
            controller: _nameController,
            hint: 'Tên hiển thị',
            iconAsset: AppAssets.navPaw,
            autofillHints: const [AutofillHints.name],
            validator: (v) {
              final text = v?.trim() ?? '';
              if (text.isEmpty) return 'Vui lòng nhập tên hiển thị';
              if (text.length > 32) return 'Tên hiển thị tối đa 32 ký tự';
              return null;
            },
          ),
          const SizedBox(height: 14),
          _CozyField(
            controller: _emailController,
            hint: 'Email',
            iconAsset: AppAssets.navMail,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            validator: _validateEmail,
          ),
          const SizedBox(height: 14),
          _CozyField(
            controller: _passwordController,
            hint: 'Mật khẩu',
            iconAsset: AppAssets.achRankShield,
            obscureText: _obscurePassword,
            autofillHints: const [AutofillHints.newPassword],
            validator: _validatePassword,
            suffix: _EyeToggle(
              obscured: _obscurePassword,
              onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
            ),
          ),
          const SizedBox(height: 14),
          _CozyField(
            controller: _confirmController,
            hint: 'Xác nhận mật khẩu',
            iconAsset: AppAssets.achRankShield,
            obscureText: _obscureConfirm,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Vui lòng nhập lại mật khẩu';
              if (v != _passwordController.text) return 'Mật khẩu xác nhận chưa khớp';
              return null;
            },
            onSubmitted: busy ? null : (_) => _submitRegister(),
            suffix: _EyeToggle(
              obscured: _obscureConfirm,
              onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm),
            ),
          ),
          const SizedBox(height: 20),
          _PrimaryButton(label: 'Đăng ký tài khoản', busy: busy, onPressed: _submitRegister),
          const SizedBox(height: 18),
          const _OrDivider(),
          const SizedBox(height: 16),
          _GoogleButton(onPressed: busy ? null : _submitGoogle),
          const SizedBox(height: 14),
          _SwitchRow(
            question: 'Đã có tài khoản?',
            action: 'Đăng nhập',
            onTap: busy ? null : () => _switchMode(_AuthMode.login),
          ),
        ],
      ),
    );
  }

  Widget _buildForgotEmailForm(bool busy) {
    final local = context.read<AuthProvider>().usesLocalAuth;
    return Form(
      key: _forgotEmailFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Greeting(
            title: 'Quên mật khẩu',
            subtitle: local
                ? 'Nhập email đã đăng ký để nhận mã OTP gồm 6 chữ số.'
                : 'Nhập email đã đăng ký để nhận hướng dẫn đặt lại mật khẩu.',
          ),
          const SizedBox(height: 18),
          _CozyField(
            controller: _emailController,
            hint: 'Email',
            iconAsset: AppAssets.navMail,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            validator: _validateEmail,
            onSubmitted: busy ? null : (_) => _submitForgotEmail(),
          ),
          const SizedBox(height: 20),
          _PrimaryButton(
            label: local ? 'Gửi mã OTP' : 'Gửi email đặt lại mật khẩu',
            busy: busy,
            onPressed: _submitForgotEmail,
          ),
          const SizedBox(height: 14),
          _SwitchRow(
            question: 'Nhớ mật khẩu rồi?',
            action: 'Quay lại Đăng nhập',
            onTap: busy ? null : () => _switchMode(_AuthMode.login),
          ),
        ],
      ),
    );
  }

  Widget _buildForgotOtpForm(bool busy) {
    return Form(
      key: _forgotOtpFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Greeting(
            title: 'Nhập mã OTP',
            subtitle: 'Mã gồm 6 chữ số đã được gửi tới ${_emailController.text.trim()}.',
          ),
          const SizedBox(height: 18),
          _CozyField(
            controller: _otpController,
            hint: 'Mã OTP 6 số',
            iconAsset: AppAssets.navMail,
            keyboardType: TextInputType.number,
            maxLength: 6,
            validator: (v) {
              final text = v?.trim() ?? '';
              if (!RegExp(r'^\d{6}$').hasMatch(text)) return 'Mã OTP gồm đúng 6 chữ số';
              return null;
            },
          ),
          const SizedBox(height: 14),
          _CozyField(
            controller: _newPasswordController,
            hint: 'Mật khẩu mới',
            iconAsset: AppAssets.achRankShield,
            obscureText: _obscurePassword,
            autofillHints: const [AutofillHints.newPassword],
            validator: _validatePassword,
            onSubmitted: busy ? null : (_) => _submitForgotOtp(),
            suffix: _EyeToggle(
              obscured: _obscurePassword,
              onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
            ),
          ),
          const SizedBox(height: 20),
          _PrimaryButton(label: 'Xác nhận & đặt lại', busy: busy, onPressed: _submitForgotOtp),
          const SizedBox(height: 8),
          TextButton(
            onPressed: busy ? null : _submitForgotEmail,
            style: TextButton.styleFrom(foregroundColor: _ctaColor),
            child: const Text('Gửi lại mã', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          _SwitchRow(
            question: 'Nhớ mật khẩu rồi?',
            action: 'Quay lại Đăng nhập',
            onTap: busy ? null : () => _switchMode(_AuthMode.login),
          ),
        ],
      ),
    );
  }
}

class _BouncingMascot extends StatelessWidget {
  final Animation<double> animation;

  const _BouncingMascot({required this.animation});

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    return AnimatedBuilder(
      animation: animation,
      builder: (_, child) {
        final t = Curves.easeInOut.transform(animation.value);
        return Transform.translate(offset: Offset(0, -8 * t), child: child);
      },
      child: Container(
        width: 128,
        height: 128,
        decoration: BoxDecoration(
          color: spec.surface,
          borderRadius: BorderRadius.circular(32),
          border: Border.all(color: spec.primary, width: 3),
          boxShadow: [
            BoxShadow(
              color: spec.textPrimary.withValues(alpha: 0.16),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Image.asset(
          LoginScreen.mascotAsset,
          fit: BoxFit.cover,
          filterQuality: FilterQuality.medium,
          semanticLabel: 'Mèo Nihongo Master',
          errorBuilder: (_, __, ___) => const SizedBox.shrink(),
        ),
      ),
    );
  }
}

class _AuthTabs extends StatelessWidget {
  final bool isLogin;
  final ValueChanged<bool>? onChanged;

  const _AuthTabs({required this.isLogin, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    return Container(
      height: 46,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: spec.primarySoft,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 240),
            curve: Curves.easeOutCubic,
            alignment: isLogin ? Alignment.centerLeft : Alignment.centerRight,
            child: FractionallySizedBox(
              widthFactor: 0.5,
              heightFactor: 1,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: spec.surface,
                  borderRadius: BorderRadius.circular(999),
                  boxShadow: [
                    BoxShadow(
                      color: spec.textPrimary.withValues(alpha: 0.08),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              _tab('Đăng nhập', isLogin, () => onChanged?.call(true), spec),
              _tab('Đăng ký', !isLogin, () => onChanged?.call(false), spec),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tab(String label, bool selected, VoidCallback onTap, AppThemeSpec spec) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onChanged == null ? null : onTap,
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 14.5,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? spec.accent : spec.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}

class _Greeting extends StatelessWidget {
  final String title;
  final String subtitle;

  const _Greeting({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const AppAssetIcon(AppAssets.achTitleRed, size: 26),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: spec.textPrimary,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Padding(
          padding: const EdgeInsets.only(left: 36),
          child: Text(
            subtitle,
            style: TextStyle(
              fontSize: 13.5,
              height: 1.4,
              fontWeight: FontWeight.w600,
              color: spec.textSecondary,
            ),
          ),
        ),
      ],
    );
  }
}

class _CozyField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final String iconAsset;
  final bool obscureText;
  final TextInputType? keyboardType;
  final Iterable<String>? autofillHints;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onSubmitted;
  final Widget? suffix;
  final int? maxLength;

  const _CozyField({
    required this.controller,
    required this.hint,
    required this.iconAsset,
    this.obscureText = false,
    this.keyboardType,
    this.autofillHints,
    this.validator,
    this.onSubmitted,
    this.suffix,
    this.maxLength,
  });

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    OutlineInputBorder border(Color color, [double width = 1.5]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(999),
          borderSide: BorderSide(color: color, width: width),
        );

    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      autofillHints: autofillHints,
      validator: validator,
      onFieldSubmitted: onSubmitted,
      maxLength: maxLength,
      textInputAction: onSubmitted == null ? TextInputAction.next : TextInputAction.done,
      style: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        color: spec.textPrimary,
      ),
      decoration: InputDecoration(
        hintText: hint,
        counterText: '',
        hintStyle: TextStyle(color: spec.textSecondary, fontWeight: FontWeight.w500),
        filled: true,
        fillColor: spec.background,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        prefixIcon: Padding(
          padding: const EdgeInsets.only(left: 14, right: 8),
          child: AppAssetIcon(iconAsset, size: 22),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 44, minHeight: 44),
        suffixIcon: suffix,
        errorMaxLines: 2,
        enabledBorder: border(spec.primary.withValues(alpha: 0.7)),
        focusedBorder: border(spec.accent, 2),
        errorBorder: border(AppTheme.error),
        focusedErrorBorder: border(AppTheme.error, 2),
      ),
    );
  }
}

class _EyeToggle extends StatelessWidget {
  final bool obscured;
  final VoidCallback onPressed;

  const _EyeToggle({required this.obscured, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: IconButton(
        onPressed: onPressed,
        tooltip: obscured ? 'Hiện mật khẩu' : 'Ẩn mật khẩu',
        icon: Icon(
          obscured ? Icons.visibility_off_outlined : Icons.visibility_outlined,
          color: AppTheme.textSecondary,
          size: 21,
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final bool busy;
  final VoidCallback onPressed;

  const _PrimaryButton({required this.label, required this.busy, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 52,
      child: FilledButton(
        onPressed: busy ? null : onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: _LoginScreenState._ctaColor,
          disabledBackgroundColor: _LoginScreenState._ctaColor.withValues(alpha: 0.6),
          foregroundColor: Colors.white,
          shape: const StadiumBorder(),
          elevation: 2,
          shadowColor: AppTheme.textPrimary.withValues(alpha: 0.2),
        ),
        child: busy
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    label,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(width: 10),
                  const Icon(Icons.arrow_forward_rounded, size: 20),
                ],
              ),
      ),
    );
  }
}

class _OrDivider extends StatelessWidget {
  const _OrDivider();

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    final line = Expanded(
      child: Container(height: 1, color: spec.primary.withValues(alpha: 0.3)),
    );
    return Row(
      children: [
        line,
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Text(
            'hoặc',
            style: TextStyle(color: spec.textSecondary, fontWeight: FontWeight.w700),
          ),
        ),
        line,
      ],
    );
  }
}

class _GoogleButton extends StatelessWidget {
  final VoidCallback? onPressed;

  const _GoogleButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    return SizedBox(
      height: 50,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: spec.background,
          foregroundColor: spec.textPrimary,
          shape: const StadiumBorder(),
          side: BorderSide(color: spec.primary.withValues(alpha: 0.7), width: 1.5),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(width: 20, height: 20, child: CustomPaint(painter: _GoogleLogoPainter())),
            SizedBox(width: 12),
            Text(
              'Tiếp tục với Google',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final String question;
  final String action;
  final VoidCallback? onTap;

  const _SwitchRow({required this.question, required this.action, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final spec = AppTheme.activeSpec;
    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        Text(
          question,
          style: TextStyle(color: spec.textSecondary, fontWeight: FontWeight.w600),
        ),
        TextButton(
          onPressed: onTap,
          style: TextButton.styleFrom(foregroundColor: spec.primary),
          child: Text(action, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

class _GoogleLogoPainter extends CustomPainter {
  const _GoogleLogoPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = size.width * 0.2;
    final rect = Offset.zero & size;
    final arcRect = rect.deflate(stroke / 2);
    double rad(double deg) => deg * math.pi / 180;
    Paint p(Color c) => Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;

    canvas.drawArc(arcRect, rad(-160), rad(115), false, p(const Color(0xFFEA4335)));
    canvas.drawArc(arcRect, rad(160), rad(40), false, p(const Color(0xFFFBBC05)));
    canvas.drawArc(arcRect, rad(45), rad(115), false, p(const Color(0xFF34A853)));
    canvas.drawArc(arcRect, rad(0), rad(45), false, p(const Color(0xFF4285F4)));
    canvas.drawLine(
      Offset(size.width / 2, size.height / 2),
      Offset(size.width - stroke / 2, size.height / 2),
      p(const Color(0xFF4285F4)),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PetalPainter extends CustomPainter {
  final double progress;

  _PetalPainter({required this.progress});

  static const int _count = 12;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.activeSpec.primaryMuted.withValues(alpha: 0.55);
    for (var i = 0; i < _count; i++) {
      final seed = i * 0.6180339;
      final speed = 0.7 + (i % 4) * 0.15;
      final phase = (progress * speed + seed) % 1.0;
      final baseX = ((seed * 7.31) % 1.0) * size.width;
      final sway = math.sin((phase * 2 + seed) * math.pi * 2) * 26;
      final x = baseX + sway;
      final y = phase * (size.height + 40) - 20;
      final scale = 0.7 + (i % 3) * 0.2;

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate((phase * 4 + seed) * math.pi);
      final w = 14 * scale;
      final h = 9 * scale;
      final petal = Path()
        ..moveTo(-w / 2, 0)
        ..quadraticBezierTo(-w / 2, -h, w / 2, -h / 2)
        ..quadraticBezierTo(w / 2, h, -w / 2, 0)
        ..close();
      canvas.drawPath(petal, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _PetalPainter oldDelegate) => oldDelegate.progress != progress;
}
