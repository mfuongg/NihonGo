import 'package:flutter/material.dart';

import '../../models/kanji.dart';
import '../../models/vocabulary.dart';
import '../../utils/theme.dart';

enum MapLearningMode { vocabulary, kanji }

extension MapLearningModeX on MapLearningMode {
  String get label => this == MapLearningMode.vocabulary ? 'Bản đồ Từ vựng' : 'Bản đồ Kanji';
  String get shortLabel => this == MapLearningMode.vocabulary ? 'Từ vựng' : 'Kanji';
  String get keyPrefix => this == MapLearningMode.vocabulary ? 'vocab' : 'kanji';
  Color get themeColor => this == MapLearningMode.vocabulary ? AppTheme.primary : AppTheme.accent;
}

enum WorldThemeStyle { oceanN5, techN4, travelN3, spaceN2, fairylandN1 }

/// Cấu hình dùng chung cho mỗi Thế giới bản đồ 10 Level (N5 -> N1).
class WorldConfig {
  final String jlptLevel;
  final WorldThemeStyle style;
  final String backgroundAsset;
  final double aspectRatio;
  final Color scaffoldBackground;
  final String vehicleKey;
  final List<Offset> nodeAnchors;
  final List<Offset> milestoneAnchors;
  final Offset? portalAuraAnchor;

  const WorldConfig({
    required this.jlptLevel,
    required this.style,
    required this.backgroundAsset,
    required this.aspectRatio,
    required this.scaffoldBackground,
    required this.vehicleKey,
    required this.nodeAnchors,
    this.milestoneAnchors = const [],
    this.portalAuraAnchor,
  });

  /// Thế giới 1: N5 — Đại dương huyền bí (`841×1870`).
  static const WorldConfig n5Ocean = WorldConfig(
    jlptLevel: 'N5',
    style: WorldThemeStyle.oceanN5,
    backgroundAsset: 'assets/images/map/n5_ocean_world_10nodes_bg.png',
    aspectRatio: 1870.0 / 841.0,
    scaffoldBackground: Color(0xFF7AD3F6),
    vehicleKey: 'map-cat-submarine',
    nodeAnchors: [
      Offset(0.585, 0.878), // Node 1: Bệ đá dưới cùng bên phải
      Offset(0.472, 0.792), // Node 2: Bệ đá thứ hai bên trái
      Offset(0.626, 0.712), // Node 3: Cạnh vỏ sò ngọc trai tím
      Offset(0.405, 0.640), // Node 4: Bên trái
      Offset(0.620, 0.572), // Node 5: Cạnh rương kho báu vàng
      Offset(0.496, 0.506), // Node 6: Bên trái
      Offset(0.692, 0.438), // Node 7: Bên phải
      Offset(0.495, 0.396), // Node 8: Cạnh xác tàu đắm
      Offset(0.720, 0.285), // Node 9: Bên phải trước thềm cung điện
      Offset(0.658, 0.233), // Node 10: Trước Cổng Đền Thờ Vỏ Sò
    ],
    milestoneAnchors: [
      Offset(0.530, 0.335),
    ],
  );

  /// Thế giới 2: N4 — Thành phố công nghệ (`841×1870`).
  static const WorldConfig n4Tech = WorldConfig(
    jlptLevel: 'N4',
    style: WorldThemeStyle.techN4,
    backgroundAsset: 'assets/images/map/n4_tech_world_10nodes_bg.png',
    aspectRatio: 1870.0 / 841.0,
    scaffoldBackground: Color(0xFFA8C8F8),
    vehicleKey: 'map-cat-hovercar',
    nodeAnchors: [
      Offset(0.620, 0.876), // Node 1: Khởi hành bên dưới màn hình mèo
      Offset(0.488, 0.788), // Node 2: Cạnh quả cầu hologram hành tinh
      Offset(0.635, 0.708), // Node 3: Khúc cua cây anh đào
      Offset(0.452, 0.624), // Node 4: Trên thác nước đôi
      Offset(0.612, 0.558), // Node 5: Giữa cầu công nghệ
      Offset(0.510, 0.495), // Node 6: Cạnh trạm nghiên cứu
      Offset(0.675, 0.430), // Node 7: Cạnh đài radar vệ tinh
      Offset(0.506, 0.388), // Node 8: Dưới đường tàu điện trên cao
      Offset(0.742, 0.283), // Node 9: Khúc cua lên đỉnh thành phố
      Offset(0.668, 0.232), // Node 10: Ngay trước Cổng Dịch Chuyển Tai Mèo
    ],
    milestoneAnchors: [
      Offset(0.578, 0.330),
    ],
    portalAuraAnchor: Offset(0.662, 0.168),
  );

  /// Thế giới 3: N3 — Du hành thế giới (`842×1868`).
  static const WorldConfig n3Travel = WorldConfig(
    jlptLevel: 'N3',
    style: WorldThemeStyle.travelN3,
    backgroundAsset: 'assets/images/map/n3_travel_world_10nodes_bg.png',
    aspectRatio: 1868.0 / 842.0,
    scaffoldBackground: Color(0xFF9ED4F7),
    vehicleKey: 'map-cat-biplane',
    nodeAnchors: [
      Offset(0.596, 0.878), // Node 1: Khởi hành cạnh hồ hoa súng & cối xay gió
      Offset(0.482, 0.792), // Node 2: Khúc cua cánh đồng hoa Tulip
      Offset(0.654, 0.718), // Node 3: Phía trên cối xay gió
      Offset(0.562, 0.650), // Node 4: Cạnh đấu trường Colosseum
      Offset(0.712, 0.580), // Node 5: Phía trên cầu đá cổ kính
      Offset(0.460, 0.545), // Node 6: Phía trên Colosseum
      Offset(0.712, 0.438), // Node 7: Cạnh tháp đồng hồ Big Ben & xe buýt 2 tầng
      Offset(0.525, 0.396), // Node 8: Cạnh tháp Eiffel & khinh khí cầu
      Offset(0.730, 0.283), // Node 9: Đèo hoa anh đào trên mây
      Offset(0.642, 0.231), // Node 10: Ngay trước Cổng Torii Núi Phú Sĩ
    ],
    milestoneAnchors: [
      Offset(0.512, 0.488),
      Offset(0.525, 0.336),
    ],
  );

  /// Thế giới 4: N2 — Vũ trụ vô tận (`841×1870`).
  static const WorldConfig n2Space = WorldConfig(
    jlptLevel: 'N2',
    style: WorldThemeStyle.spaceN2,
    backgroundAsset: 'assets/images/map/n2_space_world_10nodes_bg.png',
    aspectRatio: 1870.0 / 841.0,
    scaffoldBackground: Color(0xFF2B2D6E),
    vehicleKey: 'map-cat-ufo',
    nodeAnchors: [
      Offset(0.608, 0.875), // Node 1: Khởi hành chân dốc thiên thạch
      Offset(0.468, 0.785), // Node 2: Cạnh đài thiên văn kính viễn vọng
      Offset(0.630, 0.702), // Node 3: Cạnh trạm năng lượng mặt trời & radar
      Offset(0.460, 0.618), // Node 4: Khúc cua tinh thể thạch anh tím
      Offset(0.610, 0.545), // Node 5: Đường dốc ngân hà
      Offset(0.515, 0.476), // Node 6: Dưới trạm kính không gian
      Offset(0.625, 0.408), // Node 7: Cạnh bệ phóng tên lửa vũ trụ
      Offset(0.550, 0.340), // Node 8: Phía trên trạm kính không gian
      Offset(0.728, 0.282), // Node 9: Đỉnh dốc sao Thổ
      Offset(0.638, 0.228), // Node 10: Ngay trước Cổng Tinh Thể Vũ Trụ
    ],
  );

  /// Thế giới 5: N1 — Vương quốc thần tiên (`841×1870`).
  static const WorldConfig n1Fairyland = WorldConfig(
    jlptLevel: 'N1',
    style: WorldThemeStyle.fairylandN1,
    backgroundAsset: 'assets/images/map/n1_fairyland_10nodes_bg.png',
    aspectRatio: 1870.0 / 841.0,
    scaffoldBackground: Color(0xFFB8D4F8),
    vehicleKey: 'map-cat-cloudboat',
    nodeAnchors: [
      Offset(0.612, 0.878), // Node 1: Khởi hành chân cầu mây
      Offset(0.478, 0.792), // Node 2: Cạnh cổng vòm hoa thần tiên
      Offset(0.630, 0.712), // Node 3: Thềm mây ánh sao
      Offset(0.462, 0.638), // Node 4: Khúc cua thác mây
      Offset(0.624, 0.566), // Node 5: Cạnh đài cầu pha lê
      Offset(0.530, 0.500), // Node 6: Dưới tượng Kỳ lân Pegasus
      Offset(0.700, 0.432), // Node 7: Cầu mây thiên giới
      Offset(0.526, 0.396), // Node 8: Phía trên tượng Kỳ lân Pegasus
      Offset(0.726, 0.285), // Node 9: Đèo hoa anh đào cầu vồng
      Offset(0.650, 0.238), // Node 10: Ngay trước Cổng Lâu Đài Pha Lê
    ],
    milestoneAnchors: [
      Offset(0.545, 0.340),
    ],
  );

  static WorldConfig forLevel(String level) {
    switch (level.toUpperCase()) {
      case 'N4':
        return n4Tech;
      case 'N3':
        return n3Travel;
      case 'N2':
        return n2Space;
      case 'N1':
        return n1Fairyland;
      case 'N5':
      default:
        return n5Ocean;
    }
  }
}

class JlptWorld {
  final int number;
  final String level;
  final String name;
  final String tagline;
  final List<Color> gradient;
  final IconData icon;
  final bool isBuilt;
  final WorldConfig config;

  const JlptWorld({
    required this.number,
    required this.level,
    required this.name,
    required this.tagline,
    required this.gradient,
    required this.icon,
    required this.isBuilt,
    required this.config,
  });

  static const List<JlptWorld> all = [
    JlptWorld(
      number: 1,
      level: 'N5',
      name: 'Đại dương huyền bí',
      tagline: 'Rạn san hô & ngọc trai',
      gradient: [Color(0xFFD8F0F0), Color(0xFF9FD3DA)],
      icon: Icons.waves_rounded,
      isBuilt: true,
      config: WorldConfig.n5Ocean,
    ),
    JlptWorld(
      number: 2,
      level: 'N4',
      name: 'Thành phố công nghệ',
      tagline: 'Đèn neon & cổng dịch chuyển',
      gradient: [Color(0xFFE6E4F4), Color(0xFFB9B4DE)],
      icon: Icons.memory_rounded,
      isBuilt: true,
      config: WorldConfig.n4Tech,
    ),
    JlptWorld(
      number: 3,
      level: 'N3',
      name: 'Du hành thế giới',
      tagline: 'Kỳ quan & cổng Torii Phú Sĩ',
      gradient: [Color(0xFFF7E9DC), Color(0xFFE7C3A4)],
      icon: Icons.flight_takeoff_rounded,
      isBuilt: true,
      config: WorldConfig.n3Travel,
    ),
    JlptWorld(
      number: 4,
      level: 'N2',
      name: 'Vũ trụ vô tận',
      tagline: 'Tinh vân & cổng tinh thể',
      gradient: [Color(0xFFDCE3F2), Color(0xFF9EAAD3)],
      icon: Icons.rocket_launch_rounded,
      isBuilt: true,
      config: WorldConfig.n2Space,
    ),
    JlptWorld(
      number: 5,
      level: 'N1',
      name: 'Vương quốc thần tiên',
      tagline: 'Mây cầu vồng & lâu đài pha lê',
      gradient: [Color(0xFFF3E3EC), Color(0xFFD7AFC6)],
      icon: Icons.auto_awesome_rounded,
      isBuilt: true,
      config: WorldConfig.n1Fairyland,
    ),
  ];
}

/// Một nút màn chơi trên bản đồ, dựng từ dữ liệu thật đã nạp từ kho `verified_v2`.
class MapLevel {
  final String key;
  final int number;
  final String title;
  final String topic;
  final List<VocabularyWord> words;
  final List<String> kanji;
  final List<String> kanjiIds;

  const MapLevel({
    required this.key,
    required this.number,
    required this.title,
    required this.topic,
    required this.words,
    this.kanji = const [],
    this.kanjiIds = const [],
  });
}

class MapLevelCatalog {
  MapLevelCatalog._();

  static const int maxLevels = 10;
  static const int wordsPerLevel = 12;
  static const int kanjiPerLevel = 8;
  static const int quizQuestions = 10;

  static const List<String> _categoryOrder = [
    'nouns',
    'verbs',
    'adjectives',
    'common',
    'pronouns',
    'general',
  ];

  static const Map<String, String> _categoryLabels = {
    'nouns': 'Danh từ',
    'verbs': 'Động từ',
    'adjectives': 'Tính từ',
    'common': 'Phó từ & Thán từ',
    'pronouns': 'Đại từ & Từ chỉ định',
    'general': 'Tổng hợp',
  };

  static String levelKey(MapLearningMode mode, String jlpt, int number) =>
      '${mode.keyPrefix}:$jlpt:$number';

  static List<MapLevel> build({
    required MapLearningMode mode,
    required String jlpt,
    required List<VocabularyWord> allWords,
    required List<KanjiItem> allKanji,
  }) {
    final levelWords = allWords.where((w) => w.jlptLevel == jlpt && w.japanese.isNotEmpty).toList()
      ..sort((a, b) => a.id.compareTo(b.id));
    return mode == MapLearningMode.vocabulary
        ? _buildVocabulary(jlpt, levelWords)
        : _buildKanji(jlpt, levelWords, allKanji);
  }

  static List<MapLevel> _buildVocabulary(String jlpt, List<VocabularyWord> words) {
    final byCategory = <String, List<VocabularyWord>>{};
    for (final w in words) {
      final cat = _categoryLabels.containsKey(w.category) ? w.category : 'general';
      (byCategory[cat] ??= []).add(w);
    }

    final queues = <String, List<List<VocabularyWord>>>{};
    for (final cat in _categoryOrder) {
      final list = byCategory[cat];
      if (list == null || list.isEmpty) continue;
      final chunks = <List<VocabularyWord>>[];
      for (var i = 0; i < list.length; i += wordsPerLevel) {
        final chunk = list.sublist(i, (i + wordsPerLevel).clamp(0, list.length));
        if (chunk.length >= 4) chunks.add(chunk);
      }
      if (chunks.isNotEmpty) queues[cat] = chunks;
    }

    final levels = <MapLevel>[];
    final partCounter = <String, int>{};
    while (levels.length < maxLevels && queues.values.any((q) => q.isNotEmpty)) {
      for (final cat in _categoryOrder) {
        final queue = queues[cat];
        if (queue == null || queue.isEmpty) continue;
        if (levels.length >= maxLevels) break;
        final part = (partCounter[cat] ?? 0) + 1;
        partCounter[cat] = part;
        final number = levels.length + 1;
        final label = _categoryLabels[cat]!;
        levels.add(MapLevel(
          key: levelKey(MapLearningMode.vocabulary, jlpt, number),
          number: number,
          title: 'Bài $number: $label $part',
          topic: label,
          words: queue.removeAt(0),
        ));
      }
    }
    return levels;
  }

  static List<MapLevel> _buildKanji(
    String jlpt,
    List<VocabularyWord> words,
    List<KanjiItem> allKanji,
  ) {
    final kanji = allKanji.where((k) => k.jlptLevel == jlpt && k.kanji.isNotEmpty).toList()
      ..sort((a, b) {
        final byStroke = a.strokeCount.compareTo(b.strokeCount);
        return byStroke != 0 ? byStroke : a.kanji.compareTo(b.kanji);
      });

    final levels = <MapLevel>[];
    for (var i = 0; i < kanji.length && levels.length < maxLevels; i += kanjiPerLevel) {
      final group = kanji.sublist(i, (i + kanjiPerLevel).clamp(0, kanji.length));
      final chars = group.map((k) => k.kanji).toList();
      final related = words
          .where((w) => chars.any((c) => w.japanese.contains(c)))
          .take(15)
          .toList();
      final cards = <VocabularyWord>[...related];
      if (cards.length < kanjiPerLevel) {
        for (final k in group) {
          if (cards.any((w) => w.japanese == k.kanji)) continue;
          cards.add(VocabularyWord(
            id: k.id,
            japanese: k.kanji,
            hiragana: k.kunyomi.isNotEmpty ? k.kunyomi : k.onyomi,
            romaji: k.onyomi,
            vietnamese: k.vietnamese,
            english: k.english,
            jlptLevel: jlpt,
            category: 'kanji',
          ));
        }
      }
      final number = levels.length + 1;
      levels.add(MapLevel(
        key: levelKey(MapLearningMode.kanji, jlpt, number),
        number: number,
        title: 'Quyển $number: ${chars.take(4).join(' ')}${chars.length > 4 ? '…' : ''}',
        topic: 'Chữ Hán',
        words: cards,
        kanji: chars,
        kanjiIds: group.map((k) => k.id).toList(),
      ));
    }
    return levels;
  }

  /// 10/10: 3 sao · 8–9: 2 sao · 6–7: 1 sao (quy đổi theo tỉ lệ nếu ít hơn 10 câu).
  static int starsForScore(int score, int total) {
    if (total <= 0) return 0;
    final ratio = score / total;
    if (ratio >= 1) return 3;
    if (ratio >= 0.8) return 2;
    if (ratio >= 0.6) return 1;
    return 0;
  }
}
