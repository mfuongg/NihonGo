import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/kanji_data.dart';
import '../../models/kanji.dart';
import '../../models/vocabulary.dart';
import '../../providers/progress_provider.dart';
import '../../providers/vocabulary_provider.dart';
import '../../services/local_database_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../vocabulary/flashcard_screen.dart';
import '../vocabulary/vocabulary_quiz_screen.dart';
import 'map_level_catalog.dart';

export 'map_level_catalog.dart' show MapLearningMode, WorldConfig, WorldThemeStyle;

typedef WorldMapScreen = WorldRoadmapScreen;

/// Tải dữ liệu từ vựng & kanji đã xác minh, dùng chung cho cổng và bản đồ.
mixin _MapDataLoader<T extends StatefulWidget> on State<T> {
  List<KanjiItem> kanji = const [];
  bool loadingData = true;

  Future<void> loadMapData() async {
    final vocab = context.read<VocabularyProvider>();
    await vocab.ensureLoaded();
    if (KanjiData.getAllKanji().isEmpty) {
      try {
        await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      kanji = KanjiData.getAllKanji();
      loadingData = false;
    });
  }
}

// ---------------------------------------------------------------------------
// MAP-01 · Cổng 5 thế giới
// ---------------------------------------------------------------------------

class WorldGateScreen extends StatefulWidget {
  final MapLearningMode initialMode;

  const WorldGateScreen({super.key, this.initialMode = MapLearningMode.vocabulary});

  @override
  State<WorldGateScreen> createState() => _WorldGateScreenState();
}

class _WorldGateScreenState extends State<WorldGateScreen> with _MapDataLoader {
  late MapLearningMode _mode = widget.initialMode;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => loadMapData());
  }

  void _openWorld(JlptWorld world, ProgressProvider progress) {
    if (!progress.isWorldUnlocked(world.isBuilt)) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text('Thế giới ${world.number} sẽ mở trong bản cập nhật tới')));
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => WorldRoadmapScreen(world: world, initialMode: _mode)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = context.watch<ProgressProvider>();
    final vocab = context.watch<VocabularyProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.background,
        surfaceTintColor: Colors.transparent,
        title: const Text('Chọn thế giới', style: TextStyle(fontWeight: FontWeight.w800)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          Center(
            child: _ModeToggle(mode: _mode, onChanged: (m) => setState(() => _mode = m)),
          ),
          const SizedBox(height: 16),
          for (final world in JlptWorld.all)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: _WorldPortalCard(
                key: ValueKey('world-gate-card-${world.level}'),
                world: world,
                mode: _mode,
                levels: progress.isWorldUnlocked(world.isBuilt) && !loadingData
                    ? MapLevelCatalog.build(
                        mode: _mode,
                        jlpt: world.level,
                        allWords: vocab.allWords,
                        allKanji: kanji,
                      )
                    : const [],
                progress: progress,
                onTap: () => _openWorld(world, progress),
              ),
            ),
        ],
      ),
    );
  }
}

class _WorldPortalCard extends StatelessWidget {
  final JlptWorld world;
  final MapLearningMode mode;
  final List<MapLevel> levels;
  final ProgressProvider progress;
  final VoidCallback onTap;

  const _WorldPortalCard({
    super.key,
    required this.world,
    required this.mode,
    required this.levels,
    required this.progress,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final earned = levels.fold<int>(0, (sum, l) => sum + progress.mapStarsFor(l.key));
    final maxStars = levels.length * 3;
    final locked = !progress.isWorldUnlocked(world.isBuilt);
    final adminUnlocked = !world.isBuilt && progress.isAdminMode;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: locked
                  ? world.gradient.map((c) => Color.lerp(c, const Color(0xFFE9E5E6), 0.55)!).toList()
                  : world.gradient,
            ),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.75),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  locked ? Icons.lock_rounded : world.icon,
                  size: 32,
                  color: locked ? AppTheme.textSecondary : const Color(0xFF3F7F8C),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Thế giới ${world.number} · ${world.level}',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textSecondary),
                        ),
                        if (adminUnlocked) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.78),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              'Admin',
                              style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: AppTheme.accent),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      world.name,
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      world.tagline,
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                    ),
                    if (!locked && maxStars > 0) ...[
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, size: 18, color: Color(0xFFE9B949)),
                          const SizedBox(width: 3),
                          Text(
                            '$earned / $maxStars',
                            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(999),
                              child: LinearProgressIndicator(
                                value: earned / maxStars,
                                minHeight: 6,
                                backgroundColor: Colors.white.withValues(alpha: 0.6),
                                valueColor: AlwaysStoppedAnimation(mode.themeColor),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              locked
                  ? Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.7),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'Sắp mở',
                        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppTheme.textSecondary),
                      ),
                    )
                  : Icon(Icons.chevron_right_rounded, color: AppTheme.textPrimary),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// MAP-02 · Bản đồ 10 Level dùng chung (N5 Đại dương, N4 Công nghệ, N3 Du hành)
// ---------------------------------------------------------------------------

class WorldRoadmapScreen extends StatefulWidget {
  final JlptWorld world;
  final MapLearningMode initialMode;
  final WorldConfig? configOverride;

  const WorldRoadmapScreen({
    super.key,
    required this.world,
    this.initialMode = MapLearningMode.vocabulary,
    this.configOverride,
  });

  WorldConfig get effectiveConfig => configOverride ?? world.config;

  @override
  State<WorldRoadmapScreen> createState() => _WorldRoadmapScreenState();
}

enum _NodeState { locked, current, unlocked, completed }

class _WorldRoadmapScreenState extends State<WorldRoadmapScreen>
    with _MapDataLoader, TickerProviderStateMixin {
  late MapLearningMode _mode = widget.initialMode;
  late final AnimationController _ambient =
      AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..repeat(reverse: true);
  final ScrollController _scroll = ScrollController();
  bool _didAutoScroll = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => loadMapData());
  }

  @override
  void dispose() {
    _ambient.dispose();
    _pulse.dispose();
    _scroll.dispose();
    super.dispose();
  }

  List<MapLevel> _levels(List<VocabularyWord> allWords) => MapLevelCatalog.build(
        mode: _mode,
        jlpt: widget.world.level,
        allWords: allWords,
        allKanji: kanji,
      );

  List<_NodeState> _states(List<MapLevel> levels, ProgressProvider progress) {
    final states = <_NodeState>[];
    var currentAssigned = false;
    for (var i = 0; i < levels.length; i++) {
      final stars = progress.mapStarsFor(levels[i].key);
      final unlocked = progress.isMapLevelUnlocked(
        index: i,
        previousLevelKey: i > 0 ? levels[i - 1].key : null,
      );
      if (!unlocked) {
        states.add(_NodeState.locked);
      } else if (stars > 0) {
        states.add(_NodeState.completed);
      } else if (!currentAssigned) {
        states.add(_NodeState.current);
        currentAssigned = true;
      } else {
        states.add(_NodeState.unlocked);
      }
    }
    return states;
  }

  void _switchMode(MapLearningMode mode) {
    if (mode == _mode) return;
    setState(() {
      _mode = mode;
      _didAutoScroll = false;
    });
  }

  Offset _pedestalCenter(WorldConfig config, int index, double width, double mapHeight) {
    final anchors = config.nodeAnchors;
    if (index >= 0 && index < anchors.length) {
      final a = anchors[index];
      return Offset(width * a.dx, mapHeight * a.dy);
    }
    final t = (index + 1) / (anchors.length + 1);
    return Offset(width * 0.5, mapHeight * (1.0 - t));
  }

  void _autoScrollTo(double nodeY, double mapHeight, double viewport) {
    if (_didAutoScroll || !_scroll.hasClients) return;
    _didAutoScroll = true;
    final fromBottom = mapHeight - nodeY;
    final target = (fromBottom - viewport * 0.42).clamp(0.0, _scroll.position.maxScrollExtent);
    _scroll.jumpTo(target);
  }

  Future<void> _openDetail(MapLevel level, _NodeState state, List<VocabularyWord> levelPool) async {
    if (state == _NodeState.locked) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Đạt ít nhất 1 sao ở bài trước để mở khóa')));
      return;
    }
    final action = await showModalBottomSheet<_LevelAction>(
      context: context,
      backgroundColor: AppTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => _LevelDetailSheet(level: level, mode: _mode, jlpt: widget.world.level),
    );
    if (!mounted || action == null) return;
    action == _LevelAction.practice ? _startPractice(level) : _startQuiz(level, levelPool);
  }

  void _startPractice(MapLevel level) {
    final progress = context.read<ProgressProvider>();
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FlashcardScreen(
        level: widget.world.level,
        words: level.words,
        title: level.title,
        onSessionComplete: (known, total) async {
          final rewarded = await progress.completeMapPractice(level.key);
          if (rewarded) {
            messenger.showSnackBar(
              SnackBar(content: Text('Hoàn thành ${level.title} · +${ProgressProvider.mapPracticeRewardCoins} Coin')),
            );
          }
        },
      ),
    ));
  }

  void _startQuiz(MapLevel level, List<VocabularyWord> levelPool) {
    final progress = context.read<ProgressProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final isKanji = _mode == MapLearningMode.kanji;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VocabularyQuizScreen(
        level: widget.world.level,
        words: level.words,
        questionLimit: MapLevelCatalog.quizQuestions,
        distractorPool: levelPool,
        title: 'Kiểm tra · ${level.title}',
        onFinished: (score, total) async {
          final stars = MapLevelCatalog.starsForScore(score, total);
          final previous = progress.mapStarsFor(level.key);
          await progress.recordMapLevelStars(level.key, stars);
          if (isKanji && stars > 0) {
            for (final id in level.kanjiIds) {
              progress.markKanjiLearned(id);
            }
          }
          messenger.showSnackBar(SnackBar(
            content: Text(
              stars == 0
                  ? 'Cần đúng ít nhất 60% để vượt level'
                  : previous == 0
                      ? 'Vượt level với $stars sao! Bài tiếp theo đã mở'
                      : 'Đạt $stars sao',
            ),
          ));
        },
      ),
    ));
  }

  Widget _buildAmbientOverlay(WorldConfig config) {
    switch (config.style) {
      case WorldThemeStyle.oceanN5:
        return UnderwaterBubblesOverlay(animation: _ambient);
      case WorldThemeStyle.techN4:
        return HoloTechParticlesOverlay(animation: _ambient);
      case WorldThemeStyle.travelN3:
        return DriftingSakuraPetalsOverlay(animation: _ambient);
      case WorldThemeStyle.spaceN2:
        return CosmicStardustOverlay(animation: _ambient);
      case WorldThemeStyle.fairylandN1:
        return FairyDustSparklesOverlay(animation: _ambient);
    }
  }

  Widget _buildGuardianVehicle(WorldConfig config, bool flipHorizontal) {
    switch (config.style) {
      case WorldThemeStyle.oceanN5:
        return _CatSubmarine(animation: _ambient, flipHorizontal: flipHorizontal);
      case WorldThemeStyle.techN4:
        return _CatHoverPod(animation: _ambient, flipHorizontal: flipHorizontal);
      case WorldThemeStyle.travelN3:
        return _CatAviatorBiplane(animation: _ambient, flipHorizontal: flipHorizontal);
      case WorldThemeStyle.spaceN2:
        return _CatCosmicUfo(animation: _ambient, flipHorizontal: flipHorizontal);
      case WorldThemeStyle.fairylandN1:
        return _CatCelestialCloudBoat(animation: _ambient, flipHorizontal: flipHorizontal);
    }
  }

  @override
  Widget build(BuildContext context) {
    final config = widget.effectiveConfig;
    final progress = context.watch<ProgressProvider>();
    final vocab = context.watch<VocabularyProvider>();
    final levels = loadingData ? const <MapLevel>[] : _levels(vocab.allWords);
    final states = _states(levels, progress);
    final levelPool = vocab.allWords.where((w) => w.jlptLevel == widget.world.level).toList();
    final earned = levels.fold<int>(0, (sum, l) => sum + progress.mapStarsFor(l.key));

    return Scaffold(
      backgroundColor: config.scaffoldBackground,
      body: Stack(
        children: [
          Positioned.fill(
            child: LayoutBuilder(
              builder: (context, constraints) {
                if (loadingData) {
                  return const Center(child: CircularProgressIndicator(color: Colors.white));
                }
                if (levels.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text('Chưa có dữ liệu cho bản đồ này', textAlign: TextAlign.center),
                    ),
                  );
                }

                final width = constraints.maxWidth;
                final mapHeight = math.max(
                  constraints.maxHeight,
                  width * config.aspectRatio,
                );
                final centers = [
                  for (var i = 0; i < levels.length; i++)
                    _pedestalCenter(config, i, width, mapHeight),
                ];
                final currentIndex = states.indexOf(_NodeState.current);
                final focusIndex = currentIndex >= 0
                    ? currentIndex
                    : math.max(0, states.lastIndexWhere((s) => s == _NodeState.completed));

                WidgetsBinding.instance.addPostFrameCallback(
                  (_) => _autoScrollTo(centers[focusIndex].dy, mapHeight, constraints.maxHeight),
                );

                return SingleChildScrollView(
                  key: ValueKey('world-roadmap-scroll-${widget.world.level}'),
                  controller: _scroll,
                  reverse: true,
                  child: SizedBox(
                    width: width,
                    height: mapHeight,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        // Lớp 1: Nền tranh nghệ thuật 10 bệ đá ngôi sao (BoxFit.fitWidth)
                        Positioned.fill(
                          child: Image.asset(
                            config.backgroundAsset,
                            width: width,
                            height: mapHeight,
                            fit: BoxFit.fitWidth,
                            alignment: Alignment.topCenter,
                            filterQuality: FilterQuality.medium,
                          ),
                        ),

                        // Hào quang xoay nhẹ tại Cổng Dịch Chuyển Tai Mèo (Thế giới N4)
                        if (config.portalAuraAnchor != null)
                          Positioned(
                            left: width * config.portalAuraAnchor!.dx - 74,
                            top: mapHeight * config.portalAuraAnchor!.dy - 74,
                            width: 148,
                            height: 148,
                            child: IgnorePointer(
                              child: _TeleportPortalAura(animation: _ambient),
                            ),
                          ),

                        // Lớp 2: Hiệu ứng môi trường chuyển động (Bong bóng N5 / Hạt Holo N4 / Hoa anh đào N3)
                        Positioned.fill(
                          child: _buildAmbientOverlay(config),
                        ),

                        // Trạm trang trí phụ trên bệ đá trung gian (đảm bảo không bệ đá nào bị bỏ trống)
                        for (var m = 0; m < config.milestoneAnchors.length; m++)
                          Positioned(
                            left: width * config.milestoneAnchors[m].dx - 32,
                            top: mapHeight * config.milestoneAnchors[m].dy - 32,
                            width: 64,
                            height: 64,
                            child: IgnorePointer(
                              child: _WorldMilestoneOrnament(style: config.style, pulse: _pulse),
                            ),
                          ),

                        // Lớp 3: Ghim 10 Level Node tương tác trên 10 bệ đá ngôi sao
                        for (var i = 0; i < levels.length; i++)
                          Positioned(
                            left: centers[i].dx - 48,
                            top: centers[i].dy - 48,
                            width: 96,
                            height: 96,
                            child: _PedestalLevelNode(
                              key: ValueKey('map-node-${levels[i].number}'),
                              level: levels[i],
                              state: states[i],
                              stars: progress.mapStarsFor(levels[i].key),
                              mode: _mode,
                              pulse: _pulse,
                              onTap: () => _openDetail(levels[i], states[i], levelPool),
                            ),
                          ),

                        // Phương tiện Mèo Hộ Pháp bơi/bay nhấp nhô cạnh bài học hiện tại (hoặc đỉnh bản đồ khi đã full sao)
                        if (focusIndex >= 0 && focusIndex < centers.length)
                          Positioned(
                            key: ValueKey(config.vehicleKey),
                            left: (centers[focusIndex].dx > width * 0.54
                                    ? centers[focusIndex].dx - 114
                                    : centers[focusIndex].dx + 34)
                                .clamp(8.0, width - 92.0),
                            top: centers[focusIndex].dy - 54,
                            child: IgnorePointer(
                              child: _buildGuardianVehicle(
                                config,
                                centers[focusIndex].dx <= width * 0.54,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Lớp 4: Thanh Header điều hướng nổi phía trên
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: _MapTopBar(
              world: widget.world,
              mode: _mode,
              earned: earned,
              maxStars: levels.length * 3,
              onModeChanged: _switchMode,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Lớp 2A · UnderwaterBubblesOverlay (Thế giới 1: N5 Đại dương)
// ---------------------------------------------------------------------------

class UnderwaterBubblesOverlay extends StatelessWidget {
  final Animation<double> animation;

  const UnderwaterBubblesOverlay({super.key, required this.animation});

  static final List<_BubbleParticle> _particles = _generateParticles(22);

  static List<_BubbleParticle> _generateParticles(int count) {
    final rng = math.Random(202605);
    return List<_BubbleParticle>.generate(count, (i) {
      final baseX = (i + 0.35) / count;
      final jitterX = (rng.nextDouble() - 0.5) * 0.06;
      return _BubbleParticle(
        xFraction: (baseX + jitterX).clamp(0.05, 0.95),
        phase: rng.nextDouble(),
        speedMultiplier: 1 + (i % 3),
        diameter: 4.0 + rng.nextDouble() * 12.0,
        opacity: 0.22 + rng.nextDouble() * 0.38,
        wobblePixels: 5.0 + rng.nextDouble() * 11.0,
        wobbleCycles: 1 + (i % 3),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animation,
          builder: (_, __) => CustomPaint(
            painter: _UnderwaterBubblesPainter(
              progress: animation.value,
              particles: _particles,
            ),
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

class _BubbleParticle {
  final double xFraction;
  final double phase;
  final int speedMultiplier;
  final double diameter;
  final double opacity;
  final double wobblePixels;
  final int wobbleCycles;

  const _BubbleParticle({
    required this.xFraction,
    required this.phase,
    required this.speedMultiplier,
    required this.diameter,
    required this.opacity,
    required this.wobblePixels,
    required this.wobbleCycles,
  });
}

class _UnderwaterBubblesPainter extends CustomPainter {
  final double progress;
  final List<_BubbleParticle> particles;

  const _UnderwaterBubblesPainter({
    required this.progress,
    required this.particles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final fillPaint = Paint()..style = PaintingStyle.fill;
    final rimPaint = Paint()..style = PaintingStyle.stroke;
    final highlightPaint = Paint()..style = PaintingStyle.fill;

    for (final p in particles) {
      final life = (progress * p.speedMultiplier + p.phase) % 1.0;
      final y = size.height * (0.98 - life * 0.94);
      final sineWave = math.sin((life * p.wobbleCycles + p.phase) * math.pi * 2);
      final x = (size.width * p.xFraction + sineWave * p.wobblePixels).clamp(8.0, size.width - 8.0);

      double alpha = p.opacity;
      double radius = p.diameter * 0.5;
      if (life < 0.08) {
        alpha *= (life / 0.08).clamp(0.0, 1.0);
      } else if (life > 0.88) {
        final popT = (life - 0.88) / 0.12;
        alpha *= (1.0 - popT).clamp(0.0, 1.0);
        radius *= (1.0 + popT * 0.45);
      }

      final center = Offset(x, y);
      fillPaint.color = Colors.white.withValues(alpha: (alpha * 0.42).clamp(0.0, 1.0));
      rimPaint
        ..color = Colors.white.withValues(alpha: alpha.clamp(0.0, 1.0))
        ..strokeWidth = radius > 5 ? 1.5 : 1.1;

      canvas.drawCircle(center, radius, fillPaint);
      canvas.drawCircle(center, radius, rimPaint);

      if (radius >= 3.2 && life <= 0.92) {
        highlightPaint.color = Colors.white.withValues(alpha: (alpha * 1.15).clamp(0.0, 0.85));
        canvas.drawCircle(
          center.translate(-radius * 0.34, -radius * 0.34),
          math.max(1.1, radius * 0.24),
          highlightPaint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _UnderwaterBubblesPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ---------------------------------------------------------------------------
// Lớp 2B · HoloTechParticlesOverlay (Thế giới 2: N4 Thành phố công nghệ)
// ---------------------------------------------------------------------------

class HoloTechParticlesOverlay extends StatelessWidget {
  final Animation<double> animation;

  const HoloTechParticlesOverlay({super.key, required this.animation});

  static final List<_HoloTechMote> _motes = _generateMotes(24);

  static List<_HoloTechMote> _generateMotes(int count) {
    final rng = math.Random(202604);
    const colors = [
      Color(0xFFA0E7E5), // Xanh điện neon pastel
      Color(0xFFD8B4F8), // Tím lavender neon pastel
      Color(0xFFB8F2E6), // Mint phát sáng
      Color(0xFFE5CFF7), // Tím hồng ánh kim
    ];
    return List<_HoloTechMote>.generate(count, (i) {
      return _HoloTechMote(
        startX: 0.06 + rng.nextDouble() * 0.88,
        startY: 0.06 + rng.nextDouble() * 0.88,
        driftX: (rng.nextDouble() > 0.5 ? 1 : -1) * (0.06 + rng.nextDouble() * 0.08),
        driftY: -(0.18 + rng.nextDouble() * 0.25),
        phase: rng.nextDouble(),
        speed: 1 + (i % 2),
        size: 3.0 + rng.nextDouble() * 5.0, // 3px – 8px
        color: colors[i % colors.length],
        isDiamond: i % 3 == 0,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animation,
          builder: (_, __) => CustomPaint(
            painter: _HoloTechParticlesPainter(
              progress: animation.value,
              motes: _motes,
            ),
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

class _HoloTechMote {
  final double startX;
  final double startY;
  final double driftX;
  final double driftY;
  final double phase;
  final int speed;
  final double size;
  final Color color;
  final bool isDiamond;

  const _HoloTechMote({
    required this.startX,
    required this.startY,
    required this.driftX,
    required this.driftY,
    required this.phase,
    required this.speed,
    required this.size,
    required this.color,
    required this.isDiamond,
  });
}

class _HoloTechParticlesPainter extends CustomPainter {
  final double progress;
  final List<_HoloTechMote> motes;

  const _HoloTechParticlesPainter({
    required this.progress,
    required this.motes,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final glowPaint = Paint()..style = PaintingStyle.fill;
    final corePaint = Paint()..style = PaintingStyle.fill;

    for (final m in motes) {
      final life = (progress * m.speed + m.phase) % 1.0;
      final fx = (m.startX + m.driftX * life) % 1.0;
      final fy = (m.startY + m.driftY * life + 1.0) % 1.0;
      final x = (fx < 0 ? fx + 1.0 : fx) * size.width;
      final y = fy * size.height;

      // Nhấp nháy phát sáng (twinkle 60fps)
      final twinkle = 0.45 + 0.55 * (0.5 + 0.5 * math.sin((progress * 6 + m.phase) * math.pi * 2));
      final edgeFade = life < 0.12
          ? life / 0.12
          : life > 0.88
              ? (1.0 - life) / 0.12
              : 1.0;
      final alpha = (twinkle * edgeFade).clamp(0.0, 1.0);
      final center = Offset(x, y);
      final radius = m.size * 0.5 * (0.85 + 0.3 * twinkle);

      glowPaint.color = m.color.withValues(alpha: (alpha * 0.45).clamp(0.0, 1.0));
      canvas.drawCircle(center, radius * 2.4, glowPaint);

      corePaint.color = m.color.withValues(alpha: (alpha * 0.92).clamp(0.0, 1.0));
      if (m.isDiamond) {
        final r = radius * 1.35;
        final path = Path()
          ..moveTo(center.dx, center.dy - r)
          ..lineTo(center.dx + r * 0.72, center.dy)
          ..lineTo(center.dx, center.dy + r)
          ..lineTo(center.dx - r * 0.72, center.dy)
          ..close();
        canvas.drawPath(path, corePaint);
      } else {
        canvas.drawCircle(center, radius, corePaint);
      }

      corePaint.color = Colors.white.withValues(alpha: (alpha * 0.85).clamp(0.0, 1.0));
      canvas.drawCircle(center, radius * 0.42, corePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _HoloTechParticlesPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _TeleportPortalAura extends StatelessWidget {
  final Animation<double> animation;

  const _TeleportPortalAura({required this.animation});

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: animation,
        builder: (_, __) => CustomPaint(
          painter: _TeleportPortalAuraPainter(progress: animation.value),
        ),
      ),
    );
  }
}

class _TeleportPortalAuraPainter extends CustomPainter {
  final double progress;

  const _TeleportPortalAuraPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.5);
    final angle = progress * math.pi * 2 * 2;
    final pulse = 0.5 + 0.5 * math.sin(angle * 2);

    final glowPaint = Paint()
      ..color = const Color(0xFFA0E7E5).withValues(alpha: 0.18 + 0.10 * pulse)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, size.width * 0.42, glowPaint);

    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    final rect = Rect.fromCircle(center: Offset.zero, radius: size.width * 0.40);
    for (var i = 0; i < 4; i++) {
      arcPaint.color = (i.isEven ? const Color(0xFFA0E7E5) : const Color(0xFFD8B4F8))
          .withValues(alpha: 0.72);
      canvas.drawArc(rect, i * math.pi * 0.5, math.pi * 0.28, false, arcPaint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _TeleportPortalAuraPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ---------------------------------------------------------------------------
// Lớp 2C · DriftingSakuraPetalsOverlay (Thế giới 3: N3 Du hành thế giới)
// ---------------------------------------------------------------------------

class DriftingSakuraPetalsOverlay extends StatelessWidget {
  final Animation<double> animation;

  const DriftingSakuraPetalsOverlay({super.key, required this.animation});

  static final List<_SakuraPetalParticle> _petals = _generatePetals(18);

  static List<_SakuraPetalParticle> _generatePetals(int count) {
    final rng = math.Random(202603);
    const colors = [
      Color(0xFFFFB7B2),
      Color(0xFFFFC0CB),
      Color(0xFFFFD1DC),
      Color(0xFFF8BBD0),
    ];
    return List<_SakuraPetalParticle>.generate(count, (i) {
      return _SakuraPetalParticle(
        xFraction: 0.05 + (i + 0.4) / count * 0.90,
        phase: rng.nextDouble(),
        speed: 1 + (i % 2),
        length: 8.0 + rng.nextDouble() * 6.0,
        swayPixels: 14.0 + rng.nextDouble() * 18.0,
        swayCycles: 1 + (i % 3),
        spinCycles: (i.isEven ? 1 : -1) * (1 + (i % 2)),
        color: colors[i % colors.length],
        opacity: 0.58 + rng.nextDouble() * 0.30,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animation,
          builder: (_, __) => CustomPaint(
            painter: _DriftingSakuraPetalsPainter(
              progress: animation.value,
              petals: _petals,
            ),
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

class _SakuraPetalParticle {
  final double xFraction;
  final double phase;
  final int speed;
  final double length;
  final double swayPixels;
  final int swayCycles;
  final int spinCycles;
  final Color color;
  final double opacity;

  const _SakuraPetalParticle({
    required this.xFraction,
    required this.phase,
    required this.speed,
    required this.length,
    required this.swayPixels,
    required this.swayCycles,
    required this.spinCycles,
    required this.color,
    required this.opacity,
  });
}

class _DriftingSakuraPetalsPainter extends CustomPainter {
  final double progress;
  final List<_SakuraPetalParticle> petals;

  const _DriftingSakuraPetalsPainter({
    required this.progress,
    required this.petals,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final petalPaint = Paint()..style = PaintingStyle.fill;
    final strokePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    for (final p in petals) {
      final life = (progress * p.speed + p.phase) % 1.0;
      final y = size.height * (0.02 + life * 0.96);
      final sway = math.sin((life * p.swayCycles + p.phase) * math.pi * 2);
      final x = (size.width * p.xFraction + sway * p.swayPixels + life * 24.0) % size.width;
      final rot = (life * p.spinCycles + p.phase) * math.pi * 2 + sway * 0.35;

      double alpha = p.opacity;
      if (life < 0.07) {
        alpha *= life / 0.07;
      } else if (life > 0.92) {
        alpha *= (1.0 - life) / 0.08;
      }

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(rot);

      final w = p.length * 0.65;
      final h = p.length;
      final path = Path()
        ..moveTo(0, h * 0.5)
        ..cubicTo(-w, h * 0.15, -w * 0.85, -h * 0.45, -w * 0.18, -h * 0.5)
        ..lineTo(0, -h * 0.32)
        ..lineTo(w * 0.18, -h * 0.5)
        ..cubicTo(w * 0.85, -h * 0.45, w, h * 0.15, 0, h * 0.5)
        ..close();

      petalPaint.color = p.color.withValues(alpha: alpha.clamp(0.0, 1.0));
      strokePaint.color = Colors.white.withValues(alpha: (alpha * 0.65).clamp(0.0, 1.0));
      canvas.drawPath(path, petalPaint);
      canvas.drawPath(path, strokePaint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _DriftingSakuraPetalsPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ---------------------------------------------------------------------------
// Lớp 2D · CosmicStardustOverlay (Thế giới 4: N2 Vũ trụ vô tận)
// ---------------------------------------------------------------------------

class CosmicStardustOverlay extends StatelessWidget {
  final Animation<double> animation;

  const CosmicStardustOverlay({super.key, required this.animation});

  static final List<_StardustMote> _stars = _generateStars(26);

  static List<_StardustMote> _generateStars(int count) {
    final rng = math.Random(202602);
    const colors = [
      Color(0xFFFFF3B0), // Vàng sao lấp lánh
      Color(0xFFE0BBE4), // Tím galaxy pastel
      Color(0xFFCAE9FF), // Xanh băng ngân hà
      Color(0xFFFFFFFF), // Trắng tinh vân
    ];
    return List<_StardustMote>.generate(count, (i) {
      return _StardustMote(
        x: 0.04 + rng.nextDouble() * 0.92,
        y: 0.03 + rng.nextDouble() * 0.94,
        phase: rng.nextDouble(),
        speed: 1 + (i % 3),
        size: 2.0 + rng.nextDouble() * 4.0, // 2px – 6px
        color: colors[i % colors.length],
        isFourPointStar: i % 3 == 0,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animation,
          builder: (_, __) => CustomPaint(
            painter: _CosmicStardustPainter(
              progress: animation.value,
              stars: _stars,
            ),
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

class _StardustMote {
  final double x;
  final double y;
  final double phase;
  final int speed;
  final double size;
  final Color color;
  final bool isFourPointStar;

  const _StardustMote({
    required this.x,
    required this.y,
    required this.phase,
    required this.speed,
    required this.size,
    required this.color,
    required this.isFourPointStar,
  });
}

class _CosmicStardustPainter extends CustomPainter {
  final double progress;
  final List<_StardustMote> stars;

  const _CosmicStardustPainter({
    required this.progress,
    required this.stars,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final glowPaint = Paint()..style = PaintingStyle.fill;
    final corePaint = Paint()..style = PaintingStyle.fill;

    for (final s in stars) {
      final twinkle = 0.25 + 0.75 * (0.5 + 0.5 * math.sin((progress * s.speed * 4 + s.phase) * math.pi * 2));
      final driftY = math.sin((progress * 2 + s.phase) * math.pi * 2) * 5.0;
      final center = Offset(size.width * s.x, size.height * s.y + driftY);
      final r = s.size * 0.5 * (0.8 + 0.4 * twinkle);

      glowPaint.color = s.color.withValues(alpha: (twinkle * 0.45).clamp(0.0, 1.0));
      canvas.drawCircle(center, r * 2.5, glowPaint);

      corePaint.color = s.color.withValues(alpha: (0.4 + 0.6 * twinkle).clamp(0.0, 1.0));
      if (s.isFourPointStar) {
        final arm = r * 2.1;
        final waist = r * 0.45;
        final starPath = Path()
          ..moveTo(center.dx, center.dy - arm)
          ..lineTo(center.dx + waist, center.dy - waist)
          ..lineTo(center.dx + arm, center.dy)
          ..lineTo(center.dx + waist, center.dy + waist)
          ..lineTo(center.dx, center.dy + arm)
          ..lineTo(center.dx - waist, center.dy + waist)
          ..lineTo(center.dx - arm, center.dy)
          ..lineTo(center.dx - waist, center.dy - waist)
          ..close();
        canvas.drawPath(starPath, corePaint);
      } else {
        canvas.drawCircle(center, r, corePaint);
      }
    }

    // Vệt sao băng (Shooting stars) lướt nhẹ qua dải ngân hà
    for (var i = 0; i < 3; i++) {
      final cycle = (progress * 3 + i * 0.33) % 1.0;
      if (cycle > 0.32) continue;
      final t = cycle / 0.32;
      final startX = size.width * (0.82 - i * 0.22);
      final startY = size.height * (0.08 + i * 0.24);
      final head = Offset(startX - t * size.width * 0.36, startY + t * size.height * 0.14);
      final tail = Offset(head.dx + 42, head.dy - 18);
      final fade = (t < 0.2 ? t / 0.2 : (1.0 - t) / 0.8).clamp(0.0, 1.0);

      final trailPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomLeft,
          end: Alignment.topRight,
          colors: [
            const Color(0xFFFFF3B0).withValues(alpha: 0.88 * fade),
            const Color(0xFFE0BBE4).withValues(alpha: 0.0),
          ],
        ).createShader(Rect.fromPoints(head, tail))
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(head, tail, trailPaint);
      canvas.drawCircle(
        head,
        2.5,
        Paint()..color = Colors.white.withValues(alpha: 0.92 * fade),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CosmicStardustPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ---------------------------------------------------------------------------
// Lớp 2E · FairyDustSparklesOverlay (Thế giới 5: N1 Vương quốc thần tiên)
// ---------------------------------------------------------------------------

class FairyDustSparklesOverlay extends StatelessWidget {
  final Animation<double> animation;

  const FairyDustSparklesOverlay({super.key, required this.animation});

  static final List<_FairyDustMote> _sparkles = _generateSparkles(24);

  static List<_FairyDustMote> _generateSparkles(int count) {
    final rng = math.Random(202601);
    const colors = [
      Color(0xFFFFE066), // Bụi tiên vàng óng ánh
      Color(0xFFFFB6C1), // Hồng phấn cầu vồng
      Color(0xFFE8D7FF), // Tím pha lê ánh sáng
      Color(0xFFFFF9C4), // Ánh kim thần tiên
    ];
    return List<_FairyDustMote>.generate(count, (i) {
      return _FairyDustMote(
        xFraction: 0.05 + rng.nextDouble() * 0.90,
        phase: rng.nextDouble(),
        speed: 1 + (i % 2),
        size: 3.5 + rng.nextDouble() * 4.5,
        swayPixels: 10.0 + rng.nextDouble() * 14.0,
        color: colors[i % colors.length],
        isCrystal: i.isEven,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: animation,
          builder: (_, __) => CustomPaint(
            painter: _FairyDustSparklesPainter(
              progress: animation.value,
              sparkles: _sparkles,
            ),
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

class _FairyDustMote {
  final double xFraction;
  final double phase;
  final int speed;
  final double size;
  final double swayPixels;
  final Color color;
  final bool isCrystal;

  const _FairyDustMote({
    required this.xFraction,
    required this.phase,
    required this.speed,
    required this.size,
    required this.swayPixels,
    required this.color,
    required this.isCrystal,
  });
}

class _FairyDustSparklesPainter extends CustomPainter {
  final double progress;
  final List<_FairyDustMote> sparkles;

  const _FairyDustSparklesPainter({
    required this.progress,
    required this.sparkles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final haloPaint = Paint()..style = PaintingStyle.fill;
    final corePaint = Paint()..style = PaintingStyle.fill;

    for (final s in sparkles) {
      final life = (progress * s.speed + s.phase) % 1.0;
      final y = size.height * (0.96 - life * 0.92);
      final sway = math.sin((life * 2 + s.phase) * math.pi * 2);
      final x = (size.width * s.xFraction + sway * s.swayPixels).clamp(8.0, size.width - 8.0);
      final shimmer = 0.45 + 0.55 * (0.5 + 0.5 * math.cos((progress * 6 + s.phase) * math.pi * 2));
      final edgeFade = life < 0.1
          ? life / 0.1
          : life > 0.9
              ? (1.0 - life) / 0.1
              : 1.0;
      final alpha = (shimmer * edgeFade).clamp(0.0, 1.0);
      final center = Offset(x, y);
      final r = s.size * 0.5;

      haloPaint.color = s.color.withValues(alpha: (alpha * 0.45).clamp(0.0, 1.0));
      canvas.drawCircle(center, r * 2.5, haloPaint);

      corePaint.color = s.color.withValues(alpha: (alpha * 0.92).clamp(0.0, 1.0));
      if (s.isCrystal) {
        final arm = r * 1.65;
        final waist = r * 0.42;
        final path = Path()
          ..moveTo(center.dx, center.dy - arm)
          ..lineTo(center.dx + waist, center.dy - waist)
          ..lineTo(center.dx + arm, center.dy)
          ..lineTo(center.dx + waist, center.dy + waist)
          ..lineTo(center.dx, center.dy + arm)
          ..lineTo(center.dx - waist, center.dy + waist)
          ..lineTo(center.dx - arm, center.dy)
          ..lineTo(center.dx - waist, center.dy - waist)
          ..close();
        canvas.drawPath(path, corePaint);
      } else {
        canvas.drawCircle(center, r, corePaint);
      }

      corePaint.color = Colors.white.withValues(alpha: (alpha * 0.88).clamp(0.0, 1.0));
      canvas.drawCircle(center, r * 0.38, corePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _FairyDustSparklesPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ---------------------------------------------------------------------------
// Lớp 3 · _PedestalLevelNode & _WorldMilestoneOrnament
// ---------------------------------------------------------------------------

class _WorldMilestoneOrnament extends StatelessWidget {
  final WorldThemeStyle style;
  final Animation<double> pulse;

  const _WorldMilestoneOrnament({required this.style, required this.pulse});

  @override
  Widget build(BuildContext context) {
    final (icon, colors) = switch (style) {
      WorldThemeStyle.oceanN5 => (
          Icons.auto_awesome_rounded,
          const [Color(0xFF80DEEA), Color(0xFF26C6DA)]
        ),
      WorldThemeStyle.techN4 => (
          Icons.bolt_rounded,
          const [Color(0xFFA0E7E5), Color(0xFFD8B4F8)]
        ),
      WorldThemeStyle.travelN3 => (
          Icons.explore_rounded,
          const [Color(0xFFFFB7B2), Color(0xFFF6CF6B)]
        ),
      WorldThemeStyle.spaceN2 => (
          Icons.public_rounded,
          const [Color(0xFFE0BBE4), Color(0xFF957DAD)]
        ),
      WorldThemeStyle.fairylandN1 => (
          Icons.stars_rounded,
          const [Color(0xFFFFE066), Color(0xFFFFB6C1)]
        ),
    };

    return AnimatedBuilder(
      animation: pulse,
      builder: (_, child) {
        final scale = 0.94 + pulse.value * 0.08;
        return Transform.scale(scale: scale, child: child);
      },
      child: Center(
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: colors,
            ),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withValues(alpha: 0.9), width: 1.8),
            boxShadow: [
              BoxShadow(
                color: colors.first.withValues(alpha: 0.45),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Icon(icon, size: 17, color: Colors.white),
        ),
      ),
    );
  }
}

class _PedestalLevelNode extends StatelessWidget {
  final MapLevel level;
  final _NodeState state;
  final int stars;
  final MapLearningMode mode;
  final Animation<double> pulse;
  final VoidCallback onTap;

  const _PedestalLevelNode({
    super.key,
    required this.level,
    required this.state,
    required this.stars,
    required this.mode,
    required this.pulse,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isCurrent = state == _NodeState.current;
    final isLocked = state == _NodeState.locked;
    final isCompleted = state == _NodeState.completed;
    final isKanji = mode == MapLearningMode.kanji;

    final badgeColor = isLocked
        ? const Color(0xFF7B8591)
        : isCurrent
            ? const Color(0xFFE06D85)
            : isCompleted
                ? const Color(0xFF2D9B83)
                : mode.themeColor;

    final badgeText = isKanji && level.kanji.isNotEmpty
        ? '${level.number}·${level.kanji.first}'
        : '${level.number}';

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Tooltip(
        message: level.title,
        child: SizedBox(
          width: 96,
          height: 96,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              // Vòng tròn phát sáng nhấp nháy (Pulsing Glow) quanh bệ đá cho bài đang học
              if (isCurrent)
                AnimatedBuilder(
                  animation: pulse,
                  builder: (_, __) {
                    final t = pulse.value;
                    final glowSize = 68.0 + t * 14.0;
                    return Container(
                      width: glowSize,
                      height: glowSize * 0.68,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: const Color(0xFFFFF4B8).withValues(alpha: 0.9 - t * 0.25),
                          width: 3.0,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFFD54F).withValues(alpha: 0.65 - t * 0.2),
                            blurRadius: 16 + t * 8,
                            spreadRadius: 3 + t * 3,
                          ),
                          BoxShadow(
                            color: const Color(0xFF64FFDA).withValues(alpha: 0.45),
                            blurRadius: 18,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    );
                  },
                )
              else if (isCompleted)
                Container(
                  width: 66,
                  height: 44,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: const Color(0xFFFFE082).withValues(alpha: 0.85),
                      width: 2.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFFCA28).withValues(alpha: 0.32),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                )
              else if (!isLocked)
                Container(
                  width: 64,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.85),
                      width: 2.0,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: mode.themeColor.withValues(alpha: 0.35),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),

              // Vùng chạm 64x64 đặt đúng tâm bệ đá
              SizedBox(
                width: 64,
                height: 64,
                child: Center(
                  child: isLocked
                      ? Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: const Color(0xFF37474F).withValues(alpha: 0.52),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.55),
                              width: 1.4,
                            ),
                          ),
                          child: const Icon(
                            Icons.lock_rounded,
                            size: 18,
                            color: Color(0xFFECEFF1),
                          ),
                        )
                      : isCurrent
                          ? Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFFF8A65), Color(0xFFE06D85)],
                                ),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(color: Colors.white, width: 1.8),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x55E06D85),
                                    blurRadius: 8,
                                    offset: Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: Text(
                                'BÀI ${level.number}',
                                style: const TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                ),
              ),

              // Cụm sao (⭐ 1-3) nổi nhẹ phía trên bệ đá khi đã hoàn thành
              if (isCompleted && stars > 0)
                Positioned(
                  top: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.92),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: const Color(0xFFFFE082), width: 1.2),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x26000000),
                          blurRadius: 6,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: _StarRow(stars: stars, size: 15),
                  ),
                ),

              // Nhãn số thứ tự nhỏ gọn phía mép dưới bệ đá
              if (!isCurrent)
                Positioned(
                  bottom: 4,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1.5),
                    decoration: BoxDecoration(
                      color: badgeColor.withValues(alpha: isLocked ? 0.72 : 0.90),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.85), width: 1.2),
                    ),
                    child: Text(
                      badgeText,
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StarRow extends StatelessWidget {
  final int stars;
  final double size;

  const _StarRow({required this.stars, this.size = 22});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < 3; i++)
          Icon(
            i < stars ? Icons.star_rounded : Icons.star_outline_rounded,
            size: size,
            color: i < stars ? const Color(0xFFE9B949) : const Color(0xFFBFB6B9),
          ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Phương tiện Mèo Hộ Pháp 1 · Tàu ngầm mèo vàng (N5 Đại dương)
// ---------------------------------------------------------------------------

class _CatSubmarine extends StatelessWidget {
  final Animation<double> animation;
  final bool flipHorizontal;

  const _CatSubmarine({required this.animation, this.flipHorizontal = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, child) {
        final angle = animation.value * math.pi * 2 * 5;
        final bobY = math.sin(angle) * 5.0;
        final tilt = math.cos(angle) * 0.04;
        return Transform.translate(
          offset: Offset(0, bobY),
          child: Transform.rotate(angle: tilt, child: child),
        );
      },
      child: Transform.flip(
        flipX: flipHorizontal,
        child: const SizedBox(
          width: 84,
          height: 58,
          child: Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: _SubmarinePainter())),
              Positioned(
                left: 30,
                top: 17,
                width: 30,
                height: 30,
                child: _VehicleCatPilotAvatar(backgroundColor: Color(0xFFE6F6F8)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SubmarinePainter extends CustomPainter {
  const _SubmarinePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final body = Paint()..color = const Color(0xFFF6CF6B);
    final dark = Paint()..color = const Color(0xFFE0A945);
    final outline = Paint()
      ..color = const Color(0xFF8C6239)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final periscope = RRect.fromRectAndRadius(const Rect.fromLTWH(50, 2, 6, 14), const Radius.circular(3));
    canvas.drawRRect(periscope, dark);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(50, 2, 14, 5), const Radius.circular(3)), dark);
    final tower = RRect.fromRectAndRadius(const Rect.fromLTWH(34, 10, 26, 12), const Radius.circular(6));
    canvas.drawRRect(tower, body);
    canvas.drawRRect(tower, outline);

    final hull = RRect.fromRectAndRadius(Rect.fromLTWH(8, 16, size.width - 14, 36), const Radius.circular(18));
    canvas.drawRRect(hull, body);
    canvas.drawRRect(hull, outline);

    final tail = Path()
      ..moveTo(10, 34)
      ..lineTo(0, 24)
      ..lineTo(0, 46)
      ..close();
    canvas.drawPath(tail, dark);
    canvas.drawPath(tail, outline);

    final porthole = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5;
    canvas.drawCircle(const Offset(45, 32), 16, porthole);
    canvas.drawCircle(const Offset(45, 32), 17.5, outline);
    canvas.drawCircle(Offset(size.width - 16, 34), 4, Paint()..color = const Color(0xFFBFE6EC));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Phương tiện Mèo Hộ Pháp 2 · Xe bay mèo mini / Flying Pod Hovercar (N4 Công nghệ)
// ---------------------------------------------------------------------------

class _CatHoverPod extends StatelessWidget {
  final Animation<double> animation;
  final bool flipHorizontal;

  const _CatHoverPod({required this.animation, this.flipHorizontal = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, child) {
        final angle = animation.value * math.pi * 2 * 5;
        final bobY = math.sin(angle) * 5.5;
        final tilt = math.sin(angle * 0.5) * 0.045;
        return Transform.translate(
          offset: Offset(0, bobY),
          child: Transform.rotate(angle: tilt, child: child),
        );
      },
      child: Transform.flip(
        flipX: flipHorizontal,
        child: const SizedBox(
          width: 86,
          height: 62,
          child: Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: _HoverPodPainter())),
              Positioned(
                left: 29,
                top: 10,
                width: 28,
                height: 28,
                child: _VehicleCatPilotAvatar(backgroundColor: Color(0xFFF3E8FF)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HoverPodPainter extends CustomPainter {
  const _HoverPodPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = const Color(0xFF5E548E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    // Vòng phản trọng lực neon phía dưới gầm xe bay
    final thrusterGlow = Paint()
      ..color = const Color(0xFFA0E7E5).withValues(alpha: 0.75)
      ..style = PaintingStyle.fill;
    canvas.drawOval(const Rect.fromLTWH(16, 48, 54, 10), thrusterGlow);
    canvas.drawOval(
      const Rect.fromLTWH(24, 51, 38, 6),
      Paint()..color = Colors.white.withValues(alpha: 0.85),
    );

    // Tai mèo công nghệ trên vòm kính
    final earPaint = Paint()..color = const Color(0xFFD8B4F8);
    final leftEar = Path()
      ..moveTo(28, 14)
      ..lineTo(24, 3)
      ..lineTo(36, 9)
      ..close();
    final rightEar = Path()
      ..moveTo(58, 14)
      ..lineTo(62, 3)
      ..lineTo(50, 9)
      ..close();
    canvas.drawPath(leftEar, earPaint);
    canvas.drawPath(leftEar, outline);
    canvas.drawPath(rightEar, earPaint);
    canvas.drawPath(rightEar, outline);

    // Vòm kính buồng lái (Glass Dome)
    const domeRect = Rect.fromLTWH(23, 6, 40, 32);
    canvas.drawOval(domeRect, Paint()..color = const Color(0xFFE0FBFC).withValues(alpha: 0.88));
    canvas.drawOval(domeRect, outline);

    // Thân xe bay (Hovercar chassis)
    final bodyRect = RRect.fromRectAndRadius(
      const Rect.fromLTWH(6, 26, 74, 24),
      const Radius.circular(14),
    );
    final bodyGrad = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFD8B4F8), Color(0xFFA0E7E5)],
      ).createShader(const Rect.fromLTWH(6, 26, 74, 24));
    canvas.drawRRect(bodyRect, bodyGrad);
    canvas.drawRRect(bodyRect, outline);

    // Cánh lướt gió sau & đèn pha neon trước
    final wing = Path()
      ..moveTo(8, 28)
      ..lineTo(0, 19)
      ..lineTo(14, 26)
      ..close();
    canvas.drawPath(wing, Paint()..color = const Color(0xFF9F86C0));
    canvas.drawPath(wing, outline);

    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(18, 35, 44, 5), const Radius.circular(3)),
      Paint()..color = Colors.white.withValues(alpha: 0.82),
    );
    canvas.drawCircle(const Offset(71, 37), 4.2, Paint()..color = const Color(0xFFFFF3B0));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Phương tiện Mèo Hộ Pháp 3 · Máy bay cánh quạt phi công mini (N3 Du hành)
// ---------------------------------------------------------------------------

class _CatAviatorBiplane extends StatelessWidget {
  final Animation<double> animation;
  final bool flipHorizontal;

  const _CatAviatorBiplane({required this.animation, this.flipHorizontal = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        final angle = animation.value * math.pi * 2 * 5;
        final bobY = math.sin(angle) * 5.0;
        final tilt = math.cos(angle) * 0.05;
        final propAngle = animation.value * math.pi * 2 * 28;

        return Transform.translate(
          offset: Offset(0, bobY),
          child: Transform.rotate(
            angle: tilt,
            child: Transform.flip(
              flipX: flipHorizontal,
              child: SizedBox(
                width: 88,
                height: 62,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    const Positioned.fill(
                      child: CustomPaint(painter: _AviatorBiplanePainter()),
                    ),
                    const Positioned(
                      left: 30,
                      top: 14,
                      width: 26,
                      height: 26,
                      child: _VehicleCatPilotAvatar(backgroundColor: Color(0xFFFFF3E0)),
                    ),
                    // Cánh quạt phía mũi máy bay quay mượt mà
                    Positioned(
                      right: 1,
                      top: 21,
                      width: 14,
                      height: 26,
                      child: Transform.rotate(
                        angle: propAngle,
                        child: const CustomPaint(painter: _PropellerBladePainter()),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AviatorBiplanePainter extends CustomPainter {
  const _AviatorBiplanePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final coral = Paint()..color = const Color(0xFFF28482);
    final cream = Paint()..color = const Color(0xFFF7EDE2);
    final gold = Paint()..color = const Color(0xFFF6BD60);
    final outline = Paint()
      ..color = const Color(0xFF7F4F24)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    // Đuôi đứng máy bay
    final tailFin = Path()
      ..moveTo(12, 30)
      ..lineTo(2, 16)
      ..lineTo(4, 38)
      ..close();
    canvas.drawPath(tailFin, coral);
    canvas.drawPath(tailFin, outline);

    // Cánh trên (Upper Biplane Wing)
    final topWing = RRect.fromRectAndRadius(
      const Rect.fromLTWH(16, 6, 54, 9),
      const Radius.circular(5),
    );
    canvas.drawRRect(topWing, cream);
    canvas.drawRRect(topWing, outline);

    // Thanh chống nối 2 tầng cánh
    canvas.drawLine(const Offset(24, 15), const Offset(24, 42), outline);
    canvas.drawLine(const Offset(60, 15), const Offset(60, 42), outline);

    // Thân máy bay (Fuselage)
    final fuselage = RRect.fromRectAndRadius(
      const Rect.fromLTWH(8, 22, 68, 24),
      const Radius.circular(12),
    );
    canvas.drawRRect(fuselage, coral);
    canvas.drawRRect(fuselage, outline);

    // Cánh dưới (Lower Biplane Wing)
    final bottomWing = RRect.fromRectAndRadius(
      const Rect.fromLTWH(18, 41, 50, 8),
      const Radius.circular(4),
    );
    canvas.drawRRect(bottomWing, cream);
    canvas.drawRRect(bottomWing, outline);

    // Mũi máy bay màu vàng ấm
    final nose = RRect.fromRectAndRadius(
      const Rect.fromLTWH(66, 24, 12, 20),
      const Radius.circular(6),
    );
    canvas.drawRRect(nose, gold);
    canvas.drawRRect(nose, outline);

    // Phù hiệu ngôi sao nhỏ bên hông
    canvas.drawCircle(const Offset(18, 33), 4.5, gold);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PropellerBladePainter extends CustomPainter {
  const _PropellerBladePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.5);
    final bladePaint = Paint()
      ..color = const Color(0xFFFFF8E7).withValues(alpha: 0.9)
      ..style = PaintingStyle.fill;
    final rimPaint = Paint()
      ..color = const Color(0xFF7F4F24)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;

    final blade1 = Rect.fromCenter(center: Offset(center.dx, center.dy - 7), width: 4.5, height: 12);
    final blade2 = Rect.fromCenter(center: Offset(center.dx, center.dy + 7), width: 4.5, height: 12);
    canvas.drawOval(blade1, bladePaint);
    canvas.drawOval(blade1, rimPaint);
    canvas.drawOval(blade2, bladePaint);
    canvas.drawOval(blade2, rimPaint);
    canvas.drawCircle(center, 3.0, Paint()..color = const Color(0xFF7F4F24));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Phương tiện Mèo Hộ Pháp 4 · Đĩa bay UFO phi hành gia mini (N2 Vũ trụ)
// ---------------------------------------------------------------------------

class _CatCosmicUfo extends StatelessWidget {
  final Animation<double> animation;
  final bool flipHorizontal;

  const _CatCosmicUfo({required this.animation, this.flipHorizontal = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, child) {
        final angle = animation.value * math.pi * 2 * 5;
        final bobY = math.sin(angle) * 5.5;
        final tilt = math.sin(angle * 0.5) * 0.05;
        return Transform.translate(
          offset: Offset(0, bobY),
          child: Transform.rotate(angle: tilt, child: child),
        );
      },
      child: Transform.flip(
        flipX: flipHorizontal,
        child: const SizedBox(
          width: 88,
          height: 66,
          child: Stack(
            children: [
              Positioned.fill(child: CustomPaint(painter: _CosmicUfoPainter())),
              Positioned(
                left: 30,
                top: 12,
                width: 28,
                height: 28,
                child: _VehicleCatPilotAvatar(backgroundColor: Color(0xFFEDE7F6)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CosmicUfoPainter extends CustomPainter {
  const _CosmicUfoPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = const Color(0xFF4A3B76)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    // Quầng sáng năng lượng bên dưới đĩa bay (Tractor-beam / Cosmic Halo)
    final beamPath = Path()
      ..moveTo(26, 44)
      ..lineTo(14, 64)
      ..lineTo(74, 64)
      ..lineTo(62, 44)
      ..close();
    final beamGrad = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFFFFF3B0).withValues(alpha: 0.72),
          const Color(0xFFE0BBE4).withValues(alpha: 0.08),
        ],
      ).createShader(const Rect.fromLTWH(14, 44, 60, 20));
    canvas.drawPath(beamPath, beamGrad);
    canvas.drawOval(
      const Rect.fromLTWH(20, 46, 48, 9),
      Paint()..color = const Color(0xFFFFF3B0).withValues(alpha: 0.85),
    );

    // Ăng-ten ngôi sao trên đỉnh vòm kính UFO
    canvas.drawLine(const Offset(44, 2), const Offset(44, 9), outline);
    canvas.drawCircle(const Offset(44, 3), 3.2, Paint()..color = const Color(0xFFFFF3B0));

    // Vòm kính phi hành gia (Glass Dome)
    const domeRect = Rect.fromLTWH(23, 8, 42, 30);
    canvas.drawOval(domeRect, Paint()..color = const Color(0xFFCAE9FF).withValues(alpha: 0.88));
    canvas.drawOval(domeRect, outline);

    // Thân đĩa bay (UFO Saucer Rim)
    const saucerRect = Rect.fromLTWH(4, 28, 80, 20);
    final saucerGrad = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFE0BBE4), Color(0xFF957DAD), Color(0xFFD291BC)],
      ).createShader(saucerRect);
    canvas.drawOval(saucerRect, saucerGrad);
    canvas.drawOval(saucerRect, outline);

    // Đèn tròn phát sáng quanh vành đĩa bay
    const lampPositions = [Offset(18, 38), Offset(35, 41), Offset(53, 41), Offset(70, 38)];
    for (final pos in lampPositions) {
      canvas.drawCircle(pos, 3.2, Paint()..color = const Color(0xFFFFF3B0));
      canvas.drawCircle(pos, 3.2, outline);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Phương tiện Mèo Hộ Pháp 5 · Thuyền mây thần tiên có cánh (N1 Thần tiên)
// ---------------------------------------------------------------------------

class _CatCelestialCloudBoat extends StatelessWidget {
  final Animation<double> animation;
  final bool flipHorizontal;

  const _CatCelestialCloudBoat({required this.animation, this.flipHorizontal = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        final angle = animation.value * math.pi * 2 * 5;
        final bobY = math.sin(angle) * 5.0;
        final wingFlap = math.sin(angle * 2.2) * 0.22;

        return Transform.translate(
          offset: Offset(0, bobY),
          child: Transform.flip(
            flipX: flipHorizontal,
            child: SizedBox(
              width: 90,
              height: 64,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // Cánh thiên thần phía sau vỗ nhẹ nhàng
                  Positioned(
                    left: 8,
                    top: 6,
                    width: 34,
                    height: 26,
                    child: Transform.rotate(
                      angle: wingFlap,
                      alignment: Alignment.bottomRight,
                      child: const CustomPaint(painter: _CelestialWingPainter()),
                    ),
                  ),
                  const Positioned.fill(
                    child: CustomPaint(painter: _CelestialCloudBoatPainter()),
                  ),
                  const Positioned(
                    left: 31,
                    top: 14,
                    width: 28,
                    height: 28,
                    child: _VehicleCatPilotAvatar(backgroundColor: Color(0xFFFFF8E7)),
                  ),
                  // Cánh thiên thần phía trước vỗ nhịp nhàng
                  Positioned(
                    left: 16,
                    top: 12,
                    width: 34,
                    height: 26,
                    child: Transform.rotate(
                      angle: -wingFlap * 0.85,
                      alignment: Alignment.bottomRight,
                      child: const CustomPaint(painter: _CelestialWingPainter()),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _CelestialCloudBoatPainter extends CustomPainter {
  const _CelestialCloudBoatPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final goldOutline = Paint()
      ..color = const Color(0xFFC99700)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    // Thân thuyền vàng ánh hồng thần tiên
    final hullPath = Path()
      ..moveTo(12, 32)
      ..quadraticBezierTo(45, 56, 78, 30)
      ..lineTo(70, 48)
      ..quadraticBezierTo(44, 58, 18, 48)
      ..close();
    final hullGrad = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFE066), Color(0xFFFFB6C1), Color(0xFFE8D7FF)],
      ).createShader(const Rect.fromLTWH(12, 30, 66, 28));
    canvas.drawPath(hullPath, hullGrad);
    canvas.drawPath(hullPath, goldOutline);

    // Đệm mây bồng bềnh bao quanh mạn thuyền
    final cloudPaint = Paint()..color = const Color(0xFFFFFBFD);
    const cloudCircles = [
      (Offset(22, 44), 10.0),
      (Offset(36, 46), 12.0),
      (Offset(52, 46), 12.0),
      (Offset(66, 44), 10.0),
    ];
    for (final (center, r) in cloudCircles) {
      canvas.drawCircle(center, r, cloudPaint);
      canvas.drawCircle(
        center,
        r,
        Paint()
          ..color = const Color(0xFFF3D1F4)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4,
      );
    }

    // Ngôi sao pha lê dẫn đường ở mũi thuyền
    canvas.drawCircle(const Offset(78, 28), 5.0, Paint()..color = const Color(0xFFFFE066));
    canvas.drawCircle(const Offset(78, 28), 5.0, goldOutline);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CelestialWingPainter extends CustomPainter {
  const _CelestialWingPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final wingPath = Path()
      ..moveTo(size.width * 0.85, size.height * 0.85)
      ..quadraticBezierTo(size.width * 0.1, size.height * 0.75, 2, size.height * 0.2)
      ..quadraticBezierTo(size.width * 0.55, 0, size.width * 0.9, size.height * 0.55)
      ..close();

    canvas.drawPath(wingPath, Paint()..color = const Color(0xFFFFFBFD).withValues(alpha: 0.94));
    canvas.drawPath(
      wingPath,
      Paint()
        ..color = const Color(0xFFE5B8F4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _VehicleCatPilotAvatar extends StatelessWidget {
  final Color backgroundColor;

  const _VehicleCatPilotAvatar({required this.backgroundColor});

  @override
  Widget build(BuildContext context) {
    return ClipOval(
      child: ColoredBox(
        color: backgroundColor,
        child: OverflowBox(
          maxWidth: 62,
          maxHeight: 75,
          alignment: const Alignment(0, -0.35),
          child: Image.asset(
            'assets/study/cats/img_6883/happy.webp',
            width: 62,
            height: 75,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Lớp 4 · _MapTopBar (Thanh Header điều hướng nổi phía trên)
// ---------------------------------------------------------------------------

class _MapTopBar extends StatelessWidget {
  final JlptWorld world;
  final MapLearningMode mode;
  final int earned;
  final int maxStars;
  final ValueChanged<MapLearningMode> onModeChanged;

  const _MapTopBar({
    required this.world,
    required this.mode,
    required this.earned,
    required this.maxStars,
    required this.onModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF4FA8D8).withValues(alpha: 0.72),
            const Color(0xFF4FA8D8).withValues(alpha: 0.32),
            const Color(0xFF4FA8D8).withValues(alpha: 0.0),
          ],
          stops: const [0, 0.65, 1],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 18),
          child: Column(
            children: [
              Row(
                children: [
                  Material(
                    color: Colors.white.withValues(alpha: 0.88),
                    shape: const CircleBorder(),
                    elevation: 2,
                    shadowColor: Colors.black26,
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).maybePop(),
                      child: const Padding(
                        padding: EdgeInsets.all(9),
                        child: AppAssetIcon(AppAssets.navArrowLeft, size: 22),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(14, 7, 10, 7),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.90),
                        borderRadius: BorderRadius.circular(999),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x1F000000),
                            blurRadius: 10,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${world.level} · ${world.name}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF8E1),
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: const Color(0xFFFFE082)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.star_rounded, size: 18, color: Color(0xFFE9B949)),
                                const SizedBox(width: 3),
                                Text(
                                  '$earned/$maxStars',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _ModeToggle(mode: mode, onChanged: onModeChanged),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeToggle extends StatelessWidget {
  final MapLearningMode mode;
  final ValueChanged<MapLearningMode> onChanged;

  const _ModeToggle({required this.mode, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Widget pill(MapLearningMode m, String icon) {
      final selected = m == mode;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChanged(m),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: selected ? AppTheme.surface : Colors.transparent,
              borderRadius: BorderRadius.circular(999),
              boxShadow: selected ? AppTheme.softCardShadow : null,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AppAssetIcon(icon, size: 18),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    m.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                      color: selected ? m.themeColor : AppTheme.textSecondary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      constraints: const BoxConstraints(maxWidth: 340),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.78),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        children: [
          pill(MapLearningMode.vocabulary, AppAssets.learnBook01),
          pill(MapLearningMode.kanji, AppAssets.learnBook02),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// MAP-03 · Bảng chi tiết màn chơi
// ---------------------------------------------------------------------------

enum _LevelAction { practice, quiz }

class _LevelDetailSheet extends StatelessWidget {
  final MapLevel level;
  final MapLearningMode mode;
  final String jlpt;

  const _LevelDetailSheet({required this.level, required this.mode, required this.jlpt});

  @override
  Widget build(BuildContext context) {
    final progress = context.watch<ProgressProvider>();
    final stars = progress.mapStarsFor(level.key);
    final rewarded = progress.isMapPracticeRewarded(level.key);
    final hasWords = level.words.isNotEmpty;
    final canQuiz = level.words.length >= 2;
    final questionCount = math.min(MapLevelCatalog.quizQuestions, level.words.length);
    final preview = level.words.take(8).toList();

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppTheme.borderSubtle, borderRadius: BorderRadius.circular(999)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: mode.themeColor.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    mode == MapLearningMode.kanji && level.kanji.isNotEmpty ? level.kanji.first : '${level.number}',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: mode.themeColor),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        level.title,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        mode == MapLearningMode.kanji
                            ? '$jlpt · ${level.kanji.length} chữ Hán · ${level.words.length} từ ví dụ'
                            : '$jlpt · ${level.words.length} từ vựng',
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: AppTheme.background, borderRadius: BorderRadius.circular(16)),
              child: Row(
                children: [
                  Text(
                    'Kỷ lục',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.textSecondary),
                  ),
                  const Spacer(),
                  _StarRow(stars: stars, size: 28),
                ],
              ),
            ),
            if (mode == MapLearningMode.kanji && level.kanji.isNotEmpty) ...[
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in level.kanji)
                    Container(
                      width: 44,
                      height: 44,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF4EFF6),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFDCCFE4)),
                      ),
                      child: Text(k, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppTheme.accent)),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 14),
            if (hasWords)
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final w in preview)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Text(
                        w.hiragana.isNotEmpty && w.hiragana != w.japanese ? '${w.japanese} · ${w.hiragana}' : w.japanese,
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
                      ),
                    ),
                  if (level.words.length > preview.length)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceSoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '+${level.words.length - preview.length}',
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppTheme.textSecondary),
                      ),
                    ),
                ],
              )
            else
              Text(
                'Chưa có từ ví dụ cho nhóm chữ này.',
                style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
            const SizedBox(height: 20),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: hasWords ? () => Navigator.pop(context, _LevelAction.practice) : null,
                style: FilledButton.styleFrom(backgroundColor: mode.themeColor, shape: const StadiumBorder()),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.style_rounded, size: 20),
                    const SizedBox(width: 8),
                    const Text('Học / Luyện tập', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800)),
                    if (!rewarded) ...[
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.fromLTRB(8, 2, 6, 2),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.25),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '+${ProgressProvider.mapPracticeRewardCoins}',
                              style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
                            ),
                            SizedBox(width: 2),
                            AppAssetIcon(AppAssets.statusCoin, size: 16),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: OutlinedButton(
                onPressed: canQuiz ? () => Navigator.pop(context, _LevelAction.quiz) : null,
                style: OutlinedButton.styleFrom(
                  foregroundColor: mode.themeColor,
                  side: BorderSide(color: mode.themeColor, width: 1.6),
                  shape: const StadiumBorder(),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const AppAssetIcon(AppAssets.achTrophy, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Kiểm tra vượt level · $questionCount câu',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
