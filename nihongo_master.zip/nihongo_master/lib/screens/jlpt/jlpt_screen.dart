import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../data/jlpt_test_data.dart';
import '../../models/quiz.dart';
import '../../models/study_history.dart';
import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/study_history_provider.dart';
import '../../services/gemini_exam_service.dart';
import '../../utils/content_fallback.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/cozy_common_widgets.dart';
import '../../widgets/line_companion_cat.dart';

class JLPTScreen extends StatelessWidget {
  const JLPTScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const levels = ['N5', 'N4', 'N3', 'N2', 'N1'];

    return DefaultTabController(
      length: levels.length,
      child: Scaffold(
        backgroundColor: context.cozy.background,
        appBar: AppBar(
          backgroundColor: context.cozy.surface,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.menu_book_rounded,
                color: context.cozy.primary,
                size: 20,
              ),
              SizedBox(width: 8),
              Text(
                'Luyện đề JLPT',
                style: TextStyle(
                  fontSize: 17.5,
                  fontWeight: FontWeight.w700,
                  color: context.cozy.textPrimary,
                ),
              ),
            ],
          ),
          bottom: TabBar(
            isScrollable: true,
            labelColor: context.cozy.primary,
            unselectedLabelColor: context.cozy.textSecondary,
            indicatorColor: context.cozy.primary,
            indicatorWeight: 2.5,
            dividerColor: context.cozy.borderSubtle,
            labelStyle: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
            unselectedLabelStyle: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
            tabs: levels
                .map(
                  (level) => Tab(
                    text:
                        '$level • ${JLPTTestData.getTestsByLevel(level).length} đề',
                  ),
                )
                .toList(),
          ),
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 860),
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 14, 16, 12),
                    child: CompanionLineAnchor(
                      child: _JLPTProgressHeaderCard(levels: levels),
                    ),
                  ),
                  Expanded(
                    child: TabBarView(
                      children: levels
                          .map(
                            (level) => _JLPTLevelView(
                              level: level,
                              tests: JLPTTestData.getTestsByLevel(level),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _JLPTProgressHeaderCard extends StatelessWidget {
  final List<String> levels;

  const _JLPTProgressHeaderCard({required this.levels});

  @override
  Widget build(BuildContext context) {
    final tabController = DefaultTabController.of(context);
    final historyProvider = Provider.of<StudyHistoryProvider?>(context);
    final histories = historyProvider?.histories ?? const <StudyHistory>[];

    return AnimatedBuilder(
      animation: tabController,
      builder: (context, _) {
        final activeIndex = tabController.index.clamp(0, levels.length - 1);
        final activeLevel = levels[activeIndex];
        final totalTests = JLPTTestData.getTestsByLevel(activeLevel).length;
        final levelHistories =
            histories.where((h) => h.jlptLevel == activeLevel).toList();
        final completedTestIds =
            levelHistories.map((h) => h.testId).toSet().length;
        final ratio = totalTests == 0
            ? 0.0
            : (completedTestIds / totalTests).clamp(0.0, 1.0);
        final percent = (ratio * 100).round();

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: context.cozy.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: context.cozy.borderSubtle),
            boxShadow: context.cozy.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.star_rounded,
                    color: context.cozy.primary,
                    size: 19,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Tiến độ luyện đề & Chọn cấp độ JLPT',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: context.cozy.textPrimary,
                      ),
                    ),
                  ),
                  Text(
                    'Đã làm ${levelHistories.length} lượt',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: context.cozy.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  SizedBox(
                    width: 68,
                    height: 68,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 64,
                          height: 64,
                          child: CircularProgressIndicator(
                            value: ratio == 0 ? 0.2 : ratio,
                            strokeWidth: 6,
                            backgroundColor: context.cozy.surfaceSoft,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              context.cozy.primary,
                            ),
                            strokeCap: StrokeCap.round,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              activeLevel,
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: FontWeight.w700,
                                color: context.cozy.textPrimary,
                              ),
                            ),
                            Text(
                              '$percent%',
                              style: TextStyle(
                                fontSize: 10.5,
                                color: context.cozy.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: context.cozy.background,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: context.cozy.borderSubtle),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Cấp độ $activeLevel: Hoàn thành $completedTestIds/$totalTests bộ đề xác minh',
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: context.cozy.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(999),
                            child: LinearProgressIndicator(
                              value: ratio == 0 ? 0.2 : ratio,
                              minHeight: 7,
                              backgroundColor: context.cozy.surfaceSoft,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                context.cozy.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: List.generate(levels.length, (index) {
                  final lv = levels[index];
                  final selected = index == activeIndex;
                  return Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(
                        right: index == levels.length - 1 ? 0 : 8,
                      ),
                      child: InkWell(
                        onTap: () => tabController.animateTo(index),
                        borderRadius: BorderRadius.circular(12),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 160),
                          height: 34,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color:
                                selected ? context.cozy.primary : context.cozy.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: selected
                                  ? context.cozy.primary
                                  : context.cozy.borderSubtle,
                            ),
                          ),
                          child: Text(
                            lv,
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight:
                                  selected ? FontWeight.w700 : FontWeight.w600,
                              color: selected
                                  ? context.cozy.onPrimary
                                  : context.cozy.textPrimary,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _JLPTLevelView extends StatefulWidget {
  final String level;
  final List<JLPTTest> tests;

  const _JLPTLevelView({required this.level, required this.tests});

  @override
  State<_JLPTLevelView> createState() => _JLPTLevelViewState();
}

class _JLPTLevelViewState extends State<_JLPTLevelView> {
  static const List<Map<String, String>> _modeTabs = <Map<String, String>>[
    {'code': 'full', 'label': 'Full Test (Đề chuẩn)'},
    {'code': 'mini', 'label': 'Mini Test (Rút gọn)'},
    {'code': 'skill', 'label': 'Skill Test (Kỹ năng)'},
  ];

  static const List<Map<String, String>> _sectionFilters =
      <Map<String, String>>[
    {'code': 'all', 'label': 'Tất cả'},
    {'code': 'vocabulary', 'label': 'Từ vựng'},
    {'code': 'grammar', 'label': 'Ngữ pháp'},
    {'code': 'reading', 'label': 'Đọc hiểu'},
    {'code': 'listening', 'label': 'Nghe hiểu'},
  ];

  String _selectedMode = 'full';
  String _selectedSection = 'all';
  bool _isGeneratingAiExam = false;

  List<JLPTTest> get _mergedLevelTests {
    final loaded = JLPTTestData.getTestsByLevel(widget.level);
    if (loaded.isEmpty) return widget.tests;
    final byId = <String, JLPTTest>{};
    for (final t in loaded) {
      byId[t.id] = t;
    }
    for (final t in widget.tests) {
      byId.putIfAbsent(t.id, () => t);
    }
    return byId.values.toList();
  }

  Future<void> _handleGenerateAiExam(BuildContext context) async {
    if (_isGeneratingAiExam) return;
    setState(() => _isGeneratingAiExam = true);

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) => AlertDialog(
        backgroundColor: context.cozy.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Row(
          children: [
            SizedBox(
              width: 26,
              height: 26,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                color: context.cozy.primary,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                'Đang kết nối mô hình AI sinh đề thi...',
                key: const ValueKey('jlpt-ai-loading-text'),
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: context.cozy.textPrimary,
                ),
              ),
            ),
          ],
        ),
      ),
    );

    try {
      final result = await GeminiExamService.instance.generateExam(
        level: widget.level,
      );
      if (!context.mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      setState(() => _isGeneratingAiExam = false);

      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => TestScreen(test: result.test),
        ),
      );
      if (mounted) {
        setState(() {});
      }
    } catch (_) {
      if (!context.mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      setState(() => _isGeneratingAiExam = false);
    }
  }

  List<JLPTTest> get _filteredTests {
    List<JLPTTest> baseTests = _mergedLevelTests;
    if (_selectedSection != 'all') {
      final filtered = <JLPTTest>[];
      for (final test in baseTests) {
        final matchingQuestions = test.questions.where((q) {
          return switch (_selectedSection) {
            'vocabulary' =>
              q.type == QuestionType.vocabularyMeaning ||
                  q.type == QuestionType.vocabularyReading ||
                  q.type == QuestionType.kanjiMeaning ||
                  q.type == QuestionType.kanjiReading,
            'grammar' => q.type == QuestionType.grammar,
            'reading' => q.type == QuestionType.reading,
            'listening' => q.type == QuestionType.listening,
            _ => true,
          };
        }).toList();
        if (matchingQuestions.isNotEmpty) {
          filtered.add(
            JLPTTest(
              id: '${test.id}_$_selectedSection',
              level: test.level,
              title: test.title,
              timeMinutes: test.timeMinutes,
              questions: matchingQuestions,
              isAiGenerated: test.isAiGenerated,
              isFallback: test.isFallback,
              sourceId: test.sourceId,
              readingPassage: test.readingPassage,
            ),
          );
        }
      }
      baseTests = filtered;
    }

    if (_selectedMode == 'mini') {
      return baseTests
          .map(
            (test) => JLPTTest(
              id: '${test.id}_mini',
              level: test.level,
              title: '${test.title} (Mini)',
              timeMinutes: 10,
              questions: test.questions.take(5).toList(),
              isAiGenerated: test.isAiGenerated,
              isFallback: test.isFallback,
              sourceId: test.sourceId,
              readingPassage: test.readingPassage,
            ),
          )
          .where((t) => t.questions.isNotEmpty)
          .toList();
    }
    return baseTests;
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.level;
    final color = AppTheme.jlptColor(level);
    final displayTests = _filteredTests;
    final historyProvider = Provider.of<StudyHistoryProvider?>(context);
    final histories = historyProvider?.histories ?? const <StudyHistory>[];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton.icon(
              key: ValueKey('jlpt-ai-rag-generate-btn-$level'),
              style: ElevatedButton.styleFrom(
                backgroundColor: context.cozy.accent,
                foregroundColor: context.cozy.onPrimary,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
              ),
              onPressed: _isGeneratingAiExam
                  ? null
                  : () => _handleGenerateAiExam(context),
              icon: const Icon(Icons.auto_awesome_rounded, size: 18),
              label: const Text(
                '✨ Tạo Đề Thi Tự Động Bằng AI (RAG)',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: context.cozy.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: context.cozy.borderSubtle),
            ),
            child: Row(
              children: _modeTabs.map((mode) {
                final code = mode['code']!;
                final label = mode['label']!;
                final isSelected = _selectedMode == code;
                return Expanded(
                  child: GestureDetector(
                    key: ValueKey('jlpt-mode-$code'),
                    onTap: () {
                      setState(() {
                        _selectedMode = code;
                        if (code == 'skill' && _selectedSection == 'all') {
                          _selectedSection = 'vocabulary';
                        } else if (code == 'full') {
                          _selectedSection = 'all';
                        }
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
                      decoration: BoxDecoration(
                        color: isSelected ? context.cozy.primary : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        label,
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                          color: isSelected ? context.cozy.onPrimary : context.cozy.textSecondary,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        if (widget.tests.isNotEmpty)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Row(
              children: _sectionFilters.map((sec) {
                final code = sec['code']!;
                final label = sec['label']!;
                final isSelected = _selectedSection == code;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(label),
                    selected: isSelected,
                    selectedColor: context.cozy.primary.withValues(alpha: 0.16),
                    backgroundColor: context.cozy.surface,
                    side: BorderSide(
                      color:
                          isSelected ? context.cozy.primary : context.cozy.borderSubtle,
                    ),
                    labelStyle: TextStyle(
                      color: isSelected
                          ? context.cozy.primary
                          : context.cozy.textPrimary,
                      fontWeight:
                          isSelected ? FontWeight.w700 : FontWeight.w500,
                      fontSize: 12.5,
                    ),
                    onSelected: (_) => setState(() {
                      _selectedSection = code;
                      if (code != 'all' && _selectedMode == 'full') {
                        // Keep 'full' or 'skill' responsive to section filter
                      }
                    }),
                  ),
                );
              }).toList(),
            ),
          ),
        Expanded(
          child: displayTests.isEmpty
              ? Builder(
                  builder: (context) {
                    final settings = Provider.of<SettingsProvider?>(context);
                    final language = settings?.effectiveLanguage ?? 'vi';
                    final emptyMessage = ContentFallback.jlptTestEmptyStateText(
                      language: language,
                    );
                    return Center(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(20),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: context.cozy.surface,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: context.cozy.borderSubtle),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const CozyPlaceholderBox(
                                height: 110,
                                icon: Icons.quiz_outlined,
                                label:
                                    'Placeholder trống: Khu vực đề thi đang cập nhật',
                              ),
                              const SizedBox(height: 14),
                              Text(
                                emptyMessage,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                  color: context.cozy.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Chưa có đề $level',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: context.cozy.textSecondary,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  itemCount: displayTests.length,
                  itemBuilder: (context, index) {
                    final test = displayTests[index];
                    final matchingHistory = histories
                        .where(
                          (h) =>
                              h.testId == test.id ||
                              h.testId.startsWith(test.id),
                        )
                        .toList();
                    final latestHistory = matchingHistory.isNotEmpty
                        ? matchingHistory.first
                        : null;
                    final bestScore = matchingHistory.isEmpty
                        ? null
                        : matchingHistory
                            .map((h) => h.scorePercent)
                            .reduce((a, b) => a > b ? a : b);

                    return CompanionLineAnchor(
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: context.cozy.surface,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: context.cozy.borderSubtle),
                          boxShadow: context.cozy.softCardShadow,
                        ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: context.cozy.primary,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  level,
                                  style: TextStyle(
                                    color: context.cozy.onPrimary,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  test.title,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: context.cozy.textPrimary,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: latestHistory != null
                                      ? context.cozy.success.withValues(alpha: 0.14)
                                      : context.cozy.surfaceSoft,
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(
                                  latestHistory != null
                                      ? 'Đã làm ${matchingHistory.length} lần · Cao nhất ${bestScore!.toStringAsFixed(0)}%'
                                      : 'Chưa làm',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: latestHistory != null
                                        ? context.cozy.success
                                        : context.cozy.textSecondary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child:
                                Divider(height: 1, color: context.cozy.borderSubtle),
                          ),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              _InfoPill(
                                icon: Icons.fact_check_outlined,
                                label: '${test.questions.length} câu hỏi',
                                color: color,
                              ),
                              _InfoPill(
                                icon: Icons.timer_outlined,
                                label: '${test.timeMinutes} phút',
                                color: context.cozy.accent,
                              ),
                              if (test.isAiGenerated && !test.isFallback)
                                Tooltip(
                                  message:
                                      'Sinh tự động bởi Gemini RAG Engine từ từ vựng & ngữ pháp chuẩn SQLite (src_gemini_rag)',
                                  child: _InfoPill(
                                    icon: Icons.smart_toy_rounded,
                                    label: '🤖 AI Generated',
                                    color: context.cozy.accent,
                                  ),
                                )
                              else if (test.isFallback)
                                _InfoPill(
                                  icon: Icons.folder_special_rounded,
                                  label:
                                      '📁 Đề thi mẫu ngoại tuyến (SQLite Fallback)',
                                  color: context.cozy.warning,
                                )
                              else
                                _InfoPill(
                                  icon: Icons.verified_rounded,
                                  label:
                                      'Nguồn độ khó: Đề thi thật (official_exam)',
                                  color: context.cozy.success,
                                ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: context.cozy.background,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: context.cozy.borderSubtle),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  latestHistory != null
                                      ? Icons.check_circle_outline_rounded
                                      : Icons.info_outline_rounded,
                                  size: 17,
                                  color: latestHistory != null
                                      ? context.cozy.success
                                      : context.cozy.primary,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    latestHistory != null
                                        ? 'Trạng thái bài thi: Đã hoàn thành (${latestHistory.correctAnswers}/${latestHistory.totalQuestions} câu đúng ở lần gần nhất).'
                                        : 'Trạng thái bài thi: Sẵn sàng làm bài · Bộ câu hỏi cấp $level đã xác minh đáp án.',
                                    style: TextStyle(
                                      fontSize: 12.5,
                                      color: context.cozy.textSecondary,
                                      height: 1.35,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            height: 44,
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: context.cozy.primary,
                                foregroundColor: context.cozy.onPrimary,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: () {
                                final progressProvider =
                                    Provider.of<ProgressProvider?>(context, listen: false);
                                if (progressProvider != null &&
                                    progressProvider.progress.catEnergy <= 0) {
                                  ScaffoldMessenger.of(context)
                                    ..hideCurrentSnackBar()
                                    ..showSnackBar(
                                      SnackBar(
                                        behavior: SnackBarBehavior.floating,
                                        backgroundColor: context.cozy.error,
                                        content: Text(
                                          '⚠️ Hoàng Thượng đã cạn Thể lực (0% Energy)! Nhớ mua cá hồi nạp năng lượng sau khi thi nhé!',
                                        ),
                                      ),
                                    );
                                }
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TestScreen(test: test),
                                  ),
                                );
                              },
                              icon: const Icon(
                                Icons.play_arrow_rounded,
                                size: 20,
                              ),
                              label: const Text(
                                'Bắt đầu làm bài',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                ),
        ),
      ],
    );
  }
}

class _InfoPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _InfoPill({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: context.cozy.background,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: context.cozy.borderSubtle),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: context.cozy.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class TestScreen extends StatefulWidget {
  final JLPTTest test;
  const TestScreen({super.key, required this.test});

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  int _currentIndex = 0;
  int? _selected;
  bool _answered = false;
  bool _completed = false;
  int _score = 0;
  final Map<int, int> _selectedAnswers = <int, int>{};
  late final DateTime _startedAt;
  late final ValueNotifier<int> _timer;
  Timer? _ticker;

  static String rankGradeFor(double scorePercent) {
    if (scorePercent >= 90) return 'S';
    if (scorePercent >= 80) return 'A';
    if (scorePercent >= 65) return 'B';
    if (scorePercent >= 50) return 'C';
    return 'F';
  }

  static int baseCoinsForLevel(String level) {
    return switch (level.toUpperCase()) {
      'N1' => 40,
      'N2' => 30,
      'N3' => 25,
      'N4' => 20,
      _ => 15,
    };
  }

  static int baseGemsForLevel(String level, double scorePercent) {
    if (scorePercent < 60) return 0;
    return switch (level.toUpperCase()) {
      'N1' => 5,
      'N2' => 3,
      'N3' => 2,
      'N4' => 1,
      _ => scorePercent >= 80 ? 1 : 0,
    };
  }

  @override
  void initState() {
    super.initState();
    _startedAt = DateTime.now();
    _timer = ValueNotifier(widget.test.timeMinutes * 60);
    _startTimer();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _timer.dispose();
    super.dispose();
  }

  void _startTimer() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _completed) {
        timer.cancel();
        return;
      }
      if (_timer.value <= 1) {
        _timer.value = 0;
        timer.cancel();
        _finishTest();
        return;
      }
      _timer.value -= 1;
    });
  }

  Future<bool> _confirmExitExam() async {
    if (_completed) return true;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        backgroundColor: context.cozy.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Cảnh báo thoát phòng thi',
          style: TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            color: context.cozy.error,
          ),
        ),
        content: Text(
          'Bạn đang làm bài dở. Kết quả sẽ không được lưu nếu thoát. Xác nhận thoát?',
          style: TextStyle(fontSize: 13.5, color: context.cozy.textPrimary, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, false),
            child: const Text('Tiếp tục làm bài'),
          ),
          ElevatedButton(
            key: const ValueKey('jlpt-confirm-exit-btn'),
            style: ElevatedButton.styleFrom(
              backgroundColor: context.cozy.error,
              foregroundColor: context.cozy.onPrimary,
              minimumSize: const Size(120, 40),
            ),
            onPressed: () => Navigator.pop(dialogCtx, true),
            child: const Text('Xác nhận thoát'),
          ),
        ],
      ),
    );
    return confirmed ?? false;
  }

  void _select(int index) {
    if (_answered || _completed) return;
    setState(() {
      _selected = index;
      _selectedAnswers[_currentIndex] = index;
    });
  }

  void _checkAnswer() {
    if (_selected == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Hãy chọn đáp án trước khi kiểm tra nhé.'),
        ),
      );
      return;
    }

    setState(() {
      _answered = true;
      _selectedAnswers[_currentIndex] = _selected!;
      if (_selected == widget.test.questions[_currentIndex].correctIndex) {
        _score++;
      }
    });
  }

  void _next() {
    if (_currentIndex == widget.test.questions.length - 1) {
      _finishTest();
      return;
    }
    setState(() {
      _currentIndex++;
      _selected = null;
      _answered = false;
    });
  }

  Future<void> _finishTest() async {
    if (_completed) return;
    _completed = true;
    _ticker?.cancel();

    final total = widget.test.questions.length;
    final wrong = total - _score;
    final scorePercent = total > 0 ? (_score / total) * 100 : 0.0;
    final duration = DateTime.now().difference(_startedAt);
    final auth = context.read<AuthProvider>();
    final historyProvider = context.read<StudyHistoryProvider>();
    final progressProvider = context.read<ProgressProvider>();
    final history = StudyHistory(
      id: const Uuid().v4(),
      userId: auth.currentUser?.uid ?? 'guest',
      testId: widget.test.id,
      title: widget.test.title,
      jlptLevel: widget.test.level,
      totalQuestions: total,
      correctAnswers: _score,
      wrongAnswers: wrong,
      scorePercent: scorePercent,
      timeTakenSeconds: duration.inSeconds,
      completedAt: DateTime.now(),
    );

    final baseCoins = baseCoinsForLevel(widget.test.level);
    final rewardCoins = scorePercent >= 80
        ? baseCoins
        : (scorePercent >= 50 ? (baseCoins * 0.6).round() : 5);
    final rewardGems = baseGemsForLevel(widget.test.level, scorePercent);
    final rankGrade = rankGradeFor(scorePercent);

    await historyProvider.addHistory(history);
    progressProvider.recordTestResult(
      widget.test.level,
      _score,
      total,
      title: widget.test.title,
      mode: 'jlpt',
    );
    await progressProvider.rewardCoinsAndGems(
      coins: rewardCoins,
      gems: rewardGems,
    );

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ResultDialog(
        history: history,
        questions: widget.test.questions,
        selectedAnswers: Map<int, int>.from(_selectedAnswers),
        rankGrade: rankGrade,
        rewardCoins: rewardCoins,
        rewardGems: rewardGems,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.test.questions[_currentIndex];
    final color = context.cozy.primary;

    return PopScope(
      canPop: _completed,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final canExit = await _confirmExitExam();
        if (canExit && context.mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: context.cozy.background,
        appBar: AppBar(
          backgroundColor: context.cozy.surface,
          leading: IconButton(
            key: const ValueKey('jlpt-exam-back-btn'),
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () async {
              final canExit = await _confirmExitExam();
              if (canExit && context.mounted) {
                Navigator.of(context).pop();
              }
            },
          ),
          title: Text(
            widget.test.title,
            style: TextStyle(
              fontSize: 16.5,
              fontWeight: FontWeight.w700,
              color: context.cozy.textPrimary,
            ),
          ),
          actions: [
            Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: context.cozy.primarySoft,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AppAssetIcon(AppAssets.statusSleepCat, size: 15),
                  SizedBox(width: 4),
                  Text(
                    'Im lặng',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: context.cozy.accent,
                    ),
                  ),
                ],
              ),
            ),
            ValueListenableBuilder<int>(
              valueListenable: _timer,
              builder: (context, value, _) {
                final m = (value ~/ 60).toString().padLeft(2, '0');
                final s = (value % 60).toString().padLeft(2, '0');
                return Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: Center(
                    child: Container(
                      key: const ValueKey('jlpt-exam-timer'),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: context.cozy.surfaceSoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '$m:$s',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: context.cozy.textPrimary,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 820),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.test.isAiGenerated && !widget.test.isFallback) ...[
                    Tooltip(
                      message:
                          'Sinh tự động bởi Gemini RAG Engine từ từ vựng & ngữ pháp chuẩn SQLite (src_gemini_rag)',
                      child: Container(
                        key: const ValueKey('exam-badge-ai-generated'),
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: context.cozy.accent.withValues(alpha: 0.14),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: context.cozy.accent.withValues(alpha: 0.45),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.smart_toy_rounded,
                              size: 16,
                              color: context.cozy.accent,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '🤖 AI Generated',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                                color: context.cozy.accent,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Sinh từ kho từ vựng & ngữ pháp chuẩn SQLite (Gemini RAG)',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  color: context.cozy.textSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ] else if (widget.test.isFallback) ...[
                    Container(
                      key: const ValueKey('exam-badge-sqlite-fallback'),
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: context.cozy.warning.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: context.cozy.warning.withValues(alpha: 0.45),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.folder_special_rounded,
                                size: 16,
                                color: context.cozy.warning,
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  '📁 Đề thi mẫu ngoại tuyến (SQLite Fallback)',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w800,
                                    color: context.cozy.textPrimary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'Đang sử dụng đề dự phòng do sự cố kết nối AI',
                            key: const ValueKey('exam-fallback-notice'),
                            style: TextStyle(
                              fontSize: 11.5,
                              color: context.cozy.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                  if (widget.test.readingPassage != null &&
                      widget.test.readingPassage!.trim().isNotEmpty) ...[
                    Container(
                      key: const ValueKey('exam-reading-passage-card'),
                      width: double.infinity,
                      constraints: const BoxConstraints(maxHeight: 96),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: context.cozy.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: context.cozy.borderSubtle),
                      ),
                      child: SingleChildScrollView(
                        child: Text(
                          widget.test.readingPassage!,
                          style: TextStyle(
                            fontSize: 12.5,
                            height: 1.35,
                            color: context.cozy.textPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: context.cozy.surface,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: context.cozy.borderSubtle),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Câu ${_currentIndex + 1}/${widget.test.questions.length}',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: context.cozy.textPrimary,
                                ),
                              ),
                            ),
                            Text(
                              'Điểm $_score',
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: (_currentIndex + 1) /
                                widget.test.questions.length,
                            minHeight: 7,
                            backgroundColor: context.cozy.surfaceSoft,
                            valueColor: AlwaysStoppedAnimation(color),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: context.cozy.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: context.cozy.borderSubtle),
                    ),
                    child: Column(
                      children: [
                        if (question.questionJp.isNotEmpty)
                          Text(
                            question.questionJp,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: context.cozy.textPrimary,
                            ),
                          ),
                        const SizedBox(height: 8),
                        Text(
                          question.question,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 14.5,
                            color: context.cozy.textSecondary,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: ListView.builder(
                      itemCount: question.options.length,
                      itemBuilder: (context, index) {
                        final isCorrect = index == question.correctIndex;
                        final isSelected = index == _selected;
                        Color border = context.cozy.borderSubtle;
                        Color bg = context.cozy.surface;
                        Color textColor = context.cozy.textPrimary;

                        if (_answered) {
                          if (isCorrect) {
                            border = context.cozy.success;
                            bg = context.cozy.success.withValues(alpha: 0.12);
                            textColor = context.cozy.textPrimary;
                          } else if (isSelected) {
                            border = context.cozy.error;
                            bg = context.cozy.error.withValues(alpha: 0.12);
                            textColor = context.cozy.textPrimary;
                          }
                        } else if (isSelected) {
                          border = color;
                          bg = color.withValues(alpha: 0.10);
                          textColor = context.cozy.textPrimary;
                        }

                        return GestureDetector(
                          onTap: () => _select(index),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: bg,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: border, width: 1.2),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CircleAvatar(
                                  radius: 14,
                                  backgroundColor:
                                      border.withValues(alpha: 0.22),
                                  child: Text(
                                    String.fromCharCode(65 + index),
                                    style: TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w700,
                                      color: context.cozy.textPrimary,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        question.options[index],
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: textColor,
                                        ),
                                      ),
                                      if (_answered && isCorrect) ...[
                                        const SizedBox(height: 4),
                                        Text(
                                          'Đáp án đúng',
                                          style: TextStyle(
                                            color: context.cozy.success,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ] else if (_answered && isSelected) ...[
                                        const SizedBox(height: 4),
                                        Text(
                                          'Bạn đã chọn',
                                          style: TextStyle(
                                            color: context.cozy.error,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  if (_answered)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: context.cozy.surface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: context.cozy.borderSubtle),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Giải thích',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: color,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            question.explanation,
                            style: TextStyle(
                              height: 1.4,
                              color: context.cozy.textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: context.cozy.primary,
                        foregroundColor: context.cozy.onPrimary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _answered ? _next : _checkAnswer,
                      icon: Icon(
                        _answered
                            ? Icons.arrow_forward_rounded
                            : Icons.verified_rounded,
                        size: 19,
                      ),
                      label: Text(
                        _answered
                            ? (_currentIndex ==
                                    widget.test.questions.length - 1
                                ? 'Nộp bài'
                                : 'Câu tiếp theo')
                            : 'Kiểm tra đáp án',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
    );
  }
}

class _ResultDialog extends StatelessWidget {
  final StudyHistory history;
  final List<QuizQuestion> questions;
  final Map<int, int> selectedAnswers;
  final String rankGrade;
  final int rewardCoins;
  final int rewardGems;

  const _ResultDialog({
    required this.history,
    this.questions = const <QuizQuestion>[],
    this.selectedAnswers = const <int, int>{},
    this.rankGrade = 'B',
    this.rewardCoins = 15,
    this.rewardGems = 0,
  });

  void _openReviewSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: context.cozy.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.82,
          minChildSize: 0.5,
          maxChildSize: 0.94,
          builder: (_, scrollController) {
            return Column(
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    color: context.cozy.borderSubtle,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Xem lại bài & Giải thích đáp án',
                          style: TextStyle(
                            fontSize: 16.5,
                            fontWeight: FontWeight.w800,
                            color: context.cozy.textPrimary,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(sheetCtx),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                ),
                Divider(height: 1, color: context.cozy.borderSubtle),
                Expanded(
                  child: ListView.builder(
                    controller: scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: questions.length,
                    itemBuilder: (_, idx) {
                      final q = questions[idx];
                      final userPicked = selectedAnswers[idx];
                      final isCorrect = userPicked == q.correctIndex;
                      final correctOption =
                          (q.correctIndex >= 0 && q.correctIndex < q.options.length)
                              ? q.options[q.correctIndex]
                              : '';
                      final pickedOption = (userPicked != null &&
                              userPicked >= 0 &&
                              userPicked < q.options.length)
                          ? q.options[userPicked]
                          : 'Chưa chọn';

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: context.cozy.background,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isCorrect ? context.cozy.success : context.cozy.error,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Câu ${idx + 1}: ${q.questionJp.isNotEmpty ? "${q.questionJp} — " : ""}${q.question}',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                                color: context.cozy.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Bạn chọn: $pickedOption',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: isCorrect ? context.cozy.success : context.cozy.error,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Đáp án đúng: $correctOption',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: context.cozy.success,
                              ),
                            ),
                            if (q.explanation.isNotEmpty) ...[
                              const SizedBox(height: 6),
                              Text(
                                'Giải thích: ${q.explanation}',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: context.cozy.textSecondary,
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final color =
        history.scorePercent >= 60 ? context.cozy.success : context.cozy.error;
    return AlertDialog(
      backgroundColor: context.cozy.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: context.cozy.borderSubtle),
      ),
      title: const Text(
        'Kết quả bài test',
        textAlign: TextAlign.center,
        style: TextStyle(fontWeight: FontWeight.w700),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  history.jlptLevel,
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: context.cozy.primary,
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  key: const ValueKey('jlpt-result-rank-badge'),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: color),
                  ),
                  child: Text(
                    'Hạng $rankGrade',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(history.title, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text(
              '${history.scorePercent.toStringAsFixed(0)}%',
              style: TextStyle(
                fontSize: 38,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _ScoreBox(
                  label: 'Đúng',
                  value: '${history.correctAnswers}',
                  color: context.cozy.success,
                ),
                _ScoreBox(
                  label: 'Sai',
                  value: '${history.wrongAnswers}',
                  color: context.cozy.error,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              alignment: WrapAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: context.cozy.coinSoft,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const AppAssetIcon(AppAssets.statusCoin, size: 15),
                      const SizedBox(width: 4),
                      Text(
                        '+$rewardCoins Xu',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: context.cozy.coin,
                        ),
                      ),
                    ],
                  ),
                ),
                if (rewardGems > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: context.cozy.gemSoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppAssets.statusGem, size: 15),
                        const SizedBox(width: 4),
                        Text(
                          '+$rewardGems Gem',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: context.cozy.gem,
                          ),
                        ),
                      ],
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: context.cozy.primarySoft,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AppAssetIcon(AppAssets.statusEnergy01, size: 15),
                      SizedBox(width: 4),
                      Text(
                        '-5% Thể lực',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: context.cozy.accent,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Kết quả đã được lưu vào lịch sử học tập.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                color: context.cozy.textSecondary,
              ),
            ),
          ],
        ),
      ),
      actions: [
        if (questions.isNotEmpty)
          TextButton(
            key: const ValueKey('jlpt-review-answers-btn'),
            onPressed: () => _openReviewSheet(context),
            child: const Text('Xem lại bài'),
          ),
        TextButton(
          onPressed: () {
            Navigator.pop(context);
            Navigator.pop(context);
          },
          child: const Text('Đóng'),
        ),
      ],
    );
  }
}

class _ScoreBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _ScoreBox({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          Text(label, style: TextStyle(color: color, fontSize: 12.5)),
        ],
      ),
    );
  }
}
