import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/cat_anim_state.dart';
import '../../models/daily_task.dart';
import '../../providers/auth_provider.dart';
import '../../providers/pomodoro_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/vocabulary_provider.dart';
import '../../services/avatar_upload_service.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/cozy_common_widgets.dart';
import '../../widgets/line_companion_cat.dart';
import '../admin/admin_tools_screen.dart';
import '../dictionary/dictionary_screen.dart';
import '../grammar/grammar_screen.dart';
import '../kana/kana_screen.dart';
import '../lab/ai_practice_lab_screen.dart';
import '../lab/quang_thuong_tutor_screen.dart';
import '../map/world_map_screen.dart';
import '../profile/profile_screen.dart';
import '../read/read_screen.dart';
import '../vocabulary/listening_practice_screen.dart';
import '../vocabulary/pronunciation_practice_screen.dart';
import '../vocabulary/vocabulary_notebook_screen.dart';
import '../vocabulary/writing_practice_screen.dart';

const List<String> _jlptLevels = ['N5', 'N4', 'N3', 'N2', 'N1'];

/// Tab 1 — Học.
class HomeScreen extends StatelessWidget {
  final VoidCallback? onOpenJlpt;

  const HomeScreen({super.key, this.onOpenJlpt});

  static const String headerAsset = 'assets/images/home/home_header_bg.jfif';

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final progressProvider = context.watch<ProgressProvider>();
    final pomodoroProvider = context.watch<PomodoroProvider?>();
    final auth = context.watch<AuthProvider>();
    final vocab = context.watch<VocabularyProvider>();
    final p = progressProvider.progress;
    final themeSpec = AppTheme.specFor(p.selectedLevel.isNotEmpty ? p.selectedThemeId : null);
    final level = _jlptLevels.contains(p.selectedLevel) ? p.selectedLevel : 'N5';

    final levelWords = vocab.allWords.where((w) => w.jlptLevel == level).toList();
    final learnedInLevel = levelWords.where((w) => p.learnedVocabIds.contains(w.id)).length;
    final levelRatio = levelWords.isEmpty ? 0.0 : learnedInLevel / levelWords.length;

    final user = auth.currentUser;
    final displayName = (user?.displayName ?? '').trim();
    final firstName = displayName.isEmpty ? 'bạn' : displayName.split(RegExp(r'\s+')).last;

    return Scaffold(
      backgroundColor: themeSpec.background,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Stack(
              children: [
                _FujiHeader(
                  firstName: firstName,
                  photoUrl: (p.avatarBase64 != null && p.avatarBase64!.isNotEmpty)
                      ? p.avatarBase64
                      : user?.photoUrl,
                  level: level,
                  streak: p.currentStreak,
                  coins: p.coins,
                  gems: p.gems,
                  isAdmin: auth.isAdmin,
                  onTapAvatar: () => _push(context, const ProfileScreen(initialTabIndex: 0)),
                  onTapSettings: () => _push(context, const ProfileScreen(initialTabIndex: 1)),
                  onTapLevel: () => _pickLevel(context, progressProvider, level),
                  onTapAdmin: () => _push(context, const AdminToolsScreen()),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 186, 16, 0),
                  child: CompanionLineAnchor(
                    id: 'home_progress_card',
                    label: 'Mép trên thẻ Tiến độ',
                    child: _ProgressCard(
                      level: level,
                      levelRatio: levelRatio,
                      learnedInLevel: learnedInLevel,
                      totalInLevel: levelWords.length,
                      streak: p.currentStreak,
                      todayXp: p.todayXP,
                      dailyGoal: p.dailyGoal,
                      dailyRatio: p.dailyProgress,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (pomodoroProvider?.lastPenaltyMessage != null)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              sliver: SliverToBoxAdapter(
                child: Container(
                  key: const ValueKey('pomodoro-penalty-banner'),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF1F2),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFF43F5E)),
                  ),
                  child: Row(
                    children: [
                      const AppAssetIcon(AppAssets.badgeDefeatGhost, size: 32),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          pomodoroProvider!.lastPenaltyMessage!,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF9F1239),
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: pomodoroProvider.clearMessages,
                        icon: const Icon(Icons.close_rounded, size: 18, color: Color(0xFF9F1239)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SliverToBoxAdapter(child: _SectionTitle('Bắt đầu học ngay')),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: CompanionLineAnchor(
                id: 'home_module_grid',
                label: 'Mép trên khu Bắt đầu học',
                child: _ModuleGrid(
                  onVocabulary: () => _push(
                    context,
                    const WorldGateScreen(initialMode: MapLearningMode.vocabulary),
                  ),
                  onKanji: () => _push(
                    context,
                    const WorldGateScreen(initialMode: MapLearningMode.kanji),
                  ),
                  onGrammar: () => _push(context, const GrammarScreen()),
                  onReading: () => _push(context, const ReadScreen()),
                  onListening: () => _push(context, ListeningPracticeScreen(level: level)),
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: _SectionTitle('AI Practice Lab & Gia Sư Quàng Thượng')),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: _AiLabHomeBanner(
                level: level,
                onOpenLab: () => _push(context, AiPracticeLabScreen(initialLevel: level)),
                onOpenTutor: () => _push(context, const QuangThuongTutorScreen()),
                onOpenWriting: () => _push(context, WritingPracticeScreen(level: level)),
                onOpenPronunciation: () => _push(context, PronunciationPracticeScreen(level: level)),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: _SectionTitle('Tiện ích học tập')),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: CompanionLineAnchor(
                id: 'home_utility_row',
                surfaceType: CatSurfaceType.shelf,
                label: 'Kệ Tiện ích học tập',
                child: _UtilityRow(
                  onKana: () => _push(context, const KanaScreen()),
                  onNotebook: () => _push(context, const VocabularyNotebookScreen()),
                  onDictionary: () => _push(context, const DictionaryScreen()),
                  onPomodoro: () => _showPomodoroDialog(context),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            sliver: SliverToBoxAdapter(
              child: CompanionLineAnchor(
                id: 'home_daily_review',
                surfaceType: CatSurfaceType.desk,
                label: 'Bàn ôn tập hằng ngày',
                child: _DailyReviewCard(
                  provider: progressProvider,
                  onStartReview: () => _push(
                    context,
                    const WorldGateScreen(initialMode: MapLearningMode.vocabulary),
                  ),
                  onOpenAllTasks: () => _showDailyTasksSheet(context, progressProvider),
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: _FooterQuote()),
          const SliverToBoxAdapter(child: SizedBox(height: 96)),
        ],
      ),
    );
  }

  Future<void> _pickLevel(BuildContext context, ProgressProvider provider, String current) async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Chọn cấp độ JLPT',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  for (final lv in _jlptLevels)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: SizedBox(width: double.infinity, child: Text(lv, textAlign: TextAlign.center)),
                          selected: lv == current,
                          showCheckmark: false,
                          selectedColor: AppTheme.primary,
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: lv == current ? Colors.white : AppTheme.textPrimary,
                          ),
                          onSelected: (_) => Navigator.pop(sheetContext, lv),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (picked != null && picked != current) provider.setSelectedLevel(picked);
  }

  void _showPomodoroDialog(BuildContext context) {
    final progressProvider = context.read<ProgressProvider>();
    final existingPomodoro = context.read<PomodoroProvider?>();
    final pomodoro = existingPomodoro ??
        (PomodoroProvider()..bindProgressProvider(progressProvider));

    Future<bool> confirmEarlyExit(BuildContext ctx) async {
      final ok = await showDialog<bool>(
        context: ctx,
        builder: (warnCtx) => AlertDialog(
          backgroundColor: AppTheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text(
            'Cảnh báo Anti-Cheat Pomodoro',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.error),
          ),
          content: Text(
            'Đang trong phiên học! Nếu kết thúc ngay bây giờ, hệ thống Anti-Cheat sẽ trừ -50 Xu và huỷ phiên. Bạn có chắc muốn thoát sớm?',
            style: TextStyle(fontSize: 13.5, color: AppTheme.textPrimary),
          ),
          actions: [
            TextButton(
              key: const ValueKey('pomodoro-keep-studying-btn'),
              onPressed: () => Navigator.pop(warnCtx, false),
              child: const Text('Tiếp tục học'),
            ),
            ElevatedButton(
              key: const ValueKey('pomodoro-confirm-exit-btn'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.error,
                foregroundColor: Colors.white,
                minimumSize: const Size(110, 40),
              ),
              onPressed: () => Navigator.pop(warnCtx, true),
              child: const Text('Thoát (-50 Xu)'),
            ),
          ],
        ),
      );
      return ok == true;
    }

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => ListenableBuilder(
        listenable: Listenable.merge([pomodoro, progressProvider]),
        builder: (ctx, _) {
          final phase = pomodoro.phase;
          final inStudy = pomodoro.isInStudySession;
          final energy = progressProvider.progress.catEnergy;
          final lowEnergy = energy < PomodoroProvider.lowEnergyThreshold;
          final catId = progressProvider.progress.selectedCatId;
          final catState = phase.catState;
          final catAnimKey = phase == PomodoroPhase.studying
              ? 'thinking'
              : (lowEnergy ? 'sleep' : (catState?.assetKey ?? 'idle'));
          final catAnimPath = phase.canStart && !lowEnergy && phase != PomodoroPhase.completed
              ? AppAssets.learnStudyCat
              : AppAssets.catAnimation(catId, catAnimKey);

          final (Color pillBg, Color pillFg, String pillText) = switch (phase) {
            PomodoroPhase.studying => (AppTheme.primarySoft, AppTheme.accent, '🔒 Đang học — Mèo khoá trạng thái học bài'),
            PomodoroPhase.paused => (const Color(0xFFFFF6E5), const Color(0xFFB7791F), '⏸️ Tạm dừng — giữ nguyên thời gian còn lại'),
            PomodoroPhase.shortBreak => (AppTheme.secondarySoft, AppTheme.textPrimary, '🍵 Nghỉ ngắn — Mèo thư giãn'),
            PomodoroPhase.longBreak => (AppTheme.secondarySoft, AppTheme.textPrimary, '😴 Nghỉ dài — Mèo ngủ trưa'),
            PomodoroPhase.completed => (AppTheme.secondarySoft, AppTheme.textPrimary, '🎉 Hoàn thành — sẵn sàng phiên tiếp theo'),
            PomodoroPhase.cancelled => (const Color(0xFFFFF1F2), const Color(0xFFBE123C), '⛔ Phiên đã huỷ (-50 Xu)'),
            PomodoroPhase.idle => (AppTheme.secondarySoft, AppTheme.textPrimary, '🛡️ Bảo vệ Anti-Cheat (-50 Xu nếu rời phiên học)'),
          };

          Widget configChips({
            required String label,
            required String keyPrefix,
            required List<int> values,
            required int selected,
            required ValueChanged<int> onSelected,
            String suffix = 'p',
          }) {
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final v in values)
                        ChoiceChip(
                          key: ValueKey('$keyPrefix-$v'),
                          label: Text('$v$suffix'),
                          selected: selected == v,
                          showCheckmark: false,
                          selectedColor: AppTheme.primary,
                          labelStyle: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                            color: selected == v ? Colors.white : AppTheme.textPrimary,
                          ),
                          onSelected: (_) => onSelected(v),
                        ),
                    ],
                  ),
                ],
              ),
            );
          }

          return PopScope(
            canPop: !inStudy,
            onPopInvokedWithResult: (didPop, _) async {
              if (didPop) return;
              if (await confirmEarlyExit(dialogContext) && dialogContext.mounted) {
                await pomodoro.stop();
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              }
            },
            child: AlertDialog(
              backgroundColor: AppTheme.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              title: Row(
                children: [
                  const AppAssetIcon(AppAssets.navBell, size: 26),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Pomodoro tập trung',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF6E5),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppAssets.statusCoin, size: 15),
                        const SizedBox(width: 4),
                        Text(
                          progressProvider.progress.coins >= 99999 ? '99,999' : '${progressProvider.progress.coins}',
                          key: const ValueKey('pomodoro-coin-balance'),
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFFB7791F)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                      decoration: BoxDecoration(
                        color: AppTheme.background,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppTheme.borderSubtle),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AppAssetIcon(catAnimPath, key: ValueKey('pomodoro-cat-$catAnimPath'), size: 84),
                          const SizedBox(height: 6),
                          Container(
                            key: const ValueKey('pomodoro-phase-pill'),
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: pillBg, borderRadius: BorderRadius.circular(999)),
                            child: Text(
                              pillText,
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: pillFg),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            phase.label.toUpperCase(),
                            key: const ValueKey('pomodoro-phase-label'),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.2,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                          Text(
                            pomodoro.formattedRemaining,
                            key: const ValueKey('pomodoro-timer-text'),
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              color: AppTheme.accent,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(999),
                            child: LinearProgressIndicator(
                              value: pomodoro.progressFraction,
                              minHeight: 6,
                              backgroundColor: AppTheme.borderSubtle,
                              color: phase.isBreak ? AppTheme.success : AppTheme.primary,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Phiên trong chu kỳ: ${pomodoro.cycleSessions}/${pomodoro.sessionsBeforeLongBreak} • Tổng đã hoàn thành: ${pomodoro.completedSessionsCount}',
                            key: const ValueKey('pomodoro-session-count'),
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppTheme.textSecondary),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const AppAssetIcon(AppAssets.statusEnergy01, size: 16),
                              const SizedBox(width: 4),
                              Flexible(
                                child: Text(
                                  'Thể lực Mèo: $energy% (-${pomodoro.studyMinutes}% khi xong 1 phiên)',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    color: lowEnergy ? AppTheme.error : AppTheme.textSecondary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (lowEnergy)
                            const Padding(
                              padding: EdgeInsets.only(top: 6),
                              child: Text(
                                '⚠️ Mèo đang ủ rũ vì năng lượng dưới 20%. Vào Shop mua thức ăn để nạp lại!',
                                key: ValueKey('pomodoro-low-energy-hint'),
                                textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppTheme.error),
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (pomodoro.canConfigure) ...[
                      const SizedBox(height: 4),
                      configChips(
                        label: 'Thời gian học (phút):',
                        keyPrefix: 'pomodoro-preset',
                        values: PomodoroProvider.presetMinutes,
                        selected: pomodoro.studyMinutes,
                        onSelected: pomodoro.setStudyMinutes,
                      ),
                      Slider(
                        key: const ValueKey('pomodoro-duration-slider'),
                        value: pomodoro.studyMinutes.clamp(5, 90).toDouble(),
                        min: 5,
                        max: 90,
                        divisions: 17,
                        label: '${pomodoro.studyMinutes} phút',
                        activeColor: AppTheme.primary,
                        onChanged: (val) => pomodoro.setStudyMinutes(val.round()),
                      ),
                      configChips(
                        label: 'Nghỉ ngắn (phút):',
                        keyPrefix: 'pomodoro-short',
                        values: PomodoroProvider.shortBreakPresets,
                        selected: pomodoro.shortBreakMinutes,
                        onSelected: pomodoro.setShortBreakMinutes,
                      ),
                      configChips(
                        label: 'Nghỉ dài (phút):',
                        keyPrefix: 'pomodoro-long',
                        values: PomodoroProvider.longBreakPresets,
                        selected: pomodoro.longBreakMinutes,
                        onSelected: pomodoro.setLongBreakMinutes,
                      ),
                      configChips(
                        label: 'Số phiên học trước khi nghỉ dài:',
                        keyPrefix: 'pomodoro-cycle',
                        values: const [2, 3, 4, 6],
                        selected: pomodoro.sessionsBeforeLongBreak,
                        onSelected: pomodoro.setSessionsBeforeLongBreak,
                        suffix: ' phiên',
                      ),
                    ],
                    if (pomodoro.lastPenaltyMessage != null) ...[
                      const SizedBox(height: 8),
                      Container(
                        key: const ValueKey('pomodoro-dialog-penalty-msg'),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF1F2),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFF43F5E)),
                        ),
                        child: Text(
                          pomodoro.lastPenaltyMessage!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF9F1239)),
                        ),
                      ),
                    ],
                    if (pomodoro.lastCompletionMessage != null) ...[
                      const SizedBox(height: 8),
                      Container(
                        key: const ValueKey('pomodoro-dialog-complete-msg'),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppTheme.secondarySoft,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppTheme.secondary),
                        ),
                        child: Text(
                          pomodoro.lastCompletionMessage!,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              actionsOverflowButtonSpacing: 6,
              actions: [
                if (!pomodoro.canStart)
                  TextButton(
                    key: const ValueKey('pomodoro-abort-btn'),
                    onPressed: () async {
                      if (inStudy) {
                        if (await confirmEarlyExit(dialogContext)) await pomodoro.stop();
                      } else {
                        await pomodoro.stop();
                      }
                    },
                    child: Text(
                      inStudy ? 'Kết thúc (-50 Xu)' : 'Kết thúc',
                      style: const TextStyle(color: AppTheme.error, fontWeight: FontWeight.w800),
                    ),
                  ),
                if (phase.isBreak || (phase == PomodoroPhase.paused && (pomodoro.pausedFrom?.isBreak ?? false)))
                  TextButton(
                    key: const ValueKey('pomodoro-skip-break-btn'),
                    onPressed: pomodoro.skipBreak,
                    child: const Text('Bỏ qua nghỉ'),
                  ),
                if (phase.isTicking)
                  ElevatedButton(
                    key: const ValueKey('pomodoro-pause-btn'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryMuted,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(110, 42),
                    ),
                    onPressed: pomodoro.pause,
                    child: const Text('Tạm dừng'),
                  ),
                if (phase == PomodoroPhase.paused)
                  ElevatedButton(
                    key: const ValueKey('pomodoro-resume-btn'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(110, 42),
                    ),
                    onPressed: pomodoro.resume,
                    child: const Text('Tiếp tục'),
                  ),
                if (pomodoro.canStart) ...[
                  TextButton(
                    key: const ValueKey('pomodoro-close-btn'),
                    onPressed: () => Navigator.pop(dialogContext),
                    child: Text('Đóng', style: TextStyle(color: AppTheme.textSecondary)),
                  ),
                  ElevatedButton(
                    key: const ValueKey('pomodoro-start-btn'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(140, 42),
                    ),
                    onPressed: () => pomodoro.startTimer(),
                    child: Text(phase == PomodoroPhase.completed ? 'Bắt đầu phiên tiếp' : 'Bắt đầu học'),
                  ),
                ] else if (!inStudy)
                  TextButton(
                    key: const ValueKey('pomodoro-hide-btn'),
                    onPressed: () => Navigator.pop(dialogContext),
                    child: Text('Ẩn', style: TextStyle(color: AppTheme.textSecondary)),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showDailyTasksSheet(BuildContext context, ProgressProvider provider) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        builder: (_, controller) => ListenableBuilder(
          listenable: provider,
          builder: (sheetContext, __) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.borderSubtle,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  AppAssetIcon(AppAssets.navCalendar, size: 24),
                  SizedBox(width: 8),
                  Text(
                    'Nhiệm vụ ngày',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              if (provider.dailyTasks.isEmpty)
                const CozySurfaceCard(child: Text('Chưa có nhiệm vụ hôm nay.'))
              else
                for (final task in provider.dailyTasks)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _DailyTaskTile(
                      task: task,
                      onClaim: task.isCompleted && !task.isClaimed
                          ? () async {
                              final ok = await provider.claimDailyTask(task.id);
                              if (!sheetContext.mounted) return;
                              ScaffoldMessenger.of(sheetContext).showSnackBar(
                                SnackBar(
                                  content: Text(ok ? 'Đã nhận ${task.rewardXp} EXP' : 'Chưa thể nhận thưởng'),
                                ),
                              );
                            }
                          : null,
                    ),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FujiHeader extends StatelessWidget {
  final String firstName;
  final String? photoUrl;
  final String level;
  final int streak;
  final int coins;
  final int gems;
  final bool isAdmin;
  final VoidCallback onTapAvatar;
  final VoidCallback onTapSettings;
  final VoidCallback onTapLevel;
  final VoidCallback? onTapAdmin;

  const _FujiHeader({
    required this.firstName,
    required this.photoUrl,
    required this.level,
    required this.streak,
    required this.coins,
    required this.gems,
    this.isAdmin = false,
    required this.onTapAvatar,
    required this.onTapSettings,
    required this.onTapLevel,
    this.onTapAdmin,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 236,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            HomeScreen.headerAsset,
            fit: BoxFit.cover,
            alignment: Alignment.topCenter,
            errorBuilder: (_, __, ___) => ColoredBox(color: AppTheme.surfaceSoft),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppTheme.background.withValues(alpha: 0.35),
                  AppTheme.background.withValues(alpha: 0.15),
                  AppTheme.background,
                ],
                stops: const [0, 0.55, 1],
              ),
            ),
          ),
          SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _Avatar(photoUrl: photoUrl, initial: firstName, onTap: onTapAvatar),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text(
                              'Chào $firstName ♡',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Cùng học tiếng Nhật nhé!',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: [
                                _LevelBadge(level: level, onTap: onTapLevel),
                                if (isAdmin && onTapAdmin != null)
                                  Material(
                                    color: Colors.transparent,
                                    child: InkWell(
                                      borderRadius: BorderRadius.circular(999),
                                      onTap: onTapAdmin,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                        decoration: BoxDecoration(
                                          color: AppTheme.accent,
                                          borderRadius: BorderRadius.circular(999),
                                        ),
                                        child: const Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(Icons.admin_panel_settings_rounded, size: 13, color: Colors.white),
                                            SizedBox(width: 4),
                                            Text(
                                              'Admin',
                                              style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: Colors.white),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      _GlassIconButton(
                        icon: AppAssets.navSettings,
                        tooltip: 'Cài đặt',
                        onTap: onTapSettings,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Wrap(
                      spacing: 8,
                      children: [
                        _ResourcePill(icon: AppAssets.statusStreak, value: streak, tooltip: 'Chuỗi ngày học'),
                        _ResourcePill(icon: AppAssets.statusCoin, value: coins, tooltip: 'Coin'),
                        _ResourcePill(icon: AppAssets.statusGem, value: gems, tooltip: 'Gem'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String? photoUrl;
  final String initial;
  final VoidCallback onTap;

  const _Avatar({required this.photoUrl, required this.initial, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final letter = initial.isEmpty ? '?' : initial.characters.first.toUpperCase();
    final fallback = Center(
      child: Text(
        letter,
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppTheme.accent),
      ),
    );
    return Tooltip(
      message: 'Hồ sơ',
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppTheme.surface,
            border: Border.all(color: AppTheme.surface, width: 3),
            boxShadow: AppTheme.softCardShadow,
          ),
          clipBehavior: Clip.antiAlias,
          child: Builder(
            builder: (context) {
              if (photoUrl == null || photoUrl!.isEmpty) return fallback;
              final decodedBytes = AvatarUploadService.decodeDataUri(photoUrl);
              if (decodedBytes != null) {
                return Image.memory(
                  decodedBytes,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => fallback,
                );
              }
              return Image.network(
                photoUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => fallback,
              );
            },
          ),
        ),
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  final String level;
  final VoidCallback onTap;

  const _LevelBadge({required this.level, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.primaryMuted.withValues(alpha: 0.28),
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 5, 6, 5),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'JLPT $level',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppTheme.accent),
              ),
              Icon(Icons.keyboard_arrow_down_rounded, size: 18, color: AppTheme.accent),
            ],
          ),
        ),
      ),
    );
  }
}

class _GlassIconButton extends StatelessWidget {
  final String icon;
  final String tooltip;
  final VoidCallback onTap;

  const _GlassIconButton({required this.icon, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: AppTheme.surface.withValues(alpha: 0.85),
        shape: const CircleBorder(),
        elevation: 0,
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: AppAssetIcon(icon, size: 26),
          ),
        ),
      ),
    );
  }
}

class _ResourcePill extends StatelessWidget {
  final String icon;
  final int value;
  final String tooltip;

  const _ResourcePill({required this.icon, required this.value, required this.tooltip});

  @override
  Widget build(BuildContext context) {
    final formattedValue = value >= 99999 ? '99,999' : '$value';
    return Tooltip(
      message: tooltip,
      child: Container(
        padding: const EdgeInsets.fromLTRB(6, 4, 12, 4),
        decoration: BoxDecoration(
          color: AppTheme.surface.withValues(alpha: 0.9),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: AppTheme.borderSubtle),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppAssetIcon(icon, size: 20),
            const SizedBox(width: 5),
            Text(
              formattedValue,
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final String level;
  final double levelRatio;
  final int learnedInLevel;
  final int totalInLevel;
  final int streak;
  final int todayXp;
  final int dailyGoal;
  final double dailyRatio;

  const _ProgressCard({
    required this.level,
    required this.levelRatio,
    required this.learnedInLevel,
    required this.totalInLevel,
    required this.streak,
    required this.todayXp,
    required this.dailyGoal,
    required this.dailyRatio,
  });

  @override
  Widget build(BuildContext context) {
    final percent = (levelRatio * 100).round();
    return _CozyCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const AppAssetIcon(AppAssets.achTitleRed, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Tiến độ học tập',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                ),
              ),
              const AppAssetIcon(AppAssets.statusStreak, size: 22),
              const SizedBox(width: 4),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: '$streak',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                    ),
                    TextSpan(
                      text: ' ngày',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              SizedBox(
                width: 108,
                height: 108,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox.expand(
                      child: CircularProgressIndicator(
                        value: levelRatio,
                        strokeWidth: 9,
                        strokeCap: StrokeCap.round,
                        backgroundColor: AppTheme.surfaceSoft,
                        valueColor: AlwaysStoppedAnimation(AppTheme.primary),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$percent%',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                        ),
                        Text(
                          'JLPT $level',
                          style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$learnedInLevel/$totalInLevel từ vựng $level',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryMuted.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              AppAssetIcon(AppAssets.achMedal, size: 20),
                              SizedBox(width: 6),
                              Text(
                                'Mục tiêu hôm nay',
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '$todayXp / $dailyGoal XP',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                          ),
                          const SizedBox(height: 8),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(999),
                            child: LinearProgressIndicator(
                              value: dailyRatio,
                              minHeight: 7,
                              backgroundColor: AppTheme.surface,
                              valueColor: AlwaysStoppedAnimation(AppTheme.primary),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;

  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 10),
      child: Row(
        children: [
          const AppAssetIcon(AppAssets.achTitleRed, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModuleGrid extends StatelessWidget {
  final VoidCallback onVocabulary;
  final VoidCallback onKanji;
  final VoidCallback onGrammar;
  final VoidCallback onReading;
  final VoidCallback onListening;

  const _ModuleGrid({
    required this.onVocabulary,
    required this.onKanji,
    required this.onGrammar,
    required this.onReading,
    required this.onListening,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: _ModuleCard(
                  icon: AppAssets.labVocab,
                  title: 'Từ vựng',
                  subtitle: 'Bản đồ 5 thế giới',
                  onTap: onVocabulary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _ModuleCard(
                  icon: AppAssets.labKanji,
                  title: 'Kanji',
                  subtitle: 'Bản đồ Kanji',
                  accent: AppTheme.accent,
                  onTap: onKanji,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: _ModuleCard(
                  icon: AppAssets.labGrammar,
                  title: 'Ngữ pháp',
                  subtitle: 'Mẫu câu N5–N1',
                  onTap: onGrammar,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _CozyCard(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const AppAssetIcon(AppAssets.learnStudyCat, size: 36),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Đọc & Nghe',
                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(child: _MiniAction(label: 'Đọc', icon: AppAssets.labReadingBook, onTap: onReading)),
                          const SizedBox(width: 6),
                          Expanded(child: _MiniAction(label: 'Nghe', icon: AppAssets.labListening, onTap: onListening)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AiLabHomeBanner extends StatelessWidget {
  final String level;
  final VoidCallback onOpenLab;
  final VoidCallback onOpenTutor;
  final VoidCallback onOpenWriting;
  final VoidCallback onOpenPronunciation;

  const _AiLabHomeBanner({
    required this.level,
    required this.onOpenLab,
    required this.onOpenTutor,
    required this.onOpenWriting,
    required this.onOpenPronunciation,
  });

  @override
  Widget build(BuildContext context) {
    return _CozyCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onOpenLab,
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: const AppAssetIcon(AppAssets.labAiPractice, size: 34),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Practice Lab • Nhiệm vụ thích ứng ($level)',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Luyện viết nét chữ, phát âm, gia sư Quàng Thượng & nhiệm vụ thông minh',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _MiniAction(
                  label: 'Viết tay',
                  icon: AppAssets.labWriting,
                  onTap: onOpenWriting,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _MiniAction(
                  label: 'Phát âm',
                  icon: AppAssets.labPronunciation,
                  onTap: onOpenPronunciation,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _MiniAction(
                  label: 'Quàng Thượng',
                  icon: AppAssets.labTutorCat,
                  onTap: onOpenTutor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final Color? _accent;
  Color get accent => _accent ?? AppTheme.primary;
  final VoidCallback onTap;

  const _ModuleCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    Color? accent,
  }) : _accent = accent;

  @override
  Widget build(BuildContext context) {
    return _CozyCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            alignment: Alignment.center,
            child: AppAssetIcon(icon, size: 32),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 2,
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniAction extends StatelessWidget {
  final String label;
  final String icon;
  final VoidCallback onTap;

  const _MiniAction({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.background,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 7),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppAssetIcon(icon, size: 18),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UtilityRow extends StatelessWidget {
  final VoidCallback onKana;
  final VoidCallback onNotebook;
  final VoidCallback onDictionary;
  final VoidCallback onPomodoro;

  const _UtilityRow({
    required this.onKana,
    required this.onNotebook,
    required this.onDictionary,
    required this.onPomodoro,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _UtilityButton(
            label: 'Kana',
            onTap: onKana,
            icon: Text(
              'あ',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: AppTheme.primary, height: 1),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _UtilityButton(
            label: 'Sổ tay',
            onTap: onNotebook,
            icon: const AppAssetIcon(AppAssets.navInventory, size: 30),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _UtilityButton(
            label: 'Từ điển',
            onTap: onDictionary,
            icon: const AppAssetIcon(AppAssets.navHelp, size: 30),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _UtilityButton(
            label: 'Pomodoro',
            onTap: onPomodoro,
            icon: const AppAssetIcon(AppAssets.navBell, size: 30),
          ),
        ),
      ],
    );
  }
}

class _UtilityButton extends StatelessWidget {
  final String label;
  final Widget icon;
  final VoidCallback onTap;

  const _UtilityButton({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return _CozyCard(
      onTap: onTap,
      radius: 18,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 32, child: Center(child: icon)),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textPrimary),
          ),
        ],
      ),
    );
  }
}

class _DailyReviewCard extends StatelessWidget {
  final ProgressProvider provider;
  final VoidCallback onStartReview;
  final VoidCallback onOpenAllTasks;

  const _DailyReviewCard({
    required this.provider,
    required this.onStartReview,
    required this.onOpenAllTasks,
  });

  Future<void> _claim(BuildContext context) async {
    final ok = await provider.claimDailyReviewReward();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok ? 'Đã nhận +${ProgressProvider.dailyReviewRewardCoins} Coin' : 'Chưa thể nhận thưởng'),
        backgroundColor: ok ? AppTheme.success : AppTheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final claimed = provider.isDailyReviewClaimedToday;
    final claimable = provider.canClaimDailyReview;
    final pending = provider.claimableDailyTaskCount;

    final Widget action;
    if (claimed) {
      action = const _RewardPill(label: 'Đã nhận', enabled: false);
    } else if (claimable) {
      action = _RewardPill(
        label: '+${ProgressProvider.dailyReviewRewardCoins}',
        icon: AppAssets.statusCoin,
        onTap: () => _claim(context),
      );
    } else {
      action = _RewardPill(label: 'Ôn tập', outlined: true, onTap: onStartReview);
    }

    return _CozyCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 6),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.primaryMuted.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: const AppAssetIcon(AppAssets.navCalendar, size: 28),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Ôn tập từ vựng hằng ngày',
                      style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      claimed
                          ? 'Hẹn bạn ngày mai ♡'
                          : claimable
                              ? 'Hoàn thành rồi!'
                              : 'Học ít nhất 1 từ mới hôm nay',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
              action,
            ],
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: onOpenAllTasks,
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.accent,
                visualDensity: VisualDensity.compact,
              ),
              icon: const Icon(Icons.chevron_right_rounded, size: 18),
              label: Text(
                pending > 0 ? 'Nhiệm vụ khác · $pending chờ nhận' : 'Nhiệm vụ khác',
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardPill extends StatelessWidget {
  final String label;
  final String? icon;
  final bool enabled;
  final bool outlined;
  final VoidCallback? onTap;

  const _RewardPill({
    required this.label,
    this.icon,
    this.enabled = true,
    this.outlined = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final filled = enabled && !outlined;
    return Material(
      color: !enabled
          ? AppTheme.surfaceSoft
          : filled
              ? AppTheme.primary
              : AppTheme.surface,
      shape: StadiumBorder(
        side: outlined ? BorderSide(color: AppTheme.primary, width: 1.4) : BorderSide.none,
      ),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: enabled ? onTap : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: !enabled
                      ? AppTheme.textSecondary
                      : filled
                          ? Colors.white
                          : AppTheme.primary,
                ),
              ),
              if (icon != null) ...[
                const SizedBox(width: 4),
                AppAssetIcon(icon!, size: 18),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _DailyTaskTile extends StatelessWidget {
  final DailyTask task;
  final Future<void> Function()? onClaim;

  const _DailyTaskTile({required this.task, this.onClaim});

  @override
  Widget build(BuildContext context) {
    final accent = task.isClaimed
        ? AppTheme.textSecondary
        : task.isCompleted
            ? AppTheme.success
            : AppTheme.primary;
    return _CozyCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(task.icon, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.title,
                      style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                    ),
                    Text(
                      task.description,
                      style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
              CozyTagChip(label: '+${task.rewardXp} EXP', isSelected: task.isCompleted && !task.isClaimed),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: task.completionRate,
              minHeight: 6,
              backgroundColor: AppTheme.background,
              valueColor: AlwaysStoppedAnimation(accent),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(
                '${task.progress}/${task.target}',
                style: TextStyle(color: accent, fontSize: 12, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              if (task.isClaimed)
                Text('Đã nhận', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12))
              else if (task.isCompleted)
                FilledButton(
                  onPressed: onClaim == null ? null : () => onClaim!(),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppTheme.success,
                    visualDensity: VisualDensity.compact,
                  ),
                  child: const Text('Nhận EXP'),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FooterQuote extends StatelessWidget {
  const _FooterQuote();

  @override
  Widget build(BuildContext context) {
    final line = Expanded(
      child: Container(height: 1, color: AppTheme.primaryMuted.withValues(alpha: 0.35)),
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 26, 24, 8),
      child: Row(
        children: [
          line,
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              '“ Mỗi ngày học một chút,\nbạn sẽ tiến xa hơn rất nhiều! ”',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                height: 1.5,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.w600,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          line,
        ],
      ),
    );
  }
}

class _CozyCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;

  const _CozyCard({
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 22,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final borderRadius = BorderRadius.circular(radius);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Material(
        color: AppTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: borderRadius,
          side: BorderSide(color: AppTheme.borderSubtle),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}
