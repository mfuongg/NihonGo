import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../../widgets/line_companion_cat.dart';
import '../pk/pk_lobby_screen.dart';
import '../pk/pk_models.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  // 0 = Học tập (Streak), 1 = Mèo Nổ PK (MR)
  int _activeBoardIndex = 0;

  // 0 = Tuần này, 1 = Tháng này, 2 = Tất cả
  int _streakPeriodIndex = 0;

  void _openPkLobby() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const PKLobbyScreen(),
      ),
    );
  }

  List<_StudyLeaderboardEntry> _buildStudyEntries({
    required String userName,
    required int userStreak,
    required int userWords,
  }) {
    final multiplier = _streakPeriodIndex == 0
        ? 1
        : _streakPeriodIndex == 1
            ? 2
            : 4;

    final raw = <_StudyLeaderboardEntry>[
      _StudyLeaderboardEntry(
        id: 'u_sakura',
        name: 'Sakura_N1',
        title: 'Đại Sư Ngôn Ngữ • N1',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        streakDays: 32 * multiplier,
        wordsLearned: 1420,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_kenji',
        name: 'Kenji_Tokyo',
        title: 'Chiến Thần Học Thuật • N2',
        avatarAsset: AppAssets.catHeroIdle,
        streakDays: 27 * multiplier,
        wordsLearned: 1180,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_linh',
        name: 'LinhChan_JP',
        title: 'Cao Thủ Từ Vựng • N2',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        streakDays: 23 * multiplier,
        wordsLearned: 960,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_minh',
        name: 'MinhSensei_N3',
        title: 'Mèo Tinh Anh • N3',
        avatarAsset: AppAssets.catHeroIdle,
        streakDays: 18 * multiplier,
        wordsLearned: 780,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_haruka',
        name: 'Haruka_JP',
        title: 'Mèo Phản Xạ • N3',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        streakDays: 14 * multiplier,
        wordsLearned: 620,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_me',
        name: userName,
        title: 'Bạn • Học viên Nihongo',
        avatarAsset: AppAssets.catHeroIdle,
        streakDays: userStreak > 0 ? userStreak : 7,
        wordsLearned: userWords > 0 ? userWords : 340,
        isCurrentUser: true,
      ),
      _StudyLeaderboardEntry(
        id: 'u_aki',
        name: 'Aki_Osaka',
        title: 'Mèo Nhanh Trí • N4',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        streakDays: 6 * multiplier,
        wordsLearned: 290,
        isCurrentUser: false,
      ),
      _StudyLeaderboardEntry(
        id: 'u_yuki',
        name: 'Yuki_Snow',
        title: 'Mèo Tập Sự • N5',
        avatarAsset: AppAssets.catHeroIdle,
        streakDays: 4 * multiplier,
        wordsLearned: 180,
        isCurrentUser: false,
      ),
    ];

    raw.sort((a, b) {
      final cmp = b.streakDays.compareTo(a.streakDays);
      if (cmp != 0) return cmp;
      return b.wordsLearned.compareTo(a.wordsLearned);
    });
    return raw;
  }

  List<_PkLeaderboardEntry> _buildPkEntries({
    required String userName,
    required int userMr,
    required int userWinRate,
  }) {
    final raw = <_PkLeaderboardEntry>[
      const _PkLeaderboardEntry(
        id: 'pk_raiden',
        name: 'Raiden_Meow',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        mr: 2180,
        winRatePercent: 84,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_sakura',
        name: 'Sakura_N1',
        avatarAsset: AppAssets.catHeroIdle,
        mr: 1740,
        winRatePercent: 79,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_kenji',
        name: 'Kenji_Tokyo',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        mr: 1360,
        winRatePercent: 74,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_linh',
        name: 'LinhChan_JP',
        avatarAsset: AppAssets.catHeroIdle,
        mr: 980,
        winRatePercent: 70,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_kuro',
        name: 'KuroNeko_N4',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        mr: 745,
        winRatePercent: 66,
        isCurrentUser: false,
      ),
      _PkLeaderboardEntry(
        id: 'pk_me',
        name: userName,
        avatarAsset: AppAssets.catHeroIdle,
        mr: userMr,
        winRatePercent: userWinRate,
        isCurrentUser: true,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_haruka',
        name: 'Haruka_JP',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        mr: 520,
        winRatePercent: 61,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_yuki',
        name: 'Yuki_Snow',
        avatarAsset: AppAssets.catHeroIdle,
        mr: 280,
        winRatePercent: 54,
        isCurrentUser: false,
      ),
      const _PkLeaderboardEntry(
        id: 'pk_momo',
        name: 'Momo_N5',
        avatarAsset: AppAssets.kawaiiCatAvatar,
        mr: 140,
        winRatePercent: 48,
        isCurrentUser: false,
      ),
    ];

    raw.sort((a, b) => b.mr.compareTo(a.mr));
    return raw;
  }

  @override
  Widget build(BuildContext context) {
    final progress = context.watch<ProgressProvider>().userProgress;
    final authUser = context.watch<AuthProvider>().currentUser;
    final rawName = authUser?.displayName.trim() ?? '';
    final displayName = rawName.isNotEmpty ? rawName : 'Bạn (Meow)';

    final studyEntries = _buildStudyEntries(
      userName: displayName,
      userStreak: progress.currentStreak,
      userWords: progress.learnedVocabIds.length,
    );
    final pkEntries = _buildPkEntries(
      userName: displayName,
      userMr: progress.pkRating,
      userWinRate: progress.pkWinRatePercent,
    );

    final myStudyRank =
        studyEntries.indexWhere((e) => e.isCurrentUser) + 1;
    final myStudyEntry =
        studyEntries.firstWhere((e) => e.isCurrentUser);

    final myPkRank = pkEntries.indexWhere((e) => e.isCurrentUser) + 1;
    final myPkEntry = pkEntries.firstWhere((e) => e.isCurrentUser);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            // Top Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  const AppAssetIcon(AppIcons.trophy, size: 28),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Bảng Xếp Hạng & Đấu Trường PK',
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          'Đấu Trí Ngôn Ngữ cùng AI • Đua Top Streak & Mèo Nổ PK 16 lá',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.primarySoft,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: AppTheme.borderSubtle),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppAssetIcon(AppIcons.medalRank, size: 16),
                        const SizedBox(width: 5),
                        Text(
                          '${progress.pkRating} MR',
                          style: TextStyle(
                            color: AppTheme.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Main Scrollable Content
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                children: [
                  // 1. HERO BANNER LỐI VÀO ĐẤU TRƯỜNG MÈO NỔ PK (pk_lobby_hero_banner.png)
                  CompanionLineAnchor(
                    child: _buildPkArenaHeroBanner(),
                  ),
                  const SizedBox(height: 16),

                  // 2. DUAL SUB-TABS: [🔥 Học tập (Streak)] | [💣 Mèo Nổ PK (MR)]
                  CompanionLineAnchor(
                    child: _buildDualSubTabSwitch(),
                  ),
                  const SizedBox(height: 14),

                  if (_activeBoardIndex == 0) ...[
                    _buildStreakPeriodChips(),
                    const SizedBox(height: 12),
                    CompanionLineAnchor(
                      child: _buildStudyPodiumSection(studyEntries.take(3).toList()),
                    ),
                    const SizedBox(height: 14),
                    ...List.generate(
                      studyEntries.length > 3 ? studyEntries.length - 3 : 0,
                      (idx) {
                        final rank = idx + 4;
                        final entry = studyEntries[idx + 3];
                        return CompanionLineAnchor(
                          child: _buildStudyRankRow(rank, entry),
                        );
                      },
                    ),
                  ] else ...[
                    // 8 Bậc Rank Mèo Học Thuật Showcase
                    CompanionLineAnchor(
                      child: _buildEightAcademicCatRanksCard(progress.pkRating),
                    ),
                    const SizedBox(height: 14),
                    CompanionLineAnchor(
                      child: _buildPkPodiumSection(pkEntries.take(3).toList()),
                    ),
                    const SizedBox(height: 14),
                    ...List.generate(
                      pkEntries.length > 3 ? pkEntries.length - 3 : 0,
                      (idx) {
                        final rank = idx + 4;
                        final entry = pkEntries[idx + 3];
                        return CompanionLineAnchor(
                          child: _buildPkRankRow(rank, entry),
                        );
                      },
                    ),
                  ],
                ],
              ),
            ),

            // 4. PINNED PERSONAL RANK BAR AT BOTTOM
            _buildPinnedPersonalRankBar(
              studyRank: myStudyRank,
              studyEntry: myStudyEntry,
              pkRank: myPkRank,
              pkEntry: myPkEntry,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPkArenaHeroBanner() {
    return Semantics(
      button: true,
      label: 'Vào Đấu Trường Mèo Nổ PK',
      child: InkWell(
        key: const ValueKey('leaderboard_pk_hero_banner'),
        onTap: _openPkLobby,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: AppTheme.primary.withValues(alpha: 0.45),
              width: 1.8,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withValues(alpha: 0.18),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Stack(
              children: [
                Image.asset(
                  AppAssets.pkLobbyHeroBanner,
                  height: 176,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 176,
                    color: const Color(0xFF312E81),
                  ),
                ),
                Positioned(
                  right: 12,
                  bottom: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFF59E0B), Color(0xFFE11D48)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.28),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'VÀO SẢNH PK',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(width: 4),
                        Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.white,
                          size: 16,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDualSubTabSwitch() {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: AppTheme.surfaceSoft,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              key: const ValueKey('leaderboard_tab_study'),
              onTap: () => setState(() => _activeBoardIndex = 0),
              borderRadius: BorderRadius.circular(14),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 11),
                decoration: BoxDecoration(
                  color: _activeBoardIndex == 0
                      ? AppTheme.surface
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: _activeBoardIndex == 0
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.06),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const AppAssetIcon(AppIcons.streakFire, size: 18),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        'Học tập (Streak)',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _activeBoardIndex == 0
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: InkWell(
              key: const ValueKey('leaderboard_tab_pk'),
              onTap: () => setState(() => _activeBoardIndex = 1),
              borderRadius: BorderRadius.circular(14),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 11),
                decoration: BoxDecoration(
                  color: _activeBoardIndex == 1
                      ? AppTheme.surface
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: _activeBoardIndex == 1
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.06),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const AppAssetIcon(AppIcons.bomb, size: 18),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        'Mèo Nổ PK (MR)',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _activeBoardIndex == 1
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStreakPeriodChips() {
    const labels = ['Tuần này', 'Tháng này', 'Tất cả'];
    return Row(
      children: List.generate(labels.length, (idx) {
        final selected = _streakPeriodIndex == idx;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(
              labels[idx],
              style: TextStyle(
                color: selected ? Colors.white : AppTheme.textPrimary,
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
            selected: selected,
            selectedColor: AppTheme.primary,
            backgroundColor: AppTheme.surface,
            side: BorderSide(
              color: selected
                  ? AppTheme.primary
                  : AppTheme.borderSubtle,
            ),
            onSelected: (_) => setState(() => _streakPeriodIndex = idx),
          ),
        );
      }),
    );
  }

  Widget _buildEightAcademicCatRanksCard(int currentMr) {
    final currentTier = PkRankSystem.tierForMr(currentMr);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const AppAssetIcon(AppIcons.medalRank, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '8 Bậc Rank Mèo Học Thuật (MR)',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.secondarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  'Hiện tại: ${currentTier.name}',
                  style: TextStyle(
                    color: AppTheme.accent,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: PkRankSystem.tiers.map((tier) {
              final isCurrent = tier.index == currentTier.index;
              final accent = Color(tier.accentColorValue);
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                decoration: BoxDecoration(
                  color: isCurrent
                      ? accent.withValues(alpha: 0.15)
                      : AppTheme.surfaceSoft,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isCurrent ? accent : AppTheme.borderSubtle,
                    width: isCurrent ? 1.6 : 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppAssetIcon(tier.iconAsset, size: 15),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        '${tier.name} (${tier.rangeLabel})',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isCurrent
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                          fontSize: 11,
                          fontWeight:
                              isCurrent ? FontWeight.w900 : FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildStudyPodiumSection(List<_StudyLeaderboardEntry> top3) {
    if (top3.length < 3) return const SizedBox.shrink();
    return _PodiumBannerContainer(
      title: 'Bục Vinh Danh Top 3 Streak Học Tập',
      first: _PodiumMemberData(
        name: top3[0].name,
        avatarAsset: top3[0].avatarAsset,
        scoreLabel: '${top3[0].streakDays} ngày 🔥',
        subLabel: '${top3[0].wordsLearned} từ',
      ),
      second: _PodiumMemberData(
        name: top3[1].name,
        avatarAsset: top3[1].avatarAsset,
        scoreLabel: '${top3[1].streakDays} ngày 🔥',
        subLabel: '${top3[1].wordsLearned} từ',
      ),
      third: _PodiumMemberData(
        name: top3[2].name,
        avatarAsset: top3[2].avatarAsset,
        scoreLabel: '${top3[2].streakDays} ngày 🔥',
        subLabel: '${top3[2].wordsLearned} từ',
      ),
    );
  }

  Widget _buildPkPodiumSection(List<_PkLeaderboardEntry> top3) {
    if (top3.length < 3) return const SizedBox.shrink();
    return _PodiumBannerContainer(
      title: 'Bục Vinh Danh Top 3 Cao Thủ Mèo Nổ PK',
      first: _PodiumMemberData(
        name: top3[0].name,
        avatarAsset: top3[0].avatarAsset,
        scoreLabel: '${top3[0].mr} MR',
        subLabel: PkRankSystem.tierForMr(top3[0].mr).name,
      ),
      second: _PodiumMemberData(
        name: top3[1].name,
        avatarAsset: top3[1].avatarAsset,
        scoreLabel: '${top3[1].mr} MR',
        subLabel: PkRankSystem.tierForMr(top3[1].mr).name,
      ),
      third: _PodiumMemberData(
        name: top3[2].name,
        avatarAsset: top3[2].avatarAsset,
        scoreLabel: '${top3[2].mr} MR',
        subLabel: PkRankSystem.tierForMr(top3[2].mr).name,
      ),
    );
  }

  Widget _buildStudyRankRow(int rank, _StudyLeaderboardEntry entry) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: entry.isCurrentUser ? AppTheme.primarySoft : AppTheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: entry.isCurrentUser
              ? AppTheme.primary
              : AppTheme.borderSubtle,
          width: entry.isCurrentUser ? 1.6 : 1,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              '#$rank',
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.surfaceSoft,
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(4),
            child: AppAssetIcon(entry.avatarAsset, size: 28),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.name,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${entry.title} • ${entry.wordsLearned} từ vựng',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF7ED),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const AppAssetIcon(AppIcons.streakFire, size: 15),
                const SizedBox(width: 4),
                Text(
                  '${entry.streakDays} ngày',
                  style: const TextStyle(
                    color: Color(0xFFC2410C),
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPkRankRow(int rank, _PkLeaderboardEntry entry) {
    final tier = PkRankSystem.tierForMr(entry.mr);
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: entry.isCurrentUser ? AppTheme.primarySoft : AppTheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: entry.isCurrentUser
              ? AppTheme.primary
              : AppTheme.borderSubtle,
          width: entry.isCurrentUser ? 1.6 : 1,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              '#$rank',
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.surfaceSoft,
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(4),
            child: AppAssetIcon(entry.avatarAsset, size: 28),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppAssetIcon(tier.iconAsset, size: 19),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        entry.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '${tier.name} • Tỷ lệ thắng ${entry.winRatePercent}%',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppTheme.secondarySoft,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              '${entry.mr} MR',
              style: TextStyle(
                color: AppTheme.accent,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPinnedPersonalRankBar({
    required int studyRank,
    required _StudyLeaderboardEntry studyEntry,
    required int pkRank,
    required _PkLeaderboardEntry pkEntry,
  }) {
    final isStudy = _activeBoardIndex == 0;
    final myRank = isStudy ? studyRank : pkRank;
    final pkTier = PkRankSystem.tierForMr(pkEntry.mr);

    return Container(
      key: const ValueKey('leaderboard_personal_pinned_bar'),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          top: BorderSide(color: AppTheme.borderSubtle, width: 1.4),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.primary,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '#$myRank',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppTheme.primarySoft,
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(4),
            child: const AppAssetIcon(AppAssets.catHeroIdle, size: 28),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppAssetIcon(pkTier.iconAsset, size: 17),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        'Hạng của bạn: ${isStudy ? studyEntry.name : pkEntry.name}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  isStudy
                      ? 'Chuỗi ${studyEntry.streakDays} ngày Streak • ${studyEntry.wordsLearned} từ'
                      : '${pkTier.name} • ${pkEntry.mr} MR (Thắng ${pkEntry.winRatePercent}%)',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: _openPkLobby,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              minimumSize: const Size(0, 38),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            icon: const AppAssetIcon(AppIcons.bomb, size: 15),
            label: const Text(
              'Đấu PK',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}

class _PodiumBannerContainer extends StatelessWidget {
  final String title;
  final _PodiumMemberData first;
  final _PodiumMemberData second;
  final _PodiumMemberData third;

  const _PodiumBannerContainer({
    required this.title,
    required this.first,
    required this.second,
    required this.third,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.borderSubtle),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              const AppAssetIcon(AppAssets.crownGold, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(
              AppAssets.leaderboardPodiumBanner,
              height: 110,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: _PodiumCard(
                  rank: 2,
                  crownAsset: AppAssets.crownSilver,
                  data: second,
                  accentColor: const Color(0xFF64748B),
                  isFirst: false,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _PodiumCard(
                  rank: 1,
                  crownAsset: AppAssets.crownGold,
                  data: first,
                  accentColor: const Color(0xFFD97706),
                  isFirst: true,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _PodiumCard(
                  rank: 3,
                  crownAsset: AppAssets.crownBronze,
                  data: third,
                  accentColor: const Color(0xFFB45309),
                  isFirst: false,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PodiumMemberData {
  final String name;
  final String avatarAsset;
  final String scoreLabel;
  final String subLabel;

  const _PodiumMemberData({
    required this.name,
    required this.avatarAsset,
    required this.scoreLabel,
    required this.subLabel,
  });
}

class _PodiumCard extends StatelessWidget {
  final int rank;
  final String crownAsset;
  final _PodiumMemberData data;
  final Color accentColor;
  final bool isFirst;

  const _PodiumCard({
    required this.rank,
    required this.crownAsset,
    required this.data,
    required this.accentColor,
    required this.isFirst,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 8,
        vertical: isFirst ? 14 : 10,
      ),
      decoration: BoxDecoration(
        color: isFirst ? const Color(0xFFFFFBEB) : AppTheme.surfaceSoft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: accentColor.withValues(alpha: isFirst ? 0.5 : 0.28),
          width: isFirst ? 1.8 : 1.2,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppAssetIcon(crownAsset, size: isFirst ? 26 : 22),
          const SizedBox(height: 4),
          Container(
            width: isFirst ? 46 : 40,
            height: isFirst ? 46 : 40,
            decoration: BoxDecoration(
              color: AppTheme.surface,
              shape: BoxShape.circle,
              border: Border.all(color: accentColor, width: 2),
            ),
            padding: const EdgeInsets.all(4),
            child: AppAssetIcon(data.avatarAsset, size: isFirst ? 34 : 28),
          ),
          const SizedBox(height: 6),
          Text(
            data.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            data.scoreLabel,
            style: TextStyle(
              color: accentColor,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            data.subLabel,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _StudyLeaderboardEntry {
  final String id;
  final String name;
  final String title;
  final String avatarAsset;
  final int streakDays;
  final int wordsLearned;
  final bool isCurrentUser;

  const _StudyLeaderboardEntry({
    required this.id,
    required this.name,
    required this.title,
    required this.avatarAsset,
    required this.streakDays,
    required this.wordsLearned,
    required this.isCurrentUser,
  });
}

class _PkLeaderboardEntry {
  final String id;
  final String name;
  final String avatarAsset;
  final int mr;
  final int winRatePercent;
  final bool isCurrentUser;

  const _PkLeaderboardEntry({
    required this.id,
    required this.name,
    required this.avatarAsset,
    required this.mr,
    required this.winRatePercent,
    required this.isCurrentUser,
  });
}
