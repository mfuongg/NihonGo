import 'package:flutter/material.dart';
import '../../services/feedback_audio_service.dart';
import '../../services/tts_service.dart';
import '../../theme/cozy_palette.dart';
import '../../utils/constants.dart';
import '../../widgets/cozy_common_widgets.dart';

class KanaScreen extends StatefulWidget {
  final bool allowBack;

  const KanaScreen({super.key, this.allowBack = true});

  @override
  State<KanaScreen> createState() => _KanaScreenState();
}

class _KanaScreenState extends State<KanaScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    return CozyScaffold(
      appBar: CozyAppBar(
        title: 'Bảng chữ Kana',
        subtitle: 'Chạm chữ cái để nghe phát âm chuẩn',
        allowBack: widget.allowBack,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(
              child: CozyTagChip(
                label: 'Quiz nhanh',
                useAccentStyle: true,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => KanaQuizScreen(
                      isHiragana: _tabController.index == 0,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(54),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Container(
              height: 40,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: cozy.surface,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: cozy.borderSubtle),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: cozy.primary,
                  borderRadius: BorderRadius.circular(999),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: cozy.onPrimary,
                unselectedLabelColor: cozy.textSecondary,
                labelStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
                unselectedLabelStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
                tabs: const [
                  Tab(text: 'Hiragana　ひ'),
                  Tab(text: 'Katakana　カ'),
                ],
              ),
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _KanaTable(
            table: AppConstants.hiraganaTable,
            title: 'Hiragana',
            accentColor: cozy.primary,
          ),
          _KanaTable(
            table: AppConstants.katakanaTable,
            title: 'Katakana',
            accentColor: cozy.secondary,
          ),
        ],
      ),
    );
  }
}

class _KanaTable extends StatefulWidget {
  final Map<String, List<List<String>>> table;
  final String title;
  final Color accentColor;

  const _KanaTable({
    required this.table,
    required this.title,
    required this.accentColor,
  });

  @override
  State<_KanaTable> createState() => _KanaTableState();
}

class _KanaTableState extends State<_KanaTable> {
  String? _selected;

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    final accent = widget.accentColor;
    final columns = ['a', 'i', 'u', 'e', 'o'];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CozySurfaceCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            margin: const EdgeInsets.only(bottom: 14),
            borderRadius: 20,
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.volume_up_rounded,
                    color: accent,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bảng chữ ${widget.title}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: cozy.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _selected != null
                            ? 'Đang phát âm chữ: $_selected'
                            : 'Chọn một ô bên dưới để nghe phát âm tiếng Nhật',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: cozy.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              const SizedBox(width: 32),
              ...columns.map(
                (col) => Expanded(
                  child: Center(
                    child: Text(
                      col.toUpperCase(),
                      style: TextStyle(
                        color: accent,
                        fontWeight: FontWeight.w800,
                        fontSize: 12.5,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...widget.table.entries.map((entry) {
            final rowKey = entry.key;
            final rows = entry.value;
            return Column(
              children: rows.map((row) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 32,
                        child: Text(
                          rowKey == 'vowels' ? '∅' : rowKey,
                          style: TextStyle(
                            color: cozy.textSecondary,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      ...List.generate(row.length, (i) {
                        final cell = i < row.length ? row[i] : '';
                        if (cell.isEmpty) {
                          return const Expanded(child: SizedBox());
                        }
                        final parts = cell.split('/');
                        final kana = parts[0];
                        final romaji = parts.length > 1 ? parts[1] : '';
                        final isSelected = _selected == kana;

                        return Expanded(
                          child: GestureDetector(
                            onTap: () async {
                              setState(() {
                                _selected = isSelected ? null : kana;
                              });
                              await TtsService.instance
                                  .speakJapanese(kana, rate: 0.55);
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                color: isSelected ? accent : cozy.surface,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isSelected
                                      ? accent
                                      : cozy.borderSubtle,
                                  width: isSelected ? 1.5 : 1,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    kana,
                                    style: TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.w800,
                                      color: isSelected
                                          ? cozy.onPrimary
                                          : cozy.textPrimary,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  if (romaji.isNotEmpty) ...[
                                    const SizedBox(height: 2),
                                    Text(
                                      romaji,
                                      style: TextStyle(
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w600,
                                        color: isSelected
                                            ? cozy.onPrimary
                                                .withValues(alpha: 0.85)
                                            : cozy.textSecondary,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ],
                  ),
                );
              }).toList(),
            );
          }),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class KanaQuizScreen extends StatefulWidget {
  final bool isHiragana;

  const KanaQuizScreen({super.key, this.isHiragana = true});

  @override
  State<KanaQuizScreen> createState() => _KanaQuizScreenState();
}

class _KanaQuizScreenState extends State<KanaQuizScreen> {
  final List<Map<String, String>> _kanaList = [];
  int _currentIndex = 0;
  int? _selectedAnswer;
  bool _answered = false;
  int _score = 0;
  List<String> _options = [];
  late bool _isHiragana;

  @override
  void initState() {
    super.initState();
    _isHiragana = widget.isHiragana;
    _buildKanaList();
    _generateOptions();
  }

  void _buildKanaList() {
    _kanaList.clear();
    final table = _isHiragana
        ? AppConstants.hiraganaTable
        : AppConstants.katakanaTable;

    for (final rows in table.values) {
      for (final row in rows) {
        for (final cell in row) {
          if (cell.isNotEmpty) {
            final parts = cell.split('/');
            _kanaList.add({
              'kana': parts[0],
              'romaji': parts.length > 1 ? parts[1] : '',
            });
          }
        }
      }
    }
    _kanaList.shuffle();
    if (_kanaList.length > 20) {
      _kanaList.removeRange(20, _kanaList.length);
    }
  }

  void _generateOptions() {
    if (_currentIndex >= _kanaList.length) return;
    final correct = _kanaList[_currentIndex]['romaji']!;
    final allRomaji = _kanaList.map((k) => k['romaji']!).toSet().toList()
      ..remove(correct)
      ..shuffle();
    final wrongs = allRomaji.take(3).toList();
    _options = [correct, ...wrongs]..shuffle();
  }

  void _selectAnswer(String answer) {
    if (_answered) return;
    final isCorrect = answer == _kanaList[_currentIndex]['romaji'];
    setState(() {
      _selectedAnswer = _options.indexOf(answer);
      _answered = true;
      if (isCorrect) _score++;
    });

    if (isCorrect) {
      FeedbackAudioService.instance.playCorrect();
    } else {
      FeedbackAudioService.instance.playWrong();
    }
  }

  void _next() {
    if (_currentIndex < _kanaList.length - 1) {
      setState(() {
        _currentIndex++;
        _selectedAnswer = null;
        _answered = false;
      });
      _generateOptions();
    } else {
      _showResults();
    }
  }

  void _showResults() {
    final cozy = context.cozy;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cozy.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          '🎉 Kết quả',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: cozy.textPrimary,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '$_score / ${_kanaList.length}',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w900,
                color: cozy.primary,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              '${(_score / _kanaList.length * 100).toInt()}% đúng',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: cozy.textSecondary,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.maybePop(context);
            },
            child: Text(
              'Thoát',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: cozy.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cozy = context.cozy;
    if (_kanaList.isEmpty) {
      return const CozyScaffold(
        appBar: CozyAppBar(title: 'Quiz Kana'),
        body: Center(child: Text('Không có dữ liệu')),
      );
    }

    final current = _kanaList[_currentIndex];
    final correct = current['romaji']!;
    final accent = _isHiragana ? cozy.primary : cozy.secondary;

    return CozyScaffold(
      appBar: CozyAppBar(
        title: 'Quiz ${_isHiragana ? "Hiragana" : "Katakana"}',
        subtitle: 'Câu ${_currentIndex + 1} / ${_kanaList.length}',
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                minHeight: 8,
                value: (_currentIndex + 1) / _kanaList.length,
                backgroundColor: cozy.borderSubtle,
                valueColor: AlwaysStoppedAnimation<Color>(accent),
              ),
            ),
            const SizedBox(height: 24),
            CozySurfaceCard(
              borderRadius: 24,
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 36),
              backgroundColor: cozy.surface,
              borderColor: accent.withValues(alpha: 0.35),
              child: Column(
                children: [
                  Text(
                    current['kana']!,
                    style: TextStyle(
                      fontSize: 76,
                      color: cozy.textPrimary,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Âm đọc của chữ này là gì?',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: cozy.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 2.4,
              children: _options.map((option) {
                final isSelected = _options.indexOf(option) == _selectedAnswer;
                final isCorrectOption = option == correct;

                Color bgColor = cozy.surface;
                Color borderColor = cozy.borderSubtle;
                Color textColor = cozy.textPrimary;

                if (_answered) {
                  if (isCorrectOption) {
                    bgColor = cozy.success.withValues(alpha: 0.16);
                    borderColor = cozy.success;
                    textColor = cozy.textPrimary;
                  } else if (isSelected) {
                    bgColor = cozy.error.withValues(alpha: 0.16);
                    borderColor = cozy.error;
                    textColor = cozy.textPrimary;
                  }
                }

                return GestureDetector(
                  onTap: () => _selectAnswer(option),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    decoration: BoxDecoration(
                      color: bgColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: borderColor, width: 1.5),
                    ),
                    child: Center(
                      child: Text(
                        option,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const Spacer(),
            if (_answered)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _next,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: cozy.onPrimary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: Text(
                    _currentIndex < _kanaList.length - 1
                        ? 'Tiếp theo →'
                        : 'Xem kết quả',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
