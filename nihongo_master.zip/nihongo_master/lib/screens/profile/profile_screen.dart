import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/user_progress.dart';
import '../../providers/auth_provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/avatar_upload_service.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';
import '../../widgets/app_asset_icon.dart';
import '../admin/admin_tools_screen.dart';
import '../auth/login_screen.dart';
import '../cat/guardian_cat_screen.dart';

class ProfileScreen extends StatefulWidget {
  final int initialTabIndex;

  const ProfileScreen({
    super.key,
    this.initialTabIndex = 0,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late int _subTabIndex = widget.initialTabIndex.clamp(0, 1);

  late final TextEditingController _nameController;
  late final TextEditingController _bioController;

  String _draftName = '';
  String _draftGender = 'Bí mật';
  String _draftBio = '';
  String _draftTitle = 'Tân Binh Nihongo';
  String? _draftAvatarDataUri;
  String? _lastUploadStatusText;
  bool _showBio = true;
  bool _showVip = true;
  bool _showStreak = true;
  bool _initializedFromProviders = false;

  static const List<Map<String, String>> _genderOptions = <Map<String, String>>[
    {'value': 'Nam', 'icon': '♂️', 'label': 'Nam'},
    {'value': 'Nữ', 'icon': '♀️', 'label': 'Nữ'},
    {'value': 'Khác', 'icon': '⚧️', 'label': 'Khác'},
    {'value': 'Bí mật', 'icon': '🐾', 'label': 'Bí mật'},
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _bioController = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initializedFromProviders) return;
    _initializedFromProviders = true;
    final auth = context.read<AuthProvider>();
    final progress = context.read<ProgressProvider>().progress;
    final rawName = (auth.currentUser?.displayName ?? '').trim();
    _draftName = rawName.isEmpty ? 'Học viên NihonGo' : rawName;
    _draftGender = progress.gender;
    _draftBio = progress.bio;
    final unlocked = progress.unlockedTitles;
    _draftTitle = unlocked.contains(progress.selectedTitle)
        ? progress.selectedTitle
        : unlocked.first;
    _draftAvatarDataUri = (progress.avatarBase64 != null && progress.avatarBase64!.isNotEmpty)
        ? progress.avatarBase64
        : auth.currentUser?.photoUrl;
    _showBio = progress.showBio;
    _showVip = progress.showVip;
    _showStreak = progress.showStreak;

    _nameController.text = _draftName;
    _bioController.text = _draftBio;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  Future<void> _handlePickAvatar(ImageSource source) async {
    final result = await AvatarUploadService.instance.pickCropAndCompress(
      source: source,
    );
    if (result == null || !mounted) return;
    final progressProvider = context.read<ProgressProvider>();
    final authProvider = context.read<AuthProvider>();
    setState(() {
      _draftAvatarDataUri = result.base64DataUri;
      _lastUploadStatusText =
          'Đã cắt 1:1 (${result.width}x${result.height}) • ${result.sizeInKb.toStringAsFixed(1)} KB (< 500KB)';
    });
    await progressProvider.updateProfileAndPrivacy(
      avatarBase64: result.base64DataUri,
    );
    await authProvider.updateUserProfile(
      displayName: _draftName,
      photoUrl: result.base64DataUri,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppTheme.primary,
          content: Text(
            'Đã cập nhật Avatar tỷ lệ 1:1 (${result.sizeInKb.toStringAsFixed(1)} KB < 500KB)!',
          ),
        ),
      );
  }

  Future<void> _saveProfileChanges({bool showFeedback = true}) async {
    final progressProvider = context.read<ProgressProvider>();
    final authProvider = context.read<AuthProvider>();
    final cleanName = _draftName.trim().isEmpty ? 'Học viên NihonGo' : _draftName.trim();
    await progressProvider.updateProfileAndPrivacy(
      avatarBase64: _draftAvatarDataUri,
      gender: _draftGender,
      bio: _draftBio.trim(),
      selectedTitle: _draftTitle,
      showBio: _showBio,
      showVip: _showVip,
      showStreak: _showStreak,
    );
    await authProvider.updateUserProfile(
      displayName: cleanName,
      photoUrl: _draftAvatarDataUri,
    );
    if (!mounted || !showFeedback) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppTheme.success,
          content: Text('Đã lưu Hồ sơ & Quyền riêng tư thành công!'),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final progressProvider = context.watch<ProgressProvider>();
    final settingsProvider = context.watch<SettingsProvider>();
    final authProvider = context.watch<AuthProvider>();
    final p = progressProvider.progress;
    final themeSpec = AppTheme.specFor(p.selectedThemeId);

    final unlockedTitles = p.unlockedTitles;
    if (!unlockedTitles.contains(_draftTitle)) {
      _draftTitle = unlockedTitles.first;
    }

    return Scaffold(
      backgroundColor: themeSpec.background,
      appBar: AppBar(
        backgroundColor: themeSpec.surface,
        elevation: 0,
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppAssetIcon(AppIcons.profile, size: 22),
            const SizedBox(width: 8),
            Text(
              _subTabIndex == 0 ? 'Hồ sơ & Quyền riêng tư' : 'Cài đặt hệ thống',
              style: TextStyle(
                fontSize: 17.5,
                fontWeight: FontWeight.w800,
                color: themeSpec.textPrimary,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(
              children: [
                // Bộ chuyển đổi 2 Sub-tab: [1. Hồ sơ & Quyền riêng tư] | [2. Cài đặt hệ thống]
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: themeSpec.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: themeSpec.borderSubtle),
                      boxShadow: AppTheme.softCardShadow,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _SubTabButton(
                            key: const ValueKey('profile-subtab-info'),
                            iconPath: AppIcons.profile,
                            label: 'Hồ sơ & Riêng tư',
                            selected: _subTabIndex == 0,
                            themeSpec: themeSpec,
                            onTap: () => setState(() => _subTabIndex = 0),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: _SubTabButton(
                            key: const ValueKey('profile-subtab-settings'),
                            iconPath: AppIcons.settings,
                            label: 'Cài đặt hệ thống',
                            selected: _subTabIndex == 1,
                            themeSpec: themeSpec,
                            onTap: () => setState(() => _subTabIndex = 1),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: IndexedStack(
                    index: _subTabIndex,
                    children: [
                      _buildProfileAndPrivacySubTab(
                        context: context,
                        progress: p,
                        unlockedTitles: unlockedTitles,
                        isAdmin: authProvider.isAdmin,
                        email: authProvider.currentUser?.email ?? 'guest@nihongomaster.local',
                        themeSpec: themeSpec,
                      ),
                      _buildSystemSettingsSubTab(
                        context: context,
                        progressProvider: progressProvider,
                        settingsProvider: settingsProvider,
                        authProvider: authProvider,
                        themeSpec: themeSpec,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileAndPrivacySubTab({
    required BuildContext context,
    required UserProgress progress,
    required List<String> unlockedTitles,
    required bool isAdmin,
    required String email,
    required AppThemeSpec themeSpec,
  }) {
    final safeLevelIdx = progress.userLevel.clamp(0, AppConstants.userLevels.length - 1);
    final vipLevelLabel = isAdmin
        ? 'VIP Hoàng Gia 👑'
        : 'VIP Cấp ${safeLevelIdx + 1} • ${progress.pkRankTitle}';

    final genderEmoji = _genderOptions
        .firstWhere(
          (g) => g['value'] == _draftGender,
          orElse: () => _genderOptions.last,
        )['icon']!;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 32),
      children: [
        // 1. KHUNG LIVE PREVIEW (Cập nhật tức thời y hệt cách người chơi khác nhìn thấy)
        Container(
          key: const ValueKey('profile-live-preview-card'),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: themeSpec.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: themeSpec.primary.withValues(alpha: 0.35), width: 1.4),
            boxShadow: AppTheme.softCardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: themeSpec.primarySoft,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.visibility_rounded, size: 14, color: themeSpec.primary),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              'LIVE PREVIEW • Góc nhìn người chơi khác',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: themeSpec.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'JLPT ${progress.selectedLevel}',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800,
                      color: themeSpec.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SquareAvatarView(
                    key: const ValueKey('profile-live-avatar'),
                    avatarSource: _draftAvatarDataUri,
                    fallbackName: _draftName,
                    size: 72,
                    themeSpec: themeSpec,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(
                              _draftName.trim().isEmpty ? 'Học viên NihonGo' : _draftName.trim(),
                              key: const ValueKey('live-preview-name'),
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                color: themeSpec.textPrimary,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: themeSpec.primarySoft,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                '$genderEmoji $_draftGender',
                                key: const ValueKey('live-preview-gender'),
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: themeSpec.accent,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        // Danh hiệu + Hạng VIP + Streak trên Live Preview
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                              decoration: BoxDecoration(
                                color: themeSpec.secondarySoft,
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: themeSpec.secondary.withValues(alpha: 0.4),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const AppAssetIcon(AppIcons.medalRank, size: 13),
                                  const SizedBox(width: 4),
                                  Text(
                                    _draftTitle,
                                    key: const ValueKey('live-preview-title'),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w800,
                                      color: themeSpec.textPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (_showVip)
                              Container(
                                key: const ValueKey('live-preview-vip-badge'),
                                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFF6E5),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: const Color(0xFFE5B84B)),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const AppAssetIcon(AppIcons.crown, size: 13),
                                    const SizedBox(width: 4),
                                    Text(
                                      vipLevelLabel,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                        color: Color(0xFFB45309),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            if (_showStreak)
                              Container(
                                key: const ValueKey('live-preview-streak-badge'),
                                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFF1E6),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: const Color(0xFFF4A261)),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const AppAssetIcon(AppIcons.streakFire, size: 13),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${progress.currentStreak} ngày Streak',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                        color: Color(0xFFD97706),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        if (_showBio && _draftBio.trim().isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Container(
                            key: const ValueKey('live-preview-bio-box'),
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                            decoration: BoxDecoration(
                              color: themeSpec.background,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: themeSpec.borderSubtle),
                            ),
                            child: Text(
                              '“${_draftBio.trim()}”',
                              key: const ValueKey('live-preview-bio-text'),
                              style: TextStyle(
                                fontSize: 12,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                                color: themeSpec.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 2. UPLOAD AVATAR (image_picker + Crop 1:1 + Nén < 500KB)
        _CozySectionCard(
          title: 'Ảnh đại diện (Upload Avatar 1:1 < 500KB)',
          subtitle: 'Hỗ trợ chọn từ Thư viện hoặc Camera, tự động cắt vuông 1:1 & nén dưới 500KB',
          iconPath: AppIcons.profile,
          themeSpec: themeSpec,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _SquareAvatarView(
                    avatarSource: _draftAvatarDataUri,
                    fallbackName: _draftName,
                    size: 64,
                    themeSpec: themeSpec,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                key: const ValueKey('avatar-upload-gallery-btn'),
                                onPressed: () => _handlePickAvatar(ImageSource.gallery),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: themeSpec.primary,
                                  foregroundColor: Colors.white,
                                  minimumSize: const Size(0, 42),
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                icon: const Icon(Icons.photo_library_rounded, size: 17),
                                label: const Text(
                                  'Thư viện',
                                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: OutlinedButton.icon(
                                key: const ValueKey('avatar-upload-camera-btn'),
                                onPressed: () => _handlePickAvatar(ImageSource.camera),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: themeSpec.textPrimary,
                                  minimumSize: const Size(0, 42),
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  side: BorderSide(color: themeSpec.primary.withValues(alpha: 0.45)),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                icon: Icon(Icons.camera_alt_rounded, size: 17, color: themeSpec.primary),
                                label: const Text(
                                  'Camera',
                                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _lastUploadStatusText ??
                              'Định dạng chuẩn: Tỷ lệ vuông 1:1 • Dung lượng tối đa <= 500KB',
                          key: const ValueKey('avatar-upload-status-text'),
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600,
                            color: _lastUploadStatusText != null
                                ? AppTheme.success
                                : themeSpec.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 3. FORM THÔNG TIN CÁ NHÂN
        _CozySectionCard(
          title: 'Thông tin cá nhân',
          subtitle: 'Email đăng nhập: $email',
          iconPath: AppIcons.medalRank,
          themeSpec: themeSpec,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Tên hiển thị',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                key: const ValueKey('profile-display-name-input'),
                controller: _nameController,
                onChanged: (val) => setState(() => _draftName = val),
                decoration: InputDecoration(
                  hintText: 'Nhập tên hiển thị của bạn...',
                  prefixIcon: Icon(Icons.person_rounded, color: themeSpec.primary),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'Giới tính',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _genderOptions.map((item) {
                  final value = item['value']!;
                  final icon = item['icon']!;
                  final label = item['label']!;
                  final selected = _draftGender == value;
                  return ChoiceChip(
                    key: ValueKey('gender-chip-$value'),
                    label: Text('$icon $label'),
                    selected: selected,
                    showCheckmark: false,
                    selectedColor: themeSpec.primary,
                    backgroundColor: themeSpec.background,
                    side: BorderSide(
                      color: selected ? themeSpec.primary : themeSpec.borderSubtle,
                    ),
                    labelStyle: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: selected ? Colors.white : themeSpec.textPrimary,
                    ),
                    onSelected: (_) {
                      setState(() => _draftGender = value);
                      _saveProfileChanges(showFeedback: false);
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              Text(
                'Chữ ký / Tiểu sử (Bio)',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                key: const ValueKey('profile-bio-input'),
                controller: _bioController,
                maxLines: 2,
                maxLength: 90,
                onChanged: (val) => setState(() => _draftBio = val),
                decoration: InputDecoration(
                  hintText: 'Ví dụ: Chiến thần N3 quyết tâm đỗ JLPT! 🌸',
                  prefixIcon: Icon(Icons.edit_note_rounded, color: themeSpec.primary),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Danh hiệu hiển thị (Đã mở khóa)',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                key: const ValueKey('profile-title-dropdown'),
                initialValue: _draftTitle,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.workspace_premium_rounded, color: themeSpec.primary),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
                items: unlockedTitles
                    .map(
                      (title) => DropdownMenuItem<String>(
                        value: title,
                        child: Text(
                          title,
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: themeSpec.textPrimary,
                          ),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (val) {
                  if (val == null) return;
                  setState(() => _draftTitle = val);
                  _saveProfileChanges(showFeedback: false);
                },
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  key: const ValueKey('profile-save-button'),
                  onPressed: _saveProfileChanges,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeSpec.primary,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 48),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  icon: const Icon(Icons.check_circle_outline_rounded, size: 19),
                  label: const Text(
                    'Lưu thông tin hồ sơ',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 4. QUYỀN RIÊNG TƯ (PRIVACY TOGGLES)
        _CozySectionCard(
          title: 'Quyền riêng tư (Privacy Toggles)',
          subtitle: 'Bật/tắt các thông tin xuất hiện trên Khung Live Preview & Bảng xếp hạng',
          iconPath: AppIcons.shield,
          themeSpec: themeSpec,
          child: Column(
            children: [
              _CozySwitchRow(
                switchKey: const ValueKey('privacy-switch-bio'),
                title: 'Hiển thị chữ ký',
                subtitle: 'Cho phép người chơi khác nhìn thấy dòng Bio của bạn',
                value: _showBio,
                themeSpec: themeSpec,
                onChanged: (val) {
                  setState(() => _showBio = val);
                  _saveProfileChanges(showFeedback: false);
                },
              ),
              Divider(height: 1, color: themeSpec.borderSubtle),
              _CozySwitchRow(
                switchKey: const ValueKey('privacy-switch-vip'),
                title: 'Hiển thị hạng VIP',
                subtitle: 'Hiển thị huy hiệu cấp độ VIP & bậc rank học thuật',
                value: _showVip,
                themeSpec: themeSpec,
                onChanged: (val) {
                  setState(() => _showVip = val);
                  _saveProfileChanges(showFeedback: false);
                },
              ),
              Divider(height: 1, color: themeSpec.borderSubtle),
              _CozySwitchRow(
                switchKey: const ValueKey('privacy-switch-streak'),
                title: 'Hiển thị Streak',
                subtitle: 'Hiển thị chuỗi ngày học liên tiếp trên hồ sơ công khai',
                value: _showStreak,
                themeSpec: themeSpec,
                onChanged: (val) {
                  setState(() => _showStreak = val);
                  _saveProfileChanges(showFeedback: false);
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSystemSettingsSubTab({
    required BuildContext context,
    required ProgressProvider progressProvider,
    required SettingsProvider settingsProvider,
    required AuthProvider authProvider,
    required AppThemeSpec themeSpec,
  }) {
    final p = progressProvider.progress;
    final unlockedThemes = p.unlockedThemeIds;
    final ownedCats = p.ownedCatIds;
    final scalePercent = (p.catCompanionScale * 100).round();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 32),
      children: [
        // 1. CHỌN 4 THEME MÀU SẮC MẶC ĐỊNH (+ THEME ĐÃ MỞ KHÓA)
        _CozySectionCard(
          title: 'Chủ đề màu sắc (Theme)',
          subtitle: 'Chọn 4 Theme mặc định (Dusty Rose, Ocean Blue, Sky Butter, White Sage) — Đổi toàn app tức thì',
          iconPath: AppIcons.sparkles,
          themeSpec: themeSpec,
          child: Wrap(
            spacing: 10,
            runSpacing: 10,
            children: AppTheme.themes
                .where((t) => t.isFree || unlockedThemes.contains(t.id))
                .map((spec) {
              final isSelected = p.selectedThemeId == spec.id;
              return InkWell(
                key: ValueKey('settings-theme-option-${spec.id}'),
                onTap: () async {
                  final themeProvider = context.read<ThemeProvider?>();
                  await progressProvider.selectAppTheme(spec.id);
                  await themeProvider?.setTheme(spec.id);
                },
                borderRadius: BorderRadius.circular(16),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 158,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: spec.background,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSelected ? spec.primary : spec.borderSubtle,
                      width: isSelected ? 2.2 : 1.2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: spec.primary,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        alignment: Alignment.center,
                        child: Text(spec.emoji, style: const TextStyle(fontSize: 13)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              spec.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w800,
                                color: spec.textPrimary,
                              ),
                            ),
                            Text(
                              isSelected ? 'Đang dùng ✓' : 'Chạm để đổi',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: isSelected ? spec.primary : spec.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),

        // 2. HỆ THỐNG: ÂM THANH, NHẮC NHỞ & UI GUIDE
        _CozySectionCard(
          title: 'Âm thanh, Nhắc nhở & UI Guide',
          subtitle: 'Tuỳ chỉnh trải nghiệm học tập hàng ngày',
          iconPath: AppIcons.settings,
          themeSpec: themeSpec,
          child: Column(
            children: [
              _CozySwitchRow(
                switchKey: const ValueKey('settings-switch-sound'),
                title: 'Âm thanh (Sound & BGM)',
                subtitle: 'Phát nhạc nền Cozy và hiệu ứng âm thanh khi học',
                value: settingsProvider.soundEnabled,
                themeSpec: themeSpec,
                onChanged: (_) => settingsProvider.toggleSound(),
              ),
              Divider(height: 1, color: themeSpec.borderSubtle),
              _CozySwitchRow(
                switchKey: const ValueKey('settings-switch-notifications'),
                title: 'Nhắc nhở học tập',
                subtitle: 'Thông báo giữ chuỗi Streak mỗi ngày',
                value: settingsProvider.notificationsEnabled,
                themeSpec: themeSpec,
                onChanged: (_) => settingsProvider.toggleNotifications(),
              ),
              Divider(height: 1, color: themeSpec.borderSubtle),
              _CozySwitchRow(
                switchKey: const ValueKey('settings-switch-ui-guide'),
                title: 'UI Guide (Hiện/Ẩn chú thích)',
                subtitle: 'Hiển thị gợi ý thao tác kéo thả Mèo & hướng dẫn tính năng',
                value: settingsProvider.uiGuideEnabled,
                themeSpec: themeSpec,
                onChanged: (val) => settingsProvider.setUiGuideEnabled(val),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 3. CÀI ĐẶT MÈO ĐỒNG HÀNH (Bật/Tắt, Kích thước 60%-130%, Chọn giống mèo)
        _CozySectionCard(
          title: 'Cài đặt Mèo Hộ Pháp',
          subtitle: 'Điều chỉnh hiển thị, kích thước 60%–130% và chọn giống mèo đồng hành',
          iconPath: AppIcons.paw,
          themeSpec: themeSpec,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _CozySwitchRow(
                switchKey: const ValueKey('settings-switch-cat-companion'),
                title: 'Hiển thị Mèo đồng hành',
                subtitle: 'Cho phép Hoàng Thượng đi dạo và snap lên các thẻ ở Tab 1, 2, 3',
                value: p.catCompanionEnabled,
                themeSpec: themeSpec,
                onChanged: (val) => progressProvider.setCatCompanionEnabled(val),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Kích thước Mèo đồng hành',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: themeSpec.textPrimary,
                    ),
                  ),
                  Container(
                    key: const ValueKey('settings-cat-scale-label'),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: themeSpec.primarySoft,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      '$scalePercent%',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: themeSpec.primary,
                      ),
                    ),
                  ),
                ],
              ),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: themeSpec.primary,
                  inactiveTrackColor: themeSpec.primarySoft,
                  thumbColor: themeSpec.primary,
                ),
                child: Slider(
                  key: const ValueKey('settings-slider-cat-scale'),
                  value: p.catCompanionScale.clamp(0.60, 1.30),
                  min: 0.60,
                  max: 1.30,
                  divisions: 14,
                  label: '$scalePercent%',
                  onChanged: (val) => progressProvider.setCatCompanionScale(val),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Chọn giống mèo đại diện (${ownedCats.length}/${UserProgress.allCatIds.length} đã sở hữu)',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: ownedCats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    final catId = ownedCats[index];
                    final spec = CatCatalog.findCharacter(catId);
                    final selected = p.selectedCatId == spec.folderId;
                    return InkWell(
                      key: ValueKey('settings-cat-breed-${spec.folderId}'),
                      onTap: () => progressProvider.selectCatCharacter(spec.folderId),
                      borderRadius: BorderRadius.circular(16),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        width: 86,
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: selected ? themeSpec.primarySoft : themeSpec.background,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: selected ? themeSpec.primary : themeSpec.borderSubtle,
                            width: selected ? 2.0 : 1.0,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AppAssetIcon(spec.idleAssetPath, size: 42),
                            const SizedBox(height: 4),
                            Text(
                              spec.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: selected ? themeSpec.primary : themeSpec.textPrimary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // 4. QUẢN TRỊ & ĐĂNG XUẤT
        if (authProvider.isAdmin) ...[
          _CozySectionCard(
            title: 'Quản trị viên (Admin Mode)',
            subtitle: 'Mở bảng công cụ kiểm thử & quản lý tài nguyên',
            iconPath: AppIcons.crown,
            themeSpec: themeSpec,
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const AppAssetIcon(AppIcons.crown, size: 26),
              title: Text(
                'Bảng điều khiển Admin',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: themeSpec.textPrimary,
                ),
              ),
              subtitle: Text(
                'Mở khóa toàn bộ tính năng, cấp Xu/Gem/EXP nhanh',
                style: TextStyle(fontSize: 12, color: themeSpec.textSecondary),
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AdminToolsScreen()),
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],

        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            key: const ValueKey('settings-logout-button'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.error,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            onPressed: () async {
              await authProvider.signOut();
              await progressProvider.useGuestState();
              if (!context.mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (_) => false,
              );
            },
            icon: const Icon(Icons.logout_rounded, size: 19),
            label: const Text(
              'Đăng xuất',
              style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ],
    );
  }
}

class _SubTabButton extends StatelessWidget {
  final String iconPath;
  final String label;
  final bool selected;
  final AppThemeSpec themeSpec;
  final VoidCallback onTap;

  const _SubTabButton({
    super.key,
    required this.iconPath,
    required this.label,
    required this.selected,
    required this.themeSpec,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
          color: selected ? themeSpec.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppAssetIcon(iconPath, size: 18),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: selected ? Colors.white : themeSpec.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SquareAvatarView extends StatelessWidget {
  final String? avatarSource;
  final String fallbackName;
  final double size;
  final AppThemeSpec themeSpec;

  const _SquareAvatarView({
    super.key,
    required this.avatarSource,
    required this.fallbackName,
    required this.size,
    required this.themeSpec,
  });

  @override
  Widget build(BuildContext context) {
    final trimmedName = fallbackName.trim();
    final initial = trimmedName.isEmpty ? 'N' : trimmedName.characters.first.toUpperCase();
    final fallback = Container(
      color: themeSpec.primarySoft,
      alignment: Alignment.center,
      child: Text(
        initial,
        style: TextStyle(
          fontSize: size * 0.4,
          fontWeight: FontWeight.w900,
          color: themeSpec.primary,
        ),
      ),
    );

    final bytes = AvatarUploadService.decodeDataUri(avatarSource);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.28),
        border: Border.all(color: themeSpec.primary.withValues(alpha: 0.45), width: 2),
        boxShadow: AppTheme.softCardShadow,
      ),
      clipBehavior: Clip.antiAlias,
      child: bytes != null
          ? Image.memory(
              bytes,
              width: size,
              height: size,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => fallback,
            )
          : (avatarSource != null && avatarSource!.trim().isNotEmpty)
              ? Image.network(
                  avatarSource!,
                  width: size,
                  height: size,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => fallback,
                )
              : fallback,
    );
  }
}

class _CozySectionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String iconPath;
  final AppThemeSpec themeSpec;
  final Widget child;

  const _CozySectionCard({
    required this.title,
    required this.subtitle,
    required this.iconPath,
    required this.themeSpec,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: themeSpec.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: themeSpec.borderSubtle),
        boxShadow: AppTheme.softCardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AppAssetIcon(iconPath, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: themeSpec.textPrimary,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                        color: themeSpec.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _CozySwitchRow extends StatelessWidget {
  final Key? switchKey;
  final String title;
  final String subtitle;
  final bool value;
  final AppThemeSpec themeSpec;
  final ValueChanged<bool> onChanged;

  const _CozySwitchRow({
    this.switchKey,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.themeSpec,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: themeSpec.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w500,
                    color: themeSpec.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            key: switchKey,
            value: value,
            activeThumbColor: Colors.white,
            activeTrackColor: themeSpec.primary,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
