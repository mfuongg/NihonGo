import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import '../data/grammar_data.dart';
import '../data/jlpt_test_data.dart';
import '../data/kanji_data.dart';
import '../data/reading_material_data.dart';
import '../data/vocabulary_data.dart';
import '../models/grammar.dart';
import '../models/kanji.dart';
import '../models/quiz.dart';
import '../models/reading_material.dart';
import '../models/vocabulary.dart';
import '../services/local_database_service.dart';
import 'content_fallback.dart';

class WebDatasetBootstrap {
  WebDatasetBootstrap._();

  static bool _loaded = false;

  static Future<void> ensureLoadedForWeb() async {
    if (_loaded) return;
    try {
      final vocabRaw = await rootBundle
          .loadString('assets/data/verified_v2/vocabularies.json');
      final sentencesRaw = await rootBundle
          .loadString('assets/data/verified_v2/example_sentences.json');
      final kanjiRaw = await rootBundle
          .loadString('assets/data/verified_v2/kanji_entries.json');
      final grammarRaw = await rootBundle
          .loadString('assets/data/verified_v2/grammar_points.json');
      final readingRaw = await rootBundle
          .loadString('assets/data/verified_v2/reading_materials.json');

      final vocabList =
          (jsonDecode(vocabRaw) as List).cast<Map<String, dynamic>>();
      final sentenceList =
          (jsonDecode(sentencesRaw) as List).cast<Map<String, dynamic>>();
      final kanjiList =
          (jsonDecode(kanjiRaw) as List).cast<Map<String, dynamic>>();
      final grammarList =
          (jsonDecode(grammarRaw) as List).cast<Map<String, dynamic>>();
      final readingList =
          (jsonDecode(readingRaw) as List).cast<Map<String, dynamic>>();

      final sentencesByVocab = <String, List<String>>{};
      final translationsByVocab = <String, List<String>>{};
      final examplesByGrammar = <String, List<ExampleSentence>>{};

      for (final s in sentenceList) {
        final vid = s['linked_vocab_id'] as String?;
        final jp = ContentFallback.cleanText(s['sentence_jp'] as String?);
        final tr = ContentFallback.resolveTranslation(
          translationVi: s['translation_vi'] as String?,
          translationEn: s['translation_en'] as String?,
          language: 'vi',
        );
        if (vid != null && jp != null) {
          (sentencesByVocab[vid] ??= <String>[]).add(jp);
          (translationsByVocab[vid] ??= <String>[]).add(tr);
        }
        final gid = s['linked_grammar_id'] as String?;
        if (gid != null) {
          (examplesByGrammar[gid] ??= <ExampleSentence>[]).add(
            ExampleSentence(
              japanese: (s['sentence_jp'] as String?) ?? '',
              hiragana: (s['sentence_hiragana'] as String?) ??
                  (s['sentence_furigana'] as String?) ??
                  '',
              vietnamese: (s['translation_vi'] as String?) ?? '',
              english: (s['translation_en'] as String?) ?? '',
            ),
          );
        }
      }

      final words = vocabList.map((v) {
        final id = v['id'] as String;
        final pos = (v['part_of_speech'] as String?) ?? '';
        final lower = pos.toLowerCase();
        final cat = lower.contains('verb') || lower.startsWith('v')
            ? 'verbs'
            : lower.contains('adj')
                ? 'adjectives'
                : lower.contains('pn') || lower.contains('pronoun')
                    ? 'pronouns'
                    : lower.contains('n') || lower.contains('noun')
                        ? 'nouns'
                        : 'common';
        return VocabularyWord(
          id: id,
          japanese: (v['expression'] as String?) ?? '',
          hiragana: (v['reading_hiragana'] as String?) ?? '',
          romaji: (v['reading_romaji'] as String?) ?? '',
          vietnamese: (v['meaning_vi'] as String?) ?? '',
          english: (v['meaning_en'] as String?) ?? '',
          jlptLevel: (v['original_level'] as String?) ??
              (v['estimated_level'] as String?) ??
              'N5',
          category: cat,
          exampleSentences: sentencesByVocab[id] ?? const <String>[],
          exampleTranslations: translationsByVocab[id] ?? const <String>[],
        );
      }).toList();
      VocabularyData.setLoadedWords(words);

      final kanjis = kanjiList.map((r) {
        return KanjiItem(
          id: r['id'] as String,
          kanji: (r['character'] as String?) ?? '',
          onyomi: (r['onyomi'] as String?) ?? '',
          kunyomi: (r['kunyomi'] as String?) ?? '',
          vietnamese: (r['meaning_vi'] as String?) ?? '',
          english: (r['meaning_en'] as String?) ?? '',
          strokeCount: (r['stroke_count'] as int?) ?? 1,
          jlptLevel: (r['original_level'] as String?) ??
              (r['estimated_level'] as String?) ??
              'N5',
          radicalMeaning: (r['radical'] as String?) ?? '',
        );
      }).toList();
      KanjiData.setLoadedKanji(kanjis);

      final grammars = grammarList.map((r) {
        final id = r['id'] as String;
        final titleVi = ContentFallback.cleanText(r['title_vi'] as String?);
        final titleEn = ContentFallback.cleanText(r['title_en'] as String?);
        final expVi = ContentFallback.cleanText(r['explanation_vi'] as String?);
        final expEn = ContentFallback.cleanText(r['explanation_en'] as String?);
        final formation = ContentFallback.cleanText(r['formation'] as String?);
        final rawNotes = ContentFallback.cleanText(r['notes'] as String?);
        return GrammarLesson(
          id: id,
          pattern: (r['pattern'] as String?) ?? '',
          title: ContentFallback.resolveMeaning(
            meaningVi: titleVi,
            meaningEn: titleEn,
            language: 'vi',
          ),
          titleVi: titleVi,
          titleEn: titleEn,
          explanation: ContentFallback.resolveExplanation(
            explanationVi: expVi,
            explanationEn: expEn,
            language: 'vi',
          ),
          explanationVi: expVi,
          explanationEn: expEn,
          formation: formation,
          jlptLevel: (r['original_level'] as String?) ??
              (r['estimated_level'] as String?) ??
              'N5',
          examples: examplesByGrammar[id] ?? const <ExampleSentence>[],
          notes: <String>[
            if (formation != null && formation.isNotEmpty)
              'Cấu trúc: $formation',
            if (rawNotes != null && rawNotes.isNotEmpty) rawNotes,
          ],
        );
      }).toList();
      GrammarData.setLoadedLessons(grammars);

      final readings = readingList.map((r) {
        final origLevel =
            ContentFallback.cleanText(r['original_level'] as String?);
        final titleJp = (r['title_jp'] as String?) ?? '';
        final titleVi = ContentFallback.cleanText(r['title_vi'] as String?);
        final titleEn = ContentFallback.cleanText(r['title_en'] as String?);
        final contentJp = (r['content_jp'] as String?) ?? '';
        final trVi = ContentFallback.cleanText(r['translation_vi'] as String?);
        final trEn = ContentFallback.cleanText(r['translation_en'] as String?);
        final rawSummary = ContentFallback.cleanText(r['summary'] as String?);
        final authorJp = ContentFallback.cleanText(r['author_jp'] as String?);
        final authorRomaji =
            ContentFallback.cleanText(r['author_romaji'] as String?);
        final sourceId = r['source_id'] as String?;
        final rawCat = (r['category'] as String?) ?? 'story';
        final uiCat = switch (rawCat) {
          'short_story' || 'literature' => 'Tiểu thuyết',
          'fairy_tale' => 'Cổ tích',
          _ => 'Đời sống',
        };
        final firstPara = contentJp.split('\n').firstWhere(
              (l) => l.trim().isNotEmpty,
              orElse: () => contentJp,
            );
        final previewText = firstPara.length > 120
            ? '${firstPara.substring(0, 120)}...'
            : firstPara;
        final levelLabel = ContentFallback.resolveJlptLevelLabel(
          origLevel,
          language: 'vi',
        );
        return ReadingMaterial(
          id: r['id'] as String,
          originalLevel: origLevel,
          level: levelLabel,
          category: uiCat,
          title: ContentFallback.resolveMeaning(
            meaningVi: titleVi,
            meaningEn: titleEn ?? titleJp,
            language: 'vi',
          ),
          titleVi: titleVi,
          titleEn: titleEn,
          japaneseTitle: titleJp,
          titleFurigana:
              ContentFallback.cleanText(r['title_furigana'] as String?),
          authorJp: authorJp,
          authorRomaji: authorRomaji,
          summary: rawSummary ??
              (authorJp != null
                  ? 'Tác giả: $authorJp ($authorRomaji)'
                  : previewText),
          preview: previewText,
          content: contentJp,
          translationVi: trVi,
          translationEn: trEn,
          contentRubyJson: r['content_ruby_json'] as String?,
          sourceId: sourceId,
          licenseId: r['license_id'] as String?,
          sourceUrl: r['source_url'] as String?,
          hasAudio: (r['has_audio'] as int? ?? 0) == 1,
          estimatedMinutes: (r['estimated_minutes'] as int?) ?? 5,
          tags: <String>[
            levelLabel,
            if (authorJp != null) authorJp,
            if (sourceId == 'src_aozora') 'Aozora Bunko',
            if (sourceId == 'src_hanabira') 'Hanabira CC BY 4.0',
          ],
          isFeatured: true,
        );
      }).toList();
      ReadingMaterialData.setLoadedMaterials(readings);

      await _loadListeningAndExamsForWeb();
      _loaded = true;
    } catch (_) {}
  }

  static Future<void> _loadListeningAndExamsForWeb() async {
    final lmRaw = await rootBundle
        .loadString('assets/data/verified_v2/p6_listening_materials.json');
    final trRaw = await rootBundle
        .loadString('assets/data/verified_v2/p6_transcripts.json');
    final exRaw =
        await rootBundle.loadString('assets/data/verified_v2/p6_exams.json');
    final qRaw = await rootBundle
        .loadString('assets/data/verified_v2/p6_questions.json');
    final aRaw =
        await rootBundle.loadString('assets/data/verified_v2/p6_answers.json');

    final lmList = (jsonDecode(lmRaw) as List).cast<Map<String, dynamic>>();
    final trList = (jsonDecode(trRaw) as List).cast<Map<String, dynamic>>();
    final exList = (jsonDecode(exRaw) as List).cast<Map<String, dynamic>>();
    final qList = (jsonDecode(qRaw) as List).cast<Map<String, dynamic>>();
    final aList = (jsonDecode(aRaw) as List).cast<Map<String, dynamic>>();

    final trByLm = <String, Map<String, dynamic>>{
      for (final t in trList) (t['listening_material_id'] as String): t,
    };
    final answersByQ = <String, List<Map<String, dynamic>>>{};
    for (final a in aList) {
      final qid = a['question_id'] as String;
      (answersByQ[qid] ??= <Map<String, dynamic>>[]).add(a);
    }
    for (final list in answersByQ.values) {
      list.sort(
        (x, y) =>
            ((x['option_index'] as int?) ?? 0)
                .compareTo((y['option_index'] as int?) ?? 0),
      );
    }

    final qByLm = <String, Map<String, dynamic>>{};
    final qByExam = <String, List<Map<String, dynamic>>>{};
    for (final q in qList) {
      final lmid = q['listening_material_id'] as String?;
      if (lmid != null) qByLm[lmid] = q;
      final exid = q['exam_id'] as String?;
      if (exid != null) {
        (qByExam[exid] ??= <Map<String, dynamic>>[]).add(q);
      }
    }

    final playableItems = <ListeningPracticeItem>[];
    for (final row in lmList) {
      final cat = (row['category'] as String?) ?? '';
      final url = (row['audio_url'] as String?) ?? '';
      if (cat != 'available' || !url.startsWith('assets/listening/')) continue;
      final lmId = row['id'] as String;
      final tr = trByLm[lmId];
      if (tr == null) continue;
      final q = qByLm[lmId];
      final aRows = q == null
          ? const <Map<String, dynamic>>[]
          : (answersByQ[q['id'] as String] ?? const <Map<String, dynamic>>[]);
      final options = aRows
          .map((a) => (a['content_text'] as String?) ?? '')
          .where((s) => s.isNotEmpty)
          .toList();
      final foundIdx =
          aRows.indexWhere((a) => (a['is_correct'] as int? ?? 0) == 1);
      final norm = (tr['text_jp'] as String?) ?? '';
      playableItems.add(
        ListeningPracticeItem(
          id: lmId,
          sourceId: (row['source_id'] as String?) ?? 'src_kokoro_tiny',
          externalClipId: (row['external_clip_id'] as String?) ?? lmId,
          title: (row['title'] as String?) ?? lmId,
          audioPath: url,
          audioStatus: cat,
          durationMs: (row['duration_ms'] as int?) ?? 0,
          sampleRate: (row['sample_rate'] as int?) ?? 22050,
          speakerName:
              (row['speaker_name'] as String?) ?? 'ekzemplaro (LibriVox)',
          estimatedLevel: row['estimated_level'] as String?,
          levelSource: 'estimated',
          difficultyScore: 0.0,
          classificationConfidence: 0.85,
          classificationReason: '',
          needsReview: false,
          transcriptNormalized: norm,
          transcriptOriginal: (tr['translation_en'] as String?) ?? norm,
          reading: (tr['text_furigana_reading'] as String?) ?? '',
          questionId: q?['id'] as String?,
          promptVi: (q?['prompt_text_vi'] as String?) ??
              'Nghe đoạn ghi âm và chọn câu tiếng Nhật khớp chính xác với nội dung vừa nghe:',
          promptJp: (q?['prompt_text_jp'] as String?) ?? '',
          options: options.isEmpty ? <String>[norm] : options,
          correctIndex: foundIdx < 0 ? 0 : foundIdx,
          explanation: ContentFallback.resolveExplanation(
            explanationVi: q?['explanation_vi'] as String?,
            explanationEn: q?['explanation_en'] as String?,
            language: 'vi',
          ),
        ),
      );
    }
    LocalDatabaseService.setLoadedPlayableListeningItems(playableItems);

    final tests = <JLPTTest>[];
    for (final exam in exList) {
      final examId = exam['id'] as String;
      final examLevel = (exam['original_level'] as String?) ?? 'N5';
      final qRows = qByExam[examId] ?? const <Map<String, dynamic>>[];
      if (qRows.isEmpty) continue;
      final quizQuestions = <QuizQuestion>[];
      for (final q in qRows) {
        final qId = q['id'] as String;
        final aRows = answersByQ[qId] ?? const <Map<String, dynamic>>[];
        if (aRows.isEmpty) continue;
        final options =
            aRows.map((a) => (a['content_text'] as String?) ?? '').toList();
        final correctIdx =
            aRows.indexWhere((a) => (a['is_correct'] as int? ?? 0) == 1);
        final rawType =
            ((q['question_type'] as String?) ?? 'vocab').toLowerCase();
        final questionType = switch (rawType) {
          'kanji' => QuestionType.kanjiMeaning,
          'grammar' => QuestionType.grammar,
          'reading' => QuestionType.reading,
          'listening' => QuestionType.listening,
          _ => QuestionType.vocabularyMeaning,
        };
        final qLvl = (q['original_level'] as String?) ?? examLevel;
        final mondaiCode = (q['mondai_code'] as String?) ?? '';
        final secLabel = switch (rawType) {
          'grammar' => 'Ngữ pháp (文法)',
          'reading' => 'Đọc hiểu (読解)',
          'listening' => 'Nghe hiểu (聴解)',
          _ => 'Từ vựng (文字・語彙)',
        };
        final headerLine =
            'Cấp độ chính thức: $qLvl (official_exam) • $secLabel${mondaiCode.isNotEmpty ? ' • $mondaiCode' : ''}';
        quizQuestions.add(
          QuizQuestion(
            id: qId,
            question: headerLine,
            questionJp: (q['prompt_text_jp'] as String?) ?? '',
            options: options,
            correctIndex: correctIdx < 0 ? 0 : correctIdx,
            explanation: ContentFallback.resolveExplanation(
              explanationVi: q['explanation_vi'] as String?,
              explanationEn: q['explanation_en'] as String?,
              language: 'vi',
            ),
            jlptLevel: qLvl,
            type: questionType,
          ),
        );
      }
      if (quizQuestions.isNotEmpty) {
        tests.add(
          JLPTTest(
            id: examId,
            level: examLevel,
            title: (exam['title'] as String?) ?? '',
            timeMinutes: (exam['time_limit_minutes'] as int?) ?? 20,
            questions: quizQuestions,
          ),
        );
      }
    }
    JLPTTestData.setLoadedTests(tests);
  }
}
