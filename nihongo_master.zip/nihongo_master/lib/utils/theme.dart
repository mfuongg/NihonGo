import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../theme/cozy_palette.dart';

export '../theme/cozy_palette.dart';

class AppThemeSpec {
  final String id;
  final String emoji;
  final String name;
  final String subtitle;
  final int coinPrice;
  final int gemPrice;
  final Color primary;
  final Color primaryMuted;
  final Color accent;
  final Color background;
  final Color surface;
  final Color primarySoft;
  final Color secondary;
  final Color secondarySoft;
  final Color borderSubtle;
  final Color textPrimary;
  final Color textSecondary;

  const AppThemeSpec({
    required this.id,
    required this.emoji,
    required this.name,
    required this.subtitle,
    this.coinPrice = 0,
    this.gemPrice = 0,
    required this.primary,
    required this.primaryMuted,
    required this.accent,
    required this.background,
    required this.surface,
    required this.primarySoft,
    required this.secondary,
    required this.secondarySoft,
    required this.borderSubtle,
    required this.textPrimary,
    required this.textSecondary,
  });

  bool get isFree => coinPrice == 0 && gemPrice == 0;
  bool get isGemTheme => gemPrice > 0;
  String get displayName => '$emoji $name';

  /// Bề mặt phụ (nền ô nhập, chip chưa chọn...). Dusty Rose giữ đúng mã HTML.
  Color get surfaceSoft => id == AppTheme.defaultThemeId
      ? CozyPalette.dustySurfaceSoft
      : Color.alphaBlend(primary.withValues(alpha: 0.07), background);

  /// Palette dạng `ThemeExtension` của theme này.
  CozyPalette get palette => CozyPalette(
        background: background,
        surface: surface,
        surfaceSoft: surfaceSoft,
        primary: primary,
        primaryMuted: primaryMuted,
        primarySoft: primarySoft,
        secondary: secondary,
        secondarySoft: secondarySoft,
        accent: accent,
        textPrimary: textPrimary,
        textSecondary: textSecondary,
        borderSubtle: borderSubtle,
      );
}

/// Điểm truy cập màu toàn ứng dụng.
///
/// Các màu giao diện (`primary`, `surface`, `textPrimary`, ...) là **getter theo theme
/// đang hoạt động** chứ không còn là hằng số Dusty Rose, nên widget đọc `AppTheme.xxx`
/// trong `build()` sẽ nhận màu mới khi theme đổi (MaterialApp kích hoạt rebuild toàn
/// cây qua `ThemeRefreshScope`). Widget mới nên dùng `context.cozy` / `Theme.of(context)`.
///
/// Màu chức năng (`success`, `error`, `warningOrange`, `accentGold`...) giữ nguyên ở mọi theme.
class AppTheme {
  static const String themeName = 'DUSTY ROSE & MATCHA';
  static const String defaultThemeId = 'dusty_rose';
  static String _activeThemeId = defaultThemeId;

  static String get activeThemeId => _activeThemeId;
  static AppThemeSpec get activeSpec => specFor(_activeThemeId);
  static CozyPalette get activePalette => activeSpec.palette;

  static void setActiveTheme(String? themeId) {
    final spec = specFor(themeId);
    _activeThemeId = spec.id;
  }

  static const List<String> defaultUnlockedThemeIds = <String>[
    'dusty_rose',
    'ocean_blue',
    'sky_butter',
    'white_sage',
  ];

  static const List<AppThemeSpec> themes = <AppThemeSpec>[
    AppThemeSpec(
      id: 'dusty_rose',
      emoji: '🌸',
      name: 'Dusty Rose & Matcha',
      subtitle: 'Hồng phấn trà xanh Cozy mặc định',
      primary: CozyPalette.dustyPrimary,
      primaryMuted: CozyPalette.dustyPrimaryMuted,
      accent: CozyPalette.dustyAccent,
      background: CozyPalette.dustyBackground,
      surface: CozyPalette.dustySurface,
      primarySoft: CozyPalette.dustyPrimarySoft,
      secondary: CozyPalette.dustySecondary,
      secondarySoft: CozyPalette.dustySecondarySoft,
      borderSubtle: CozyPalette.dustyBorderSubtle,
      textPrimary: CozyPalette.dustyTextPrimary,
      textSecondary: CozyPalette.dustyTextSecondary,
    ),
    AppThemeSpec(
      id: 'ocean_blue',
      emoji: '🌊',
      name: 'Ocean Blue & Slate',
      subtitle: 'Xanh đại dương thanh lịch & dịu mắt',
      primary: Color(0xFF3B82A6),
      primaryMuted: Color(0xFF72B5D8),
      accent: Color(0xFF284B63),
      background: Color(0xFFF2F8FB),
      surface: Color(0xFFFFFFFF),
      primarySoft: Color(0xFFE5F3FA),
      secondary: Color(0xFF5296A5),
      secondarySoft: Color(0xFFE8F6F8),
      borderSubtle: Color(0xFFD5E5EE),
      textPrimary: Color(0xFF1E3240),
      textSecondary: Color(0xFF5E788A),
    ),
    AppThemeSpec(
      id: 'sky_butter',
      emoji: '☁️',
      name: 'Sky Blue & Butter',
      subtitle: 'Mây xanh nắng sớm tươi sáng',
      primary: Color(0xFF5A9BD5),
      primaryMuted: Color(0xFFF4C95D),
      accent: Color(0xFF3A6EA5),
      background: Color(0xFFFFFDF6),
      surface: Color(0xFFFFFFFF),
      primarySoft: Color(0xFFEEF6FF),
      secondary: Color(0xFFE6A145),
      secondarySoft: Color(0xFFFFF8E5),
      borderSubtle: Color(0xFFEAE4D3),
      textPrimary: Color(0xFF2C3E50),
      textSecondary: Color(0xFF6E7F91),
    ),
    AppThemeSpec(
      id: 'white_sage',
      emoji: '🌿',
      name: 'White & Sage',
      subtitle: 'Trắng tinh khôi & lá xô thơm tĩnh tại',
      primary: Color(0xFF6B9080),
      primaryMuted: Color(0xFFA4C3B2),
      accent: Color(0xFF4A6B5D),
      background: Color(0xFFF6FAF7),
      surface: Color(0xFFFFFFFF),
      primarySoft: Color(0xFFEAF4EE),
      secondary: Color(0xFF84A98C),
      secondarySoft: Color(0xFFEEF6F0),
      borderSubtle: Color(0xFFDCE8E0),
      textPrimary: Color(0xFF2B3A33),
      textSecondary: Color(0xFF687D73),
    ),
    AppThemeSpec(
      id: 'cyber_midnight',
      emoji: '🌌',
      name: 'Cyber Midnight',
      subtitle: 'Ánh sao tím Neon công nghệ tương lai',
      coinPrice: 300,
      primary: Color(0xFF6366F1),
      primaryMuted: Color(0xFF22D3EE),
      accent: Color(0xFF4338CA),
      background: Color(0xFFF1F3FE),
      surface: Color(0xFFFFFFFF),
      primarySoft: Color(0xFFE5E7FF),
      secondary: Color(0xFF06B6D4),
      secondarySoft: Color(0xFFE0F9FF),
      borderSubtle: Color(0xFFD5D9F8),
      textPrimary: Color(0xFF1E1B4B),
      textSecondary: Color(0xFF5B588C),
    ),
    AppThemeSpec(
      id: 'royal_palace',
      emoji: '👑',
      name: 'Royal Golden Palace',
      subtitle: 'Cung điện Hoàng Kim sang trọng bậc nhất',
      gemPrice: 50,
      primary: Color(0xFFC88A2B),
      primaryMuted: Color(0xFFE5B84B),
      accent: Color(0xFF8C3B2B),
      background: Color(0xFFFFFBF2),
      surface: Color(0xFFFFFFFF),
      primarySoft: Color(0xFFFFF3D6),
      secondary: Color(0xFFB45309),
      secondarySoft: Color(0xFFFEF3C7),
      borderSubtle: Color(0xFFF0DFC0),
      textPrimary: Color(0xFF3E2723),
      textSecondary: Color(0xFF8D6E63),
    ),
  ];

  static AppThemeSpec specFor(String? themeId) {
    if (themeId != null && themeId.isNotEmpty) {
      for (final item in themes) {
        if (item.id == themeId) return item;
      }
    }
    return themes.first;
  }

  /// `ThemeData` đầy đủ (ColorScheme, component themes, `CozyPalette` extension) cho [themeId].
  static ThemeData themeFor(String? themeId) => lightThemeFor(specFor(themeId));

  // ---------------------------------------------------------------------------
  // Màu giao diện — đổi theo theme đang hoạt động.
  // ---------------------------------------------------------------------------
  static Color get primary => activeSpec.primary;
  static Color get primaryMuted => activeSpec.primaryMuted;
  static Color get accent => activeSpec.accent;
  static Color get background => activeSpec.background;
  static Color get surface => activeSpec.surface;
  static Color get textPrimary => activeSpec.textPrimary;
  static Color get textSecondary => activeSpec.textSecondary;
  static Color get borderSubtle => activeSpec.borderSubtle;
  static Color get surfaceSoft => activeSpec.surfaceSoft;
  static Color get primarySoft => activeSpec.primarySoft;
  static Color get secondary => activeSpec.secondary;
  static Color get secondarySoft => activeSpec.secondarySoft;

  static Color get primaryRed => primary;
  static Color get primaryDark => accent;
  static Color get accentOrange => primaryMuted;
  static Color get bgLight => background;
  static Color get bgCard => surface;
  static Color get textDark => textPrimary;
  static Color get textMedium => textSecondary;
  static Color get textLight => textSecondary.withValues(alpha: 0.62);

  /// Màu cấp độ JLPT: N5/N4/N1 theo theme, N3/N2 là màu phân biệt cố định.
  static Color get n5Color => primary;
  static Color get n4Color => primaryMuted;
  static const Color n3Color = success;
  static const Color n2Color = Color(0xFFD4A373);
  static Color get n1Color => accent;

  static List<Color> get dreamyGradient => [primary, primaryMuted, accent];

  // ---------------------------------------------------------------------------
  // Màu chức năng — giữ nguyên ý nghĩa ở mọi theme.
  // ---------------------------------------------------------------------------
  static const Color success = CozyPalette.successColor;
  static const Color error = CozyPalette.errorColor;
  static const Color accentGold = Color(0xFFD4A373);
  static const Color accentBlue = Color(0xFF7D98A1);
  static const Color accentMint = success;
  static const Color successGreen = success;
  static const Color warningOrange = Color(0xFFD4A373);
  static const Color errorRed = error;

  static List<BoxShadow> get softCardShadow => [
        BoxShadow(
          color: textPrimary.withValues(alpha: 0.05),
          blurRadius: 14,
          offset: const Offset(0, 4),
        ),
      ];

  static ThemeData get lightTheme => lightThemeFor(activeSpec);

  static ThemeData lightThemeFor(AppThemeSpec spec) {
    final primary = spec.primary;
    final primaryMuted = spec.primaryMuted;
    final accent = spec.accent;
    final surface = spec.surface;
    final background = spec.background;
    final textPrimary = spec.textPrimary;
    final textSecondary = spec.textSecondary;
    final borderSubtle = spec.borderSubtle;
    final textLight = textSecondary.withValues(alpha: 0.62);

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primary,
        brightness: Brightness.light,
      ).copyWith(
        primary: primary,
        secondary: primaryMuted,
        tertiary: accent,
        surface: surface,
        surfaceContainerLowest: surface,
        surfaceContainerLow: background,
        surfaceContainer: spec.surfaceSoft,
        surfaceContainerHigh: spec.primarySoft,
        surfaceContainerHighest: spec.primarySoft,
        primaryContainer: spec.primarySoft,
        onPrimaryContainer: accent,
        secondaryContainer: spec.secondarySoft,
        onSecondaryContainer: textPrimary,
        outline: borderSubtle,
        outlineVariant: borderSubtle,
        error: error,
        onPrimary: Colors.white,
        onSecondary: textPrimary,
        onSurface: textPrimary,
        onSurfaceVariant: textSecondary,
      ),
    );

    final textTheme = GoogleFonts.beVietnamProTextTheme(base.textTheme)
        .apply(bodyColor: textPrimary, displayColor: textPrimary)
        .copyWith(
          displayLarge: GoogleFonts.beVietnamPro(fontSize: 34, fontWeight: FontWeight.w700, color: textPrimary),
          headlineMedium: GoogleFonts.beVietnamPro(fontSize: 26, fontWeight: FontWeight.w700, color: textPrimary),
          titleLarge: GoogleFonts.beVietnamPro(fontSize: 19, fontWeight: FontWeight.w700, color: textPrimary),
          titleMedium: GoogleFonts.beVietnamPro(fontSize: 16, fontWeight: FontWeight.w600, color: textPrimary),
          bodyLarge: GoogleFonts.beVietnamPro(fontSize: 15, fontWeight: FontWeight.w500, color: textPrimary),
          bodyMedium: GoogleFonts.beVietnamPro(fontSize: 14, fontWeight: FontWeight.w400, color: textSecondary),
        );

    return base.copyWith(
      extensions: <ThemeExtension<dynamic>>[spec.palette],
      scaffoldBackgroundColor: background,
      canvasColor: background,
      splashColor: primary.withValues(alpha: 0.08),
      highlightColor: primaryMuted.withValues(alpha: 0.06),
      cardColor: surface,
      dividerColor: borderSubtle,
      dividerTheme: DividerThemeData(color: borderSubtle, thickness: 1),
      iconTheme: IconThemeData(color: textSecondary),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: textPrimary,
        iconTheme: IconThemeData(color: textPrimary),
        elevation: 0,
        centerTitle: true,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.beVietnamPro(fontSize: 19, fontWeight: FontWeight.w700, color: textPrimary),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shadowColor: textPrimary.withValues(alpha: 0.05),
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primary.withValues(alpha: 0.16), width: 1),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        titleTextStyle: GoogleFonts.beVietnamPro(fontSize: 17, fontWeight: FontWeight.w800, color: textPrimary),
        contentTextStyle: GoogleFonts.beVietnamPro(fontSize: 14, color: textPrimary),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: background,
        modalBackgroundColor: background,
        surfaceTintColor: Colors.transparent,
        dragHandleColor: borderSubtle,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: surface,
        surfaceTintColor: Colors.transparent,
        textStyle: GoogleFonts.beVietnamPro(color: textPrimary),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: primary,
        unselectedLabelColor: textSecondary,
        indicatorColor: primary,
        dividerColor: borderSubtle,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? Colors.white : textSecondary,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? primary : spec.surfaceSoft,
        ),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primary,
        thumbColor: primary,
        inactiveTrackColor: primary.withValues(alpha: 0.18),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: primary,
        linearTrackColor: borderSubtle,
        circularTrackColor: borderSubtle,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: primary),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: GoogleFonts.beVietnamPro(fontSize: 15, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(double.infinity, 50),
          foregroundColor: textPrimary,
          side: BorderSide(color: primary.withValues(alpha: 0.28), width: 1.2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: GoogleFonts.beVietnamPro(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: primary.withValues(alpha: 0.20)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: primary.withValues(alpha: 0.20)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(color: primary, width: 1.6),
        ),
        errorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(color: error, width: 1.3),
        ),
        focusedErrorBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(color: error, width: 1.6),
        ),
        prefixIconColor: textSecondary,
        suffixIconColor: textSecondary,
        labelStyle: GoogleFonts.beVietnamPro(color: textSecondary, fontWeight: FontWeight.w500),
        hintStyle: GoogleFonts.beVietnamPro(color: textLight),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: textPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        contentTextStyle: GoogleFonts.beVietnamPro(color: Colors.white, fontWeight: FontWeight.w500),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: primary,
        unselectedItemColor: textSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w700, fontSize: 12),
        unselectedLabelStyle: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w500, fontSize: 11),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: surface,
        selectedColor: primary,
        secondarySelectedColor: primaryMuted,
        labelStyle: GoogleFonts.beVietnamPro(fontSize: 12, fontWeight: FontWeight.w600, color: textPrimary),
        secondaryLabelStyle: GoogleFonts.beVietnamPro(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        side: BorderSide(color: primary.withValues(alpha: 0.22)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      ),
      textTheme: textTheme,
    );
  }

  static ThemeData get darkTheme {
    const darkBg = Color(0xFF231D20);
    const darkSurface = Color(0xFF2E262A);
    const darkText = Color(0xFFF5EFEA);
    final light = lightTheme;

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primary,
        brightness: Brightness.dark,
      ).copyWith(
        primary: primaryMuted,
        secondary: primary,
        tertiary: success,
        surface: darkSurface,
        error: error,
      ),
    );

    return base.copyWith(
      extensions: <ThemeExtension<dynamic>>[
        activePalette.copyWith(
          background: darkBg,
          surface: darkSurface,
          surfaceSoft: const Color(0xFF3A3035),
          textPrimary: darkText,
          textSecondary: Colors.white70,
          borderSubtle: Colors.white12,
        ),
      ],
      scaffoldBackgroundColor: darkBg,
      cardColor: darkSurface,
      dividerColor: Colors.white12,
      cardTheme: CardThemeData(
        color: darkSurface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryMuted.withValues(alpha: 0.18)),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: darkBg,
        foregroundColor: darkText,
        elevation: 0,
        centerTitle: true,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.beVietnamPro(fontSize: 19, fontWeight: FontWeight.w700, color: darkText),
      ),
      elevatedButtonTheme: light.elevatedButtonTheme,
      outlinedButtonTheme: light.outlinedButtonTheme,
      inputDecorationTheme: light.inputDecorationTheme.copyWith(
        fillColor: darkSurface,
        labelStyle: GoogleFonts.beVietnamPro(color: Colors.white70, fontWeight: FontWeight.w500),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: darkSurface,
        selectedItemColor: primaryMuted,
        unselectedItemColor: Colors.white54,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w700, fontSize: 12),
        unselectedLabelStyle: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w500, fontSize: 11),
      ),
      textTheme: GoogleFonts.beVietnamProTextTheme(ThemeData.dark().textTheme).apply(
        bodyColor: darkText,
        displayColor: darkText,
      ),
    );
  }

  static Color jlptColor(String level) {
    switch (level) {
      case 'N5':
        return n5Color;
      case 'N4':
        return n4Color;
      case 'N3':
        return n3Color;
      case 'N2':
        return n2Color;
      case 'N1':
        return n1Color;
      default:
        return n5Color;
    }
  }
}
