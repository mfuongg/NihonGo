class ContentFallback {
  ContentFallback._();

  static const String missingMeaningVi = 'Chưa có nghĩa';
  static const String missingMeaningEn = 'No meaning available';

  static const String missingExplanationVi = 'Chưa có giải thích';
  static const String missingExplanationEn = 'No explanation available';

  static const String missingTranslationVi = 'Chưa có bản dịch';
  static const String missingTranslationEn = 'No translation available';

  static const String unclassifiedLevelVi = 'Chưa phân cấp JLPT';
  static const String unclassifiedLevelEn = 'Not classified by JLPT';

  static const String emptyListeningVi = 'Chưa có dữ liệu luyện nghe.';
  static const String emptyListeningEn = 'No listening data available.';

  static const String emptyJlptTestVi = 'Chưa có dữ liệu luyện thi.';
  static const String emptyJlptTestEn = 'No practice test data available.';

  static String? cleanText(String? value) {
    if (value == null) return null;
    final trimmed = value.trim();
    if (trimmed.isEmpty) return null;
    if (trimmed.toLowerCase() == 'null') return null;
    return trimmed;
  }

  static bool isEnglish(String language) =>
      language.trim().toLowerCase().startsWith('en');

  /// Section 5.3 — Meaning fallback rule (Anh ↔ Việt)
  static String resolveMeaning({
    required String? meaningVi,
    required String? meaningEn,
    String language = 'vi',
  }) {
    final vi = cleanText(meaningVi);
    final en = cleanText(meaningEn);
    if (isEnglish(language)) {
      return en ?? vi ?? missingMeaningEn;
    }
    return vi ?? en ?? missingMeaningVi;
  }

  /// Section 5.3 — Explanation fallback rule (Anh ↔ Việt)
  static String resolveExplanation({
    required String? explanationVi,
    required String? explanationEn,
    String language = 'vi',
  }) {
    final vi = cleanText(explanationVi);
    final en = cleanText(explanationEn);
    if (isEnglish(language)) {
      return en ?? vi ?? missingExplanationEn;
    }
    return vi ?? en ?? missingExplanationVi;
  }

  /// Section 5.3 — Translation fallback rule (Anh ↔ Việt)
  static String resolveTranslation({
    required String? translationVi,
    required String? translationEn,
    String language = 'vi',
  }) {
    final vi = cleanText(translationVi);
    final en = cleanText(translationEn);
    if (isEnglish(language)) {
      return en ?? vi ?? missingTranslationEn;
    }
    return vi ?? en ?? missingTranslationVi;
  }

  /// Section 7.3 — JLPT Level label when original_level == null
  static String resolveJlptLevelLabel(
    String? originalLevel, {
    String language = 'vi',
  }) {
    final clean = cleanText(originalLevel);
    if (clean == null ||
        clean == unclassifiedLevelVi ||
        clean == unclassifiedLevelEn) {
      return isEnglish(language) ? unclassifiedLevelEn : unclassifiedLevelVi;
    }
    return clean;
  }

  static bool isUnclassifiedLevel(String? level) {
    final clean = cleanText(level);
    return clean == null ||
        clean == unclassifiedLevelVi ||
        clean == unclassifiedLevelEn;
  }

  /// Section 6.3 — Empty state text for Listening
  static String listeningEmptyStateText({String language = 'vi'}) {
    return isEnglish(language) ? emptyListeningEn : emptyListeningVi;
  }

  /// Section 6.3 — Empty state text for JLPT Test
  static String jlptTestEmptyStateText({String language = 'vi'}) {
    return isEnglish(language) ? emptyJlptTestEn : emptyJlptTestVi;
  }
}
