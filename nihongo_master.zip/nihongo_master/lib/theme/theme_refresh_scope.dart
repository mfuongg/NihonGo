import 'package:flutter/widgets.dart';

/// Đảm bảo **mọi** widget nhận theme mới ngay khi người dùng đổi theme.
///
/// `MaterialApp` chỉ rebuild các widget phụ thuộc `Theme.of(context)`. Những widget
/// đọc màu qua `AppTheme.xxx` (getter theo theme đang hoạt động) trong `build()` nhưng
/// không đăng ký phụ thuộc `Theme` — đặc biệt là `StatelessWidget` con, route đã mở,
/// dialog, bottom sheet — sẽ giữ màu cũ. Scope này đánh dấu toàn bộ cây con cần build lại
/// đúng một lần khi [themeId] thay đổi; state (cuộn, form, route stack) được giữ nguyên.
///
/// Đặt trong `MaterialApp.builder` để bao cả `Navigator` và các overlay.
class ThemeRefreshScope extends StatefulWidget {
  final String themeId;
  final Widget child;

  const ThemeRefreshScope({super.key, required this.themeId, required this.child});

  @override
  State<ThemeRefreshScope> createState() => _ThemeRefreshScopeState();
}

class _ThemeRefreshScopeState extends State<ThemeRefreshScope> {
  @override
  void didUpdateWidget(covariant ThemeRefreshScope oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeId != widget.themeId) {
      _markSubtreeDirty(context as Element);
    }
  }

  static void _markSubtreeDirty(Element root) {
    void visit(Element element) {
      element.markNeedsBuild();
      element.visitChildren(visit);
    }

    root.visitChildren(visit);
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
