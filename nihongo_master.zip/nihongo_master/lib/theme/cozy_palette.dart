import 'package:flutter/material.dart';

/// Bảng màu Cozy dùng chung toàn ứng dụng, đăng ký vào `ThemeData.extensions`.
///
/// Truy cập theo theme đang hoạt động:
/// ```dart
/// final c = Theme.of(context).extension<CozyPalette>()!; // hoặc CozyPalette.of(context) / context.cozy
/// ```
/// Mỗi theme (Dusty Rose, Ocean Blue, Sky Butter, White Sage, ...) tạo một instance
/// riêng từ `AppThemeSpec`, nên khi `MaterialApp.theme` đổi thì mọi widget đọc
/// palette qua `context` tự cập nhật.
@immutable
class CozyPalette extends ThemeExtension<CozyPalette> {
  // ---------------------------------------------------------------------------
  // Mã HEX gốc từ nguyên mẫu HTML (Dusty Rose & Matcha) — theme mặc định.
  // ---------------------------------------------------------------------------

  /// Nền ứng dụng (Background): `#FAF7F5`
  static const Color dustyBackground = Color(0xFFFAF7F5);

  /// Thẻ Card (Surface): `#FFFFFF`
  static const Color dustySurface = Color(0xFFFFFFFF);

  /// Bề mặt phụ ấm nhẹ
  static const Color dustySurfaceSoft = Color(0xFFF3ECEF);

  /// Màu nhấn chính (Primary - Dusty Rose): `#B5838D`
  static const Color dustyPrimary = Color(0xFFB5838D);

  /// Màu nhấn phụ (Primary Muted): `#E5989B`
  static const Color dustyPrimaryMuted = Color(0xFFE5989B);

  /// Nền nhấn dịu
  static const Color dustyPrimarySoft = Color(0xFFF5E6E8);

  /// Màu phụ trợ (Matcha Sage): `#8FA89B`
  static const Color dustySecondary = Color(0xFF8FA89B);

  /// Nền phụ trợ dịu
  static const Color dustySecondarySoft = Color(0xFFE6EFEA);

  /// Màu nhấn đậm
  static const Color dustyAccent = Color(0xFF6D597A);

  /// Chữ chính (Text Primary): `#3D3135`
  static const Color dustyTextPrimary = Color(0xFF3D3135);

  /// Chữ phụ (Text Secondary): `#8D7B82`
  static const Color dustyTextSecondary = Color(0xFF8D7B82);

  /// Viền tinh tế
  static const Color dustyBorderSubtle = Color(0xFFEBE3E6);

  // ---------------------------------------------------------------------------
  // Màu chức năng — giữ nguyên ý nghĩa ở mọi theme (đúng / cảnh báo / sai).
  // ---------------------------------------------------------------------------

  /// Màu Thành công (Matcha Success): `#8FA89B`
  static const Color successColor = Color(0xFF8FA89B);
  static const Color warningColor = Color(0xFFE2A878);
  static const Color errorColor = Color(0xFFD67A7A);

  /// Màu nhận diện tiền tệ (Xu vàng / Gem xanh) — cố định để người dùng nhận ra loại tiền.
  static const Color coinColor = Color(0xFFB7791F);
  static const Color coinSoftColor = Color(0xFFFFF6E5);
  static const Color gemColor = Color(0xFF2B6CB0);
  static const Color gemSoftColor = Color(0xFFEEF6FF);

  /// Bảng màu Dusty Rose mặc định.
  static const CozyPalette dustyRose = CozyPalette(
    background: dustyBackground,
    surface: dustySurface,
    surfaceSoft: dustySurfaceSoft,
    primary: dustyPrimary,
    primaryMuted: dustyPrimaryMuted,
    primarySoft: dustyPrimarySoft,
    secondary: dustySecondary,
    secondarySoft: dustySecondarySoft,
    accent: dustyAccent,
    textPrimary: dustyTextPrimary,
    textSecondary: dustyTextSecondary,
    borderSubtle: dustyBorderSubtle,
  );

  final Color background;
  final Color surface;
  final Color surfaceSoft;
  final Color primary;
  final Color primaryMuted;
  final Color primarySoft;
  final Color secondary;
  final Color secondarySoft;
  final Color accent;
  final Color textPrimary;
  final Color textSecondary;
  final Color borderSubtle;
  final Color success;
  final Color warning;
  final Color error;
  final Color coin;
  final Color coinSoft;
  final Color gem;
  final Color gemSoft;

  const CozyPalette({
    required this.background,
    required this.surface,
    required this.surfaceSoft,
    required this.primary,
    required this.primaryMuted,
    required this.primarySoft,
    required this.secondary,
    required this.secondarySoft,
    required this.accent,
    required this.textPrimary,
    required this.textSecondary,
    required this.borderSubtle,
    this.success = successColor,
    this.warning = warningColor,
    this.error = errorColor,
    this.coin = coinColor,
    this.coinSoft = coinSoftColor,
    this.gem = gemColor,
    this.gemSoft = gemSoftColor,
  });

  /// Chữ mờ (placeholder, chú thích phụ).
  Color get textMuted => textSecondary.withValues(alpha: 0.62);

  /// Chữ / icon trên nền [primary].
  Color get onPrimary => Colors.white;

  /// Bóng đổ cực nhẹ cho thẻ theo chuẩn HTML, ăn theo màu chữ của theme.
  List<BoxShadow> get softCardShadow => <BoxShadow>[
        BoxShadow(
          color: textPrimary.withValues(alpha: 0.05),
          blurRadius: 14,
          offset: const Offset(0, 4),
        ),
      ];

  /// Palette của theme đang hoạt động tại [context].
  static CozyPalette of(BuildContext context) =>
      Theme.of(context).extension<CozyPalette>() ?? dustyRose;

  @override
  CozyPalette copyWith({
    Color? background,
    Color? surface,
    Color? surfaceSoft,
    Color? primary,
    Color? primaryMuted,
    Color? primarySoft,
    Color? secondary,
    Color? secondarySoft,
    Color? accent,
    Color? textPrimary,
    Color? textSecondary,
    Color? borderSubtle,
    Color? success,
    Color? warning,
    Color? error,
  }) {
    return CozyPalette(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      surfaceSoft: surfaceSoft ?? this.surfaceSoft,
      primary: primary ?? this.primary,
      primaryMuted: primaryMuted ?? this.primaryMuted,
      primarySoft: primarySoft ?? this.primarySoft,
      secondary: secondary ?? this.secondary,
      secondarySoft: secondarySoft ?? this.secondarySoft,
      accent: accent ?? this.accent,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      borderSubtle: borderSubtle ?? this.borderSubtle,
      success: success ?? this.success,
      warning: warning ?? this.warning,
      error: error ?? this.error,
    );
  }

  @override
  CozyPalette lerp(ThemeExtension<CozyPalette>? other, double t) {
    if (other is! CozyPalette) return this;
    Color l(Color a, Color b) => Color.lerp(a, b, t)!;
    return CozyPalette(
      background: l(background, other.background),
      surface: l(surface, other.surface),
      surfaceSoft: l(surfaceSoft, other.surfaceSoft),
      primary: l(primary, other.primary),
      primaryMuted: l(primaryMuted, other.primaryMuted),
      primarySoft: l(primarySoft, other.primarySoft),
      secondary: l(secondary, other.secondary),
      secondarySoft: l(secondarySoft, other.secondarySoft),
      accent: l(accent, other.accent),
      textPrimary: l(textPrimary, other.textPrimary),
      textSecondary: l(textSecondary, other.textSecondary),
      borderSubtle: l(borderSubtle, other.borderSubtle),
      success: l(success, other.success),
      warning: l(warning, other.warning),
      error: l(error, other.error),
    );
  }
}

/// Truy cập nhanh palette của theme hiện tại: `context.cozy.primary`.
extension CozyPaletteContext on BuildContext {
  CozyPalette get cozy => CozyPalette.of(this);
}
