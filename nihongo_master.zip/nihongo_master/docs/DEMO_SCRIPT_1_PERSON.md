# 🎙️ KỊCH BẢN LIVE DEMO 1 NGƯỜI (BẢN MỞ RỘNG CHI TIẾT 8–10 PHÚT) — NIHONGO MASTER

> **Dành cho:** 1 người vừa trực tiếp thao tác chuột trên ứng dụng vừa thuyết minh trước Hội đồng chấm đồ án  
> **Thời lượng Live Demo:** **8 – 10 phút** (Đi qua trọn vẹn **8 phân cảnh cốt lõi** từ Học tập, Cơ sở dữ liệu SQLite v3, Bản đồ 5 Thế giới đến Pomodoro Anti-Cheat, Phòng Mèo và Đấu trường Mèo Nổ PK 4×4)  
> **Mẹo quan trọng trước khi bắt đầu:**  
> - Mở sẵn ứng dụng **Nihongo Master** bằng tài khoản **Admin Dev Mode** (`admin.nihongomaster@example.com` / `Admin@2026`) để có sẵn **`999.999 Xu`**, **`99.999 Gems`** và mở khóa toàn bộ 5 Thế giới N5–N1, 24 mèo, 36 món ăn, 32 trang phục, 6 Cozy Themes.  
> - Bật loa máy tính ở mức `40% – 50%` để Hội đồng nghe rõ tiếng phát âm TTS tiếng Nhật và bài nghe MP3.

---

## 🎬 MỞ ĐẦU CHUYỂN TỪ SLIDE SANG ỨNG DỤNG (15 GIÂY)

- **[Thao tác]:** Đang ở **Slide 13 (Kịch bản Demo Ứng dụng)**, nhấn `Alt + Tab` chuyển sang cửa sổ ứng dụng **Nihongo Master** đang mở ở **Trang chủ (`HomeScreen`)**.
- **[Lời thoại]:**
  > *"Kính thưa Thầy/Cô và các bạn, tiếp nối phần trình bày trên slide, em xin phép chuyển sang màn hình ứng dụng **Nihongo Master** đang chạy thực tế để trình diễn chi tiết các luồng chức năng học tập, cơ chế lưu trữ Offline-First và hệ sinh thái Gamification của dự án."*

---

## 🟢 CẢNH 1: TRANG CHỦ (`HomeScreen`), TIẾN ĐỘ & MÈO ĐI TRÊN MÉP THẺ (`LineCompanionCat`) — *~1 phút 15 giây*

- **[Thao tác 1.1]:** Rê chuột chỉ vào phần **Header núi Phú Sĩ** ở đầu Trang chủ (Avatar, Chuỗi ngày học `Streak`, số dư `Xu`, `Gems`) và bấm đổi thử nút chọn cấp độ từ `N5` sang `N4`, `N3` rồi quay về `N5`.
- **[Lời thoại]:**
  > *"Đầu tiên là **Màn hình Trang chủ (Tab 1)**. Ở phần Header phía trên, người học có thể theo dõi ngay chuỗi ngày học liên tiếp (**Streak**), số dư ví **Xu (Coins)**, **Đá quý (Gems)** và chuyển đổi linh hoạt giữa 5 cấp độ **JLPT từ N5 đến N1**. Khi em đổi cấp độ ở đây, toàn bộ số liệu tiến độ từ vựng, Kanji và danh sách bài học bên dưới sẽ tự động lọc theo đúng cấp độ đó."*

- **[Thao tác 1.2]:** Cuộn nhẹ xuống thẻ **Ôn tập hằng ngày** và **Nhiệm vụ hằng ngày (`DailyTask`)**, chỉ chuột vào các tiến trình nhiệm vụ.
- **[Lời thoại]:**
  > *"Ngay bên dưới là khu vực **Ôn tập hằng ngày** và **3 Nhiệm vụ mỗi ngày** được hệ thống sinh tự động. Khi học ít nhất 1 từ vựng trong ngày, người học được nhận thưởng điểm danh **`+5 Xu`** (giới hạn 1 lần/ngày qua biến `dailyReviewClaimDay` để chống cày Xu). Mọi thay đổi về Xu, Gems và XP đều được lưu tức thời xuống bộ nhớ cục bộ theo cơ chế **Offline-First**, và tự động đẩy ngầm lên **Cloud Firestore** khi thiết bị có mạng."*

- **[Thao tác 1.3]:** Nhấn giữ chuột vào chú **Mèo Hộ Pháp** đang đứng trên mép thẻ *Tiến độ*, **kéo-thả** chú mèo xuống mép trên của kệ *Tiện ích học tập* (hoặc thẻ *Bắt đầu học ngay*).
- **[Lời thoại]:**
  > *"Một điểm nhấn tương tác rất đặc trưng của ứng dụng là chú **Mèo Hộ Pháp đồng hành (`LineCompanionCat`)**. Chú mèo không chỉ nằm cố định một chỗ mà có thể bước đi dọc trên mép các thẻ giao diện. Khi em kéo và thả chú mèo gần mép một thẻ bất kỳ trong phạm vi dung sai `36px`, dịch vụ `CatPositionManager` sẽ tính toán tọa độ điểm neo bàn chân mèo (`foot anchor`) và tự động bắt dính chân mèo đứng gọn trên mép thẻ đó."*

---

## 🟢 CẢNH 2: TỪ ĐIỂN, BẢNG CHỮ CÁI KANA & HỌC TỪ VỰNG FLASHCARD 3D (THUẬT TOÁN SM-2) — *~1 phút 30 giây*

- **[Thao tác 2.1]:** Bấm vào mục **Bảng chữ cái Kana (`KanaScreen`)**, bấm thử 1–2 chữ cái Hiragana/Katakana để phát âm, sau đó quay ra bấm vào **Từ điển (`DictionaryScreen`)**, gõ tìm kiếm thử từ `"gia đình"` hoặc `"bố mẹ"` (hoặc `"先生"`).
- **[Lời thoại]:**
  > *"Đối với người mới bắt đầu, ứng dụng cung cấp **Bảng chữ cái Hiragana và Katakana** đầy đủ âm cơ bản, âm đục, âm ghép kèm phát âm mẫu.*
  > *Còn khi cần tra cứu nhanh, **Từ điển tích hợp** cho phép tìm kiếm song ngữ Nhật – Việt – Anh trên toàn bộ **7.811 từ vựng** và **2.383 chữ Kanji** trong cơ sở dữ liệu **SQLite Schema v3** mà không cần kết nối Internet."*

- **[Thao tác 2.2]:** Quay lại Trang chủ, mở phần **Từ vựng (`VocabularyScreen`)** rồi bấm vào **Học Flashcard (`FlashcardScreen`)** ở cấp độ N5.
  1. Bấm **biểu tượng Loa 🔊** để phát âm từ tiếng Nhật.
  2. Bấm vào giữa thẻ để **lật thẻ 3D (`flip_card`)** sang mặt sau (hiển thị nghĩa tiếng Việt + câu ví dụ).
  3. Bấm **biểu tượng Loa ở câu ví dụ** để đọc cả câu tiếng Nhật.
  4. Bấm nút **"Đã nhớ"** ở thẻ thứ nhất, sang thẻ thứ hai bấm **"Chưa nhớ"**.
- **[Lời thoại]:**
  > *"Tiếp theo là màn hình **Học thẻ từ Flashcard 3D**. Ở mặt trước là từ tiếng Nhật và cách đọc Hiragana kèm phát âm TTS. Khi em lật thẻ sang mặt sau, hệ thống hiển thị nghĩa **tiếng Việt** và **câu ví dụ song ngữ** được truy xuất từ SQLite v3. Với những từ ở cấp độ cao chưa có bản dịch tiếng Việt, lớp `ContentFallback` sẽ tự động hiển thị nghĩa tiếng Anh gốc nên giao diện không bao giờ bị trống dữ liệu.*
  > *Đặc biệt, bên dưới 2 nút **'Đã nhớ'** và **'Chưa nhớ'** là **thuật toán lặp lại ngắt quãng SM-2** trong `FlashcardProvider`:*
  > *- Nếu em bấm **'Đã nhớ'**, khoảng cách ngày ôn lại (`interval`) sẽ tăng dần từ **1 ngày → 3 ngày → nhân với hệ số dễ `easeFactor`** (tối đa `2.8`).*
  > *- Ngược lại, nếu bấm **'Chưa nhớ'**, chuỗi nhớ bị đưa về `0`, hệ số dễ giảm đi `0.2` và bắt buộc ôn lại vào ngày hôm sau.*
  > *- Khi bắt đầu bất kỳ phiên học nào, hàm `_priorityForWord` sẽ tự động đẩy các thẻ **đã đến hạn ôn (`isDue`)** và **các thẻ hay trả lời sai** lên đầu danh sách."*

---

## 🟢 CẢNH 3: NGỮ PHÁP, ĐỌC HIỂU CÓ FURIGANA & LUYỆN NGHE MP3 OFFLINE — *~1 phút 15 giây*

- **[Thao tác 3.1]:** Quay lại Trang chủ, bấm vào **Ngữ pháp (`GrammarScreen`)**, chọn 1 mẫu ngữ pháp N5 (ví dụ `〜は〜です`), mở xem chi tiết công thức, giải thích tiếng Việt và câu ví dụ.
- **[Lời thoại]:**
  > *"Ở phân hệ **Ngữ pháp**, toàn bộ **1.164 mẫu ngữ pháp** từ N5 đến N1 được trình bày rõ ràng gồm: cấu trúc ghép câu (`formation`), giải thích chi tiết bằng tiếng Việt và các câu ví dụ minh họa."*

- **[Thao tác 3.2]:** Quay ra mở **Đọc hiểu (`ReadScreen`)**. Chỉ chuột vào thanh lọc cấp độ (`Tất cả`, `N5`..`N1`, `Chưa phân cấp JLPT`). Chọn 1 bài đọc `N5`, mở chi tiết bài đọc:
  1. Bấm công tắc **Bật / Tắt Furigana** để Hội đồng thấy chữ Hiragana nhỏ hiện/ẩn phía trên chữ Kanji.
  2. Bấm tăng/giảm cỡ chữ và bấm nút nghe thử 1 câu trong bài, sau đó cuộn xuống xem bản dịch tiếng Việt.
- **[Lời thoại]:**
  > *"Tại phân hệ **Đọc hiểu**, ứng dụng có **40 bài đọc** (gồm 34 bài phân cấp JLPT và 6 tác phẩm văn học Aozora Bunko được tách riêng ở bộ lọc *Chưa phân cấp JLPT*). Khi vào bài đọc, người học có thể **bật/tắt phiên âm Furigana** ngay trên đầu chữ Kanji, điều chỉnh cỡ chữ, bấm nghe phát âm từng câu và đối chiếu bản dịch tiếng Việt bên dưới."*

- **[Thao tác 3.3]:** Quay ra mở **Luyện nghe (`ListeningPracticeScreen`)**, bấm nút **Play ▶️** để phát âm thanh MP3, mở xem lời thoại (`transcript`) và chọn thử 1 đáp án trắc nghiệm.
- **[Lời thoại]:**
  > *"Còn ở phân hệ **Luyện nghe**, hệ thống quản lý **308 bản ghi dữ liệu nghe**, trong đó đóng gói sẵn **30 tệp âm thanh MP3 khả dụng offline** ngay trong ứng dụng. Người học có thể nghe hội thoại, điều chỉnh tốc độ phát, xem lời thoại tiếng Nhật kèm Furigana và trả lời câu hỏi kiểm tra mức độ hiểu bài."*

---

## 🟢 CẢNH 4: BẢN ĐỒ THẾ GIỚI 5 CẤP ĐỘ (`WorldGateScreen` & `WorldRoadmapScreen`) & CƠ CHẾ 1–3 SAO — *~1 phút 30 giây*

- **[Thao tác 4.1]:** Từ Trang chủ, bấm vào thẻ **Từ vựng (hoặc Kanji)** để mở **Cổng 5 Thế giới (`WorldGateScreen`)**.
  1. Bấm chuyển đổi qua lại giữa 2 tab trên cùng: **Bản đồ Từ vựng ↔ Bản đồ Kanji**.
  2. Cuộn dọc qua 5 thẻ Thế giới: **Thế giới 1 (N5 – Đại dương huyền bí)**, **Thế giới 2 (N4 – Thành phố công nghệ)**, **Thế giới 3 (N3 – Du hành thế giới)**, **Thế giới 4 (N2 – Vũ trụ vô tận)**, **Thế giới 5 (N1 – Vương quốc thần tiên)**.
- **[Lời thoại]:**
  > *"Để việc học theo lộ trình không bị nhàm chán, nhóm đã xây dựng **Hệ thống Bản đồ 5 Thế giới** tương ứng với 5 cấp độ từ N5 đến N1, hỗ trợ cả **Bản đồ Từ vựng** và **Bản đồ Kanji**."*

- **[Thao tác 4.2]:** Bấm vào **Thế giới 1 (N5 – Đại dương huyền bí)**:
  1. Chỉ chuột vào hiệu ứng bong bóng nước chuyển động và **Tàu ngầm Mèo Hộ Pháp** đang bơi cạnh bệ đá màn chơi.
  2. Bấm vào **Node số 1 (Bài 1)** để mở bảng chi tiết màn chơi (`_LevelDetailSheet`).
  3. Chỉ vào 2 nút hành động: **`Học / Luyện tập (+5 Coin)`** và **`Kiểm tra vượt level · 10 câu`**.
- **[Lời thoại]:**
  > *"Khi bước vào một thế giới — ví dụ **Đại dương N5** — mỗi thế giới gồm **10 chặng (Node)** đặt trên các bệ đá ngôi sao cùng phương tiện di chuyển riêng của Mèo Hộ Pháp (như Tàu ngầm ở N5, Xe bay ở N4, Máy bay ở N3, Đĩa bay UFO ở N2 và Thuyền mây ở N1).*
  > *Khi bấm vào một chặng, người học có 2 bước:*
  > *1. **Học / Luyện tập:** Ôn bộ 12 từ vựng (hoặc 8 chữ Kanji) của chặng đó. Khi hoàn thành lần đầu tiên, người học nhận **`+5 Xu`**. Nếu học lại chặng này lần thứ hai, hệ thống kiểm tra tập `mapPracticeRewarded` và không cộng Xu lặp lại để chống cày tiền.*
  > *2. **Kiểm tra vượt level (10 câu hỏi):** Điểm số bài kiểm tra quyết định số sao qua hàm `starsForScore`:*
  >    *- Đúng **60% – 79% (6–7/10 câu)**: Đạt **1 Sao ⭐** — đủ điều kiện tối thiểu để mở khóa chặng tiếp theo;*
  >    *- Đúng **80% – 99% (8–9/10 câu)**: Đạt **2 Sao ⭐⭐**;*
  >    *- Đúng **100% (10/10 câu)**: Đạt **3 Sao ⭐⭐⭐** tuyệt đối.*
  >    *Hệ thống luôn bảo toàn kỷ lục số sao cao nhất mà người học từng đạt được ở mỗi chặng."*

---

## 🟢 CẢNH 5: LUYỆN ĐỀ THI THỬ JLPT N5–N1 (`JLPTScreen`) — *~1 phút*

- **[Thao tác 5.1]:** Đóng bản đồ, chuyển sang **Tab 2 trên thanh điều hướng đáy (`Luyện đề JLPT`)**.
  1. Bấm lướt qua các tab cấp độ `N5`, `N4`, `N3`, `N2`, `N1`.
  2. Chỉ chuột vào 3 chế độ luyện tập: **Làm cả đề**, **Luyện nhanh 10 câu**, **Ôn câu hay sai**.
  3. Bấm **Bắt đầu làm bài** ở đề N5 (hoặc chọn *Luyện nhanh 10 câu*).
  4. Chỉ vào đồng hồ đếm ngược góc trên bên phải và huy hiệu **`Im lặng`** (Mèo ngủ). Chọn nhanh đáp án các câu hỏi rồi bấm **Nộp bài** để mở hộp thoại **Kết quả & Xếp hạng (`_ResultDialog`)**, sau đó bấm **Xem lại bài & Giải thích đáp án**.
- **[Lời thoại]:**
  > *"Sau khi tích lũy kiến thức trên Bản đồ, người học chuyển sang **Tab 2 – Luyện đề JLPT**. Ứng dụng cung cấp **5 bộ đề chuẩn từ N5 đến N1** cùng 3 chế độ: làm cả đề tính giờ, luyện nhanh 10 câu ngẫu nhiên, hoặc ôn tập lại các câu hay làm sai.*
  > *Trong phòng thi, chú mèo tự động chuyển sang chế độ **'Im lặng'** ở góc trên để không làm phân tâm thí sinh. Khi nộp bài, hệ thống tự động chấm điểm, xếp hạng từ **S, A, B, C đến F**, thưởng **Xu và Đá quý (Gems)** theo cấp độ đề (từ 15 Xu ở N5 lên tới 40 Xu và 5 Gems ở N1), lưu lịch sử vào bảng `test_history` và cho phép xem lại lời giải chi tiết từng câu."*

---

## 🟣 CẢNH 6: ĐỒNG HỒ POMODORO & CƠ CHẾ ANTI-CHEAT PHẠT `-50 XU` (`PomodoroProvider`) — *~1 phút*

- **[Thao tác 6.1]:** Quay về **Tab 1 (`Trang chủ`)**, cuộn xuống thẻ **Đồng hồ Pomodoro**.
  1. Chỉ chuột vào các nút chọn thời lượng học (`15`, `25`, `45`, `60` phút) và thời gian nghỉ.
  2. Bấm nút **Bắt đầu (`Start`)** phiên học:
     - Chỉ chuột vào chú **Mèo Hộ Pháp** lập tức chuyển sang hoạt ảnh **ngồi học bài (`studying`)** và hiện bong bóng thoại: *"Trẫm đã khóa trạng thái học tập! Con sen cấm thoát app kẻo bay 50 Xu đấy!"*.
  3. Bấm **Tạm dừng (`Pause`)** (chú mèo chuyển sang trạng thái chờ `paused`).
  4. Bấm nút **Kết thúc / Hủy phiên sớm** khi chưa hết giờ $\rightarrow$ Chỉ chuột vào **Banner cảnh báo màu đỏ** và bong bóng thoại mèo thông báo **phạt `-50 Xu`**.
- **[Lời thoại]:**
  > *"Để rèn luyện kỷ luật tập trung, nhóm tích hợp **Đồng hồ Pomodoro thông minh** gắn liền với thể lực của Mèo Hộ Pháp.*
  > *- Trước khi bắt đầu, hệ thống kiểm tra năng lượng mèo phải đạt từ **20% trở lên**. Khi em bấm **Bắt đầu**, đồng hồ tính giờ theo mốc thời gian thực (`wall-clock`), và chú mèo lập tức chuyển sang trạng thái ngồi học cùng người dùng.*
  > *- Khi hoàn thành trọn vẹn phiên học, mỗi phút học sẽ tiêu hao **1% năng lượng của mèo**, đổi lại người học nhận được **Xu và EXP** tương ứng với số phút học.*
  > *- Ngược lại, nếu đang trong phiên học mà người dùng thu nhỏ ứng dụng xuống chạy ngầm, tắt ứng dụng đột ngột hoặc bấm hủy phiên sớm như em vừa thao tác, cơ chế **Anti-Cheat** trong `PomodoroProvider` sẽ lập tức bắt lỗi và **trừ phạt 50 Xu**."*

---

## 🟣 CẢNH 7: PHÒNG MÈO HỘ PHÁP (`GuardianCatScreen`), SHOP VẬT PHẨM & 6 COZY THEMES — *~1 phút 15 giây*

- **[Thao tác 7.1]:** Chuyển sang **Tab 4 (`Phòng Mèo – GuardianCatScreen`)**.
  1. Chỉ chuột vào 3 thanh chỉ số của mèo ở phía trên: **Độ no (`Hunger`)**, **Năng lượng (`Energy`)** và **Tâm trạng (`Mood`)**.
  2. **Kéo-thả chú mèo** đặt thử lên **Giường ngủ**, **Bàn học**, **Ghế Sofa** hoặc **Thảm** (10 vị trí nội thất trong phòng).
  3. Mở ngăn **Đồ ăn (`36 món ăn` chia 3 tab: Trái cây, Món chính, Hải sản)** $\rightarrow$ bấm cho mèo ăn 1 món (ví dụ *Cá hồi* hoặc *Dâu tây*) $\rightarrow$ chỉ vào hiệu ứng cộng chỉ số năng lượng và bong bóng thoại song ngữ Nhật–Việt tự ẩn sau 5 giây.
  4. Mở ngăn **Nhân vật (`24 chú mèo`)** và **Trang phục (`32 phụ kiện`)** $\rightarrow$ bấm đổi thử sang 1 nhân vật mèo khác và mặc thử 1 trang phục.
- **[Lời thoại]:**
  > *"Khi chú mèo bị giảm năng lượng sau các phiên học Pomodoro hoặc làm đề thi, người học sẽ vào **Tab 4 – Phòng Mèo Hộ Pháp**. Tại đây tạo thành một vòng lặp tạo động lực khép kín:*
  > *- Người học dùng **Xu và Gems** kiếm được từ việc học bài để mua sắm trong cửa hàng gồm **24 nhân vật mèo** (16 mèo mở bằng Xu, 7 mèo hiếm mở bằng Gems), **36 món ăn** và **32 bộ trang phục**.*
  > *- Khi em cho mèo ăn, chỉ số **Độ no, Tâm trạng và Năng lượng** được hồi phục ngay lập tức để sẵn sàng cho phiên học tiếp theo, đồng thời mèo sẽ trò chuyện bằng các câu thoại song ngữ Nhật – Việt vui nhộn. Chúng ta cũng có thể kéo thả mèo tương tác với **10 vị trí nội thất** trong căn phòng."*

- **[Thao tác 7.2]:** Từ góc trên Trang chủ (hoặc Cài đặt), mở **Màn hình Hồ sơ & Cài đặt (`ProfileScreen`)**:
  1. Lướt qua biểu đồ thống kê học tập (`fl_chart`), danh hiệu và ảnh đại diện.
  2. Tại mục **Chủ đề Giao diện (Cozy Themes)**, bấm đổi trực tiếp qua 2–3 bảng màu (ví dụ từ *Dusty Rose & Matcha* sang *Ocean Blue*, *Cyber Midnight* hoặc *Royal Golden Palace*) và bật thử *Dark Mode*.
- **[Lời thoại]:**
  > *"Bên cạnh việc chăm mèo, trong màn hình **Hồ sơ & Cài đặt**, người học có thể xem biểu đồ thống kê tiến độ và cá nhân hóa không gian học với **6 bảng màu Cozy Themes** cùng chế độ **Dark Mode**. Khi em bấm chọn chủ đề mới, `ThemeRefreshScope` sẽ đồng bộ màu sắc tức thời trên toàn bộ ứng dụng."*

---

## 🟣 CẢNH 8: BẢNG XẾP HẠNG & ĐẤU TRƯỜNG MÈO NỔ PK 4×4 (`PKBattleScreen`) — *~1 phút 15 giây*

- **[Thao tác 8.1]:** Chuyển sang **Tab 3 (`Bảng xếp hạng & PK`)**:
  1. Bấm chuyển thử giữa 2 tab xếp hạng: **Học tập (Streak/XP)** và **Mèo Nổ PK (Điểm MR)**.
  2. Bấm vào nút **Đấu Trường Mèo Nổ PK** để vào Sảnh chờ (`PKLobbyScreen`).
  3. Chỉ chuột vào bảng **8 bậc Rank MR** (từ *Mèo Tập Sự* đến *Thần Mèo Đại Chiến*), chọn cấp độ câu hỏi `N5` và chọn chế độ **Đấu Hạng MR** $\rightarrow$ bấm **Bắt đầu trận đấu**.
- **[Lời thoại]:**
  > *"Cuối cùng là **Tab 3 – Bảng xếp hạng và Đấu trường Mèo Nổ PK**. Tại Sảnh chờ PK, người học có thể chọn cấp độ câu hỏi từ N5 đến N1 và tham gia 3 chế độ: **Solo AI**, **PK Thường** và **Đấu Hạng MR** với **8 bậc danh hiệu** (Thắng cộng `+20 MR`, thoát giữa trận hoặc thua hạng bị trừ `-15 MR`). Như em đã báo cáo trên slide, hiện tại đối thủ trong trận đấu đang được vận hành bởi **Bot AI cục bộ** có tỷ lệ trả lời đúng từ 65% đến 78% tùy chế độ."*

- **[Thao tác 8.2]:** Trong màn hình trận đấu (`PKBattleScreen`):
  1. Ngay đầu lượt của người chơi, hộp câu hỏi tiếng Nhật hiện lên với đồng hồ đếm ngược **15 giây** $\rightarrow$ bấm chọn đáp án đúng $\rightarrow$ chỉ chuột vào biểu tượng **Khiên Bảo Hộ 🛡️ (`1/1`)** vừa sáng lên.
  2. Trên bàn cờ **4×4 gồm 16 lá bài** đang úp: bấm lật 1 lá bài $\rightarrow$ quan sát kết quả (Mèo An Toàn cộng điểm hoặc trúng Mèo Nổ thì vỡ Khiên và xáo trộn lại bài) và xem lượt lật bài của Bot AI.
- **[Lời thoại]:**
  > *"Khi bước vào bàn đấu **lưới 4×4 gồm 16 lá bài**, bên dưới có **14 lá Mèo An Toàn** và ẩn giấu **2 lá Mèo Nổ**.*
  > *- Ở đầu mỗi lượt, em có **15 giây** để trả lời một câu hỏi tiếng Nhật. Khi trả lời đúng như vừa rồi, em nhận được **1 Khiên Bảo Hộ**.*
  > *- Sau đó em chọn lật 1 lá bài trên bàn: nếu lật được **Mèo An Toàn** sẽ được cộng điểm; còn nếu chẳng may lật trúng **Mèo Nổ**, chiếc **Khiên Bảo Hộ** sẽ tự động vỡ để cứu mạng người chơi và xáo trộn lá Mèo Nổ đó sang một vị trí ngẫu nhiên khác trong các ô đang úp. Cơ chế này giúp người học vừa giải trí vừa rèn phản xạ từ vựng, chữ Hán cực kỳ nhanh dưới áp lực thời gian 15 giây."*

---

## 🎯 KẾT THÚC PHẦN LIVE DEMO & QUAY LẠI SLIDE 14 (15 GIÂY)

- **[Thao tác]:** Nhấn `Alt + Tab` quay lại **Slide 14 (Kết luận)** trên PowerPoint.
- **[Lời thoại]:**
  > *"Dạ trên đây là toàn bộ phần trình diễn trực tiếp các tính năng của ứng dụng **Nihongo Master**. Để khép lại bài báo cáo, ở Slide 14 là 6 kết quả trọng tâm mà đề tài đã hoàn thành. Em xin trân trọng cảm ơn Thầy/Cô trong Hội đồng và các bạn đã chú ý theo dõi, em rất mong nhận được các câu hỏi và ý kiến đóng góp từ Hội đồng ạ!"*
