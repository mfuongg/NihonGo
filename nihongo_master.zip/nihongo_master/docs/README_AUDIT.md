# BÁO CÁO KIỂM TOÁN & ĐỐI CHIẾU TÀI LIỆU (`docs/README_AUDIT.md`)

Tài liệu này ghi nhận kết quả khảo sát thực tế mã nguồn repository **NihonGo Master** (`nihongo_master/`) để đối chiếu và cập nhật [`README.md`](../README.md), tuân thủ nguyên tắc **chỉ ghi nhận sự thật từ mã nguồn, database, dataset và kết quả kiểm thử thực tế**.

---

## 1. Những nội dung trong `README.md` cũ đã lỗi thời và được cập nhật

| Nội dung trong `README.md` cũ (67 dòng) | Thực tế trong mã nguồn hiện tại | Cách cập nhật trong `README.md` mới |
|---|---|---|
| Cấu trúc thư mục chỉ liệt kê `auth/`, `vocabulary/`, `jlpt/`, `progress/`. | Dự án hiện có **16 phân hệ màn hình** (`admin`, `auth`, `cat`, `dictionary`, `grammar`, `home`, `jlpt`, `kana`, `kanji`, `leaderboard`, `map`, `onboarding`, `pk`, `profile`, `progress`, `read`, `settings`, `shell`, `vocabulary`), **8 Providers**, **12 Models**, **12 Services**. | Cập nhật cây thư mục thực tế đầy đủ và sơ đồ kiến trúc Mermaid. |
| Ghi hướng dẫn: *"Mở `lib/firebase_options.dart`, đặt `configured = true`"*. | `lib/firebase_options.dart` không còn biến `configured`; dự án đã cấu hình sẵn `DefaultFirebaseOptions` cho Web, Android, iOS, macOS (`projectId: apptiengnhat-d12b7`) và quản lý qua `FirebaseService.initialize()`. | Cập nhật lại mô tả cơ chế `FirebaseService` + tự động fallback offline. |
| Ghi chú: *"Nếu bạn build trên Chrome nhưng project chưa cấu hình web thì sẽ lỗi"*. | Dự án đã có thư mục `web/`, cấu hình Firebase Web và lớp `WebDatasetBootstrap` (`lib/utils/web_dataset_bootstrap.dart`) nạp trực tiếp JSON khi `kIsWeb == true`. | Bổ sung hướng dẫn chạy trên cả **Android**, **Web (Chrome/Edge)** và **Windows Desktop**. |
| Ghi *"Đăng nhập Google, Facebook"* như tính năng đã hoàn chỉnh. | `AuthService` (`lib/services/auth_service.dart`) đã triển khai Email/Password, Email Link, Google Sign-In và tài khoản Dev Admin, nhưng **chưa có hàm xử lý đăng nhập Facebook** (dù `pubspec.yaml` có khai báo `flutter_facebook_auth`). | Phân loại rõ: Email/Password, Email Link, Google Sign-In, Dev Admin đã có; Facebook Login là dependency chưa nối luồng xử lý. |
| Chỉ nhắc sơ lược *"Cache dữ liệu từ vựng offline bằng SQLite"*. | Hệ thống hiện dùng **SQLite Schema v3 (`nihongo_master.db`)** gồm **16 bảng** với cơ chế import theo lô `chunkSize = 500` và đồng bộ bản dịch không phá hủy (`syncTranslationsFromAssets()`). | Bổ sung mục riêng về kiến trúc SQLite v3 và bảng thống kê chi tiết toàn bộ dataset `verified_v2`. |
| Hoàn toàn chưa đề cập đến các phân hệ mới. | Đã có **Bản đồ Thế giới 5 cấp độ N5–N1**, **Đồng hồ Pomodoro Anti-Cheat**, **Mèo Hộ Pháp đồng hành trên mép thẻ (`LineCompanionCat`)**, **Phòng Mèo (`GuardianCatScreen`)**, **Đấu trường Mèo Nổ PK 4×4**, **6 Cozy Themes** và **Admin God-Mode**. | Bổ sung đầy đủ thông số kỹ thuật, trạng thái xác minh và kịch bản thuyết trình demo cho từng tính năng. |

---

## 2. Những thông tin và số liệu mới đã được xác minh từ mã nguồn & dữ liệu

1. **Dataset chuẩn hóa `assets/data/verified_v2/`:**
   - `vocabularies.json`: **7.811** từ vựng (đã dịch tiếng Việt **320** từ: 120 N5, 50 N4, 50 N3, 50 N2, 50 N1).
   - `kanji_entries.json`: **2.383** chữ Kanji (đã dịch tiếng Việt **60** chữ: 20 N5, 10 N4, 10 N3, 10 N2, 10 N1).
   - `grammar_points.json`: **1.164** mẫu ngữ pháp (đã dịch tiếng Việt **50** mẫu: 10 N5, 10 N4, 10 N3, 10 N2, 10 N1).
   - `reading_materials.json`: **40** bài đọc hiểu (đã dịch tiếng Việt **31** bài: 5/8 N5, 8/8 N4, 8/8 N3, 10/10 N2; 0 bài N1 do dữ liệu gốc không có N1; 6 bài Aozora Bunko có `original_level = null`).
   - `example_sentences.json`: **16.691** câu ví dụ (đã dịch tiếng Việt **703** câu liên kết: 235 N5, 122 N4, 122 N3, 114 N2, 110 N1).
   - `p6_listening_materials.json` & `p6_transcripts.json`: **308** bản ghi, kèm **30 file `.mp3` khả dụng offline** trong `assets/listening/` và **30 câu hỏi** trong `listening_questions.json`.
   - `p6_exams.json`, `p6_questions.json`, `p6_answers.json`: **5 đề luyện JLPT** (N5: 15 câu, N4: 36 câu, N3: 34 câu, N2: 42 câu, N1: 19 câu — tổng 146 câu đề JLPT + 30 câu nghe = **176 câu hỏi**, **704 đáp án**).
2. **Hệ thống Mèo Hộ Pháp & Phòng Mèo (`GuardianCatScreen` & `LineCompanionCat`):**
   - **24 nhân vật mèo** (1 mèo mặc định *Chiến Thần Hào Quang*, 16 mèo Phổ Thông mua bằng Xu `200–500 Xu`, 7 mèo Hiếm/Thần Thoại mua bằng Gem `40–100 Gems`).
   - **36 món ăn** chia làm 3 nhóm: Trái cây (12), Món chính (12), Hải sản thượng hạng (12).
   - **32 trang phục** và **10 vị trí nội thất** trên `assets/room.png`.
3. **Đồng hồ Pomodoro Anti-Cheat (`PomodoroProvider`):**
   - Phạt **`-50 Xu`** khi rời ứng dụng hoặc hủy phiên học sớm.
   - Tiêu hao **`-1%` năng lượng mèo** mỗi phút học hoàn thành; yêu cầu năng lượng mèo `>= 20%` để bắt đầu.
4. **Đấu trường Mèo Nổ PK (`PKLobbyScreen`, `PKBattleScreen`, `pk_models.dart`):**
   - Lưới **4×4 = 16 lá** (14 Mèo An Toàn + 2 Mèo Nổ), câu hỏi tiếng Nhật **15 giây/lượt**, cơ chế **Khiên Bảo Hộ 🛡️** (tối đa 1 Khiên) đỡ Mèo Nổ và xáo bài.
   - **8 bậc Rank** theo điểm Match Rating (MR) từ *Mèo Tập Sự (0–199 MR)* đến *Thần Mèo Đại Chiến (2000+ MR)*.
5. **Kết quả kiểm thử thực tế:**
   - `flutter analyze`: **0 errors, 0 warnings**.
   - 8 file test chuyên biệt (`n5_vietnamese_sync_verification_test.dart`, `n4_n1_translation_verification_test.dart`, `translation_migration_test.dart`, `pomodoro_provider_test.dart`, `cat_position_manager_test.dart`, `line_companion_cat_test.dart`, `theme_sync_test.dart`, `navigation_back_button_test.dart`): **57 / 57 bài test PASS (100%)**.
   - `test/widget_test.dart`: **17 / 19 bài test PASS** (2 bài test cũ #5 và #9 viết trước khi dịch tiếng Việt nên kỳ vọng số từ vựng có `meaning_vi` là `0` và từ `両親` có `meaning_vi == null`).
   - Python unit tests (`tools/tests/test_auto_translate.py`): **9 / 9 PASS (100%)**.

---

## 3. Các chức năng chưa xác minh / đang giả lập cục bộ

1. **Ghép trận trực tuyến (Real-time Multiplayer) trong Mèo Nổ PK:** Hiện cả 3 chế độ (*Solo AI*, *PK Thường*, *Đấu Hạng MR*) đều vận hành với Bot AI cục bộ trong `PKBattleScreen`, chưa có kết nối thời gian thực giữa 2 máy người chơi.
2. **Bảng xếp hạng trực tuyến (`LeaderboardScreen`):** Hiện xếp hạng người dùng thực tế cùng danh sách học viên mẫu được khởi tạo cục bộ, chưa đồng bộ danh sách toàn cầu từ Firestore.
3. **Đăng nhập Facebook:** Chưa được triển khai trong `AuthService`.
4. **Nhận diện chữ viết tay OCR (`google_mlkit_text_recognition`) & Nhận diện giọng nói (`speech_to_text`) trên thiết bị thật:** Đã xác minh mã nguồn và bộ chấm điểm `AiPracticeEvaluator`, nhưng độ chính xác thực tế phụ thuộc vào phần cứng micro và Google Play Services trên thiết bị Android/iOS vật lý.

---

## 4. Những thông tin cần người dùng bổ sung

- **Thông tin thành viên nhóm phát triển (Mục 16 trong `README.md`):** Họ và tên, Mã số sinh viên, Lớp học phần và Giảng viên hướng dẫn (do không có trong mã nguồn).
- **Liên kết video demo hoặc slide thuyết trình** (nếu muốn đính kèm vào đầu `README.md`).

---

## 5. Danh mục các file nguồn quan trọng nhất để tra cứu nhanh

- **Khởi tạo & Điều hướng chính:** [`lib/main.dart`](../lib/main.dart), [`lib/screens/shell/main_shell.dart`](../lib/screens/shell/main_shell.dart), [`lib/screens/home/home_screen.dart`](../lib/screens/home/home_screen.dart)
- **Database SQLite v3 & Đồng bộ dữ liệu:** [`lib/services/local_database_service.dart`](../lib/services/local_database_service.dart), [`lib/utils/web_dataset_bootstrap.dart`](../lib/utils/web_dataset_bootstrap.dart), [`lib/utils/content_fallback.dart`](../lib/utils/content_fallback.dart)
- **Bản đồ Thế giới 5 Cấp độ (N5–N1):** [`lib/screens/map/world_map_screen.dart`](../lib/screens/map/world_map_screen.dart), [`lib/screens/map/map_level_catalog.dart`](../lib/screens/map/map_level_catalog.dart)
- **Mèo Hộ Pháp & Pomodoro Anti-Cheat:** [`lib/widgets/line_companion_cat.dart`](../lib/widgets/line_companion_cat.dart), [`lib/services/cat_position_manager.dart`](../lib/services/cat_position_manager.dart), [`lib/screens/cat/guardian_cat_screen.dart`](../lib/screens/cat/guardian_cat_screen.dart), [`lib/providers/pomodoro_provider.dart`](../lib/providers/pomodoro_provider.dart)
- **Đấu trường Mèo Nổ PK 4×4:** [`lib/screens/pk/pk_lobby_screen.dart`](../lib/screens/pk/pk_lobby_screen.dart), [`lib/screens/pk/pk_battle_screen.dart`](../lib/screens/pk/pk_battle_screen.dart), [`lib/screens/pk/pk_models.dart`](../lib/screens/pk/pk_models.dart), [`lib/screens/pk/pk_result_screen.dart`](../lib/screens/pk/pk_result_screen.dart)
- **Giao diện Cozy Themes & Admin Dev Mode:** [`lib/utils/theme.dart`](../lib/utils/theme.dart), [`lib/theme/cozy_palette.dart`](../lib/theme/cozy_palette.dart), [`lib/screens/admin/admin_tools_screen.dart`](../lib/screens/admin/admin_tools_screen.dart)
- **Pipeline dịch dữ liệu Python:** [`tools/auto_translate_dataset.py`](../tools/auto_translate_dataset.py)
