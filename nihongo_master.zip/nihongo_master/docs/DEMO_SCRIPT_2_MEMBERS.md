# 🎙️ KỊCH BẢN THUYẾT TRÌNH & LIVE DEMO NHÓM 2 NGƯỜI — NIHONGO MASTER

> **Đề tài:** Nihongo Master – Ứng dụng học tiếng Nhật kết hợp Gamification  
> **Học phần:** Đồ án liên ngành – Trường Đại học Phenikaa (Năm 2026)  
> **File Slide đi kèm:** `Nihongo_Master_Presentation_Phenikaa.pptx` (14 Slides)  
> **Tổng thời lượng đề xuất:** **12 – 15 phút** *(~7 phút trình bày Slide + ~5–6 phút Live Demo trực tiếp)*

---

## 1. PHÂN CÔNG VAI TRÒ 2 THÀNH VIÊN (ĐỐI XỨNG & ĂN Ý)

Để Hội đồng chấm đồ án đánh giá cao sự đóng góp đồng đều của cả 2 thành viên, kịch bản áp dụng nguyên tắc **"1 người nói – 1 người điều khiển máy, sau đó đổi vai"**:

| Thành viên | Phần thuyết trình Slide | Phần Live Demo (Slide 13) | Thế mạnh phụ trách khi trả lời Q&A |
|---|---|---|---|
| **Thành viên 1 (TV1)** | **Slide 01 → Slide 07**<br>*(Mở đầu, Tổng quan, Bài toán – Giải pháp, Công nghệ, Kiến trúc, Database & Dataset, Chức năng học tập)* | **Thuyết minh Bước 1 → Bước 3** *(Trang chủ, Học Từ vựng/Kanji/Nghe/Đọc, Bản đồ JLPT & Luyện đề)* — **TV2** thao tác chuột.<br>Sau đó **TV1** cầm chuột thao tác Bước 4 → 6 cho **TV2** nói. | Kiến trúc MVVM-lite, SQLite Schema v3 (16 bảng), Batch Import `chunkSize = 500`, Pipeline dịch Gemini Python, Thuật toán Flashcard SM-2. |
| **Thành viên 2 (TV2)** | **Slide 08 → Slide 12 & Slide 14**<br>*(Gamification, Đấu trường Mèo Nổ PK, Giao diện, Kiểm thử, Hạn chế – Hướng phát triển, Kết luận)* | **Thao tác máy Bước 1 → Bước 3** cho **TV1** nói.<br>Sau đó **Thuyết minh Bước 4 → Bước 6** *(Pomodoro Anti-Cheat, Phòng Mèo & Cozy Theme, Đấu trường Mèo Nổ PK 4×4)* — **TV1** thao tác chuột. | Cơ chế Gamification, Tọa độ mèo `LineCompanionCat` & `CatPositionManager`, Pomodoro Anti-Cheat (`-50 Xu`), Logic bàn đấu PK 4×4, Kết quả Unit/Widget Tests. |

---

## 2. CHECKLIST CHUẨN BỊ TRƯỚC KHI LÊN BỤC BẢO VỆ (5 PHÚT TRƯỚC GIỜ G)

1. **Mở sẵn 2 cửa sổ song song (`Alt + Tab` mượt mà):**
   - **Cửa sổ 1:** PowerPoint `Nihongo_Master_Presentation_Phenikaa.pptx` ở chế độ trình chiếu (`F5`).
   - **Cửa sổ 2:** Ứng dụng **Nihongo Master** đang chạy sẵn trên **Windows Desktop** (hoặc máy ảo Android) ở màn hình **Trang chủ (`HomeScreen`)**.
2. **Tài khoản khuyên dùng khi Demo:**
   - Đăng nhập sẵn hoặc bật **Admin Dev Mode (`AdminToolsScreen`)** với tài khoản:
     - **Email:** `admin.nihongomaster@example.com`
     - **Mật khẩu:** `Admin@2026`
   - *Lý do:* Tài khoản Admin đã mở khóa sẵn toàn bộ **5 Thế giới Bản đồ (N5–N1)**, **24 nhân vật mèo**, **36 món ăn**, **32 trang phục**, **6 Cozy Themes**, cùng **`999.999 Xu`** và **`99.999 Gems`** để không bị chặn bởi điều kiện thiếu tiền/thiếu cấp độ khi Hội đồng yêu cầu bấm thử bất kỳ tính năng nào.
3. **Kiểm tra âm thanh máy tính:**
   - Bật loa ở mức vừa phải (`40% – 50%`) để khi bấm nút loa **TTS phát âm tiếng Nhật** hoặc phát **file nghe MP3**, Hội đồng nghe rõ tiếng Nhật.

---

## 3. KỊCH BẢN LỜI THOẠI CHI TIẾT THEO TỪNG SLIDE (PHẦN 1: SLIDE 01 → 12)

### 🟢 PHẦN CỦA THÀNH VIÊN 1 (SLIDE 01 → SLIDE 07) — *Thời lượng: ~3,5 phút*

#### **SLIDE 01 – TRANG BÌA** *(0:00 – 0:30)*
- **[Hành động]:** Cả 2 thành viên đứng nghiêm trang chào Hội đồng. TV2 đứng cạnh máy tính điều khiển slide.
- **[Lời thoại TV1]:**
  > *"Kính chào Thầy/Cô trong Hội đồng chấm đồ án và các bạn sinh viên. Nhóm chúng em gồm 2 thành viên là **[Tên TV1]** và **[Tên TV2]**. Hôm nay, nhóm xin trình bày báo cáo Đồ án liên ngành với đề tài: **Nihongo Master – Ứng dụng học tiếng Nhật kết hợp Gamification**."*

#### **SLIDE 02 – TỔNG QUAN ĐỀ TÀI** *(0:30 – 1:00)*
- **[Lời thoại TV1]:**
  > *"Thưa Thầy/Cô, **Nihongo Master** là ứng dụng học tiếng Nhật đa nền tảng phát triển bằng **Flutter**, kết hợp hệ thống học liệu chuẩn **JLPT từ N5 đến N1** với cơ chế trò chơi hóa (**Gamification**). Đề tài tập trung vào 4 mục tiêu chính:*
  > *1. Hỗ trợ lộ trình học bài bản theo 5 cấp độ **JLPT N5–N1**;*
  > *2. Tích hợp đầy đủ các kỹ năng: **Từ vựng, Kanji, Ngữ pháp, Đọc hiểu và Luyện nghe**;*
  > *3. Theo dõi tiến độ học tập thông qua ôn tập ngắt quãng **SM-2** và thống kê trực quan;*
  > *4. Tăng động lực tự học mỗi ngày thông qua thú cưng **Mèo Hộ Pháp** và các trò chơi tương tác."*

#### **SLIDE 03 – BÀI TOÁN VÀ GIẢI PHÁP** *(1:00 – 1:30)*
- **[Lời thoại TV1]:**
  > *"Xuất phát từ thực tế tự học tiếng Nhật, người học thường gặp 4 rào cản lớn: khó duy trì động lực lâu dài; khối lượng chữ Hán và từ vựng đồ sộ; thiếu công cụ theo dõi lịch ôn tập trực quan; và giao diện học truyền thống khá khô khan.*
  > *Để giải quyết bài toán này, **Nihongo Master** đối ứng bằng 4 giải pháp: phân nhỏ nội dung theo cấp độ JLPT; xây dựng hệ thống luyện tập đa dạng; tích hợp thú cưng đồng hành cùng phần thưởng **Xu, Gems, XP**; và quản lý kỷ luật học tập bằng đồng hồ **Pomodoro**."*

#### **SLIDE 04 – CÔNG NGHỆ SỬ DỤNG** *(1:30 – 2:00)*
- **[Lời thoại TV1]:**
  > *"Về công nghệ, nhóm sử dụng **Flutter** và ngôn ngữ **Dart** làm nền tảng cốt lõi, kết hợp quản lý trạng thái bằng **Provider**.*
  > *Dữ liệu học tập được đóng gói dưới dạng **JSON chuẩn hóa** và lưu trữ cục bộ trên **SQLite (sqflite)** giúp ứng dụng hoạt động **Offline-First**, đồng thời kết nối **Firebase** để hỗ trợ xác thực người dùng. Ngoài ra, nhóm xây dựng pipeline bằng **Python** kết nối Gemini API để Việt hóa học liệu tự động và an toàn. Ứng dụng hỗ trợ chạy trên **Android, Web và Windows Desktop**."*

#### **SLIDE 05 – KIẾN TRÚC HỆ THỐNG** *(2:00 – 2:30)*
- **[Lời thoại TV1]:**
  > *"Trên Slide 5 là kiến trúc phân tầng của hệ thống theo luồng: từ **Người dùng** tương tác với tầng **Flutter UI**, đi qua **8 Providers** quản lý trạng thái, gọi xuống tầng **Services** xử lý nghiệp vụ như cơ sở dữ liệu, phát âm TTS, nhạc nền và chấm điểm, cuối cùng truy xuất dữ liệu từ **SQLite cục bộ, JSON Assets và Firebase**."*

#### **SLIDE 06 – CƠ SỞ DỮ LIỆU VÀ DATASET** *(2:30 – 3:05)*
- **[Lời thoại TV1]:**
  > *"Điểm nhấn kỹ thuật quan trọng của dự án là cơ sở dữ liệu **SQLite Schema v3 gồm 16 bảng** nạp dữ liệu theo lô 500 bản ghi. Quy mô dataset thực tế gồm:*
  > *- **7.811 từ vựng**, **2.383 chữ Kanji**, **1.164 mẫu ngữ pháp** và **16.691 câu ví dụ**;*
  > *- **40 bài đọc hiểu** và **308 bản ghi dữ liệu nghe**, trong đó có **30 tệp âm thanh MP3 khả dụng offline** ngay trong ứng dụng;*
  > *- Cùng **5 bộ đề luyện JLPT** với tổng cộng **176 câu hỏi** và **704 đáp án**.*
  > *Nhóm đã Việt hóa và đồng bộ vào SQLite **1.164 bản ghi** trải đều từ N5 đến N1; các mục còn lại sử dụng cơ chế `ContentFallback` tự động hiển thị tiếng Anh nên không bao giờ xảy ra lỗi trống nghĩa."*

#### **SLIDE 07 – CHỨC NĂNG HỌC TẬP** *(3:05 – 3:35)*
- **[Lời thoại TV1]:**
  > *"Từ nguồn dữ liệu trên, ứng dụng cung cấp 7 phân hệ học tập: **Bảng chữ cái Kana**, **Từ vựng Flashcard SM-2**, **Chữ Hán Kanji**, **Ngữ pháp**, **Đọc hiểu có bật/tắt Furigana**, **Luyện nghe offline có transcript**, và **Luyện đề / Bản đồ JLPT N5–N1**.*
  > *Tiếp theo, em xin nhường lời cho bạn **[Tên TV2]** trình bày về hệ sinh thái Gamification, kết quả kiểm thử và phần Demo thực tế."*

---

### 🟣 PHẦN CỦA THÀNH VIÊN 2 (SLIDE 08 → SLIDE 12) — *Thời lượng: ~3,5 phút*

#### **SLIDE 08 – HỆ SINH THÁI GAMIFICATION** *(3:35 – 4:15)*
- **[Hành động]:** TV1 chuyển sang đứng cạnh máy tính điều khiển slide cho TV2 trình bày.
- **[Lời thoại TV2]:**
  > *"Em xin cảm ơn bạn **[Tên TV1]**. Kính thưa Thầy/Cô, để biến việc học tiếng Nhật thành thói quen hằng ngày, nhóm đã xây dựng hệ sinh thái **Gamification Cozy** gồm 6 thành phần:*
  > *- Hệ thống **24 nhân vật Mèo Hộ Pháp**, **36 món ăn** hồi năng lượng, **32 trang phục** và **10 vị trí nội thất** trong phòng;*
  > *- Đặc biệt, chú mèo không chỉ ở trong phòng mà còn **đứng và đi lại trực tiếp trên mép các thẻ giao diện** ở mọi màn hình chính;*
  > *- Kết hợp với **6 bảng màu Cozy Themes** và hệ thống tiền tệ **Xu, Gems** gắn liền với đồng hồ **Pomodoro Anti-Cheat**."*

#### **SLIDE 09 – ĐẤU TRƯỜNG MÈO NỔ PK** *(4:15 – 4:55)*
- **[Lời thoại TV2]:**
  > *"Bên cạnh việc học cá nhân, nhóm thiết kế **Đấu trường Mèo Nổ PK** trên bàn cờ **4×4 gồm 16 lá bài**, trong đó có **14 lá Mèo An Toàn** và **2 lá Mèo Nổ**.*
  > *Đầu mỗi lượt, người chơi có **15 giây** để trả lời một câu hỏi tiếng Nhật. Nếu trả lời đúng sẽ nhận được **Khiên Bảo Hộ** giúp đỡ 1 lần lật trúng Mèo Nổ và xáo trộn lại bài. Hệ thống có 3 chế độ: **Solo AI, PK Thường và Đấu Hạng MR** với **8 bậc Rank**.*
  > *Nhóm cũng xin báo cáo trung thực theo đúng hiện trạng mã nguồn: hiện tại các chế độ này đang vận hành với **Bot AI cục bộ** mô phỏng đối thủ theo bậc Rank, chưa có kết nối Multiplayer thời gian thực giữa hai người chơi."*

#### **SLIDE 10 – GIAO DIỆN ỨNG DỤNG** *(4:55 – 5:15)*
- **[Lời thoại TV2]:**
  > *"Slide 10 tổng hợp 6 màn hình giao diện tiêu biểu của ứng dụng gồm: **Trang chủ, Từ vựng, Kanji, Bản đồ JLPT, Phòng Mèo và Đấu trường PK**, lát nữa nhóm sẽ trình diễn trực tiếp ngay trên ứng dụng."*

#### **SLIDE 11 – KẾT QUẢ KIỂM THỬ HỆ THỐNG** *(5:15 – 5:55)*
- **[Lời thoại TV2]:**
  > *"Về đảm bảo chất lượng phần mềm, nhóm đã thực hiện kiểm thử tự động trên toàn bộ dự án với kết quả thực tế như sau:*
  > *- **Flutter Analyze** đạt **0 lỗi, 0 cảnh báo**;*
  > *- **8 bộ test chuyên biệt** kiểm thử Pomodoro, vị trí mèo, đồng bộ Theme, bản dịch N5–N1 và âm thanh đạt tuyệt đối **57/57 PASS**;*
  > *- **Python Unit Tests** cho công cụ dịch dữ liệu đạt **9/9 PASS**;*
  > *- **Widget Tests** đạt **17/19 PASS**. Hai widget test cũ chưa đạt là do được viết ở giai đoạn đầu khi kỳ vọng dữ liệu tiếng Việt còn trống (`null`), trước khi nhóm bổ sung 1.164 bản dịch tiếng Việt vào hệ thống."*

#### **SLIDE 12 – HẠN CHẾ VÀ HƯỚNG PHÁT TRIỂN** *(5:55 – 6:30)*
- **[Lời thoại TV2]:**
  > *"Nhìn nhận khách quan, dự án hiện còn 4 hạn chế: PK chưa có Multiplayer thời gian thực; Bảng xếp hạng chưa đồng bộ toàn cầu; Facebook Login mới khai báo thư viện nhưng chưa hoàn thiện luồng gọi; và tính năng OCR viết tay / nhận diện giọng nói cần kiểm thử sâu hơn trên thiết bị di động thật.*
  > *Đây cũng chính là 5 hướng phát triển trọng tâm của nhóm trong giai đoạn tiếp theo."*

---

## 4. KỊCH BẢN LIVE DEMO TRỰC TIẾP TRÊN ỨNG DỤNG (SLIDE 13 — 6 BƯỚC)

- **[Chuyển cảnh tại Slide 13]:**
  - **TV2 nói:** *"Ngay sau đây, nhóm xin phép chuyển sang màn hình ứng dụng thực tế để trình diễn 6 bước trong kịch bản Demo. Ở 3 bước đầu về Học tập, bạn **[Tên TV1]** sẽ thuyết minh và em sẽ thao tác trên máy."*
  - **Thao tác:** Nhấn `Alt + Tab` chuyển sang cửa sổ **Nihongo Master** đang mở ở **Trang chủ (`HomeScreen`)**.

---

### 🔹 NỬA ĐẦU DEMO (BƯỚC 1 → BƯỚC 3): **TV1 Thuyết minh – TV2 Thao tác chuột** *(~2,5 phút)*

| Bước | Thao tác trên màn hình của **TV2** | Lời thuyết minh trực tiếp của **TV1** |
|---|---|---|
| **Bước 1: Trang chủ (`HomeScreen`)**<br>*(~30 giây)* | 1. Chỉ chuột vào thanh Header núi Phú Sĩ (Streak, Xu, Gems, nút chọn cấp độ `N5`–`N1`).<br>2. Đổi cấp độ từ `N5` sang `N4` rồi quay lại `N5`.<br>3. **Kéo-thả chú mèo** từ mép thẻ Tiến độ xuống kệ **Tiện ích học tập**. | *"Đầu tiên là **Trang chủ**. Thầy/Cô có thể thấy thông tin chuỗi ngày học Streak, số Xu, Gems và bộ chọn cấp độ từ **N5 đến N1**. Điểm thú vị là chú **Mèo Hộ Pháp** đang đi dọc ngay trên mép thẻ giao diện; khi bạn **[Tên TV2]** kéo thả chú mèo sang thẻ khác, hệ thống tự động tính toán tọa độ bám dính chính xác lên mép trên của thẻ đó."* |
| **Bước 2: Học Từ vựng, Kanji & Đọc/Nghe**<br>*(~60 giây)* | 1. Bấm vào **Tiện ích Từ điển** hoặc vào mục **Từ vựng / Flashcard N5**.<br>2. Bấm **lật thẻ Flashcard 3D**, bấm **biểu tượng Loa 🔊** để phát âm tiếng Nhật.<br>3. Mở nhanh màn hình **Đọc hiểu (`ReadScreen`)**, mở 1 bài N5, bấm nút **Bật/Tắt Furigana** và xem bản dịch tiếng Việt. | *"Bước thứ hai là **Học Từ vựng và Đọc hiểu**. Trên màn hình Flashcard, dữ liệu tiếng Việt đã được đồng bộ từ **SQLite v3** hiển thị rõ ràng kèm phát âm TTS tiếng Nhật. Khi lật thẻ và chọn mức độ nhớ, thuật toán **SM-2** sẽ tự động tính ngày ôn tập tiếp theo. Còn ở màn hình **Đọc hiểu**, người học có thể bật/tắt phiên âm **Furigana** trên đầu chữ Kanji và đối chiếu bản dịch tiếng Việt ngay bên dưới."* |
| **Bước 3: Bản đồ JLPT & Luyện đề**<br>*(~60 giây)* | 1. Quay lại Trang chủ, bấm vào thẻ **Từ vựng** để mở **Bản đồ Thế giới (`WorldGateScreen`)**.<br>2. Lướt qua 5 Thế giới (**N5 Đại dương → N4 Công nghệ → N3 Du hành → N2 Vũ trụ → N1 Thần tiên**).<br>3. Bấm vào 1 chặng (Node) ở N5 để hiện popup 5 bước học.<br>4. Chuyển sang **Tab 2 (JLPT)**, bấm mở thử 1 đề thi N5 có đồng hồ đếm ngược. | *"Bước thứ ba là **Bản đồ JLPT 5 cấp độ và Luyện đề**. Thay vì danh sách bài học đơn điệu, mỗi cấp độ N5–N1 được thiết kế như một thế giới riêng với phương tiện di chuyển và 10 chặng thử thách, kết hợp từ học thẻ từ, luyện viết, luyện nói đến đánh Boss vượt ải. Khi đã vững kiến thức, người học chuyển sang **Tab 2 – Luyện đề JLPT** để làm bài thi thử có giới hạn thời gian và xem giải thích đáp án chi tiết."* |

---

### 🔸 NỬA SAU DEMO (BƯỚC 4 → BƯỚC 6): **TV2 Thuyết minh – TV1 Thao tác chuột** *(~2,5 phút)*

- **[Chuyển giao]:** TV1 nói: *"Tiếp theo, em xin chuyển quyền điều khiển để bạn **[Tên TV2]** giới thiệu 3 bước về Pomodoro, Phòng Mèo và Đấu trường Mèo Nổ PK."* (TV1 cầm chuột, TV2 tiến lên thuyết minh).

| Bước | Thao tác trên màn hình của **TV1** | Lời thuyết minh trực tiếp của **TV2** |
|---|---|---|
| **Bước 4: Đồng hồ Pomodoro Anti-Cheat**<br>*(~45 giây)* | 1. Tại Trang chủ (Tab 1), cuộn tới thẻ **Đồng hồ Pomodoro**.<br>2. Bấm **Bắt đầu (`Start`)** phiên học → chỉ chuột vào chú mèo chuyển sang hoạt ảnh ngồi học (`studying`).<br>3. Bấm **Tạm dừng (`Pause`)** rồi bấm **Đặt lại / Hủy phiên sớm** để hiện thông báo **Anti-Cheat phạt `-50 Xu`**. | *"Ở bước thứ tư là **Đồng hồ Pomodoro tích hợp Anti-Cheat**. Khi bắt đầu phiên học, chú mèo lập tức chuyển sang trạng thái ngồi học tập trung cùng người dùng và tiêu hao 1% năng lượng mỗi phút. Đặc biệt, nếu người học thoát ứng dụng hoặc bấm hủy phiên học giữa chừng như bạn **[Tên TV1]** vừa thao tác, cơ chế **Anti-Cheat** sẽ kích hoạt và **trừ 50 Xu** để rèn tính kỷ luật."* |
| **Bước 5: Phòng Mèo & Đổi Cozy Theme**<br>*(~45 giây)* | 1. Chuyển sang **Tab 4 (Phòng Mèo – `GuardianCatScreen`)**.<br>2. Kéo mèo đặt lên **Giường / Bàn học / Thảm**.<br>3. Mở ngăn **Đồ ăn (36 món)** cho mèo ăn → hiện hiệu ứng hồi năng lượng & câu thoại tiếng Nhật–Việt.<br>4. Mở ngăn **Nhân vật (24 mèo)** & **Trang phục (32 bộ)**.<br>5. Mở **Hồ sơ / Cài đặt Theme**, bấm đổi sang *Ocean Blue* hoặc *Cyber Midnight*. | *"Bước thứ năm là **Phòng Mèo Hộ Pháp (Tab 4)**. Tại đây người học dùng số Xu và Gems tích lũy được để mở khóa **24 nhân vật mèo, 36 món ăn và 32 trang phục**. Chúng ta có thể kéo-thả mèo vào 10 vị trí nội thất trong phòng, cho mèo ăn để hồi năng lượng và trò chuyện bằng câu thoại song ngữ Nhật–Việt. Đồng thời, người dùng có thể đổi tức thời **6 bảng màu Cozy Themes** trên toàn bộ ứng dụng."* |
| **Bước 6: Đấu trường Mèo Nổ PK 4×4**<br>*(~60 giây)* | 1. Chuyển sang **Tab 3 (Xếp hạng & PK)** → bấm vào banner **Đấu Trường Mèo Nổ PK**.<br>2. Chọn chế độ **Đấu Hạng MR** (cấp độ N5) → bấm **Bắt đầu trận đấu**.<br>3. Khi câu hỏi hiện lên với đồng hồ **15 giây**, chọn đáp án đúng để nhận **Khiên Bảo Hộ 🛡️**.<br>4. Bấm lật 1–2 lá bài trên bàn cờ **4×4 (16 lá)** và cho Hội đồng xem lượt Bot AI phản hồi. | *"Và bước cuối cùng là **Đấu trường Mèo Nổ PK**. Trên bàn đấu **4×4 gồm 16 lá bài**, đầu lượt em có **15 giây** để trả lời câu hỏi tiếng Nhật. Khi trả lời đúng, người chơi nhận được **1 Khiên Bảo Hộ** hiển thị trên thanh trạng thái. Sau đó người chơi lật 1 lá bài trên bàn: nếu là Mèo An Toàn sẽ được cộng điểm; nếu lật trúng 1 trong 2 lá **Mèo Nổ**, chiếc Khiên sẽ tự động vỡ để cứu mạng và xáo trộn lại lá Mèo Nổ vào bàn đấu."* |

---

## 5. KẾT THÚC BÀI BÁO CÁO (SLIDE 14 — KẾT LUẬN) *(~30 giây)*

- **[Hành động]:** TV1 nhấn `Alt + Tab` quay lại **Slide 14 (Kết luận)** trên PowerPoint. Cả 2 thành viên cùng đứng hướng về Hội đồng.
- **[Lời thoại TV2]:**
  > *"Kính thưa Thầy/Cô, qua quá trình thực hiện đồ án liên ngành, nhóm chúng em đã hoàn thành ứng dụng **Nihongo Master** đa nền tảng bằng Flutter, xây dựng cơ sở dữ liệu **SQLite v3** với đầy đủ học liệu **JLPT N5–N1**, kết hợp thành công hệ sinh thái **Gamification Mèo Hộ Pháp**, đồng hồ **Pomodoro Anti-Cheat**, **Bản đồ Thế giới** và **Đấu trường Mèo Nổ PK**.*
  > *Bài trình bày và Demo của nhóm đến đây là kết thúc. Nhóm rất mong nhận được những ý kiến đóng góp quý báu từ Thầy/Cô trong Hội đồng. Chúng em xin trân trọng cảm ơn!"*

---

## 6. CẨM NANG CHIA NHAU TRẢ LỜI CÂU HỎI HỘI ĐỒNG (Q&A CHEAT SHEET)

Khi Hội đồng đặt câu hỏi, hai bạn phân chia trả lời đúng trọng tâm như sau:

1. **Câu hỏi 1 (Dành cho TV1): *"Với hơn 28.000 bản ghi (7.811 từ vựng, 16.691 câu ví dụ...), làm sao ứng dụng khởi động lần đầu mà không bị treo giao diện (UI freeze)?"***
   - **Trả lời (TV1):** *"Dạ thưa Thầy/Cô, trong `LocalDatabaseService`, nhóm sử dụng kỹ thuật **Chunked Batch Import** với kích thước lô `chunkSize = 500` bản ghi kết hợp `Batch` của SQLite và nhường luồng giao diện (`Future.delayed(Duration.zero)`) giữa các lô. Sau khi nạp xong lần đầu, hệ thống tạo file đánh dấu `.nihongo_master_verified_import_v2.done` nên từ lần mở thứ hai trở đi ứng dụng truy vấn trực tiếp từ SQLite tức thì."*

2. **Câu hỏi 2 (Dành cho TV1): *"Khi nhóm dịch thêm từ vựng tiếng Việt trong file JSON rồi cập nhật ứng dụng, tiến độ học Flashcard cũ của người dùng trong SQLite có bị mất không?"***
   - **Trả lời (TV1):** *"Dạ hoàn toàn không bị mất ạ. Nhóm đã thiết kế hàm `syncTranslationsFromAssets()` ở Schema v3 dựa trên mã băm SHA-1 (`translation_fingerprint_v1`). Khi phát hiện file JSON có bản dịch mới, hệ thống chỉ chạy lệnh `UPDATE` trên các cột tiếng Việt (`meaning_vi`, `translation_vi`...), giữ nguyên 100% dữ liệu tiến độ của người dùng trong bảng `flashcard_progress` và `test_history`."*

3. **Câu hỏi 3 (Dành cho TV2): *"Làm thế nào chú mèo có thể biết vị trí các thẻ trên màn hình để đứng đúng trên mép thẻ khi cuộn trang hoặc đổi kích thước màn hình?"***
   - **Trả lời (TV2):** *"Dạ thưa Thầy/Cô, nhóm xây dựng widget `CompanionLineAnchor` gắn vào các thẻ giao diện cùng dịch vụ `CatPositionManager`. Hệ thống quy đổi tọa độ điểm neo chân mèo (`foot anchor` tại `56,5%` chiều ngang và `81,82%` chiều cao ảnh sprite) sang tỷ lệ tương đối `xRatio` theo chiều rộng của từng thẻ. Nhờ vậy, khi người dùng kéo-thả mèo trong phạm vi dung sai `36px` hoặc thay đổi kích thước màn hình, chân chú mèo luôn bám chính xác trên mép thẻ."*

4. **Câu hỏi 4 (Dành cho TV2): *"Đồng hồ Pomodoro xử lý thế nào nếu ứng dụng bị đưa xuống chạy ngầm (Background), có bị lệch thời gian đếm ngược không?"***
   - **Trả lời (TV2):** *"Dạ trong `PomodoroProvider`, nhóm không chỉ dựa vào biến đếm `Timer.periodic` mỗi giây mà lưu mốc thời gian thực `wall-clock` (`_phaseEndsAt`). Đồng thời provider lắng nghe `AppLifecycleState`: nếu người dùng đang trong phiên học mà thoát ứng dụng sang trạng thái `paused` hoặc `detached`, cơ chế **Anti-Cheat** sẽ tự động hủy phiên học đó và phạt `-50 Xu`."*


---

## 7. GIẢI THÍCH KỸ THUẬT CHUYÊN SÂU (DỰA TRÊN MÃ NGUỒN THỰC TẾ)

### 7.1. Thuật toán lặp lại ngắt quãng SM-2 (Spaced Repetition) áp dụng ở đâu và tính như thế nào?

- **Nơi áp dụng:**
  - Model: [`lib/models/flashcard_progress.dart`](../lib/models/flashcard_progress.dart) và bảng SQLite `flashcard_progress`.
  - Xử lý logic: [`lib/providers/flashcard_provider.dart`](../lib/providers/flashcard_provider.dart) (hàm `_applySpacedRepetition` dòng 125–158 và `_priorityForWord` dòng 116–123).
  - Giao diện sử dụng: [`lib/screens/vocabulary/flashcard_screen.dart`](../lib/screens/vocabulary/flashcard_screen.dart) (khi học Flashcard ở mục Từ vựng và khi học trong từng Node của Bản đồ Thế giới).
- **Công thức tính trong code:**
  - Mỗi thẻ khởi tạo với: `interval = 1` (ngày), `easeFactor = 2.5` (hệ số dễ), `repetition = 0` (số lần nhớ liên tiếp).
  - **Khi người học bấm "Đã nhớ" (`correct = true`):**
    - Tăng số lần nhớ liên tiếp: `repetition += 1`.
    - Tính khoảng cách ngày ôn tập lại (`interval`):
      - Lần 1 (`repetition == 1`): `interval = 1` ngày.
      - Lần 2 (`repetition == 2`): `interval = 3` ngày.
      - Lần 3 trở đi (`repetition >= 3`): `interval = (interval * easeFactor).round()` ngày.
    - Tăng hệ số dễ: `easeFactor = (easeFactor + 0.1).clamp(1.3, 2.8)`.
  - **Khi người học bấm "Chưa nhớ" (`correct = false`):**
    - Đặt lại chuỗi nhớ `repetition = 0` và bắt ôn lại vào ngày hôm sau (`interval = 1` ngày).
    - Giảm hệ số dễ: `easeFactor = (easeFactor - 0.2).clamp(1.3, 2.5)`.
  - **Đặt lịch ngày ôn tiếp theo:** `nextReview = DateTime.now().add(Duration(days: interval))`.
- **Cơ chế ưu tiên thẻ khi mở phiên học (`_priorityForWord`):**
  - Khi bắt đầu học, danh sách thẻ được sắp xếp giảm dần theo điểm ưu tiên:
    - Thẻ mới chưa học: `10.0` điểm (ưu tiên cao nhất).
    - Thẻ đã học: `priority = (isDue ? 8.0 : 0.0) + (wrongCount * 1.5) + (3.0 - easeFactor)`.
    - Nhờ đó, các thẻ **đã đến hạn ôn (`isDue`)**, **hay trả lời sai (`wrongCount` cao)** và **khó nhớ (`easeFactor` thấp)** luôn được đẩy lên đầu.

---

### 7.2. Cơ chế nhận Xu khi Offline (Chống cày Xu) và Đồng bộ dữ liệu khi có mạng lại

1. **Khi Offline có nhận được Xu không? Cơ chế chặn nhận Xu lặp lại hoạt động ra sao?**
   - **Lưu cục bộ Offline-First:** Mọi thao tác cộng/trừ Xu (`rawCoins`), Gems (`rawGems`) và XP trong [`lib/providers/progress_provider.dart`](../lib/providers/progress_provider.dart) đều gọi hàm `_persist()`:
     - Bước 1: Gọi `_saveProgress()` lưu ngay lập tức xuống bộ nhớ thiết bị (`SharedPreferences` với khóa `'wallet_coins'`, `'wallet_gems'` và bảng `SQLite`). Do đó, **khi học Offline hợp lệ, người học vẫn được cộng Xu vào ví cục bộ ngay lập tức**.
     - Bước 2: Gọi `unawaited(_syncRemoteProgress())` để đẩy ngầm lên Cloud Firestore. Nếu đang mất mạng, khối `try-catch` sẽ bỏ qua lỗi mạng mà không làm gián đoạn việc học.
   - **3 trường hợp hệ thống CHẶN không cho nhận Xu (Anti-Farming & Anti-Cheat):**
     1. **Học lại bài đã hoàn thành trên Bản đồ (`mapPracticeRewarded`):** Hàm `completeMapPractice(levelKey)` kiểm tra danh sách `mapPracticeRewarded`. Người học chỉ nhận được **`+5 Xu` ở lần đầu tiên** hoàn thành phần học của Node đó; các lần học lại sau sẽ không được cộng thêm Xu để chống cày tiền.
     2. **Nhận thưởng Ôn tập hằng ngày quá 1 lần (`dailyReviewClaimDay`):** Hàm `claimDailyReviewReward()` chỉ cho nhận **`+5 Xu` đúng 1 lần/ngày** sau khi đã học ít nhất 1 từ vựng trong ngày (`vocabStudyDay == _todayKey()`).
     3. **Vi phạm Anti-Cheat trong Pomodoro:** Nếu đang trong phiên học Pomodoro mà thoát app, chuyển tab hoặc bấm dừng sớm, người học **không nhận được Xu thưởng** của phiên đó mà còn bị phạt **`-50 Xu`** (nhưng giới hạn sàn `max(0, rawCoins - 50)` để không bị âm Xu).

2. **Khi có mạng trở lại, dữ liệu đồng bộ giữa Local và Firebase như thế nào?**
   - **Chiều đẩy từ Máy lên Cloud (`Local → Firestore`):**
     - Mỗi khi có bất kỳ cập nhật tiến độ nào hoặc khi khởi động lại app có mạng, hàm `_syncRemoteProgress()` sẽ đóng gói toàn bộ trạng thái qua `_buildRemoteProgressPayload()` (kèm `'schemaVersion': 3`) và ghi lên Firestore với `SetOptions(merge: true)` tại 3 nơi:
       1. `users/{uid}`: Lưu thống kê tổng quan (`totalXp`, `streak`, `longestStreak`, `learnedVocabCount`, `learnedKanjiCount`, `userLevel`).
       2. `users/{uid}/app_state/progress`: Lưu chi tiết ví `coins`, `gems`, `mapLevelStars`, túi đồ ăn `foodInventory`, trang phục `ownedOutfits`, danh sách mèo `ownedCatIds`, điểm `pkRating` và 250 lịch sử thi gần nhất.
       3. `leaderboards/weekly` & `leaderboards/monthly`: Cập nhật điểm xếp hạng tuần và tháng.
   - **Chiều tải từ Cloud về Máy (`Firestore → Local`):**
     - Khi đăng nhập hoặc mở app có mạng, `_restoreRemoteProgressIfAvailable()` kiểm tra nếu dữ liệu trên Cloud có `schemaVersion >= 3` thì tải về và cập nhật vào `SharedPreferences`.
     - Đối với tiến độ **Flashcard SM-2** (`FlashcardProvider.startSession`) và **Lịch sử làm đề** (`StudyHistoryProvider.init`): ứng dụng nạp dữ liệu từ **SQLite cục bộ trước** để hiển thị ngay, sau đó tải danh sách từ Firestore (`users/{uid}/flashcard_progress` và `users/{uid}/test_history`) rồi dùng lệnh `upsert` (`ConflictAlgorithm.replace`) để hợp nhất vào SQLite.

---

### 7.3. Cơ chế tính 1 Sao / 2 Sao / 3 Sao trên Bản đồ & Xếp hạng Đề thi JLPT

1. **Cách tính Sao ở bài Kiểm tra vượt ải trên Bản đồ Thế giới (`MapLevelCatalog.starsForScore`):**
   - Mỗi chặng (Node) trên Bản đồ có bài kiểm tra gồm **`10 câu hỏi`** (`quizQuestions = 10`). Tỷ lệ đúng `ratio = score / total` quyết định số sao:
     - **⭐⭐⭐ 3 Sao:** `ratio >= 1.0` (**Đúng 100%** — tức **10/10 câu**).
     - **⭐⭐ 2 Sao:** `0.8 <= ratio < 1.0` (**Đúng từ 80% – 99%** — tức **8/10 hoặc 9/10 câu**).
     - **⭐ 1 Sao:** `0.6 <= ratio < 0.8` (**Đúng từ 60% – 79%** — tức **6/10 hoặc 7/10 câu**).
     - **0 Sao (Trượt):** `ratio < 0.6` (**Dưới 60%** — tức **từ 5/10 câu trở xuống**).
   - **Điều kiện qua màn & lưu kỷ lục:**
     - Đạt từ **1 Sao trở lên ($\ge 60\%$)** sẽ mở khóa chặng tiếp theo trên bản đồ (và tự động đánh dấu thuộc các chữ Kanji của chặng đó nếu đang ở chế độ Bản đồ Kanji).
     - Hệ thống chỉ lưu **kỷ lục số sao cao nhất** từng đạt được ở mỗi chặng (`clamped <= mapStarsFor(levelKey)` thì giữ nguyên kỷ lục cũ).

2. **Cách tính Hạng (Grade) và Thưởng Xu/Gems khi nộp Đề thi JLPT (`JLPTScreen`):**
   - **Hạng bài thi (`rankGradeFor`):**
     - Hạng **S:** $\ge 90\%$ | Hạng **A:** $80\% - 89\%$ | Hạng **B:** $65\% - 79\%$ | Hạng **C:** $50\% - 64\%$ | Hạng **F:** $< 50\%$.
   - **Thưởng Xu (`baseCoinsForLevel`):**
     - Mức chuẩn theo cấp độ: `N5 = 15 Xu`, `N4 = 20 Xu`, `N3 = 25 Xu`, `N2 = 30 Xu`, `N1 = 40 Xu`.
     - Điểm $\ge 80\%$: nhận **100%** mức chuẩn | Điểm $50\% - 79\%$: nhận **60%** mức chuẩn | Điểm $< 50\%$: nhận **5 Xu**.
   - **Thưởng Gems (`baseGemsForLevel`):**
     - Điểm $< 60\%$: `0 Gem`.
     - Điểm $\ge 60\%$: `N1 = +5 Gems`, `N2 = +3 Gems`, `N3 = +2 Gems`, `N4 = +1 Gem`, `N5 = +1 Gem` (riêng N5 cần $\ge 80\%$).
