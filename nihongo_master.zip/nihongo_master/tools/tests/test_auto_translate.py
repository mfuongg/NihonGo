"""Kiểm thử offline cho tools/auto_translate_dataset.py (không gọi API thật).

Chạy:  python -m unittest discover -s tools/tests -v
"""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import auto_translate_dataset as atd  # noqa: E402


def _vocab(i, vi=None, status=None):
    rec = {
        'id': f'v{i}', 'source_id': 'src', 'license_id': 'lic', 'source_url': None, 'jmdict_id': None,
        'expression': f'語{i}', 'reading_hiragana': 'ご', 'reading_romaji': 'go', 'part_of_speech': 'noun',
        'meaning_vi': vi, 'meaning_en': f'word {i}', 'category': None, 'original_level': 'N5',
        'estimated_level': None, 'is_level_estimated': 0, 'estimation_basis': None,
    }
    if status:
        rec['translation_status'] = status
    return rec


class AutoTranslateTest(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix='nm_translate_'))
        self.vocab = [
            _vocab(1),                                   # cần dịch (null)
            _vocab(2, vi=''),                            # cần dịch (rỗng)
            _vocab(3, vi='nghĩa gốc'),                   # đã có -> bỏ qua
            _vocab(4, vi='', status='reviewed'),         # reviewed -> không đụng
            _vocab(5),                                   # sẽ giả lập lỗi
        ]
        self.sentences = [
            {'id': 's1', 'sentence_jp': '語1を使います。', 'translation_vi': None,
             'translation_en': 'I use word 1.', 'linked_vocab_id': 'v1'},
            {'id': 's2', 'sentence_jp': '別の文。', 'translation_vi': 'Câu đã dịch.',
             'translation_en': 'Another.', 'linked_vocab_id': 'v3'},
        ]
        self._write('vocabularies.json', self.vocab)
        self._write('example_sentences.json', self.sentences)
        self.log = self.dir / 'translate_error.log'

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def _write(self, name, data):
        (self.dir / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def _read(self, name):
        return json.loads((self.dir / name).read_text(encoding='utf-8'))

    def _run(self, *extra):
        args = atd.parse_args([
            '--data-dir', str(self.dir), '--provider', 'mock', '--sleep', '0',
            '--log-file', str(self.log), '--backup-dir', str(self.dir / 'backups'), '--env-file', str(self.dir / 'none.env'),
            '--mock-fail-ids', '語5', *extra,
        ])
        return atd.run(args)

    def test_translates_only_blank_records_and_keeps_other_fields(self):
        stats = self._run()
        self.assertEqual(stats.translated, 2)
        self.assertEqual(stats.failed, 1)
        out = {r['id']: r for r in self._read('vocabularies.json')}
        self.assertEqual(out['v1']['meaning_vi'], '[MOCK] meaning_vi')
        self.assertEqual(out['v1']['translation_status'], 'ai_translated')
        self.assertEqual(out['v2']['translation_status'], 'ai_translated')
        self.assertEqual(out['v3']['meaning_vi'], 'nghĩa gốc')
        self.assertNotIn('translation_status', out['v3'])
        self.assertEqual(out['v4']['meaning_vi'], '')
        self.assertEqual(out['v4']['translation_status'], 'reviewed')
        self.assertIsNone(out['v5']['meaning_vi'])
        self.assertNotIn('translation_status', out['v5'])
        # Các trường khác giữ nguyên tuyệt đối.
        original = {r['id']: r for r in self.vocab}
        for rid, rec in out.items():
            for k, v in original[rid].items():
                if k != 'meaning_vi':
                    self.assertEqual(rec[k], v, f'{rid}.{k} bị thay đổi')
        # Câu ví dụ liên kết được dịch theo ngữ cảnh, câu đã có giữ nguyên.
        sents = {s['id']: s for s in self._read('example_sentences.json')}
        self.assertEqual(sents['s1']['translation_vi'], '[MOCK] example_vi')
        self.assertEqual(sents['s1']['translation_status'], 'ai_translated')
        self.assertEqual(sents['s2']['translation_vi'], 'Câu đã dịch.')
        # Lỗi được ghi log.
        self.assertIn('v5', self.log.read_text(encoding='utf-8'))

    def test_backup_created_before_write_and_not_overwritten(self):
        before = (self.dir / 'vocabularies.json').read_text(encoding='utf-8')
        self._run()
        bak = self.dir / 'backups' / 'vocabularies.json.bak'
        self.assertTrue(bak.exists())
        self.assertEqual(bak.read_text(encoding='utf-8'), before)
        self._run('--mock-fail-ids', '')  # lần 2 dịch nốt v5 -> backup mới có timestamp, .bak gốc giữ nguyên
        self.assertEqual(bak.read_text(encoding='utf-8'), before)
        self.assertTrue(list((self.dir / 'backups').glob('vocabularies.json.*.bak')))
        self.assertFalse(list(self.dir.glob('*.bak')), 'Không được để .bak trong thư mục dữ liệu')

    def test_idempotent_rerun_makes_no_requests_and_no_changes(self):
        self._run('--mock-fail-ids', '')
        snapshot = (self.dir / 'vocabularies.json').read_text(encoding='utf-8')
        for _ in range(3):
            stats = self._run('--mock-fail-ids', '')
            self.assertEqual(stats.requests, 0)
            self.assertEqual(stats.translated, 0)
        self.assertEqual((self.dir / 'vocabularies.json').read_text(encoding='utf-8'), snapshot)

    def test_dry_run_never_writes(self):
        before = (self.dir / 'vocabularies.json').read_text(encoding='utf-8')
        stats = self._run('--dry-run')
        self.assertEqual(stats.candidates, 3)
        self.assertEqual(stats.requests, 0)
        self.assertEqual((self.dir / 'vocabularies.json').read_text(encoding='utf-8'), before)
        self.assertFalse((self.dir / 'backups').exists())

    def test_parse_llm_json_strict(self):
        self.assertEqual(atd.parse_llm_json('{"meaning_vi": " nhà "}', ('meaning_vi',)), {'meaning_vi': 'nhà'})
        self.assertEqual(atd.parse_llm_json('```json\n{"meaning_vi": "nhà"}\n```', ('meaning_vi',)),
                         {'meaning_vi': 'nhà'})
        with self.assertRaises(ValueError):
            atd.parse_llm_json('{"meaning_vi": ""}', ('meaning_vi',))
        with self.assertRaises(ValueError):
            atd.parse_llm_json('{"other": "x"}', ('meaning_vi',))
        with self.assertRaises(json.JSONDecodeError):
            atd.parse_llm_json('nhà', ('meaning_vi',))

    def test_mock_refused_on_real_dataset(self):
        with self.assertRaises(SystemExit):
            atd.run(atd.parse_args(['--provider', 'mock', '--sleep', '0']))

    def test_dotenv_does_not_override_existing_env(self):
        env = self.dir / '.env'
        env.write_text('# comment\nNM_TEST_KEY="from-file"\nexport NM_TEST_OTHER=abc\n', encoding='utf-8')
        import os
        os.environ['NM_TEST_KEY'] = 'from-env'
        os.environ.pop('NM_TEST_OTHER', None)
        atd.load_dotenv(env)
        self.assertEqual(os.environ['NM_TEST_KEY'], 'from-env')
        self.assertEqual(os.environ['NM_TEST_OTHER'], 'abc')

    def test_limit_restricts_records_translated(self):
        stats = self._run('--mock-fail-ids', '', '--limit', '1')
        self.assertEqual(stats.candidates, 1)
        self.assertEqual(stats.translated, 1)
        self.assertEqual(stats.requests, 1)
        out = {r['id']: r for r in self._read('vocabularies.json')}
        self.assertEqual(out['v1']['translation_status'], 'ai_translated')
        self.assertEqual(out['v2']['meaning_vi'], '')  # chưa dịch vì --limit 1

    def test_api_key_is_never_logged_on_error(self):
        import os
        secret = 'AIzaSyTestSecretKey987654321'
        os.environ['GEMINI_API_KEY'] = secret
        try:
            err_log = atd.ErrorLog(self.log)
            err_log.write('vocabularies', 'v5', f'HTTP 403 key={secret} forbidden')
            content = self.log.read_text(encoding='utf-8')
            self.assertNotIn(secret, content)
            self.assertIn('[REDACTED]', content)
        finally:
            os.environ.pop('GEMINI_API_KEY', None)


if __name__ == '__main__':
    unittest.main()
