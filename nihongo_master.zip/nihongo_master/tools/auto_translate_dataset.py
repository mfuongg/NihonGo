#!/usr/bin/env python3
"""Pipeline Việt hoá an toàn & idempotent cho dataset `assets/data/verified_v2/`.

Chỉ điền các trường tiếng Việt đang `null` / rỗng bằng LLM (JSON mode), gắn
`"translation_status": "ai_translated"` cho bản ghi được dịch, và **không đụng**
bất kỳ trường nào khác (`id`, `expression`, `original_level`, ...).

Bảo vệ dữ liệu
  * Backup trước lần ghi đầu tiên vào `backups/verified_v2/<file>.json.bak` (nếu đã có thì
    `<file>.json.<YYYYmmdd-HHMMSS>.bak` để không ghi đè bản gốc).
  * Ghi nguyên tử: ghi ra file tạm rồi `os.replace`.
  * Idempotent: bản ghi đã có tiếng Việt hoặc `translation_status == "reviewed"`
    luôn bị bỏ qua -> chạy lại 100 lần không đổi dữ liệu cũ, không gọi API thừa.
  * Lỗi từng bản ghi được ghi vào `translate_error.log`, script chạy tiếp.
  * Lưu checkpoint định kỳ + khi Ctrl+C.

Cấu hình qua biến môi trường hoặc file `.env` ở thư mục dự án (KHÔNG hardcode key):
  TRANSLATE_PROVIDER=gemini | openai          (mặc định: gemini)
  GEMINI_API_KEY=...                          (provider gemini)
  OPENAI_API_KEY=...                          (provider openai / API tương thích OpenAI)
  OPENAI_BASE_URL=https://api.openai.com/v1   (tuỳ chọn)
  TRANSLATE_MODEL=...                         (tuỳ chọn)
  TRANSLATE_RATE_LIMIT_SECONDS=1.5            (khoảng nghỉ giữa các request)

Ví dụ:
  python tools/auto_translate_dataset.py --dry-run
  python tools/auto_translate_dataset.py --tables vocabularies --limit 50
  python tools/auto_translate_dataset.py --tables vocabularies,kanji_entries,grammar_points
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_DIR = PROJECT_ROOT / 'assets' / 'data' / 'verified_v2'
# Backup đặt NGOÀI assets/: pubspec.yaml bundle toàn bộ thư mục verified_v2/, file .bak ở đó sẽ bị đóng gói vào app.
DEFAULT_BACKUP_DIR = PROJECT_ROOT / 'backups' / 'verified_v2'
STATUS_AI = 'ai_translated'
STATUS_REVIEWED = 'reviewed'
VALID_STATUSES = {'source', STATUS_AI, STATUS_REVIEWED}


# --------------------------------------------------------------------------------------
# Cấu hình bảng: trường tiếng Việt cần điền + cách dựng ngữ cảnh + khoá JSON LLM trả về.
# Tên trường khớp đúng schema SQLite (`LocalDatabaseService._createSchemaV2`).
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TableSpec:
    file: str
    vi_fields: tuple[str, ...]          # trường trong bản ghi
    response_keys: tuple[str, ...]      # khoá JSON LLM phải trả về (cùng thứ tự vi_fields)
    describe: str


TABLES: dict[str, TableSpec] = {
    'vocabularies': TableSpec(
        'vocabularies.json', ('meaning_vi',), ('meaning_vi',),
        'Từ vựng tiếng Nhật (JMdict/OpenJLPT).'),
    'kanji_entries': TableSpec(
        'kanji_entries.json', ('meaning_vi',), ('meaning_vi',),
        'Chữ Hán (Kanji) tiếng Nhật.'),
    'grammar_points': TableSpec(
        'grammar_points.json', ('title_vi', 'explanation_vi'), ('title_vi', 'explanation_vi'),
        'Mẫu ngữ pháp JLPT.'),
    'example_sentences': TableSpec(
        'example_sentences.json', ('translation_vi',), ('translation_vi',),
        'Câu ví dụ tiếng Nhật (Tatoeba).'),
    'reading_materials': TableSpec(
        'reading_materials.json', ('title_vi', 'translation_vi'), ('title_vi', 'translation_vi'),
        'Bài đọc hiểu tiếng Nhật (JLPT / Aozora).'),
}


def is_blank(v: Any) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def needs_translation(rec: dict, spec: TableSpec) -> bool:
    if rec.get('translation_status') == STATUS_REVIEWED:
        return False
    return any(is_blank(rec.get(f)) for f in spec.vi_fields)


# --------------------------------------------------------------------------------------
# .env & logging
# --------------------------------------------------------------------------------------
def load_dotenv(path: Path) -> None:
    """Parser .env tối giản (không ghi đè biến môi trường đã có)."""
    if not path.exists():
        return
    for raw in path.read_text(encoding='utf-8-sig').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip().removeprefix('export ').strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def redact_secrets(text: str) -> str:
    """Ẩn giá trị API key nếu lỡ xuất hiện trong thông báo lỗi."""
    out = text
    for env_key in ('GEMINI_API_KEY', 'OPENAI_API_KEY'):
        val = os.environ.get(env_key, '').strip()
        if val and len(val) >= 4 and val in out:
            out = out.replace(val, '[REDACTED]')
    return out


class ErrorLog:
    def __init__(self, path: Path):
        self.path = path
        self.count = 0

    def write(self, table: str, rec_id: str, message: str) -> None:
        self.count += 1
        safe_msg = redact_secrets(message)
        stamp = _dt.datetime.now().isoformat(timespec='seconds')
        line = f'{stamp}\t{table}\t{rec_id}\t{safe_msg}'
        print(f'  [LỖI] {table}/{rec_id}: {safe_msg}', file=sys.stderr)
        with self.path.open('a', encoding='utf-8') as f:
            f.write(line + '\n')


# --------------------------------------------------------------------------------------
# JSON file I/O (giữ định dạng indent=2 như file gốc, backup, ghi nguyên tử)
# --------------------------------------------------------------------------------------
@dataclass
class JsonFile:
    path: Path
    data: list[dict]
    ensure_ascii: bool
    backup_dir: Path | None = None
    backed_up: bool = False
    dirty: bool = False

    @classmethod
    def load(cls, path: Path, backup_dir: Path | None = None) -> 'JsonFile':
        text = path.read_text(encoding='utf-8')
        data = json.loads(text)
        if not isinstance(data, list):
            raise ValueError(f'{path.name}: định dạng không phải mảng JSON')
        # Nếu file gốc không chứa ký tự ngoài ASCII mà có \uXXXX thì giữ ensure_ascii.
        ensure_ascii = all(ord(ch) < 128 for ch in text[:200000]) and '\\u' in text
        return cls(path, data, ensure_ascii, backup_dir)

    def backup_once(self) -> Path | None:
        if self.backed_up:
            return None
        target_dir = self.backup_dir or self.path.parent
        target_dir.mkdir(parents=True, exist_ok=True)
        bak = target_dir / (self.path.name + '.bak')
        if bak.exists():
            stamp = _dt.datetime.now().strftime('%Y%m%d-%H%M%S')
            bak = target_dir / f'{self.path.name}.{stamp}.bak'
        shutil.copy2(self.path, bak)
        self.backed_up = True
        print(f'  Backup: {bak}')
        return bak

    def save(self) -> None:
        if not self.dirty:
            return
        self.backup_once()
        fd, tmp = tempfile.mkstemp(prefix=self.path.name, suffix='.tmp', dir=str(self.path.parent))
        try:
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as f:
                json.dump(self.data, f, ensure_ascii=self.ensure_ascii, indent=2)
                f.write('\n')
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        self.dirty = False


# --------------------------------------------------------------------------------------
# Prompt (JSON mode)
# --------------------------------------------------------------------------------------
SYSTEM_PROMPT = (
    'Bạn là biên dịch viên Nhật–Việt cho ứng dụng học tiếng Nhật JLPT. '
    'Dịch chính xác, tự nhiên, ngắn gọn theo văn phong từ điển học tập; giữ nguyên thuật ngữ ngữ pháp. '
    'Không thêm romaji, không giải thích ngoài yêu cầu. '
    'CHỈ trả về MỘT đối tượng JSON thuần hợp lệ, KHÔNG bọc trong ```json, KHÔNG có văn bản nào khác.'
)


def build_prompt(table: str, rec: dict, ctx: dict) -> tuple[str, tuple[str, ...]]:
    """Trả về (prompt, khoá JSON bắt buộc)."""
    if table == 'vocabularies':
        ex = ctx.get('example')
        keys = ('meaning_vi', 'example_vi') if ex else ('meaning_vi',)
        lines = [
            f"word: {rec.get('expression', '')}",
            f"reading: {rec.get('reading_hiragana', '')}",
            f"part_of_speech: {rec.get('part_of_speech') or ''}",
            f"meaning_en: {rec.get('meaning_en', '')}",
        ]
        if ex:
            lines += [f"example_sentence: {ex.get('sentence_jp', '')}",
                      f"example_en: {ex.get('translation_en') or ''}"]
        fmt = '{"meaning_vi": "...", "example_vi": "..."}' if ex else '{"meaning_vi": "..."}'
        task = ('Dịch nghĩa của từ sang tiếng Việt (dựa vào ngữ cảnh câu ví dụ nếu có; nhiều nghĩa thì ngăn bằng "; ")'
                + (' và dịch câu ví dụ sang tiếng Việt.' if ex else '.'))
    elif table == 'kanji_entries':
        keys = ('meaning_vi',)
        lines = [f"kanji: {rec.get('character', '')}", f"onyomi: {rec.get('onyomi') or ''}",
                 f"kunyomi: {rec.get('kunyomi') or ''}", f"meaning_en: {rec.get('meaning_en', '')}"]
        fmt = '{"meaning_vi": "..."}'
        task = 'Dịch nghĩa chữ Hán sang tiếng Việt (có thể kèm âm Hán Việt in hoa ở đầu, ví dụ "NHẬT: mặt trời; ngày").'
    elif table == 'grammar_points':
        keys = ('title_vi', 'explanation_vi')
        lines = [f"pattern: {rec.get('pattern', '')}", f"title_en: {rec.get('title_en') or ''}",
                 f"formation: {rec.get('formation') or ''}", f"explanation_en: {rec.get('explanation_en') or ''}"]
        fmt = '{"title_vi": "...", "explanation_vi": "..."}'
        task = 'Dịch tiêu đề và phần giải thích mẫu ngữ pháp sang tiếng Việt.'
    elif table == 'example_sentences':
        keys = ('translation_vi',)
        lines = [f"sentence_jp: {rec.get('sentence_jp', '')}",
                 f"translation_en: {rec.get('translation_en') or ''}"]
        fmt = '{"translation_vi": "..."}'
        task = 'Dịch câu tiếng Nhật sang tiếng Việt tự nhiên.'
    elif table == 'reading_materials':
        keys = ('title_vi', 'translation_vi')
        lines = [f"title_jp: {rec.get('title_jp', '')}",
                 f"title_en: {rec.get('title_en') or ''}",
                 f"summary: {rec.get('summary') or ''}",
                 f"content_jp: {(rec.get('content_jp') or '')[:1500]}",
                 f"translation_en: {(rec.get('translation_en') or '')[:1500]}"]
        fmt = '{"title_vi": "...", "translation_vi": "..."}'
        task = 'Dịch tiêu đề và nội dung/tóm tắt bài đọc tiếng Nhật sang tiếng Việt tự nhiên.'
    else:
        raise ValueError(table)
    prompt = (f'{task}\n\nDữ liệu:\n' + '\n'.join(lines)
              + f'\n\nTrả về đúng định dạng JSON: {fmt}')
    return prompt, keys


FENCE_RE = re.compile(r'^\s*```(?:json)?\s*|\s*```\s*$', re.IGNORECASE)


def parse_llm_json(text: str, required: tuple[str, ...]) -> dict[str, str]:
    cleaned = FENCE_RE.sub('', text.strip())
    obj = json.loads(cleaned)
    if not isinstance(obj, dict):
        raise ValueError('LLM không trả về object JSON')
    out = {}
    for k in required:
        v = obj.get(k)
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f'thiếu hoặc rỗng khoá "{k}"')
        out[k] = v.strip()
    return out


# --------------------------------------------------------------------------------------
# Providers
# --------------------------------------------------------------------------------------
class TransientError(Exception):
    """Lỗi tạm thời (429/5xx/mạng) -> thử lại."""


def _post_json(url: str, body: dict, headers: dict, timeout: float = 60) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode('utf-8'),
                                 headers={'Content-Type': 'application/json', **headers}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        detail = e.read().decode('utf-8', 'replace')[:300]
        if e.code == 429 or e.code >= 500:
            raise TransientError(f'HTTP {e.code}: {detail}') from e
        raise RuntimeError(f'HTTP {e.code}: {detail}') from e
    except (urllib.error.URLError, TimeoutError) as e:
        raise TransientError(f'Lỗi mạng: {e}') from e


def gemini_provider(model: str) -> Callable[[str], str]:
    key = os.environ.get('GEMINI_API_KEY')
    if not key:
        raise SystemExit('Thiếu GEMINI_API_KEY (đặt trong .env hoặc biến môi trường).')
    url = f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'

    def call(prompt: str) -> str:
        data = _post_json(url, {
            'systemInstruction': {'parts': [{'text': SYSTEM_PROMPT}]},
            'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
            'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0.2},
        }, {'x-goog-api-key': key})
        try:
            return data['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError) as e:
            raise RuntimeError(f'Phản hồi Gemini không hợp lệ: {str(data)[:200]}') from e
    return call


def openai_provider(model: str) -> Callable[[str], str]:
    key = os.environ.get('OPENAI_API_KEY')
    if not key:
        raise SystemExit('Thiếu OPENAI_API_KEY (đặt trong .env hoặc biến môi trường).')
    base = os.environ.get('OPENAI_BASE_URL', 'https://api.openai.com/v1').rstrip('/')

    def call(prompt: str) -> str:
        data = _post_json(f'{base}/chat/completions', {
            'model': model,
            'temperature': 0.2,
            'response_format': {'type': 'json_object'},
            'messages': [{'role': 'system', 'content': SYSTEM_PROMPT},
                         {'role': 'user', 'content': prompt}],
        }, {'Authorization': f'Bearer {key}'})
        try:
            return data['choices'][0]['message']['content']
        except (KeyError, IndexError) as e:
            raise RuntimeError(f'Phản hồi OpenAI không hợp lệ: {str(data)[:200]}') from e
    return call


def mock_provider(fail_tokens: set[str]) -> Callable[[str], str]:
    """Chỉ dùng để kiểm thử offline (bắt buộc --data-dir khác thư mục dataset thật)."""
    def call(prompt: str) -> str:
        for token in fail_tokens:  # giả lập lỗi khi prompt chứa token (ví dụ từ vựng)
            if token in prompt:
                return 'xin lỗi, đây không phải JSON'
        keys = re.findall(r'"(\w+_vi)": "\.\.\."', prompt.rsplit('Trả về đúng định dạng JSON:', 1)[-1])
        return json.dumps({k: f'[MOCK] {k}' for k in keys}, ensure_ascii=False)
    return call


# --------------------------------------------------------------------------------------
# Pipeline
# --------------------------------------------------------------------------------------
@dataclass
class Stats:
    candidates: int = 0
    translated: int = 0
    failed: int = 0
    skipped_existing: int = 0
    requests: int = 0
    by_table: dict = field(default_factory=dict)


def call_with_retry(call: Callable[[str], str], prompt: str, retries: int, base_sleep: float) -> str:
    attempt = 0
    while True:
        try:
            return call(prompt)
        except TransientError:
            attempt += 1
            if attempt > retries:
                raise
            time.sleep(base_sleep * (2 ** attempt))


def _ensure_utf8_stdio() -> None:
    # Console Windows mặc định cp1252 không in được tiếng Việt.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            try:
                stream.reconfigure(encoding='utf-8', errors='replace')
            except (ValueError, OSError):
                pass


def run(args: argparse.Namespace) -> Stats:
    _ensure_utf8_stdio()
    data_dir = Path(args.data_dir).resolve()
    tables = [t.strip() for t in args.tables.split(',') if t.strip()]
    for t in tables:
        if t not in TABLES:
            raise SystemExit(f'Bảng không hỗ trợ: {t}. Hỗ trợ: {", ".join(TABLES)}')

    provider_name = args.provider or os.environ.get('TRANSLATE_PROVIDER', 'gemini')
    if provider_name == 'mock' and data_dir == DEFAULT_DATA_DIR.resolve() and not args.dry_run:
        raise SystemExit('Provider "mock" chỉ dùng cho kiểm thử: hãy chỉ định --data-dir tới một bản sao.')
    model = args.model or os.environ.get('TRANSLATE_MODEL') or (
        'gemini-2.0-flash' if provider_name == 'gemini' else 'gpt-4o-mini')
    sleep_s = args.sleep if args.sleep is not None else float(os.environ.get('TRANSLATE_RATE_LIMIT_SECONDS', '1.5'))

    call: Callable[[str], str] | None = None
    if not args.dry_run:
        if provider_name == 'gemini':
            call = gemini_provider(model)
        elif provider_name == 'openai':
            call = openai_provider(model)
        elif provider_name == 'mock':
            call = mock_provider(set(filter(None, (args.mock_fail_ids or '').split(','))))
        else:
            raise SystemExit(f'Provider không hỗ trợ: {provider_name}')

    errors = ErrorLog(Path(args.log_file).resolve())
    stats = Stats()
    files: dict[str, JsonFile] = {}

    def get_file(table: str) -> JsonFile:
        if table not in files:
            files[table] = JsonFile.load(data_dir / TABLES[table].file, Path(args.backup_dir).resolve())
        return files[table]

    # Ngữ cảnh câu ví dụ cho từ vựng (example_sentences.linked_vocab_id).
    example_by_vocab: dict[str, dict] = {}
    if 'vocabularies' in tables:
        for s in get_file('example_sentences').data:
            vid = s.get('linked_vocab_id')
            if vid and vid not in example_by_vocab and not is_blank(s.get('sentence_jp')):
                example_by_vocab[vid] = s

    def save_all() -> None:
        if args.dry_run:
            return
        for jf in files.values():
            jf.save()

    print(f'Provider: {"(dry-run)" if args.dry_run else provider_name} | model: {model} | nghỉ {sleep_s}s/request')
    print(f'Dataset: {data_dir}')
    since_save = 0
    try:
        for table in tables:
            spec = TABLES[table]
            jf = get_file(table)
            pending = [r for r in jf.data if needs_translation(r, spec)]
            stats.skipped_existing += len(jf.data) - len(pending)
            if args.limit:
                pending = pending[: max(0, args.limit - stats.candidates)]
            stats.candidates += len(pending)
            stats.by_table[table] = {'total': len(jf.data), 'pending': len(pending), 'translated': 0, 'failed': 0}
            print(f'\n== {table}: {len(jf.data)} bản ghi, cần dịch {len(pending)}')
            if args.dry_run:
                for r in pending[:3]:
                    prompt, keys = build_prompt(table, r, {'example': example_by_vocab.get(r.get('id'))})
                    print(f'  -- ví dụ prompt ({r.get("id")}) -> khoá {keys}\n' + '\n'.join('     ' + l for l in prompt.splitlines()))
                continue

            for idx, rec in enumerate(pending, 1):
                rec_id = str(rec.get('id'))
                ex = example_by_vocab.get(rec_id) if table == 'vocabularies' else None
                ex_needs = ex is not None and needs_translation(ex, TABLES['example_sentences'])
                prompt, keys = build_prompt(table, rec, {'example': ex if ex_needs else None})
                try:
                    stats.requests += 1
                    raw = call_with_retry(call, prompt, args.retries, sleep_s)
                    result = parse_llm_json(raw, keys)
                except Exception as e:  # noqa: BLE001 — ghi log và chạy tiếp
                    stats.failed += 1
                    stats.by_table[table]['failed'] += 1
                    errors.write(table, rec_id, f'{type(e).__name__}: {e}')
                else:
                    # Chỉ ghi vào trường tiếng Việt đang trống + gắn trạng thái.
                    for fld, key in zip(spec.vi_fields, spec.response_keys):
                        if is_blank(rec.get(fld)):
                            rec[fld] = result[key]
                    rec['translation_status'] = STATUS_AI
                    if ex_needs and 'example_vi' in result:
                        ex['translation_vi'] = result['example_vi']
                        ex['translation_status'] = STATUS_AI
                        get_file('example_sentences').dirty = True
                    jf.dirty = True
                    stats.translated += 1
                    stats.by_table[table]['translated'] += 1
                    since_save += 1
                    if since_save >= args.save_every:
                        save_all()
                        since_save = 0
                if idx % 25 == 0 or idx == len(pending):
                    print(f'  {idx}/{len(pending)} (thành công {stats.by_table[table]["translated"]}, lỗi {stats.by_table[table]["failed"]})')
                time.sleep(sleep_s)
    except KeyboardInterrupt:
        print('\nĐã dừng (Ctrl+C) — lưu tiến độ...')
    finally:
        save_all()

    print('\n== Tổng kết')
    print(json.dumps(stats.__dict__, ensure_ascii=False, indent=2))
    if errors.count:
        print(f'{errors.count} lỗi -> {errors.path}')
    return stats


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description='Việt hoá an toàn dataset verified_v2 bằng LLM (JSON mode).')
    ap.add_argument('--data-dir', default=str(DEFAULT_DATA_DIR))
    ap.add_argument('--tables', default='vocabularies',
                    help=f'Danh sách bảng, ngăn bởi dấu phẩy. Hỗ trợ: {", ".join(TABLES)}')
    ap.add_argument('--limit', type=int, default=0, help='Số bản ghi tối đa cần dịch trong lần chạy (0 = tất cả)')
    ap.add_argument('--provider', choices=['gemini', 'openai', 'mock'], default=None)
    ap.add_argument('--model', default=None)
    ap.add_argument('--sleep', type=float, default=None, help='Giây nghỉ giữa các request (rate limit)')
    ap.add_argument('--retries', type=int, default=3, help='Số lần thử lại khi 429/5xx/lỗi mạng')
    ap.add_argument('--save-every', type=int, default=25, help='Lưu checkpoint sau mỗi N bản dịch thành công')
    ap.add_argument('--backup-dir', default=str(DEFAULT_BACKUP_DIR),
                    help='Thư mục chứa <file>.json.bak (mặc định ngoài assets/ để không bị bundle vào app)')
    ap.add_argument('--log-file', default=str(PROJECT_ROOT / 'tools' / 'translate_error.log'))
    ap.add_argument('--dry-run', action='store_true', help='Chỉ thống kê & in prompt mẫu, không gọi API, không ghi file')
    ap.add_argument('--env-file', default=str(PROJECT_ROOT / '.env'))
    ap.add_argument('--mock-fail-ids', default='', help=argparse.SUPPRESS)
    return ap.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    load_dotenv(Path(args.env_file))
    run(args)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
