-- =============================================================================
-- Nihongo Master — SQLite migration v2 -> v3: translation_status
-- =============================================================================
-- Mục đích: đánh dấu nguồn gốc bản dịch tiếng Việt của từng bản ghi nội dung.
--   'source'        : dữ liệu gốc chuẩn / người dịch (đáng tin cậy) — mặc định
--   'ai_translated' : máy dịch tự động, chưa kiểm duyệt
--   'reviewed'      : đã được con người kiểm duyệt / sửa lại
--
-- An toàn:
--   * Chỉ dùng ALTER TABLE ... ADD COLUMN (SQLite gán DEFAULT cho mọi dòng cũ,
--     không rebuild bảng, không đụng khoá ngoại, không xoá dữ liệu).
--   * KHÔNG chạm các bảng tiến trình: flashcard_progress, test_history,
--     cat_care_state, vocabulary_cache.
--   * Toàn bộ chạy trong 1 transaction; lỗi -> rollback, DB giữ nguyên v2.
--   * Bản trong app (LocalDatabaseService.migrateToV3) kiểm tra PRAGMA table_info
--     trước mỗi ALTER nên chạy lại nhiều lần vẫn an toàn. File SQL thuần này chỉ
--     dành cho DB đang ở user_version = 2 (SQLite không hỗ trợ ADD COLUMN IF NOT EXISTS).
--
-- Chạy tay (sqlite3 CLI):
--   sqlite3 nihongo_master.db "PRAGMA user_version;"   -- phải là 2
--   sqlite3 nihongo_master.db < tools/migrations/v3_translation_status.sql
-- =============================================================================

BEGIN TRANSACTION;

ALTER TABLE vocabularies ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  CHECK (translation_status IN ('source', 'ai_translated', 'reviewed'));

ALTER TABLE kanji_entries ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  CHECK (translation_status IN ('source', 'ai_translated', 'reviewed'));

ALTER TABLE grammar_points ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  CHECK (translation_status IN ('source', 'ai_translated', 'reviewed'));

ALTER TABLE example_sentences ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  CHECK (translation_status IN ('source', 'ai_translated', 'reviewed'));

ALTER TABLE reading_materials ADD COLUMN translation_status TEXT NOT NULL DEFAULT 'source'
  CHECK (translation_status IN ('source', 'ai_translated', 'reviewed'));

CREATE TABLE IF NOT EXISTS dataset_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

PRAGMA user_version = 3;

COMMIT;

-- Kiểm tra sau migration:
--   SELECT translation_status, COUNT(*) FROM vocabularies GROUP BY translation_status;
--   SELECT COUNT(*) FROM flashcard_progress;   -- không đổi so với trước migration
