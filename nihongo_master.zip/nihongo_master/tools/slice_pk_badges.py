#!/usr/bin/env python3
"""
Tự động tách nền trắng (#FFFFFF / gần trắng) sang Alpha trong suốt
và cắt chuẩn xác 10 huy hiệu PK từ sprite sheet `assets/images/pk/pk_badges_sheet_raw.png`.
"""

from collections import deque
from pathlib import Path
import sys
from PIL import Image

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


TOP_ROW_NAMES = [
    "badge_shield_cat.png",
    "badge_trophy_cat.png",
    "badge_defeat_ghost.png",
]

BOTTOM_ROW_NAMES = [
    "rank_01_bronze.png",
    "rank_02_silver.png",
    "rank_03_gold.png",
    "rank_04_purple.png",
    "rank_05_diamond.png",
    "rank_06_master.png",
    "rank_07_mythic.png",
]


def is_near_white(r: int, g: int, b: int, threshold: int = 242) -> bool:
    return r >= threshold and g >= threshold and b >= threshold


def remove_white_background(img: Image.Image) -> Image.Image:
    """
    Chuyển nền trắng tinh (#FFFFFF / gần trắng) thành trong suốt (Alpha = 0)
    bằng thuật toán flood-fill từ biên ngoài + lỗ quai cúp, bảo toàn tuyệt đối
    màu trắng bên trong mặt mèo ma, dấu chân mèo và cánh thiên thần.
    """
    rgba = img.convert("RGBA")
    width, height = rgba.size
    pixels = rgba.load()

    visited = [[False] * width for _ in range(height)]
    is_bg = [[False] * width for _ in range(height)]
    queue: deque[tuple[int, int]] = deque()

    # 1. Khởi tạo hạt giống từ 4 cạnh biên của bức ảnh
    for x in range(width):
        for y in (0, height - 1):
            r, g, b, _ = pixels[x, y]
            if is_near_white(r, g, b):
                visited[y][x] = True
                is_bg[y][x] = True
                queue.append((x, y))

    for y in range(height):
        for x in (0, width - 1):
            if not visited[y][x]:
                r, g, b, _ = pixels[x, y]
                if is_near_white(r, g, b):
                    visited[y][x] = True
                    is_bg[y][x] = True
                    queue.append((x, y))

    # 2. BFS loang toàn bộ nền trắng bên ngoài
    dirs = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)]
    while queue:
        cx, cy = queue.popleft()
        for dx, dy in dirs:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < width and 0 <= ny < height and not visited[ny][nx]:
                r, g, b, _ = pixels[nx, ny]
                if is_near_white(r, g, b):
                    visited[ny][nx] = True
                    is_bg[ny][nx] = True
                    queue.append((nx, ny))

    # 3. Xử lý các lỗ nền trắng khép kín bên trong 2 quai cúp (badge_trophy_cat ở giữa hàng trên)
    # Quai cúp nằm trong vùng x: [0.34*W .. 0.66*W], y: [0.12*H .. 0.36*H]
    trophy_x0, trophy_x1 = int(width * 0.34), int(width * 0.66)
    trophy_y0, trophy_y1 = int(height * 0.12), int(height * 0.36)
    for sy in range(trophy_y0, trophy_y1):
        for sx in range(trophy_x0, trophy_x1):
            if not visited[sy][sx]:
                r, g, b, _ = pixels[sx, sy]
                if is_near_white(r, g, b, 248):
                    comp: list[tuple[int, int]] = []
                    q2: deque[tuple[int, int]] = deque([(sx, sy)])
                    visited[sy][sx] = True
                    while q2:
                        cx, cy = q2.popleft()
                        comp.append((cx, cy))
                        for dx, dy in dirs:
                            nx, ny = cx + dx, cy + dy
                            if (
                                trophy_x0 <= nx < trophy_x1
                                and trophy_y0 <= ny < trophy_y1
                                and not visited[ny][nx]
                            ):
                                nr, ng, nb, _ = pixels[nx, ny]
                                if is_near_white(nr, ng, nb, 242):
                                    visited[ny][nx] = True
                                    q2.append((nx, ny))
                    # Lỗ quai cúp có diện tích vừa phải (từ 300 đến 25000 px)
                    if 300 <= len(comp) <= 25000:
                        for px, py in comp:
                            is_bg[py][px] = True

    # 4. Áp dụng Alpha = 0 cho nền và làm mượt viền (anti-aliased edge feathering)
    for y in range(height):
        for x in range(width):
            if is_bg[y][x]:
                pixels[x, y] = (255, 255, 255, 0)

    for y in range(1, height - 1):
        for x in range(1, width - 1):
            if not is_bg[y][x]:
                r, g, b, a = pixels[x, y]
                if r >= 225 and g >= 225 and b >= 225:
                    touches_bg = any(
                        is_bg[y + dy][x + dx] for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1))
                    )
                    if touches_bg:
                        lum = (r + g + b) / 3.0
                        new_alpha = int(max(0.0, min(1.0, (250.0 - lum) / 30.0)) * a)
                        pixels[x, y] = (r, g, b, new_alpha)

    return rgba


def find_badge_bboxes(
    rgba: Image.Image, min_area: int = 1200, merge_gap: int = 12
) -> list[tuple[int, int, int, int]]:
    """
    Tìm các thành phần liên thông của các pixel không trong suốt (alpha > 16),
    sau đó gộp các chi tiết nhỏ rời (như chấm khói tím quanh mèo ma hoặc ngôi sao lấp lánh)
    vào huy hiệu gần nhất.
    """
    width, height = rgba.size
    alpha = rgba.getchannel("A")
    a_pixels = alpha.load()

    visited = [[False] * width for _ in range(height)]
    raw_boxes: list[tuple[int, int, int, int, int]] = []
    dirs = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)]

    for y in range(height):
        for x in range(width):
            if not visited[y][x] and a_pixels[x, y] > 16:
                q: deque[tuple[int, int]] = deque([(x, y)])
                visited[y][x] = True
                x0 = x1 = x
                y0 = y1 = y
                count = 0
                while q:
                    cx, cy = q.popleft()
                    count += 1
                    if cx < x0:
                        x0 = cx
                    if cx > x1:
                        x1 = cx
                    if cy < y0:
                        y0 = cy
                    if cy > y1:
                        y1 = cy
                    for dx, dy in dirs:
                        nx, ny = cx + dx, cy + dy
                        if 0 <= nx < width and 0 <= ny < height and not visited[ny][nx]:
                            if a_pixels[nx, ny] > 16:
                                visited[ny][nx] = True
                                q.append((nx, ny))
                if count >= 25:
                    raw_boxes.append((x0, y0, x1 + 1, y1 + 1, count))

    # Gộp các mảnh nhỏ (như chấm khói cạnh mèo ma) vào các cụm chính lớn
    major = [list(b[:4]) for b in raw_boxes if b[4] >= min_area]
    minor = [b[:4] for b in raw_boxes if b[4] < min_area]

    for mx0, my0, mx1, my1 in minor:
        mcx = (mx0 + mx1) / 2.0
        mcy = (my0 + my1) / 2.0
        best_idx = -1
        best_dist = 1e18
        for idx, (bx0, by0, bx1, by1) in enumerate(major):
            # Tính khoảng cách tới hình chữ nhật major[idx]
            dx = max(bx0 - mcx, 0.0, mcx - bx1)
            dy = max(by0 - mcy, 0.0, mcy - by1)
            dist = dx * dx + dy * dy
            if dist < best_dist:
                best_dist = dist
                best_idx = idx
        if best_idx >= 0 and best_dist <= (merge_gap * 4) ** 2:
            major[best_idx][0] = min(major[best_idx][0], mx0)
            major[best_idx][1] = min(major[best_idx][1], my0)
            major[best_idx][2] = max(major[best_idx][2], mx1)
            major[best_idx][3] = max(major[best_idx][3], my1)

    return [tuple(b) for b in major]


def crop_row_badges(
    rgba: Image.Image, row_bboxes: list[tuple[int, int, int, int]], pad: int = 2
) -> list[Image.Image]:
    width, height = rgba.size
    results: list[Image.Image] = []
    n = len(row_bboxes)
    for i, (x0, y0, x1, y1) in enumerate(row_bboxes):
        min_x = 0 if i == 0 else (row_bboxes[i - 1][2] + x0) // 2
        max_x = width if i == n - 1 else (x1 + row_bboxes[i + 1][0]) // 2
        cx0 = max(min_x, max(0, x0 - pad))
        cy0 = max(0, y0 - pad)
        cx1 = min(max_x, min(width, x1 + pad))
        cy1 = min(height, y1 + pad)
        results.append(rgba.crop((cx0, cy0, cx1, cy1)))
    return results


def main() -> None:
    project_root = Path(__file__).resolve().parent.parent
    raw_sheet_path = project_root / "assets" / "images" / "pk" / "pk_badges_sheet_raw.png"
    out_dir = project_root / "assets" / "images" / "pk"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not raw_sheet_path.exists():
        raise FileNotFoundError(f"Không tìm thấy ảnh gốc: {raw_sheet_path}")

    print(f"Đang đọc sprite sheet: {raw_sheet_path}")
    raw_img = Image.open(raw_sheet_path)
    clean_rgba = remove_white_background(raw_img)

    bboxes = find_badge_bboxes(clean_rgba, min_area=5000, merge_gap=20)
    if len(bboxes) != 10:
        raise RuntimeError(f"Kỳ vọng tìm thấy 10 huy hiệu nhưng phát hiện {len(bboxes)}: {bboxes}")

    mid_y = clean_rgba.height * 0.54
    top_row = sorted([b for b in bboxes if (b[1] + b[3]) / 2.0 < mid_y], key=lambda b: b[0])
    bottom_row = sorted([b for b in bboxes if (b[1] + b[3]) / 2.0 >= mid_y], key=lambda b: b[0])

    if len(top_row) != 3 or len(bottom_row) != 7:
        raise RuntimeError(
            f"Phân hàng không khớp: Hàng trên={len(top_row)} (cần 3), Hàng dưới={len(bottom_row)} (cần 7)"
        )

    top_crops = crop_row_badges(clean_rgba, top_row, pad=2)
    for name, cropped, bbox in zip(TOP_ROW_NAMES, top_crops, top_row):
        out_path = out_dir / name
        cropped.save(out_path, format="PNG")
        print(f"Đã lưu [Hàng trên] {name}: size={cropped.size}, bbox={bbox}")

    bottom_crops = crop_row_badges(clean_rgba, bottom_row, pad=2)
    for name, cropped, bbox in zip(BOTTOM_ROW_NAMES, bottom_crops, bottom_row):
        out_path = out_dir / name
        cropped.save(out_path, format="PNG")
        print(f"Đã lưu [Hàng dưới] {name}: size={cropped.size}, bbox={bbox}")

    print("Hoàn tất tách nền và cắt 10 huy hiệu PK!")


if __name__ == "__main__":
    main()
