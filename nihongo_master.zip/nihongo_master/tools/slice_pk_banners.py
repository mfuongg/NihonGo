#!/usr/bin/env python3
"""
Script cắt đôi bức ảnh `assets/images/pk/pk_banners_raw.png` theo chiều dọc (Vertical Split):
- Nửa trên (0% -> 50% chiều cao): Lưu thành `assets/images/pk/pk_victory_banner.png`
- Nửa dưới (50% -> 100% chiều cao): Lưu thành `assets/images/pk/pk_defeat_banner.png`
Đồng thời tách nền caro xám trắng bên ngoài thành trong suốt (Transparent Alpha).
"""

from collections import deque
from pathlib import Path
import shutil
import sys
from PIL import Image

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def is_checkerboard_bg(r: int, g: int, b: int) -> bool:
    """
    Nhận diện pixel nền caro xám/trắng trung tính bên ngoài banner:
    Độ lệch màu giữa R, G, B nhỏ (neutral gray/white) và độ sáng cao (>= 185).
    """
    max_c = max(r, g, b)
    min_c = min(r, g, b)
    return min_c >= 185 and (max_c - min_c) <= 18


def clean_banner_half(half_img: Image.Image, pad: int = 6) -> Image.Image:
    """
    Loại bỏ nền caro xám/trắng từ biên ngoài bằng BFS flood-fill
    và crop gọn theo bounding box của banner.
    """
    rgba = half_img.convert("RGBA")
    width, height = rgba.size
    pixels = rgba.load()

    visited = [[False] * width for _ in range(height)]
    is_bg = [[False] * width for _ in range(height)]
    queue: deque[tuple[int, int]] = deque()

    for x in range(width):
        for y in (0, height - 1):
            r, g, b, _ = pixels[x, y]
            if is_checkerboard_bg(r, g, b):
                visited[y][x] = True
                is_bg[y][x] = True
                queue.append((x, y))

    for y in range(height):
        for x in (0, width - 1):
            if not visited[y][x]:
                r, g, b, _ = pixels[x, y]
                if is_checkerboard_bg(r, g, b):
                    visited[y][x] = True
                    is_bg[y][x] = True
                    queue.append((x, y))

    dirs = [(-1, 0), (1, 0), (0, -1), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)]
    while queue:
        cx, cy = queue.popleft()
        for dx, dy in dirs:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < width and 0 <= ny < height and not visited[ny][nx]:
                r, g, b, _ = pixels[nx, ny]
                if is_checkerboard_bg(r, g, b):
                    visited[ny][nx] = True
                    is_bg[ny][nx] = True
                    queue.append((nx, ny))

    for y in range(height):
        for x in range(width):
            if is_bg[y][x]:
                pixels[x, y] = (255, 255, 255, 0)

    # Làm mềm viền tiếp giáp nền
    for y in range(1, height - 1):
        for x in range(1, width - 1):
            if not is_bg[y][x]:
                r, g, b, a = pixels[x, y]
                if is_checkerboard_bg(r, g, b):
                    touches_bg = any(
                        is_bg[y + dy][x + dx] for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1))
                    )
                    if touches_bg:
                        pixels[x, y] = (r, g, b, int(a * 0.35))

    bbox = rgba.getbbox()
    if not bbox:
        return rgba

    x0, y0, x1, y1 = bbox
    cx0 = max(0, x0 - pad)
    cy0 = max(0, y0 - pad)
    cx1 = min(width, x1 + pad)
    cy1 = min(height, y1 + pad)
    return rgba.crop((cx0, cy0, cx1, cy1))


def main() -> None:
    project_root = Path(__file__).resolve().parent.parent
    pk_dir = project_root / "assets" / "images" / "pk"
    raw_path = pk_dir / "pk_banners_raw.png"
    fallback_uuid_path = pk_dir / "d442cc68-548b-4cc2-8bc2-b16935232501.png"

    if not raw_path.exists() and fallback_uuid_path.exists():
        shutil.copyfile(fallback_uuid_path, raw_path)
        print(f"Đã chuẩn hóa tên file gốc sang: {raw_path}")

    if not raw_path.exists():
        raise FileNotFoundError(f"Không tìm thấy file ảnh gốc: {raw_path}")

    img = Image.open(raw_path)
    width, height = img.size
    mid_y = height // 2

    # 1. Cắt đôi theo chiều dọc: 0% -> 50% (Victory) và 50% -> 100% (Defeat)
    top_half = img.crop((0, 0, width, mid_y))
    bottom_half = img.crop((0, mid_y, width, height))

    victory_banner = clean_banner_half(top_half, pad=6)
    defeat_banner = clean_banner_half(bottom_half, pad=6)

    victory_out = pk_dir / "pk_victory_banner.png"
    defeat_out = pk_dir / "pk_defeat_banner.png"

    victory_banner.save(victory_out, format="PNG")
    defeat_banner.save(defeat_out, format="PNG")

    print(f"Đã lưu nửa trên (0%->50%): {victory_out} (size={victory_banner.size})")
    print(f"Đã lưu nửa dưới (50%->100%): {defeat_out} (size={defeat_banner.size})")


if __name__ == "__main__":
    main()
