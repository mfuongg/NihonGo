import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:nihongo_master/data/grammar_data.dart';
import 'package:nihongo_master/data/kanji_data.dart';
import 'package:nihongo_master/data/reading_material_data.dart';
import 'package:nihongo_master/data/vocabulary_data.dart';
import 'package:nihongo_master/models/grammar.dart';
import 'package:nihongo_master/models/kanji.dart';
import 'package:nihongo_master/models/reading_material.dart';
import 'package:nihongo_master/models/vocabulary.dart';
import 'package:nihongo_master/providers/flashcard_provider.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/providers/vocabulary_provider.dart';
import 'package:nihongo_master/screens/grammar/grammar_screen.dart';
import 'package:nihongo_master/screens/lab/ai_practice_lab_screen.dart';
import 'package:nihongo_master/screens/lab/quang_thuong_tutor_screen.dart';
import 'package:nihongo_master/screens/read/read_screen.dart';
import 'package:nihongo_master/screens/vocabulary/pronunciation_practice_screen.dart';
import 'package:nihongo_master/screens/vocabulary/vocabulary_screen.dart';
import 'package:nihongo_master/screens/vocabulary/writing_practice_screen.dart';
import 'package:nihongo_master/services/ai_practice_evaluator.dart';
import 'package:nihongo_master/services/gemini_exam_service.dart';
import 'package:nihongo_master/widgets/app_asset_icon.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    VocabularyData.setLoadedWords(<VocabularyWord>[
      VocabularyWord(
        id: 'v_n5_1',
        japanese: '先生',
        hiragana: 'せんせい',
        romaji: 'sensei',
        vietnamese: 'giáo viên, thầy cô',
        english: 'teacher',
        jlptLevel: 'N5',
        category: 'Trường học',
        exampleSentences: const <String>['先生はやさしいです。'],
        exampleTranslations: const <String>['Thầy giáo rất hiền.'],
      ),
      VocabularyWord(
        id: 'v_n5_2',
        japanese: '学校',
        hiragana: 'がっこう',
        romaji: 'gakkou',
        vietnamese: 'trường học',
        english: 'school',
        jlptLevel: 'N5',
        category: 'Trường học',
      ),
      VocabularyWord(
        id: 'v_n4_1',
        japanese: '約束',
        hiragana: 'やくそく',
        romaji: 'yakusoku',
        vietnamese: 'lời hứa, cuộc hẹn',
        english: 'promise',
        jlptLevel: 'N4',
        category: 'Giao tiếp',
      ),
    ]);
    KanjiData.setLoadedKanji(<KanjiItem>[
      KanjiItem(
        id: 'k_n5_1',
        kanji: '日',
        onyomi: 'ニチ',
        kunyomi: 'ひ',
        vietnamese: 'NHẬT - mặt trời, ngày',
        english: 'sun, day',
        strokeCount: 4,
        jlptLevel: 'N5',
        exampleWords: const <String>['日本', '毎日'],
      ),
      KanjiItem(
        id: 'k_n4_1',
        kanji: '族',
        onyomi: 'ゾク',
        kunyomi: '',
        vietnamese: 'TỘC - gia tộc, họ hàng',
        english: 'family, tribe',
        strokeCount: 11,
        jlptLevel: 'N4',
        exampleWords: const <String>['家族'],
      ),
    ]);
    GrammarData.setLoadedLessons(<GrammarLesson>[
      GrammarLesson(
        id: 'g_n5_1',
        title: 'Trợ từ は và が',
        titleVi: 'Cách dùng trợ từ は và が',
        pattern: 'N1 は N2 です',
        formation: 'Danh từ 1 + は + Danh từ 2 + です',
        explanation: 'Trợ từ đánh dấu chủ đề câu.',
        explanationVi: 'Trợ từ は đánh dấu chủ đề của câu tiếng Nhật.',
        jlptLevel: 'N5',
        examples: const <ExampleSentence>[],
      ),
    ]);
  });

  tearDown(() {
    GeminiExamService.instance.configureForTesting();
  });

  test('All 16 AI Practice Lab & Tutor icons exist on disk and are valid PNGs', () {
    expect(AppAssets.aiLabIcons.length, 16);
    for (final relPath in AppAssets.aiLabIcons) {
      final file = File(relPath);
      expect(file.existsSync(), isTrue, reason: 'Missing icon file: $relPath');
      expect(file.lengthSync(), greaterThan(200), reason: 'Empty icon: $relPath');
    }
  });

  test('AiPracticeEvaluator distinguishes OCR, Stroke Check, and Typed Answer without claiming 100% OCR on stroke_layout', () {
    final word = VocabularyWord(
      id: 'k_n4_1',
      japanese: '族',
      hiragana: 'ぞく',
      romaji: 'zoku',
      vietnamese: 'gia tộc',
      english: 'family',
      jlptLevel: 'N4',
      category: 'Kanji',
    );

    // Looks up real stroke count (11) from KanjiData
    expect(AiPracticeEvaluator.expectedStrokeCountForWord(word), 11);

    final wordN5 = VocabularyWord(
      id: 'k_n5_1',
      japanese: '日',
      hiragana: 'ひ',
      romaji: 'hi',
      vietnamese: 'mặt trời',
      english: 'sun',
      jlptLevel: 'N5',
      category: 'Kanji',
    );

    final strokeResult = AiPracticeEvaluator.evaluateWritingStrokes(
      word: wordN5,
      strokes: const <List<Offset>>[
        <Offset>[Offset(60, 60), Offset(60, 220)],
        <Offset>[Offset(60, 60), Offset(220, 60), Offset(220, 220)],
        <Offset>[Offset(60, 140), Offset(220, 140)],
        <Offset>[Offset(60, 220), Offset(220, 220)],
      ],
      canvasSize: const Size(280, 280),
      explicitStrokeCount: 4,
    );
    expect(strokeResult.evaluationMode, 'stroke_layout');
    expect(strokeResult.isCorrect, isTrue);
    expect(strokeResult.score, lessThanOrEqualTo(0.85));
    expect(strokeResult.feedback, contains('chưa nhận diện mặt chữ'));

    final typedResult = AiPracticeEvaluator.evaluateWriting(
      word: wordN5,
      recognizedText: 'ひ',
      evaluationMode: 'typed_answer',
    );
    expect(typedResult.evaluationMode, 'typed_answer');
    expect(typedResult.isCorrect, isTrue);
  });

  test('GeminiExamService SQLite RAG filters by JLPT level, handles empty/no-match queries, and handles HTTP 200/401/429/503', () async {
    // 1. Empty query must return empty RAG list
    final emptyRag = await GeminiExamService.instance.retrieveTutorSqliteItems(
      query: '   ',
      level: 'N5',
    );
    expect(emptyRag, isEmpty);

    // 2. Non-existent term must return empty RAG list (no fake/unrelated fallback items)
    final noMatchRag = await GeminiExamService.instance.retrieveTutorSqliteItems(
      query: 'từ xyz999khôngtồntại nghĩa là gì',
      level: 'N5',
    );
    expect(noMatchRag, isEmpty);

    // 3. Explicit JLPT level in query (N4) must only return N4 items
    final n4KanjiRag = await GeminiExamService.instance.retrieveTutorSqliteItems(
      query: 'Tra cứu Kanji N4',
      level: 'N5',
    );
    expect(n4KanjiRag, isNotEmpty);
    expect(n4KanjiRag.every((item) => item.level == 'N4'), isTrue);
    expect(n4KanjiRag.first.titleJp, '族');

    // 4. Online Gemini response (HTTP 200)
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'test_key',
      httpPostOverride: (uri, headers, body) async {
        expect(headers['Content-Type'], contains('charset=utf-8'));
        return GeminiHttpResponse(
          statusCode: 200,
          body: jsonEncode(<String, Object?>{
            'candidates': <Object?>[
              <String, Object?>{
                'content': <String, Object?>{
                  'parts': <Object?>[
                    <String, Object?>{
                      'text': 'Meow! Từ 先生 (せんせい) nghĩa là giáo viên nhé con sen!',
                    },
                  ],
                },
              },
            ],
          }),
        );
      },
    );

    final onlineRes = await GeminiExamService.instance.askQuangThuongTutor(
      query: 'Giải thích từ 先生',
      level: 'N5',
    );
    expect(onlineRes.isAiOnline, isTrue);
    expect(onlineRes.retrievedSqliteItems, isNotEmpty);
    expect(onlineRes.retrievedSqliteItems.first.titleJp, '先生');
    expect(onlineRes.aiGeneratedExplanation, contains('せんせい'));

    // 5. Authentication error (HTTP 401)
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'bad_key',
      httpPostOverride: (uri, headers, body) async {
        return const GeminiHttpResponse(statusCode: 401, body: 'Unauthorized');
      },
    );
    final authErrRes = await GeminiExamService.instance.askQuangThuongTutor(
      query: 'Kanji 日 bao nhiêu nét?',
      level: 'N5',
    );
    expect(authErrRes.isAiOnline, isFalse);
    expect(authErrRes.aiGeneratedExplanation, isNull);
    expect(authErrRes.errorMessage, contains('401'));
    expect(authErrRes.retrievedSqliteItems.first.titleJp, '日');

    // 6. Rate-limit error (HTTP 429)
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'test_key',
      httpPostOverride: (uri, headers, body) async {
        return const GeminiHttpResponse(statusCode: 429, body: 'Too Many Requests');
      },
    );
    final quotaErrRes = await GeminiExamService.instance.askQuangThuongTutor(
      query: 'Kanji 日 bao nhiêu nét?',
      level: 'N5',
    );
    expect(quotaErrRes.isAiOnline, isFalse);
    expect(quotaErrRes.errorMessage, contains('429'));
  });

  test('Adaptive Quests track real learning progress, persist across restarts, and prevent duplicate reward claims', () async {
    final provider = ProgressProvider();
    await provider.init();

    var quests = provider.getAdaptiveQuests(levelOverride: 'N5');
    expect(quests.length, 5);
    final readingQuest = quests.firstWhere((q) => q.skillType == 'reading');
    expect(readingQuest.status, 'not_started');

    // Learn a real N4 word and verify N4 vocab quest advances while N5 vocab quest stays 0
    provider.markVocabLearned('v_n4_1');
    final xpAfterFirstVocab = provider.progress.totalXP;
    // Duplicate markVocabLearned on same ID must NOT increment quest progress or XP again
    provider.markVocabLearned('v_n4_1');
    expect(provider.progress.totalXP, xpAfterFirstVocab);
    expect(provider.progress.learnedVocabIds.length, 1);
    final n4VocabQuest = provider
        .getAdaptiveQuests(levelOverride: 'N4')
        .firstWhere((q) => q.skillType == 'vocab');
    expect(n4VocabQuest.currentProgress, 1);

    // Learn a real N5 Kanji and verify duplicate markKanjiLearned on same ID does NOT increment quest progress or XP again
    provider.markKanjiLearned('k_n5_1');
    final xpAfterFirstKanji = provider.progress.totalXP;
    provider.markKanjiLearned('k_n5_1');
    expect(provider.progress.totalXP, xpAfterFirstKanji);
    expect(provider.progress.learnedKanjiIds.length, 1);
    final n5KanjiQuest = provider
        .getAdaptiveQuests(levelOverride: 'N5')
        .firstWhere((q) => q.skillType == 'kanji');
    expect(n5KanjiQuest.currentProgress, 1);

    await provider.recordAdaptiveQuestProgress('reading', levelOverride: 'N5');
    quests = provider.getAdaptiveQuests(levelOverride: 'N5');
    final completedReading = quests.firstWhere((q) => q.skillType == 'reading');
    expect(completedReading.isCompleted, isTrue);
    expect(completedReading.status, 'completed');

    final xpBefore = provider.progress.totalXP;
    final coinsBefore = provider.progress.rawCoins;
    final claimedFirst = await provider.claimAdaptiveQuestReward(
      completedReading.id,
      levelOverride: 'N5',
    );
    expect(claimedFirst, isTrue);
    expect(provider.progress.totalXP, xpBefore + completedReading.xpReward);
    expect(provider.progress.rawCoins, coinsBefore + completedReading.coinReward);

    // Second claim attempt must be rejected
    final claimedSecond = await provider.claimAdaptiveQuestReward(
      completedReading.id,
      levelOverride: 'N5',
    );
    expect(claimedSecond, isFalse);

    // Re-initialize a new ProgressProvider to verify restart persistence
    final restartedProvider = ProgressProvider();
    await restartedProvider.init();
    final restoredReading = restartedProvider
        .getAdaptiveQuests(levelOverride: 'N5')
        .firstWhere((q) => q.skillType == 'reading');
    expect(restoredReading.isCompleted, isTrue);
    expect(restoredReading.isClaimed, isTrue);
    expect(
      await restartedProvider.claimAdaptiveQuestReward(
        restoredReading.id,
        levelOverride: 'N5',
      ),
      isFalse,
    );
  });

  testWidgets('WritingPracticeScreen checks typed answer, Undo/Clear, and restores in-progress session on reopen', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();

    Widget buildApp() {
      return MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: WritingPracticeScreen(
            level: 'N5',
            initialTargetType: 'kanji',
          ),
        ),
      );
    }

    await tester.pumpWidget(buildApp());
    await tester.pumpAndSettle();

    expect(find.textContaining('1 / 1 từ'), findsOneWidget);
    expect(find.text('日'), findsWidgets);

    // Enter typed answer 'ひ' and tap 'Kiểm tra kết quả'
    await tester.enterText(find.byType(TextField), 'ひ');
    await tester.pump();
    await tester.tap(find.text('Kiểm tra kết quả'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 3));

    expect(find.text('Kiểm tra đáp án nhập (Typed Check)'), findsOneWidget);
    expect(progressProvider.isKanjiLearned('k_n5_1'), isTrue);

    // Switch to 'Từ vựng (2)', advance to card 2/2, then rebuild from scratch to verify session restore
    await tester.tap(find.textContaining('Từ vựng'));
    await tester.pumpAndSettle();
    expect(find.textContaining('1 / 2 từ'), findsOneWidget);

    await tester.tap(find.text('Bỏ qua'));
    await tester.pumpAndSettle();
    expect(find.textContaining('2 / 2 từ'), findsOneWidget);

    // Unmount and reopen WritingPracticeScreen (vocab mode) to verify restored index (2 / 2 từ)
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 3));
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: WritingPracticeScreen(
            level: 'N5',
            initialTargetType: 'vocab',
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.textContaining('2 / 2 từ'), findsOneWidget);
    expect(find.textContaining('Đã khôi phục phiên đang làm dở'), findsOneWidget);
  });

  testWidgets('PronunciationPracticeScreen distinguishes TTS sample from speech recognition and supports non-AI self-practice', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: PronunciationPracticeScreen(level: 'N5'),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));

    expect(find.text('Tốc độ mẫu 0.5×'), findsOneWidget);
    expect(find.text('Tốc độ mẫu 1.0×'), findsOneWidget);
    expect(find.text('Tốc độ mẫu 1.5×'), findsOneWidget);

    // Confirm self-practice reading (non-AI mode)
    final selfPracticeBtn = find.text('Đã nghe mẫu & tự luyện đọc (Không chấm AI)');
    expect(selfPracticeBtn, findsOneWidget);
    await tester.ensureVisible(selfPracticeBtn);
    await tester.pump();
    await tester.tap(selfPracticeBtn);
    await tester.pump();
    await tester.pump(const Duration(seconds: 3));

    expect(find.text('Đã tự luyện đọc (Không chấm AI)'), findsOneWidget);
    // Verify no fake percentage badge is shown for self-practice
    expect(find.textContaining('Mức khớp'), findsNothing);
  });

  testWidgets('AiPracticeLabScreen and QuangThuongTutorScreen render, validate empty input, and retry cleanly after error', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final flashcardProvider = FlashcardProvider();
    final vocabProvider = VocabularyProvider();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<FlashcardProvider>.value(value: flashcardProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: AiPracticeLabScreen(initialLevel: 'N5'),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('AI Practice Lab'), findsOneWidget);
    expect(find.text('Luyện viết tiếng Nhật'), findsOneWidget);
    expect(find.text('Luyện đọc & Phát âm'), findsOneWidget);
    expect(find.text('Gia sư Quàng Thượng'), findsOneWidget);
    expect(find.textContaining('Ôn từ vựng cần củng cố'), findsOneWidget);

    // Navigate to QuangThuongTutorScreen
    await tester.tap(find.text('Gia sư Quàng Thượng'));
    await tester.pumpAndSettle();

    expect(find.text('Gia Sư Quàng Thượng'), findsWidgets);
    expect(find.text('Gửi'), findsOneWidget);
    // Send button is disabled when input is empty
    final sendBtnFinder = find.ancestor(
      of: find.text('Gửi'),
      matching: find.byWidgetPredicate((w) => w is ButtonStyleButton),
    );
    final sendButton = tester.widget<ButtonStyleButton>(sendBtnFinder.first);
    expect(sendButton.onPressed, isNull);

    // Simulate HTTP 503 failure first, then HTTP 200 on retry
    var callCount = 0;
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'test_key',
      httpPostOverride: (uri, headers, body) async {
        callCount++;
        if (callCount == 1) {
          return const GeminiHttpResponse(statusCode: 503, body: 'Service Unavailable');
        }
        return GeminiHttpResponse(
          statusCode: 200,
          body: jsonEncode(<String, Object?>{
            'candidates': <Object?>[
              <String, Object?>{
                'content': <String, Object?>{
                  'parts': <Object?>[
                    <String, Object?>{
                      'text': 'Lời giảng Gemini sau khi thử lại thành công!',
                    },
                  ],
                },
              },
            ],
          }),
        );
      },
    );

    await tester.enterText(find.byType(TextField), 'Giải thích từ 先生');
    await tester.pump();
    await tester.tap(find.text('Gửi'));
    await tester.pumpAndSettle();

    expect(find.text('Gửi lại'), findsOneWidget);
    expect(find.text('Giải thích từ 先生'), findsOneWidget);

    // Tap 'Gửi lại' and verify failed bubble is replaced without duplicating user bubble
    await tester.tap(find.text('Gửi lại'));
    await tester.pumpAndSettle();

    expect(find.text('Giải thích từ 先生'), findsOneWidget);
    expect(find.text('Lời giảng Gemini sau khi thử lại thành công!'), findsOneWidget);
    expect(find.text('Gửi lại'), findsNothing);
  });

  testWidgets('All 4 AI Practice Lab screens render without overflow across Small Phone, Normal Phone, Large Phone, Tablet, Desktop, and Landscape viewports', (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final flashcardProvider = FlashcardProvider();
    final vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();

    const viewports = <Size>[
      Size(320, 568),  // Small phone
      Size(390, 844),  // Normal phone
      Size(430, 932),  // Large phone
      Size(768, 1024), // Tablet
      Size(1280, 800), // Desktop / wide screen
      Size(640, 360),  // Landscape
    ];

    final screens = <Widget>[
      const AiPracticeLabScreen(initialLevel: 'N5'),
      const QuangThuongTutorScreen(),
      const WritingPracticeScreen(level: 'N5', initialTargetType: 'vocab'),
      const PronunciationPracticeScreen(level: 'N5'),
    ];

    for (final size in viewports) {
      tester.view.devicePixelRatio = 1.0;
      tester.view.physicalSize = size;

      for (final screen in screens) {
        await tester.pumpWidget(
          MultiProvider(
            providers: [
              ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
              ChangeNotifierProvider<FlashcardProvider>.value(value: flashcardProvider),
              ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
            ],
            child: MaterialApp(home: screen),
          ),
        );
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 300));
        expect(tester.takeException(), isNull, reason: 'Overflow or layout error on ${screen.runtimeType} at $size');
      }
    }

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 3));
  });

  testWidgets('GrammarScreen and ReadScreen deduplicate session quest progress and map unclassified Aozora reading to user JLPT level', (tester) async {
    tester.view.physicalSize = const Size(1440, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final progressProvider = ProgressProvider();
    await progressProvider.init();
    progressProvider.setSelectedLevel('N1');
    final settingsProvider = SettingsProvider();

    ReadingMaterialData.setLoadedMaterials(const <ReadingMaterial>[
      ReadingMaterial(
        id: 'aozora_test_1',
        originalLevel: null,
        level: 'Chưa phân cấp JLPT',
        category: 'Văn học cổ điển',
        title: 'Tôi là con mèo (Aozora)',
        titleVi: 'Tôi là con mèo (Aozora)',
        japaneseTitle: '吾輩は猫である',
        summary: 'Tác phẩm cổ điển Aozora Bunko.',
        preview: '吾輩は猫である。名前はまだ無い。',
        content: '吾輩は猫である。\n\n名前はまだ無い。',
        translationVi: 'Tôi là một con mèo. Tên thì vẫn chưa có.',
        translationEn: 'I am a cat. As yet I have no name.',
        estimatedMinutes: 5,
        tags: <String>['Aozora'],
      ),
    ]);

    // 1. Mount GrammarScreen: opening screen alone must NOT increment grammar quest
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: const MaterialApp(home: GrammarScreen()),
      ),
    );
    await tester.pumpAndSettle();

    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N5').firstWhere((q) => q.skillType == 'grammar').currentProgress,
      0,
    );

    // Tap the same N5 grammar lesson twice -> progress increments only once (to 1)
    await tester.tap(find.text('N1 は N2 です'));
    await tester.pumpAndSettle();
    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N5').firstWhere((q) => q.skillType == 'grammar').currentProgress,
      1,
    );
    Navigator.of(tester.element(find.byType(GrammarDetailScreen))).pop();
    await tester.pumpAndSettle();

    await tester.tap(find.text('N1 は N2 です'));
    await tester.pumpAndSettle();
    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N5').firstWhere((q) => q.skillType == 'grammar').currentProgress,
      1,
    );
    Navigator.of(tester.element(find.byType(GrammarDetailScreen))).pop();
    await tester.pumpAndSettle();

    // 2. Mount ReadScreen: opening screen alone must NOT increment N1 reading quest
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: const MaterialApp(
          key: ValueKey<String>('read_screen_app'),
          home: ReadScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N1').firstWhere((q) => q.skillType == 'reading').currentProgress,
      0,
    );

    // Tap unclassified Aozora reading twice -> maps to user's selectedLevel ('N1') and increments only once
    await tester.tap(find.text('Tôi là con mèo (Aozora)').first);
    await tester.pumpAndSettle();
    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N1').firstWhere((q) => q.skillType == 'reading').currentProgress,
      1,
    );
    Navigator.of(tester.element(find.byType(ReadDetailScreen))).pop();
    await tester.pumpAndSettle();

    await tester.tap(find.text('Tôi là con mèo (Aozora)').first);
    await tester.pumpAndSettle();
    expect(
      progressProvider.getAdaptiveQuests(levelOverride: 'N1').firstWhere((q) => q.skillType == 'reading').currentProgress,
      1,
    );
  });

  test('Phase 5.2 — Japanese question normalization & SQLite retrieval (Tests 1-7: exact, natural JP question, reading, English meaning, no-match, offline Gemini)', () async {
    final service = GeminiExamService.instance;
    // Ensure Gemini is disconnected (no API key, no proxy)
    service.configureForTesting(
      apiKeyOverride: '',
      proxyUrlOverride: '',
      httpPostOverride: null,
    );

    // Test 1: Query `学校` -> exact retrieval
    final cand1 = service.extractQueryCandidates('学校');
    expect(cand1, contains('学校'));
    final res1 = await service.askQuangThuongTutor(query: '学校', level: 'N5');
    expect(res1.retrievedSqliteItems, isNotEmpty);
    expect(res1.retrievedSqliteItems.first.titleJp, '学校');
    expect(res1.retrievedSqliteItems.first.itemId, 'v_n5_2');
    expect(res1.retrievedSqliteItems.first.level, 'N5');
    expect(res1.sqliteSummaryAnswer, contains('学校（がっこう）'));
    expect(res1.sqliteSummaryAnswer, contains('Nghĩa tiếng Việt: trường học'));
    expect(res1.sqliteSummaryAnswer, contains('Nguồn: SQLite Tra Cứu Chuẩn'));

    // Test 2: Query `日本語の「学校」はどういう意味ですか？` -> extracts `学校`, retrieves record, not no-match
    final cand2 = service.extractQueryCandidates('日本語の「学校」はどういう意味ですか？');
    expect(cand2.first, '学校');
    expect(cand2, isNot(contains('日本語')));
    expect(cand2, isNot(contains('意味')));
    final res2 = await service.askQuangThuongTutor(
      query: '日本語の「学校」はどういう意味ですか？',
      level: 'N5',
    );
    expect(res2.retrievedSqliteItems, isNotEmpty);
    expect(res2.retrievedSqliteItems.first.titleJp, '学校');
    expect(res2.retrievedSqliteItems.first.itemId, 'v_n5_2');
    expect(res2.sqliteSummaryAnswer, contains('学校（がっこう）'));
    expect(res2.sqliteSummaryAnswer, contains('Nghĩa tiếng Việt: trường học'));
    expect(res2.sqliteSummaryAnswer, contains('Nguồn: SQLite Tra Cứu Chuẩn'));
    expect(res2.sqliteSummaryAnswer, isNot(contains('Không tìm thấy')));

    // Test 3: Query `学校の意味を教えて` -> recognizes keyword `学校`, queries SQLite
    final cand3 = service.extractQueryCandidates('学校の意味を教えて');
    expect(cand3.first, '学校');
    final res3 = await service.askQuangThuongTutor(
      query: '学校の意味を教えて',
      level: 'N5',
    );
    expect(res3.retrievedSqliteItems, isNotEmpty);
    expect(res3.retrievedSqliteItems.first.titleJp, '学校');
    expect(res3.sqliteSummaryAnswer, contains('学校（がっこう）'));

    // Test 4: Query `がっこう` -> retrieves by reading (`reading_hiragana`)
    final cand4 = service.extractQueryCandidates('がっこう');
    expect(cand4, contains('がっこう'));
    final res4 = await service.askQuangThuongTutor(
      query: 'がっこう',
      level: 'N5',
    );
    expect(res4.retrievedSqliteItems, isNotEmpty);
    expect(res4.retrievedSqliteItems.first.titleJp, '学校');
    expect(res4.retrievedSqliteItems.first.hiragana, 'がっこう');

    // Test 5: Query `school` -> retrieves by English meaning (`meaning_en`)
    final cand5 = service.extractQueryCandidates('school');
    expect(cand5, contains('school'));
    final res5 = await service.askQuangThuongTutor(
      query: 'school',
      level: 'N5',
    );
    expect(res5.retrievedSqliteItems, isNotEmpty);
    expect(res5.retrievedSqliteItems.first.titleJp, '学校');
    expect(res5.retrievedSqliteItems.first.meaningEn, 'school');

    // Test 6: Non-existent query -> transparent no-match, no fake meaning, no crash
    final res6 = await service.askQuangThuongTutor(
      query: '日本語の「宇宙エレベーター量子触媒999」はどういう意味ですか？',
      level: 'N5',
    );
    expect(res6.retrievedSqliteItems, isEmpty);
    expect(res6.sqliteSummaryAnswer, contains('Không tìm thấy dữ liệu khớp'));
    expect(res6.sqliteSummaryAnswer, isNot(contains('trường học')));

    // Test 7: Gemini disconnected -> SQLite retrieval still works without requiring API key or showing fallback error
    expect(res2.isAiOnline, isFalse);
    expect(res2.aiGeneratedExplanation, isNull);
    expect(res2.errorMessage, isNull);

    // Cross-level check (Section 5): N4 word `約束` queried while on N5 keeps its real level `N4`
    final resCross = await service.askQuangThuongTutor(
      query: '日本語の「約束」はどういう意味ですか？',
      level: 'N5',
    );
    expect(resCross.retrievedSqliteItems, isNotEmpty);
    expect(resCross.retrievedSqliteItems.first.titleJp, '約束');
    expect(resCross.retrievedSqliteItems.first.level, 'N4');
    expect(resCross.sqliteSummaryAnswer, contains('N4 (khác cấp N5 đang chọn)'));
  });

  testWidgets('Phase 5.2 — Test 8 (Retry re-runs retrieval without duplicate bubbles) & Section 9 (Mở kho Từ vựng opens exact word detail)', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    // Start with a non-empty fixture that does NOT yet contain `学校` so first query returns no-match
    // without touching the on-disk SQLite database, then add `学校` and tap `Gửi lại`.
    VocabularyData.setLoadedWords(<VocabularyWord>[
      VocabularyWord(
        id: 'v_n5_1',
        japanese: '先生',
        hiragana: 'せんせい',
        romaji: 'sensei',
        vietnamese: 'giáo viên, thầy cô',
        english: 'teacher',
        jlptLevel: 'N5',
        category: 'Trường học',
      ),
    ]);
    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();
    final settingsProvider = SettingsProvider();

    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: '',
      proxyUrlOverride: '',
      httpPostOverride: null,
    );

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: const MaterialApp(
          home: QuangThuongTutorScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    const naturalJpQuestion = '日本語の「学校」はどういう意味ですか？';
    await tester.enterText(find.byType(TextField), naturalJpQuestion);
    await tester.pump();
    await tester.tap(find.text('Gửi'));
    await tester.pumpAndSettle();

    // 1 user bubble + 1 assistant no-match bubble
    expect(find.text(naturalJpQuestion), findsOneWidget);
    expect(find.textContaining('Không tìm thấy dữ liệu khớp'), findsOneWidget);
    expect(find.text('Gửi lại'), findsOneWidget);

    // Safe navigation check when no record was found: tapping `Mở kho Từ vựng` opens list safely without detail sheet
    await tester.tap(find.text('Mở kho Từ vựng'));
    await tester.pumpAndSettle();
    expect(find.text('📖 Từ vựng'), findsOneWidget);
    expect(find.text('Đánh dấu đã học'), findsNothing);
    Navigator.of(tester.element(find.byType(VocabularyScreen))).pop();
    await tester.pumpAndSettle();

    // Now add `学校` (`v_n5_2`) to the test fixture so retry will find `学校`
    VocabularyData.setLoadedWords(<VocabularyWord>[
      VocabularyWord(
        id: 'v_n5_1',
        japanese: '先生',
        hiragana: 'せんせい',
        romaji: 'sensei',
        vietnamese: 'giáo viên, thầy cô',
        english: 'teacher',
        jlptLevel: 'N5',
        category: 'Trường học',
      ),
      VocabularyWord(
        id: 'v_n5_2',
        japanese: '学校',
        hiragana: 'がっこう',
        romaji: 'gakkou',
        vietnamese: 'trường học',
        english: 'school',
        jlptLevel: 'N5',
        category: 'Trường học',
      ),
    ]);

    // Tap `Gửi lại` -> must re-run SQLite retrieval and replace assistant bubble without duplicating user bubble
    await tester.tap(find.text('Gửi lại'));
    await tester.pumpAndSettle();

    expect(find.text(naturalJpQuestion), findsOneWidget);
    expect(find.textContaining('Không tìm thấy dữ liệu khớp'), findsNothing);
    expect(find.textContaining('学校（がっこう）'), findsOneWidget);
    expect(find.textContaining('Nghĩa tiếng Việt: trường học'), findsOneWidget);
    expect(find.textContaining('Nguồn: SQLite Tra Cứu Chuẩn'), findsOneWidget);

    // Section 9: Tap `Mở kho Từ vựng` -> must pass `v_n5_2` and open the exact word detail sheet
    final openVocabBtn = find.text('Mở kho Từ vựng');
    expect(openVocabBtn, findsOneWidget);
    await tester.tap(openVocabBtn);
    await tester.pumpAndSettle();

    // Verify `_WordDetailSheet` for `学校` is open
    expect(find.text('🇻🇳 Tiếng Việt'), findsOneWidget);
    expect(find.text('🇬🇧 English'), findsOneWidget);
    expect(find.text('Đánh dấu đã học'), findsOneWidget);
  });

  test('Phase 5.3 — Meaning fallback & status separation (Tests 1-7, 10, 11, 12)', () async {
    final service = GeminiExamService.instance;
    service.configureForTesting(
      apiKeyOverride: '',
      proxyUrlOverride: '',
      httpPostOverride: null,
    );

    // Test 1 — Vietnamese meaning available (`食べる` -> `ăn`)
    VocabularyData.setLoadedWords(<VocabularyWord>[
      VocabularyWord(
        id: 'vocab_n5_taberu',
        japanese: '食べる',
        hiragana: 'たべる',
        romaji: 'taberu',
        vietnamese: 'ăn',
        english: 'to eat',
        jlptLevel: 'N5',
        category: 'verbs',
      ),
      // Test 2 — English only (`学校`, `vocab_oj_n5_dd8ac16bd2`, Vietnamese: null/empty)
      VocabularyWord(
        id: 'vocab_oj_n5_dd8ac16bd2',
        japanese: '学校',
        hiragana: 'がっこう',
        romaji: 'gakkou',
        vietnamese: '',
        english: 'school',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      // Include `意味` in pool to verify Test 10 (no false meaning from `意味` when asking `日本語の「学校」はどういう意味ですか？`)
      VocabularyWord(
        id: 'vocab_oj_n5_cb29ccdd2a',
        japanese: '意味',
        hiragana: 'いみ',
        romaji: 'imi',
        vietnamese: '',
        english: 'meaning',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      // Test 3 — Vietnamese empty string (`''`)
      VocabularyWord(
        id: 'vocab_n5_empty_vi',
        japanese: '教室',
        hiragana: 'きょうしつ',
        romaji: 'kyoushitsu',
        vietnamese: '',
        english: 'classroom',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      // Test 4 — Vietnamese whitespace (`'   '`)
      VocabularyWord(
        id: 'vocab_n5_whitespace_vi',
        japanese: '図書館',
        hiragana: 'としょかん',
        romaji: 'toshokan',
        vietnamese: '   ',
        english: 'library',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      // Test 5 — Missing both meanings (`meaning_vi = null`, `meaning_en = null`)
      VocabularyWord(
        id: 'vocab_n5_missing_both',
        japanese: '黒板',
        hiragana: 'こくばん',
        romaji: 'kokuban',
        vietnamese: '',
        english: '',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      // Test 11 — Existing Vietnamese records regression (`今年`, `家族`, `乗り換える`)
      VocabularyWord(
        id: 'vocab_oj_n5_0037062666',
        japanese: '今年',
        hiragana: 'ことし',
        romaji: 'kotoshi',
        vietnamese: 'năm nay',
        english: 'this year',
        jlptLevel: 'N5',
        category: 'time',
      ),
      VocabularyWord(
        id: 'vocab_oj_n5_1c9db63bdc',
        japanese: '家族',
        hiragana: 'かぞく',
        romaji: 'kazoku',
        vietnamese: 'gia đình; người nhà',
        english: 'family, members of a family',
        jlptLevel: 'N5',
        category: 'family',
      ),
      VocabularyWord(
        id: 'vocab_oj_n4_001',
        japanese: '乗り換える',
        hiragana: 'のりかえる',
        romaji: 'norikaeru',
        vietnamese: 'đổi xe; chuyển tàu',
        english: 'to transfer (trains), to change (bus, train)',
        jlptLevel: 'N4',
        category: 'verbs',
      ),
    ]);

    // Verify Test 1: Vietnamese meaning available
    final res1 = await service.askQuangThuongTutor(query: '食べる', level: 'N5');
    expect(res1.isRetrievalSuccess, isTrue);
    expect(res1.retrievalStatus, TutorRetrievalStatus.success);
    expect(res1.primaryMeaningStatus, TutorMeaningStatus.available);
    expect(res1.retrievedSqliteItems.first.hasMeaningVi, isTrue);
    expect(res1.sqliteSummaryAnswer, contains('食べる（たべる）'));
    expect(res1.sqliteSummaryAnswer, contains('Romaji: taberu'));
    expect(res1.sqliteSummaryAnswer, contains('Nghĩa tiếng Việt: ăn'));
    expect(res1.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: to eat'));
    expect(res1.sqliteSummaryAnswer, contains('Nguồn: SQLite Tra Cứu Chuẩn'));
    expect(
      res1.sqliteSummaryAnswer,
      isNot(contains('Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.')),
    );

    // Verify Test 2 & Test 6 & Test 10: English only (`学校`) with Gemini offline on `日本語の「学校」はどういう意味ですか？`
    final res2 = await service.askQuangThuongTutor(
      query: '日本語の「学校」はどういう意味ですか？',
      level: 'N5',
    );
    expect(res2.isRetrievalSuccess, isTrue);
    expect(res2.retrievalStatus, TutorRetrievalStatus.successPartialMeaning);
    expect(res2.primaryMeaningStatus, TutorMeaningStatus.partialEnglishOnly);
    expect(res2.retrievedSqliteItems.first.itemId, 'vocab_oj_n5_dd8ac16bd2');
    expect(res2.retrievedSqliteItems.first.titleJp, '学校');
    expect(res2.retrievedSqliteItems.first.hiragana, 'がっこう');
    expect(res2.retrievedSqliteItems.first.hasMeaningVi, isFalse);
    expect(res2.retrievedSqliteItems.first.hasMeaningEn, isTrue);
    expect(res2.sqliteSummaryAnswer, contains('学校（がっこう）'));
    expect(res2.sqliteSummaryAnswer, contains('Romaji: gakkou'));
    expect(res2.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: school'));
    expect(
      res2.sqliteSummaryAnswer,
      contains('Nghĩa tiếng Việt: Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.'),
    );
    expect(res2.sqliteSummaryAnswer, contains('Nguồn: SQLite Tra Cứu Chuẩn'));
    expect(
      res2.sqliteSummaryAnswer,
      contains('Bạn có thể mở kho từ vựng để xem thông tin chi tiết.'),
    );
    expect(res2.sqliteSummaryAnswer, isNot(contains('Không tìm thấy')));
    // Test 10: No hardcoded Vietnamese meaning for `学校` and no false meaning from `意味`
    expect(res2.sqliteSummaryAnswer, isNot(contains('trường học')));
    expect(res2.sqliteSummaryAnswer, isNot(contains('meaning')));
    expect(res2.isAiOnline, isFalse);
    expect(res2.errorMessage, isNull);

    // Verify Test 3: Vietnamese empty string (`''`)
    final res3 = await service.askQuangThuongTutor(query: '教室', level: 'N5');
    expect(res3.retrievalStatus, TutorRetrievalStatus.successPartialMeaning);
    expect(res3.retrievedSqliteItems.first.hasMeaningVi, isFalse);
    expect(res3.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: classroom'));
    expect(
      res3.sqliteSummaryAnswer,
      contains('Nghĩa tiếng Việt: Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.'),
    );
    expect(res3.sqliteSummaryAnswer, isNot(contains('Nghĩa tiếng Việt: null')));
    expect(res3.sqliteSummaryAnswer, isNot(matches(RegExp(r'Nghĩa tiếng Việt:\s*$', multiLine: true))));

    // Verify Test 4: Vietnamese whitespace (`'   '`)
    final res4 = await service.askQuangThuongTutor(query: '図書館', level: 'N5');
    expect(res4.retrievalStatus, TutorRetrievalStatus.successPartialMeaning);
    expect(res4.retrievedSqliteItems.first.hasMeaningVi, isFalse);
    expect(res4.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: library'));
    expect(
      res4.sqliteSummaryAnswer,
      contains('Nghĩa tiếng Việt: Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.'),
    );
    expect(res4.sqliteSummaryAnswer, isNot(contains('Nghĩa tiếng Việt:    ')));

    // Verify Test 5: Missing both meanings (`meaning_vi = null`, `meaning_en = null`)
    final res5 = await service.askQuangThuongTutor(query: '黒板', level: 'N5');
    expect(res5.isRetrievalSuccess, isTrue);
    expect(res5.retrievalStatus, TutorRetrievalStatus.successNoMeaning);
    expect(res5.primaryMeaningStatus, TutorMeaningStatus.missingAll);
    expect(res5.retrievedSqliteItems.first.hasMeaningVi, isFalse);
    expect(res5.retrievedSqliteItems.first.hasMeaningEn, isFalse);
    expect(res5.sqliteSummaryAnswer, contains('黒板（こくばん）'));
    expect(res5.sqliteSummaryAnswer, contains('Romaji: kokuban'));
    expect(
      res5.sqliteSummaryAnswer,
      contains('Nghĩa: Bản ghi trong bộ dữ liệu hiện chưa có thông tin nghĩa tiếng Việt và tiếng Anh.'),
    );

    // Verify Test 7: Retrieval no-match (`これは存在しない単語12345`)
    final res7 = await service.askQuangThuongTutor(
      query: 'これは存在しない単語12345',
      level: 'N5',
    );
    expect(res7.isRetrievalSuccess, isFalse);
    expect(res7.retrievalStatus, TutorRetrievalStatus.noMatch);
    expect(res7.retrievedSqliteItems, isEmpty);
    expect(res7.sqliteSummaryAnswer, contains('Không tìm thấy dữ liệu khớp'));
    expect(res7.sqliteSummaryAnswer, isNot(contains('school')));
    expect(res7.sqliteSummaryAnswer, isNot(contains('ăn')));

    // Phase 5.4 additional query variations: unbracketed JP question, punctuation, whitespace, invalid query, HTTP 500
    final resUnbracketed = await service.askQuangThuongTutor(
      query: '学校の意味を教えて',
      level: 'N5',
    );
    expect(resUnbracketed.isRetrievalSuccess, isTrue);
    expect(resUnbracketed.retrievedSqliteItems.first.itemId, 'vocab_oj_n5_dd8ac16bd2');
    expect(resUnbracketed.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: school'));

    final resPunctWhitespace = await service.askQuangThuongTutor(
      query: '   「学校」！？   ',
      level: 'N5',
    );
    expect(resPunctWhitespace.isRetrievalSuccess, isTrue);
    expect(resPunctWhitespace.retrievedSqliteItems.first.itemId, 'vocab_oj_n5_dd8ac16bd2');

    final resInvalidPunct = await service.askQuangThuongTutor(
      query: '！？。---',
      level: 'N5',
    );
    expect(resInvalidPunct.isRetrievalSuccess, isFalse);
    expect(resInvalidPunct.retrievalStatus, TutorRetrievalStatus.invalidQuery);
    expect(resInvalidPunct.retrievedSqliteItems, isEmpty);

    service.configureForTesting(
      apiKeyOverride: 'test_key',
      httpPostOverride: (uri, headers, body) async => const GeminiHttpResponse(
        statusCode: 500,
        body: '{"error":"Internal Server Error"}',
      ),
    );
    final resHttp500 = await service.askQuangThuongTutor(
      query: '学校',
      level: 'N5',
    );
    expect(resHttp500.isAiOnline, isFalse);
    expect(resHttp500.isRetrievalSuccess, isTrue);
    expect(resHttp500.isDatabaseError, isFalse);
    expect(resHttp500.errorMessage, contains('HTTP 500'));
    expect(resHttp500.sqliteSummaryAnswer, contains('Nghĩa tiếng Anh: school'));

    service.configureForTesting(
      apiKeyOverride: '',
      proxyUrlOverride: '',
      httpPostOverride: null,
    );

    // Verify Test 11: Existing Vietnamese records regression
    final res11a = await service.askQuangThuongTutor(query: '今年', level: 'N5');
    expect(res11a.retrievalStatus, TutorRetrievalStatus.success);
    expect(res11a.sqliteSummaryAnswer, contains('Nghĩa tiếng Việt: năm nay'));
    expect(
      res11a.sqliteSummaryAnswer,
      isNot(contains('Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.')),
    );

    final res11b = await service.askQuangThuongTutor(query: '家族', level: 'N5');
    expect(res11b.retrievalStatus, TutorRetrievalStatus.success);
    expect(
      res11b.sqliteSummaryAnswer,
      contains('Nghĩa tiếng Việt: gia đình; người nhà'),
    );

    final res11c = await service.askQuangThuongTutor(
      query: '乗り換える',
      level: 'N4',
    );
    expect(res11c.retrievalStatus, TutorRetrievalStatus.success);
    expect(
      res11c.sqliteSummaryAnswer,
      contains('Nghĩa tiếng Việt: đổi xe; chuyển tàu'),
    );

    // Verify Test 12: Dataset integrity (`assets/data/verified_v2/`)
    final datasetDir = Directory('assets/data/verified_v2');
    expect(datasetDir.existsSync(), isTrue);
    final jsonFiles = datasetDir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.json'))
        .toList();
    expect(jsonFiles.length, 24);
    final vocabJsonFile = File('assets/data/verified_v2/vocabularies.json');
    final vocabList = jsonDecode(vocabJsonFile.readAsStringSync()) as List<dynamic>;
    expect(vocabList.length, 7811);
    final gakkouRecord = vocabList.cast<Map<String, dynamic>>().firstWhere(
          (r) => r['id'] == 'vocab_oj_n5_dd8ac16bd2',
        );
    expect(gakkouRecord['expression'], '学校');
    expect(gakkouRecord['reading_hiragana'], 'がっこう');
    expect(gakkouRecord['meaning_vi'], isNull);
    expect(gakkouRecord['meaning_en'], 'school');
  });

  testWidgets('Phase 5.3 — Tests 8 & 9: Tutor UI with English-only SQLite record (`学校`), Retry without duplicates, and Vocabulary detail sheet with null Vietnamese meaning', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    final gakkouEnglishOnly = VocabularyWord(
      id: 'vocab_oj_n5_dd8ac16bd2',
      japanese: '学校',
      hiragana: 'がっこう',
      romaji: 'gakkou',
      vietnamese: '',
      english: 'school',
      jlptLevel: 'N5',
      category: 'nouns',
      exampleSentences: const <String>['学校を出たあと、どうするつもり？'],
      exampleTranslations: const <String>['What are you going to do after leaving school?'],
    );

    VocabularyData.setLoadedWords(<VocabularyWord>[gakkouEnglishOnly]);
    final progressProvider = ProgressProvider();
    await progressProvider.init();
    final vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();
    final settingsProvider = SettingsProvider();

    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: '',
      proxyUrlOverride: '',
      httpPostOverride: null,
    );

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: const MaterialApp(
          home: QuangThuongTutorScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    const naturalJpQuestion = '日本語の「学校」はどういう意味ですか？';
    await tester.enterText(find.byType(TextField), naturalJpQuestion);
    await tester.pump();
    await tester.tap(find.text('Gửi'));
    await tester.pumpAndSettle();

    expect(find.text(naturalJpQuestion), findsOneWidget);
    expect(find.textContaining('学校（がっこう）'), findsOneWidget);
    expect(find.textContaining('Romaji: gakkou'), findsOneWidget);
    expect(find.textContaining('Nghĩa tiếng Anh: school'), findsOneWidget);
    expect(
      find.textContaining('Nghĩa tiếng Việt: Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.'),
      findsOneWidget,
    );
    expect(find.textContaining('Nguồn: SQLite Tra Cứu Chuẩn'), findsOneWidget);
    expect(find.textContaining('Không tìm thấy'), findsNothing);

    // Test 8: Retry re-runs retrieval and does not duplicate user or assistant bubble
    await tester.tap(find.text('Gửi lại'));
    await tester.pumpAndSettle();
    expect(find.text(naturalJpQuestion), findsOneWidget);
    expect(find.textContaining('学校（がっこう）'), findsOneWidget);

    final learnedBefore = progressProvider.progress.learnedVocabIds.length;
    final xpBefore = progressProvider.progress.totalXP;
    final coinsBefore = progressProvider.progress.rawCoins;

    // Test 9: Tap `Mở kho Từ vựng` -> opens `_WordDetailSheet` for `vocab_oj_n5_dd8ac16bd2` without crashing on empty Vietnamese meaning
    await tester.tap(find.text('Mở kho Từ vựng'));
    await tester.pumpAndSettle();

    expect(find.text('🇻🇳 Tiếng Việt'), findsOneWidget);
    expect(
      find.text('Bộ dữ liệu chưa có bản dịch tiếng Việt cho từ này.'),
      findsOneWidget,
    );
    expect(find.text('🇬🇧 English'), findsOneWidget);
    expect(find.text('school'), findsWidgets);
    expect(find.text('Đánh dấu đã học'), findsOneWidget);
    // Verify opening VocabularyScreen does not automatically write/mutate progress
    expect(progressProvider.progress.learnedVocabIds.length, learnedBefore);
    expect(progressProvider.progress.totalXP, xpBefore);
    expect(progressProvider.progress.rawCoins, coinsBefore);
    expect(tester.takeException(), isNull);

    // Phase 5.4.6: Opening VocabularyScreen with non-existent initialVocabId does not crash or open wrong word sheet
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: MaterialApp(
          key: UniqueKey(),
          home: const VocabularyScreen(
            initialLevel: 'N5',
            initialVocabId: 'vocab_nonexistent_99999',
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('🇻🇳 Tiếng Việt'), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
