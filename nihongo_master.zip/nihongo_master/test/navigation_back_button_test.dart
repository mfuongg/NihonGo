import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihongo_master/data/grammar_data.dart';
import 'package:nihongo_master/data/kanji_data.dart';
import 'package:nihongo_master/data/reading_material_data.dart';
import 'package:nihongo_master/data/vocabulary_data.dart';
import 'package:nihongo_master/models/grammar.dart';
import 'package:nihongo_master/models/kanji.dart';
import 'package:nihongo_master/models/reading_material.dart';
import 'package:nihongo_master/models/vocabulary.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/screens/dictionary/dictionary_screen.dart';
import 'package:nihongo_master/screens/grammar/grammar_screen.dart';
import 'package:nihongo_master/screens/kana/kana_screen.dart';
import 'package:nihongo_master/screens/read/read_screen.dart';
import 'package:nihongo_master/utils/theme.dart';
import 'package:nihongo_master/widgets/cozy_common_widgets.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    VocabularyData.setLoadedWords([
      VocabularyWord(
        id: 'vocab_test_1',
        japanese: '猫',
        hiragana: 'ねこ',
        romaji: 'neko',
        vietnamese: 'Con mèo',
        english: 'cat',
        jlptLevel: 'N5',
        category: 'general',
      ),
    ]);
    KanjiData.setLoadedKanji([
      KanjiItem(
        id: 'kanji_test_1',
        kanji: '猫',
        onyomi: 'ビョウ',
        kunyomi: 'ねこ',
        vietnamese: 'Miêu (con mèo)',
        english: 'cat',
        strokeCount: 11,
        jlptLevel: 'N5',
        exampleWords: const [],
        exampleReadings: const [],
        exampleMeanings: const [],
      ),
    ]);
    GrammarData.setLoadedLessons([
      GrammarLesson(
        id: 'gram_test_1',
        pattern: '〜は〜です',
        title: 'A là B',
        titleVi: 'A là B',
        titleEn: 'A is B',
        explanation: 'Dùng để khẳng định danh từ.',
        explanationVi: 'Dùng để khẳng định danh từ.',
        explanationEn: 'Polite copula.',
        jlptLevel: 'N5',
        examples: const [
          ExampleSentence(
            japanese: '私は学生です。',
            hiragana: 'わたしはがくせいです。',
            vietnamese: 'Tôi là học sinh.',
            english: 'I am a student.',
          ),
        ],
        notes: const ['Dùng trong văn phong lịch sự.'],
      ),
    ]);
    ReadingMaterialData.setLoadedMaterials(const [
      ReadingMaterial(
        id: 'read_test_1',
        title: 'Buổi sáng ở Tokyo',
        japaneseTitle: '東京の朝',
        level: 'N5',
        originalLevel: 'N5',
        category: 'Truyện đọc phân cấp',
        estimatedMinutes: 4,
        summary: 'Bài đọc ngắn N5 về buổi sáng.',
        preview: '朝六時に起きます。',
        content: '朝六時に起きます。\n\nコーヒーを飲みます。',
        translationVi: 'Tôi thức dậy lúc 6 giờ sáng. Tôi uống cà phê.',
        translationEn: 'I wake up at 6 AM. I drink coffee.',
        tags: ['N5', 'Đời sống'],
      ),
    ]);
  });

  testWidgets(
      '1. Root Route Rule: KanaScreen, GrammarScreen, ReadScreen, DictionaryScreen NEVER show Back button when mounted as root route',
      (WidgetTester tester) async {
    final settings = SettingsProvider();
    final rootScreens = <Widget>[
      const KanaScreen(),
      const GrammarScreen(),
      const ReadScreen(),
      const DictionaryScreen(),
    ];

    for (final screen in rootScreens) {
      await tester.pumpWidget(
        ChangeNotifierProvider<SettingsProvider>.value(
          value: settings,
          child: MaterialApp(
            theme: AppTheme.lightThemeFor(AppTheme.specFor('dusty_rose')),
            home: screen,
          ),
        ),
      );
      await tester.pumpAndSettle();

      // Must NOT show back button on a Root Route where Navigator.canPop is false
      expect(
        find.byKey(const Key('cozy_app_bar_back_button')),
        findsNothing,
        reason:
            '${screen.runtimeType} must not render a back button when it is the root route',
      );
      expect(
        find.byIcon(Icons.arrow_back_ios_new_rounded),
        findsNothing,
      );
    }
  });

  testWidgets(
      '2. Pushed Route Rule: Screens show Back button when pushed via Navigator.push and pop cleanly back to parent',
      (WidgetTester tester) async {
    final settings = SettingsProvider();
    final targetScreens = <MapEntry<String, Widget>>[
      const MapEntry('Kana', KanaScreen()),
      const MapEntry('Grammar', GrammarScreen()),
      const MapEntry('Read', ReadScreen()),
      const MapEntry('Dictionary', DictionaryScreen()),
    ];

    await tester.pumpWidget(
      ChangeNotifierProvider<SettingsProvider>.value(
        value: settings,
        child: MaterialApp(
          theme: AppTheme.lightThemeFor(AppTheme.specFor('dusty_rose')),
          home: Builder(
            builder: (context) => CozyScaffold(
              appBar: const CozyAppBar(
                title: 'Root Home',
                allowBack: false,
              ),
              body: Column(
                children: targetScreens
                    .map(
                      (entry) => ElevatedButton(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => entry.value),
                        ),
                        child: Text('Open ${entry.key}'),
                      ),
                    )
                    .toList(),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Root Home has no back button
    expect(find.byKey(const Key('cozy_app_bar_back_button')), findsNothing);

    for (final entry in targetScreens) {
      await tester.tap(find.text('Open ${entry.key}'));
      await tester.pumpAndSettle();

      // Pushed screen MUST show the Cozy back button
      expect(
        find.byKey(const Key('cozy_app_bar_back_button')),
        findsOneWidget,
        reason: 'Pushed ${entry.key} screen must display back button',
      );

      // Tapping back button pops cleanly back to Root Home
      await tester.tap(find.byKey(const Key('cozy_app_bar_back_button')));
      await tester.pumpAndSettle();
      expect(find.text('Root Home'), findsOneWidget);
      expect(find.byKey(const Key('cozy_app_bar_back_button')), findsNothing);
    }
  });

  testWidgets(
      '3. Theme Synchronization & Adaptive Layout across Kana, Grammar, Read, Dictionary and Detail screens',
      (WidgetTester tester) async {
    final settings = SettingsProvider();
    String activeThemeId = 'dusty_rose';
    late StateSetter setAppState;

    Widget buildTestable(Widget child) {
      return StatefulBuilder(
        builder: (context, setState) {
          setAppState = setState;
          return ChangeNotifierProvider<SettingsProvider>.value(
            value: settings,
            child: MaterialApp(
              key: ValueKey<Type>(child.runtimeType),
              theme: AppTheme.lightThemeFor(AppTheme.specFor(activeThemeId)),
              home: child,
            ),
          );
        },
      );
    }

    // Check GrammarScreen + GrammarDetailScreen
    await tester.pumpWidget(buildTestable(const GrammarScreen()));
    await tester.pumpAndSettle();

    Scaffold scaffold = tester.widget<Scaffold>(find.byType(Scaffold).first);
    expect(
      scaffold.backgroundColor,
      equals(AppTheme.specFor('dusty_rose').palette.background),
    );

    // Switch theme to Ocean Blue
    setAppState(() {
      activeThemeId = 'ocean_blue';
    });
    await tester.pumpAndSettle();
    scaffold = tester.widget<Scaffold>(find.byType(Scaffold).first);
    expect(
      scaffold.backgroundColor,
      equals(AppTheme.specFor('ocean_blue').palette.background),
    );

    // Tap into GrammarDetailScreen
    await tester.tap(find.text('〜は〜です'));
    await tester.pumpAndSettle();
    expect(find.text('Giải thích cách dùng'), findsOneWidget);
    expect(find.text('Tôi là học sinh.'), findsOneWidget);
    scaffold = tester.widget<Scaffold>(find.byType(Scaffold).last);
    expect(
      scaffold.backgroundColor,
      equals(AppTheme.specFor('ocean_blue').palette.background),
    );

    // Check DictionaryScreen search results (clean list with dividers)
    activeThemeId = 'white_sage';
    await tester.pumpWidget(buildTestable(const DictionaryScreen()));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField), 'neko');
    await tester.pumpAndSettle();
    expect(find.text('Con mèo'), findsOneWidget);
    scaffold = tester.widget<Scaffold>(find.byType(Scaffold).first);
    expect(
      scaffold.backgroundColor,
      equals(AppTheme.specFor('white_sage').palette.background),
    );

    // Check ReadDetailScreen article layout
    activeThemeId = 'sky_butter';
    await tester.pumpWidget(
      buildTestable(
        ReadDetailScreen(
          material: ReadingMaterialData.getAllMaterials().first,
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Bản dịch / Tóm tắt'), findsOneWidget);
    scaffold = tester.widget<Scaffold>(find.byType(Scaffold).first);
    expect(
      scaffold.backgroundColor,
      equals(AppTheme.specFor('sky_butter').palette.background),
    );
  });
}
