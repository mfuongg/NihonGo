import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/models/cat_anim_state.dart';
import 'package:nihongo_master/models/cat_surface.dart';
import 'package:nihongo_master/services/cat_position_manager.dart';

void main() {
  const manager = CatPositionManager();
  const catW = 120.0;
  const viewW = 400.0;

  const bottomNav = CatSurface(id: 'bottom_nav', type: CatSurfaceType.bottomNav, left: 0, y: 700, width: 400);
  const card = CatSurface(id: 'card', type: CatSurfaceType.card, left: 16, y: 300, width: 368, height: 120);
  const leftShelf = CatSurface(id: 'shelf', type: CatSurfaceType.shelf, left: 16, y: 500, width: 170, height: 80);
  const surfaces = [bottomNav, card, leftShelf];

  group('Foot anchor (56.5% / 81.82%)', () {
    test('topLeft <-> foot round trip', () {
      const foot = Offset(200, 300);
      final tl = CatPositionManager.topLeftFromFoot(foot, catW);
      final h = CatPositionManager.heightForWidth(catW);
      expect(tl.dx, closeTo(200 - catW * 0.565, 1e-9));
      expect(tl.dy, closeTo(300 - h * 0.8182, 1e-9));
      final back = CatPositionManager.footFromTopLeft(tl, catW);
      expect(back.dx, closeTo(foot.dx, 1e-9));
      expect(back.dy, closeTo(foot.dy, 1e-9));
    });

    test('sprite keeps 453:550 ratio', () {
      expect(CatPositionManager.heightForWidth(453), closeTo(550, 1e-9));
    });
  });

  group('findNearest (thuật toán HTML)', () {
    test('thả gần mép trên thẻ -> chân đứng đúng y của thẻ', () {
      final r = manager.findNearest(const Offset(200, 330), surfaces, catWidth: catW, viewportWidth: viewW)!;
      expect(r.surface.id, 'card');
      expect(r.foot.dy, 300);
      expect(r.foot.dx, 200);
    });

    test('bỏ qua bề mặt lệch ngang quá dung sai 36px', () {
      // Chân ở x=330, gần y của kệ (500) nhưng kệ chỉ trải tới x=186-14.
      final r = manager.findNearest(const Offset(330, 505), surfaces, catWidth: catW, viewportWidth: viewW)!;
      expect(r.surface.id, isNot('shelf'));
    });

    test('ưu tiên kệ/bàn (priorityBonus) khi khoảng cách gần như nhau', () {
      const desk = CatSurface(id: 'desk', type: CatSurfaceType.desk, left: 0, y: 410, width: 400);
      const divider = CatSurface(id: 'div', type: CatSurfaceType.divider, left: 0, y: 400, width: 400);
      final r = manager.findNearest(const Offset(200, 404), [desk, divider], catWidth: catW, viewportWidth: viewW)!;
      expect(r.surface.id, 'desk');
    });

    test('thả ở khoảng trống xa -> fallback tìm toàn màn hình', () {
      final r = manager.findNearest(const Offset(300, 120), surfaces, catWidth: catW, viewportWidth: viewW)!;
      expect(r.surface.id, 'card');
    });

    test('bề mặt không tương tác bị bỏ qua', () {
      const blocked = CatSurface(id: 'x', type: CatSurfaceType.card, left: 0, y: 300, width: 400, interactive: false);
      final r = manager.findNearest(const Offset(200, 300), [blocked, bottomNav], catWidth: catW, viewportWidth: viewW)!;
      expect(r.surface.id, 'bottom_nav');
    });

    test('xRatio nằm trong [0.04, 0.96] và chân không tràn khỏi màn hình', () {
      final r = manager.findNearest(const Offset(399, 700), surfaces, catWidth: catW, viewportWidth: viewW)!;
      expect(r.xRatio, inInclusiveRange(0.04, 0.96));
      final tl = CatPositionManager.topLeftFromFoot(r.foot, catW);
      expect(tl.dx + catW, lessThanOrEqualTo(viewW + 1e-9));
    });
  });

  group('restingFoot (vị trí tương đối, responsive)', () {
    test('cùng xRatio cho kết quả tỉ lệ theo độ rộng bề mặt', () {
      final narrow = manager.restingFoot(card, 0.5, catWidth: catW, viewportWidth: viewW);
      const wide = CatSurface(id: 'card', type: CatSurfaceType.card, left: 16, y: 260, width: 668);
      final wideFoot = manager.restingFoot(wide, 0.5, catWidth: catW, viewportWidth: 700);
      expect(narrow.dx, closeTo(16 + 368 * 0.5, 1e-9));
      expect(wideFoot.dx, closeTo(16 + 668 * 0.5, 1e-9));
      expect(wideFoot.dy, 260);
    });

    test('bề mặt hẹp hơn mèo vẫn đứng trong vùng hiển thị', () {
      const tiny = CatSurface(id: 't', type: CatSurfaceType.platform, left: 0, y: 200, width: 40);
      final foot = manager.restingFoot(tiny, 0.04, catWidth: catW, viewportWidth: viewW);
      final tl = CatPositionManager.topLeftFromFoot(foot, catW);
      expect(tl.dx, greaterThanOrEqualTo(-1e-9));
    });
  });

  test('clampFootToViewport không cho mèo rơi ra ngoài', () {
    final f = CatPositionManager.clampFootToViewport(const Offset(-50, 2000), const Size(400, 700), catW);
    final tl = CatPositionManager.topLeftFromFoot(f, catW);
    expect(tl.dx, greaterThanOrEqualTo(-1e-9));
    expect(f.dy, lessThanOrEqualTo(700));
  });

  test('CatAnimState ánh xạ về 5 asset có sẵn', () {
    const allowed = {'idle', 'blink', 'happy', 'thinking', 'sleep'};
    for (final s in CatAnimState.values) {
      expect(allowed.contains(s.assetKey), isTrue, reason: s.name);
    }
    expect(CatAnimState.studying.assetKey, 'thinking');
    expect(CatAnimState.walk.assetKey, 'idle');
  });
}
