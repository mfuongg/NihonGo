import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:nihongo_master/data/grammar_data.dart';
import 'package:nihongo_master/data/jlpt_test_data.dart';
import 'package:nihongo_master/data/kanji_data.dart';
import 'package:nihongo_master/data/reading_material_data.dart';
import 'package:nihongo_master/data/vocabulary_data.dart';
import 'package:nihongo_master/models/flashcard_progress.dart';
import 'package:nihongo_master/models/grammar.dart';
import 'package:nihongo_master/models/kanji.dart';
import 'package:nihongo_master/models/quiz.dart';
import 'package:nihongo_master/models/reading_material.dart';
import 'package:nihongo_master/models/study_history.dart';
import 'package:nihongo_master/models/vocabulary.dart';
import 'package:nihongo_master/providers/auth_provider.dart';
import 'package:nihongo_master/providers/flashcard_provider.dart';
import 'package:nihongo_master/providers/pomodoro_provider.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/providers/study_history_provider.dart';
import 'package:nihongo_master/providers/theme_provider.dart';
import 'package:nihongo_master/providers/vocabulary_provider.dart';
import 'package:nihongo_master/screens/admin/admin_tools_screen.dart';
import 'package:nihongo_master/screens/auth/login_screen.dart';
import 'package:nihongo_master/screens/cat/guardian_cat_screen.dart';
import 'package:nihongo_master/screens/home/leaderboard_screen.dart';
import 'package:nihongo_master/screens/jlpt/jlpt_screen.dart';
import 'package:nihongo_master/screens/map/map_level_catalog.dart';
import 'package:nihongo_master/screens/map/world_map_screen.dart';
import 'package:nihongo_master/screens/pk/cat_explosion_pk_screen.dart';
import 'package:nihongo_master/screens/profile/profile_screen.dart';
import 'package:nihongo_master/screens/read/read_screen.dart';
import 'package:nihongo_master/screens/shell/main_shell.dart';
import 'package:nihongo_master/screens/vocabulary/listening_practice_screen.dart';
import 'package:nihongo_master/screens/vocabulary/vocabulary_quiz_screen.dart';
import 'package:nihongo_master/screens/vocabulary/word_matching_screen.dart';
import 'package:nihongo_master/services/auth_service.dart';
import 'package:nihongo_master/services/avatar_upload_service.dart';
import 'package:nihongo_master/services/cat_dialogue_service.dart';
import 'package:nihongo_master/services/feedback_audio_service.dart';
import 'package:nihongo_master/services/gemini_exam_service.dart';
import 'package:nihongo_master/services/local_database_service.dart';
import 'package:nihongo_master/utils/content_fallback.dart';
import 'package:nihongo_master/utils/theme.dart';
import 'package:nihongo_master/widgets/app_asset_icon.dart';
import 'package:nihongo_master/widgets/line_companion_cat.dart';

class MockListeningAudioController implements ListeningAudioController {
  final List<String> actions = <String>[];
  final List<String> playedAudioPaths = <String>[];
  int playCount = 0;
  int pauseCount = 0;
  int replayCount = 0;
  int blockedMetadataOnlyCalls = 0;

  @override
  Future<bool> playItem(ListeningPracticeItem item, {double rate = 1.0}) async {
    if (!item.isPlayable ||
        item.audioStatus != 'available' ||
        item.audioPath.trim().isEmpty) {
      blockedMetadataOnlyCalls++;
      return false;
    }
    playCount++;
    actions.add('play:${item.audioPath}@$rate');
    playedAudioPaths.add(item.audioPath);
    return true;
  }

  @override
  Future<void> pause() async {
    pauseCount++;
    actions.add('pause');
  }

  @override
  Future<bool> replayItem(ListeningPracticeItem item, {double rate = 1.0}) async {
    if (!item.isPlayable ||
        item.audioStatus != 'available' ||
        item.audioPath.trim().isEmpty) {
      blockedMetadataOnlyCalls++;
      return false;
    }
    replayCount++;
    actions.add('replay:${item.audioPath}@$rate');
    playedAudioPaths.add(item.audioPath);
    return true;
  }

  @override
  Future<void> stop() async {
    actions.add('stop');
  }

  @override
  void dispose() {
    actions.add('dispose');
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Directory tempDir;
  const audioGlobalChannel = MethodChannel('xyz.luan/audioplayers.global');
  const audioPlayersChannel = MethodChannel('xyz.luan/audioplayers');
  const flutterTtsChannel = MethodChannel('flutter_tts');

  setUp(() async {
    FeedbackAudioService.disabledForTesting = true;
    tempDir = await Directory.systemTemp.createTemp('nihongo_master_reset_test_');
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(tempDir.path);

    // Mock audio/TTS platform channels so headless flutter test never invokes native audio drivers
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(audioGlobalChannel, (call) async => 1);
    messenger.setMockMethodCallHandler(audioPlayersChannel, (call) async => 1);
    messenger.setMockMethodCallHandler(flutterTtsChannel, (call) async => 1);
  });

  tearDown(() async {
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(audioGlobalChannel, null);
    messenger.setMockMethodCallHandler(audioPlayersChannel, null);
    messenger.setMockMethodCallHandler(flutterTtsChannel, null);

    VocabularyData.setLoadedWords(const []);
    KanjiData.setLoadedKanji(const []);
    GrammarData.setLoadedLessons(const []);
    ReadingMaterialData.setLoadedMaterials(const []);
    JLPTTestData.setLoadedTests(const []);
    await LocalDatabaseService.instance.closeDatabaseSafely();
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(null);
    if (tempDir.existsSync()) {
      await tempDir.delete(recursive: true);
    }
  });

  test('1. Old hardcoded learning datasets are completely cleared', () {
    expect(VocabularyData.getAllWords(), isEmpty);
    expect(VocabularyData.getWordsByLevel('N5'), isEmpty);
    expect(VocabularyData.search('私'), isEmpty);

    expect(KanjiData.getAllKanji(), isEmpty);
    expect(KanjiData.getKanjiByLevel('N5'), isEmpty);
    expect(KanjiData.getPracticeWordsByLevel('N5'), isEmpty);
    expect(KanjiData.search('日'), isEmpty);

    expect(GrammarData.getAllLessons(), isEmpty);
    expect(GrammarData.getLessonsByLevel('N5'), isEmpty);

    expect(buildReadingMaterials(), isEmpty);
    expect(buildCultureTopics(), isEmpty);

    expect(JLPTTestData.getAllTests(), isEmpty);
    expect(JLPTTestData.getTestsByLevel('N5'), isEmpty);
  });

  test('2. Backup & One-time DEV/TEST SQLite reset deletes legacy DB and recreates clean v2 schema', () async {
    SharedPreferences.setMockInitialValues({
      'learned_vocab': ['n5_001', 'n5_101'],
      'learned_kanji': ['k_001', 'kanji_vocab_n5_001'],
      'fav_vocab': ['n5_002'],
      'fav_kanji': ['k_002'],
      'test_history_json': '[{"level":"N5","score":80}]',
      'community_contributions_v1': '[{"id":"c1"}]',
    });

    // Seed a legacy v1 SQLite database with old fake data, flashcard_progress, and test_history
    final dbFilePath = await LocalDatabaseService.instance.resolveDatabaseFilePath();
    final legacyDb = await databaseFactory.openDatabase(
      dbFilePath,
      options: OpenDatabaseOptions(
        version: 1,
        onCreate: (db, version) async {
          await db.execute('''
            CREATE TABLE vocabulary_cache (
              id TEXT PRIMARY KEY,
              japanese TEXT,
              hiragana TEXT,
              romaji TEXT,
              vietnamese TEXT,
              english TEXT,
              jlptLevel TEXT,
              category TEXT,
              exampleSentences TEXT,
              exampleTranslations TEXT,
              isLearned INTEGER,
              isFavorite INTEGER,
              correctCount INTEGER,
              wrongCount INTEGER,
              lastStudied TEXT,
              srsInterval INTEGER
            )
          ''');
          await db.execute('''
            CREATE TABLE flashcard_progress (
              vocabId TEXT PRIMARY KEY,
              userId TEXT,
              interval INTEGER,
              easeFactor REAL,
              repetition INTEGER,
              nextReview TEXT,
              correctCount INTEGER,
              wrongCount INTEGER,
              lastReviewed TEXT
            )
          ''');
          await db.execute('''
            CREATE TABLE test_history (
              id TEXT PRIMARY KEY,
              userId TEXT,
              testId TEXT,
              title TEXT,
              jlptLevel TEXT,
              totalQuestions INTEGER,
              correctAnswers INTEGER,
              wrongAnswers INTEGER,
              scorePercent REAL,
              timeTakenSeconds INTEGER,
              completedAt TEXT
            )
          ''');
        },
      ),
    );

    await legacyDb.insert('vocabulary_cache', {
      'id': 'n5_101',
      'japanese': '家族の言葉',
      'hiragana': 'かぞくのことば',
      'romaji': 'kazoku no kotoba',
      'vietnamese': 'lời nói của gia đình',
      'english': 'words of family',
      'jlptLevel': 'N5',
      'category': 'family',
      'exampleSentences': '[]',
      'exampleTranslations': '[]',
      'isLearned': 1,
      'isFavorite': 0,
      'correctCount': 2,
      'wrongCount': 0,
      'lastStudied': null,
      'srsInterval': 1,
    });
    await legacyDb.insert('flashcard_progress', {
      'vocabId': 'kanji_practice_k_001_0',
      'userId': 'guest',
      'interval': 1,
      'easeFactor': 2.5,
      'repetition': 1,
      'nextReview': DateTime.now().toIso8601String(),
      'correctCount': 1,
      'wrongCount': 0,
      'lastReviewed': DateTime.now().toIso8601String(),
    });
    await legacyDb.insert('test_history', {
      'id': 'th_legacy_01',
      'userId': 'guest',
      'testId': 'N5_test_01',
      'title': 'Đề N5 số 1',
      'jlptLevel': 'N5',
      'totalQuestions': 10,
      'correctAnswers': 8,
      'wrongAnswers': 2,
      'scorePercent': 80.0,
      'timeTakenSeconds': 120,
      'completedAt': DateTime.now().toIso8601String(),
    });
    await legacyDb.close();

    // Execute the one-time DEV/TEST reset
    final resetReport = await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();

    expect(resetReport.executed, isTrue);
    expect(resetReport.backupPath, isNotNull);
    expect(File(resetReport.backupPath!).existsSync(), isTrue);

    // Pre-reset inspection captured v1 state
    expect(resetReport.preResetInspection, isNotNull);
    expect(resetReport.preResetInspection!.version, equals(1));
    expect(resetReport.preResetInspection!.tableRowCounts['vocabulary_cache'], equals(1));
    expect(resetReport.preResetInspection!.tableRowCounts['flashcard_progress'], equals(1));
    expect(resetReport.preResetInspection!.tableRowCounts['test_history'], equals(1));

    // Post-reset inspection verifies clean v2 schema
    final post = resetReport.postResetInspection!;
    expect(post.isHealthy, isTrue);
    expect(post.isAllLearningDataEmpty, isTrue);
    expect(post.version, equals(LocalDatabaseService.databaseVersion));
    expect(post.foreignKeysEnabled, isTrue);
    expect(post.foreignKeyViolations, isEmpty);

    for (final requiredTable in LocalDatabaseService.requiredTables) {
      expect(post.tables, contains(requiredTable));
    }
    for (final learningTable in LocalDatabaseService.learningAndProgressTables) {
      expect(post.tableRowCounts[learningTable], equals(0));
    }

    // Verify SharedPreferences legacy learning keys were cleared
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getStringList('learned_vocab'), isNull);
    expect(prefs.getStringList('learned_kanji'), isNull);
    expect(prefs.getStringList('fav_vocab'), isNull);
    expect(prefs.getStringList('fav_kanji'), isNull);
    expect(prefs.getString('test_history_json'), isNull);
    expect(prefs.getString('community_contributions_v1'), isNull);
    expect(prefs.getBool(LocalDatabaseService.devResetPrefsKey), isTrue);
  });

  test('3. Foreign keys are actively enforced and prevent orphan records', () async {
    await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    final db = await LocalDatabaseService.instance.database;

    // Attempting to insert data_source referencing a missing license must fail
    await expectLater(
      () => db.insert('data_sources', {
        'id': 'src_invalid',
        'name': 'Invalid Source',
        'source_url': 'https://example.com',
        'license_id': 'non_existent_license',
        'attribution_text': 'Test',
        'fetched_at': DateTime.now().toIso8601String(),
      }),
      throwsA(isA<DatabaseException>()),
    );

    // Attempting to insert raw flashcard_progress referencing a missing vocabulary_cache row must fail
    await expectLater(
      () => db.insert('flashcard_progress', {
        'vocabId': 'missing_vocab_id',
        'userId': 'guest',
        'interval': 1,
        'easeFactor': 2.5,
        'repetition': 1,
        'nextReview': DateTime.now().toIso8601String(),
        'correctCount': 1,
        'wrongCount': 0,
        'lastReviewed': DateTime.now().toIso8601String(),
      }),
      throwsA(isA<DatabaseException>()),
    );

    // Verify ON DELETE CASCADE cleans up flashcard_progress when parent vocabulary_cache row is deleted
    final tempWord = VocabularyWord(
      id: 'temp_vocab_1',
      japanese: 'テスト',
      hiragana: 'てすと',
      romaji: 'tesuto',
      vietnamese: 'kiểm tra',
      english: 'test',
      jlptLevel: 'N5',
      category: 'test',
    );
    await LocalDatabaseService.instance.cacheVocabulary([tempWord]);
    await LocalDatabaseService.instance.upsertFlashcardProgress(
      FlashcardProgress.initial(userId: 'guest', vocabId: 'temp_vocab_1'),
    );

    var progressMap = await LocalDatabaseService.instance.getAllFlashcardProgress(userId: 'guest');
    expect(progressMap.containsKey('temp_vocab_1'), isTrue);

    await db.delete('vocabulary_cache', where: 'id = ?', whereArgs: ['temp_vocab_1']);
    progressMap = await LocalDatabaseService.instance.getAllFlashcardProgress(userId: 'guest');
    expect(progressMap, isEmpty);

    final inspection = await LocalDatabaseService.instance.inspectDatabase();
    expect(inspection.foreignKeyViolations, isEmpty);
    expect(inspection.isAllLearningDataEmpty, isTrue);
  });

  test('4. Database is NOT reset again on subsequent app launches and backups are never overwritten', () async {
    final firstReset = await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    expect(firstReset.executed, isTrue);

    final db = await LocalDatabaseService.instance.database;
    await db.insert('licenses', {
      'id': 'lic_test',
      'code': 'CC0',
      'name': 'Public Domain',
      'allow_redistribution': 1,
      'allow_modification': 1,
      'require_attribution': 0,
      'require_share_alike': 0,
    });

    // Simulate closing and reopening the app
    await LocalDatabaseService.instance.closeDatabaseSafely();

    final secondReset = await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    expect(secondReset.executed, isFalse);

    final reopenedDb = await LocalDatabaseService.instance.database;
    final licenses = await reopenedDb.query('licenses', where: 'id = ?', whereArgs: ['lic_test']);
    expect(licenses.length, equals(1));

    // Also verify backupCurrentDatabaseIfPresent never overwrites an existing backup
    final backupDir = p.join(tempDir.path, 'manual_backups');
    final b1 = await LocalDatabaseService.instance.backupCurrentDatabaseIfPresent(targetBackupDir: backupDir);
    final b2 = await LocalDatabaseService.instance.backupCurrentDatabaseIfPresent(targetBackupDir: backupDir);
    expect(b1, isNotNull);
    expect(b2, isNotNull);
    expect(b1, isNot(equals(b2)));
    expect(File(b1!).existsSync(), isTrue);
    expect(File(b2!).existsSync(), isTrue);
  });

  test('5. Chunked Batch Import (chunkSize = 500) imports all verified v2 datasets with 0 errors and 0 orphans', () async {
    SharedPreferences.setMockInitialValues({});
    await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();

    final report = await LocalDatabaseService.instance.importVerifiedDataset(
      chunkSize: 500,
    );

    expect(report.executed, isTrue);
    expect(report.success, isTrue);
    expect(report.totalErrors, equals(0));
    expect(report.orphanRecordCount, equals(0));
    expect(report.duplicateIdCount, equals(0));
    expect(report.unclassifiedReadingCount, equals(6));

    // Verify per-table chunked batch import results
    expect(report.tableResults['licenses']!.expectedCount, equals(3));
    expect(report.tableResults['licenses']!.chunkCount, equals(1));
    expect(report.tableResults['licenses']!.insertedCount, equals(3));

    expect(report.tableResults['data_sources']!.expectedCount, equals(3));
    expect(report.tableResults['data_sources']!.chunkCount, equals(1));
    expect(report.tableResults['data_sources']!.insertedCount, equals(3));

    expect(report.tableResults['vocabularies']!.expectedCount, equals(7811));
    expect(report.tableResults['vocabularies']!.chunkCount, equals(16));
    expect(report.tableResults['vocabularies']!.insertedCount, equals(7811));

    expect(report.tableResults['kanji_entries']!.expectedCount, equals(2383));
    expect(report.tableResults['kanji_entries']!.chunkCount, equals(5));
    expect(report.tableResults['kanji_entries']!.insertedCount, equals(2383));

    expect(report.tableResults['grammar_points']!.expectedCount, equals(1164));
    expect(report.tableResults['grammar_points']!.chunkCount, equals(3));
    expect(report.tableResults['grammar_points']!.insertedCount, equals(1164));

    expect(report.tableResults['example_sentences']!.expectedCount, equals(16691));
    expect(report.tableResults['example_sentences']!.chunkCount, equals(34));
    expect(report.tableResults['example_sentences']!.insertedCount, equals(16691));

    expect(report.tableResults['reading_materials']!.expectedCount, equals(40));
    expect(report.tableResults['reading_materials']!.chunkCount, equals(1));
    expect(report.tableResults['reading_materials']!.insertedCount, equals(40));

    expect(report.tableResults['vocabulary_cache']!.expectedCount, equals(7811));
    expect(report.tableResults['vocabulary_cache']!.chunkCount, equals(16));
    expect(report.tableResults['vocabulary_cache']!.insertedCount, equals(7811));

    // Empty datasets are skipped without fabricating records
    expect(report.tableResults['listening_materials']!.skipped, isTrue);
    expect(report.tableResults['listening_materials']!.insertedCount, equals(0));
    expect(report.tableResults['transcripts']!.skipped, isTrue);
    expect(report.tableResults['transcripts']!.insertedCount, equals(0));
    expect(report.tableResults['exams']!.skipped, isTrue);
    expect(report.tableResults['exams']!.insertedCount, equals(0));
    expect(report.tableResults['questions']!.skipped, isTrue);
    expect(report.tableResults['questions']!.insertedCount, equals(0));
    expect(report.tableResults['answers']!.skipped, isTrue);
    expect(report.tableResults['answers']!.insertedCount, equals(0));

    // Post-import SQLite verification
    final post = report.postImportInspection;
    expect(post.isHealthy, isTrue);
    expect(post.version, equals(LocalDatabaseService.databaseVersion));
    expect(post.foreignKeysEnabled, isTrue);
    expect(post.foreignKeyViolations, isEmpty);
    expect(post.tableRowCounts['vocabularies'], equals(7811));
    expect(post.tableRowCounts['kanji_entries'], equals(2383));
    expect(post.tableRowCounts['grammar_points'], equals(1164));
    expect(post.tableRowCounts['example_sentences'], equals(16691));
    expect(post.tableRowCounts['reading_materials'], equals(40));
    expect(post.tableRowCounts['vocabulary_cache'], equals(7811));
    expect(post.tableRowCounts['listening_materials'], equals(0));
    expect(post.tableRowCounts['transcripts'], equals(0));
    expect(post.tableRowCounts['exams'], equals(0));
    expect(post.tableRowCounts['questions'], equals(0));
    expect(post.tableRowCounts['answers'], equals(0));

    // Verify Phase 2 + Phase 3 Vietnamese translations are imported and untranslated rows remain NULL
    final db = await LocalDatabaseService.instance.database;
    final nonNullVocabVi = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM vocabularies WHERE meaning_vi IS NOT NULL'),
    );
    expect(nonNullVocabVi, equals(320));

    final nonNullKanjiVi = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM kanji_entries WHERE meaning_vi IS NOT NULL'),
    );
    expect(nonNullKanjiVi, equals(60));

    final nonNullGrammarVi = Sqflite.firstIntValue(
      await db.rawQuery(
        'SELECT COUNT(*) FROM grammar_points WHERE title_vi IS NOT NULL OR explanation_vi IS NOT NULL',
      ),
    );
    expect(nonNullGrammarVi, equals(50));

    final nonNullSentenceVi = Sqflite.firstIntValue(
      await db.rawQuery(
        'SELECT COUNT(*) FROM example_sentences WHERE translation_vi IS NOT NULL',
      ),
    );
    expect(nonNullSentenceVi, equals(703));

    final nonNullReadingVi = Sqflite.firstIntValue(
      await db.rawQuery(
        'SELECT COUNT(*) FROM reading_materials WHERE title_vi IS NOT NULL OR translation_vi IS NOT NULL',
      ),
    );
    expect(nonNullReadingVi, equals(31));

    // Verify 40 reading_materials = 34 Hanabira (classified N5..N2) + 6 Aozora Bunko (original_level IS NULL)
    final hanabiraReadingCount = Sqflite.firstIntValue(
      await db.rawQuery(
        "SELECT COUNT(*) FROM reading_materials WHERE source_id = 'src_hanabira' AND original_level IS NOT NULL",
      ),
    );
    expect(hanabiraReadingCount, equals(34));

    final aozoraReadingCount = Sqflite.firstIntValue(
      await db.rawQuery(
        "SELECT COUNT(*) FROM reading_materials WHERE source_id = 'src_aozora' AND original_level IS NULL",
      ),
    );
    expect(aozoraReadingCount, equals(6));

    final unclassifiedCount =
        await LocalDatabaseService.instance.countUnclassifiedReadingMaterials();
    expect(unclassifiedCount, equals(6));

    // Verify vocabulary_cache is 100% synchronized with vocabularies & example_sentences
    final syncedCacheCount = Sqflite.firstIntValue(
      await db.rawQuery('''
        SELECT COUNT(*)
        FROM vocabulary_cache vc
        INNER JOIN vocabularies v ON vc.id = v.id
        WHERE vc.japanese = v.expression
          AND vc.hiragana = v.reading_hiragana
          AND vc.jlptLevel = v.original_level
          AND vc.english = v.meaning_en
          AND vc.vietnamese = COALESCE(v.meaning_vi, '')
      '''),
    );
    expect(syncedCacheCount, equals(7811));

    final distinctVocabWithSentences = Sqflite.firstIntValue(
      await db.rawQuery(
        'SELECT COUNT(DISTINCT linked_vocab_id) FROM example_sentences WHERE linked_vocab_id IS NOT NULL',
      ),
    );
    final cacheWithExamplesCount = Sqflite.firstIntValue(
      await db.rawQuery(
        "SELECT COUNT(*) FROM vocabulary_cache WHERE exampleSentences != '[]'",
      ),
    );
    expect(cacheWithExamplesCount, equals(distinctVocabWithSentences));
    expect(cacheWithExamplesCount, equals(7108));

    // Load into memory and verify in-memory repositories
    await LocalDatabaseService.instance.loadVerifiedDatasetsIntoMemory();
    expect(VocabularyData.getAllWords().length, equals(7811));
    expect(KanjiData.getAllKanji().length, equals(2383));
    expect(GrammarData.getAllLessons().length, equals(1164));
    final loadedReadings = buildReadingMaterials();
    expect(loadedReadings.length, equals(40));
    expect(
      loadedReadings
          .where(
            (r) =>
                r.sourceId == 'src_aozora' &&
                r.originalLevel == null &&
                r.isUnclassified &&
                r.displayLevelLabel(language: 'vi') == 'Chưa phân cấp JLPT' &&
                r.displayLevelLabel(language: 'en') == 'Not classified by JLPT',
          )
          .length,
      equals(6),
    );
    expect(
      loadedReadings
          .where((r) => r.sourceId == 'src_hanabira' && r.originalLevel != null && !r.isUnclassified)
          .length,
      equals(34),
    );
    expect(JLPTTestData.getAllTests(), isEmpty);

    // Subsequent call to ensureVerifiedDatasetImportedAndLoaded does not re-import or reset
    final secondReport =
        await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
    expect(secondReport.executed, isFalse);
  });

  test('6. Language Fallback Anh <-> Viet works for all required cases without overwriting source fields', () {
    // 1. language == 'vi' and meaning_vi is present -> displays meaning_vi
    expect(
      ContentFallback.resolveMeaning(
        language: 'vi',
        meaningVi: 'Con mèo',
        meaningEn: 'Cat',
      ),
      equals('Con mèo'),
    );

    // 2. language == 'vi' and meaning_vi == null while meaning_en is present -> displays meaning_en
    expect(
      ContentFallback.resolveMeaning(
        language: 'vi',
        meaningVi: null,
        meaningEn: 'Cat',
      ),
      equals('Cat'),
    );

    // 3. language == 'vi' and meaning_vi is empty/whitespace while meaning_en is present -> displays meaning_en
    expect(
      ContentFallback.resolveMeaning(
        language: 'vi',
        meaningVi: '   ',
        meaningEn: 'Cat',
      ),
      equals('Cat'),
    );

    // 4. language == 'vi' and both meaning_vi == null and meaning_en == null -> displays 'Chưa có nghĩa'
    expect(
      ContentFallback.resolveMeaning(
        language: 'vi',
        meaningVi: null,
        meaningEn: null,
      ),
      equals('Chưa có nghĩa'),
    );

    // 5. language == 'en' and meaning_en == null while meaning_vi is present -> displays meaning_vi
    expect(
      ContentFallback.resolveMeaning(
        language: 'en',
        meaningVi: 'Con mèo',
        meaningEn: null,
      ),
      equals('Con mèo'),
    );

    // 6. language == 'en' and both meaning_en and meaning_vi are empty -> displays 'No meaning available'
    expect(
      ContentFallback.resolveMeaning(
        language: 'en',
        meaningVi: '',
        meaningEn: '  ',
      ),
      equals('No meaning available'),
    );

    // Explanation & Translation fallbacks
    expect(
      ContentFallback.resolveExplanation(
        language: 'vi',
        explanationVi: null,
        explanationEn: 'Used to indicate topic',
      ),
      equals('Used to indicate topic'),
    );
    expect(
      ContentFallback.resolveExplanation(
        language: 'vi',
        explanationVi: null,
        explanationEn: null,
      ),
      equals('Chưa có giải thích'),
    );
    expect(
      ContentFallback.resolveTranslation(
        language: 'vi',
        translationVi: null,
        translationEn: 'I am a student.',
      ),
      equals('I am a student.'),
    );
    expect(
      ContentFallback.resolveTranslation(
        language: 'en',
        translationVi: null,
        translationEn: null,
      ),
      equals('No translation available'),
    );

    // Verify Model-level fallback preserves raw fields and never returns "null"
    final word = VocabularyWord(
      id: 'vocab_n5_0001',
      japanese: '猫',
      hiragana: 'ねこ',
      romaji: 'neko',
      vietnamese: '',
      english: 'cat',
      jlptLevel: 'N5',
      category: 'general',
      exampleSentences: ['猫が好きです。'],
      exampleTranslations: ['I like cats.'],
    );
    expect(word.vietnamese, equals('')); // Raw field preserved
    expect(word.displayMeaning(language: 'vi'), equals('cat'));
    expect(word.displayMeaning(language: 'en'), equals('cat'));
    expect(word.displayExampleTranslation(0, language: 'vi'), equals('I like cats.'));
    expect(word.displayExampleTranslation(99, language: 'vi'), equals('Chưa có bản dịch'));

    final kanji = KanjiItem(
      id: 'kanji_n5_0001',
      kanji: '日',
      onyomi: 'ニチ',
      kunyomi: 'ひ',
      vietnamese: '',
      english: 'day, sun, Japan',
      strokeCount: 4,
      jlptLevel: 'N5',
      exampleWords: [],
      exampleReadings: [],
      exampleMeanings: [],
    );
    expect(kanji.vietnamese, equals('')); // Raw field preserved
    expect(kanji.displayMeaning(language: 'vi'), equals('day, sun, Japan'));

    final grammar = GrammarLesson(
      id: 'gram_n5_0001',
      pattern: '〜は〜です',
      title: '',
      titleVi: null,
      titleEn: 'A is B',
      explanation: '',
      explanationVi: null,
      explanationEn: 'Polite copula construction',
      jlptLevel: 'N5',
      examples: const [
        ExampleSentence(
          japanese: '私は学生です。',
          hiragana: 'わたしはがくせいです。',
          vietnamese: '',
          english: 'I am a student.',
        ),
      ],
      notes: const [],
    );
    expect(grammar.titleVi, isNull);
    expect(grammar.explanationVi, isNull);
    expect(grammar.displayTitle(language: 'vi'), equals('A is B'));
    expect(grammar.displayExplanation(language: 'vi'), equals('Polite copula construction'));
    expect(grammar.examples.first.displayTranslation(language: 'vi'), equals('I am a student.'));
  });

  testWidgets('7. Reading Screen displays unclassified Aozora Bunko works (original_level == null) and filters strictly', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    ReadingMaterialData.setLoadedMaterials([
      const ReadingMaterial(
        id: 'read_hana_n5_01',
        title: 'My Daily Routine',
        japaneseTitle: '私の一日',
        level: 'N5',
        originalLevel: 'N5',
        category: 'Truyện đọc phân cấp',
        estimatedMinutes: 3,
        summary: 'A short N5 passage.',
        preview: '朝六時に起きます。',
        content: '朝六時に起きます。',
        translationEn: 'I wake up at 6 AM.',
        tags: ['Hanabira', 'N5'],
      ),
      const ReadingMaterial(
        id: 'read_aozora_001',
        title: 'Rashomon',
        japaneseTitle: '羅生門',
        level: 'Chưa phân cấp JLPT',
        originalLevel: null,
        category: 'Văn học cổ điển',
        estimatedMinutes: 15,
        summary: 'Akutagawa Ryunosuke classic short story.',
        preview: 'ある日の暮方の事である。',
        content: 'ある日の暮方の事である。',
        authorJp: '芥川龍之介',
        tags: ['Aozora Bunko', 'Chưa phân cấp JLPT'],
      ),
    ]);

    final settingsProvider = SettingsProvider();
    await tester.binding.setSurfaceSize(const Size(1080, 1920));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      ChangeNotifierProvider<SettingsProvider>.value(
        value: settingsProvider,
        child: const MaterialApp(
          home: ReadScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // In 'Tất cả' filter, both N5 and unclassified Aozora Bunko works are displayed
    expect(find.text('2 tài liệu'), findsOneWidget);
    expect(find.text('My Daily Routine'), findsOneWidget);
    expect(find.text('Rashomon'), findsOneWidget);
    expect(find.text('Chưa phân cấp JLPT'), findsWidgets);

    // Filter by 'N5' -> ONLY N5 passage is shown; original_level == null is excluded
    await tester.tap(find.widgetWithText(ChoiceChip, 'N5'));
    await tester.pumpAndSettle();
    expect(find.text('1 tài liệu'), findsOneWidget);
    expect(find.text('My Daily Routine'), findsOneWidget);
    expect(find.text('Rashomon'), findsNothing);

    // Filter by 'N1' -> 0 passages shown (unclassified is NOT placed in N1)
    await tester.tap(find.widgetWithText(ChoiceChip, 'N1'));
    await tester.pumpAndSettle();
    expect(find.text('0 tài liệu'), findsOneWidget);
    expect(find.text('Rashomon'), findsNothing);

    // Filter by 'Chưa phân cấp JLPT' -> ONLY the unclassified Aozora Bunko work is shown
    await tester.tap(find.widgetWithText(ChoiceChip, 'Chưa phân cấp JLPT'));
    await tester.pumpAndSettle();
    expect(find.text('1 tài liệu'), findsOneWidget);
    expect(find.text('Rashomon'), findsOneWidget);
    expect(find.text('My Daily Routine'), findsNothing);

    // Switch language to English ('en') -> badge displays 'Not classified by JLPT'
    await settingsProvider.setStudyLanguage('en');
    await tester.pumpAndSettle();
    expect(find.text('Not classified by JLPT'), findsWidgets);
  });

  testWidgets('8. Listening and JLPT Test screens render exact Empty State in vi/en without Start buttons or fake history', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.runAsync(() async {
      await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
      final listeningCount = await LocalDatabaseService.instance.getListeningMaterialCount();
      LocalDatabaseService.setLoadedListeningCount(listeningCount);
    });
    JLPTTestData.setLoadedTests(const []);

    final settingsProvider = SettingsProvider();
    final vocabProvider = VocabularyProvider();
    final progressProvider = ProgressProvider();
    final authProvider = AuthProvider();
    final historyProvider = StudyHistoryProvider();

    // 8a. Test ListeningPracticeScreen Empty State (Vietnamese & English)
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
        ],
        child: const MaterialApp(
          home: ListeningPracticeScreen(level: 'N5'),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Chưa có dữ liệu luyện nghe.'), findsOneWidget);
    expect(find.text('Kiểm tra đáp án ✔'), findsNothing);

    await settingsProvider.setStudyLanguage('en');
    await tester.pumpAndSettle();
    expect(find.text('No listening data available.'), findsOneWidget);

    // 8b. Test JLPTScreen Empty State (Vietnamese & English)
    await settingsProvider.setStudyLanguage('vi');
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
        ],
        child: const MaterialApp(
          home: JLPTScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Chưa có dữ liệu luyện thi.'), findsOneWidget);
    expect(find.text('Bắt đầu làm bài'), findsNothing);

    await settingsProvider.setStudyLanguage('en');
    await tester.pumpAndSettle();
    expect(find.text('No practice test data available.'), findsOneWidget);

    // Verify 0 fake test_history records were created
    final historyCount = await tester.runAsync(() async {
      final db = await LocalDatabaseService.instance.database;
      return Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM test_history'),
      );
    });
    expect(historyCount, equals(0));
  });

  test('9. [Prompt 5] Flashcard end-to-end validation: SQLite load, progress creation, SRS update, JOIN with Vocabulary, and preservation across cache updates', () async {
    SharedPreferences.setMockInitialValues({});
    await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();

    final vocabProvider = VocabularyProvider();
    await vocabProvider.init();
    expect(vocabProvider.allWords.length, equals(7811));

    // 1. Get N5 vocabulary for Flashcard from SQLite
    final n5Words = vocabProvider.getWordsForFlashcard('N5');
    expect(n5Words.length, equals(674));
    expect(n5Words.every((w) => w.id.startsWith('vocab_oj_')), isTrue);
    expect(n5Words.any((w) => w.id.startsWith('n5_')), isFalse);

    // 2. Start Flashcard session
    final flashProvider = FlashcardProvider();
    await flashProvider.startSession(n5Words.take(10).toList(), userId: 'guest');
    expect(flashProvider.hasSession, isTrue);
    expect(flashProvider.sessionWords.length, equals(10));

    final word1 = flashProvider.sessionWords[0];
    final word2 = flashProvider.sessionWords[1];

    // 3. Create new progress for word1 (known) and word2 (unknown)
    final p1First = await flashProvider.markAnswer(word1, true);
    expect(p1First.repetition, equals(1));
    expect(p1First.interval, equals(1));
    expect(p1First.correctCount, equals(1));
    expect(p1First.wrongCount, equals(0));

    final p2First = await flashProvider.markAnswer(word2, false);
    expect(p2First.repetition, equals(0));
    expect(p2First.interval, equals(1));
    expect(p2First.correctCount, equals(0));
    expect(p2First.wrongCount, equals(1));

    // 4. Update existing progress for word1 (known again) -> must update in-place without duplicates
    final p1Second = await flashProvider.markAnswer(word1, true);
    expect(p1Second.repetition, equals(2));
    expect(p1Second.interval, equals(3));
    expect(p1Second.correctCount, equals(2));

    // 5. Update word progress in VocabularyProvider & re-cache vocabulary -> must NOT wipe flashcard_progress via ON DELETE CASCADE
    await vocabProvider.updateWordProgress(
      wordId: word1.id,
      known: true,
      interval: p1Second.interval,
      reviewedAt: DateTime.now(),
    );
    await LocalDatabaseService.instance.cacheVocabulary(n5Words.take(5).toList());

    // 6. Query flashcard_progress and verify no duplicate or lost progress
    final progressMap = await LocalDatabaseService.instance.getAllFlashcardProgress(userId: 'guest');
    expect(progressMap.length, equals(2));
    expect(progressMap[word1.id]!.repetition, equals(2));
    expect(progressMap[word1.id]!.interval, equals(3));
    expect(progressMap[word1.id]!.correctCount, equals(2));
    expect(progressMap[word2.id]!.wrongCount, equals(1));

    // 7. Attempt to create progress for non-existent / legacy vocabId -> safely ignored
    await LocalDatabaseService.instance.upsertFlashcardProgress(
      FlashcardProgress.initial(userId: 'guest', vocabId: 'n5_001_legacy'),
    );
    final progressAfterLegacy = await LocalDatabaseService.instance.getAllFlashcardProgress(userId: 'guest');
    expect(progressAfterLegacy.length, equals(2));
    expect(progressAfterLegacy.containsKey('n5_001_legacy'), isFalse);

    // 8. Verify INNER JOIN between flashcard_progress, vocabulary_cache, and vocabularies
    final joinedRows = await LocalDatabaseService.instance.getFlashcardProgressJoinedWithVocabulary(
      userId: 'guest',
    );
    expect(joinedRows.length, equals(2));
    for (final row in joinedRows) {
      expect((row['vocabId'] as String).startsWith('vocab_oj_'), isTrue);
      expect((row['japanese'] as String).isNotEmpty, isTrue);
      expect((row['english'] as String).isNotEmpty, isTrue);
      expect(row['vietnamese'], equals(row['meaning_vi'] ?? ''));
    }
  });

  test('10. [Prompt 5] Restart persistence, schema & index verification, and preservation of flashcard_progress & test_history without reset or re-import', () async {
    SharedPreferences.setMockInitialValues({});
    final initialImport = await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
    expect(initialImport.executed, isTrue);

    final db = await LocalDatabaseService.instance.database;

    // Verify all 12 required indexes exist in sqlite_master
    final indexRows = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'index' AND name LIKE 'idx_%'",
    );
    final indexNames = indexRows.map((r) => r['name'] as String).toSet();
    const expectedIndexes = <String>{
      'idx_vocab_expression',
      'idx_vocab_reading',
      'idx_vocab_orig_level',
      'idx_kanji_orig_level',
      'idx_grammar_orig_level',
      'idx_sentences_vocab',
      'idx_reading_cat',
      'idx_transcripts_listening',
      'idx_questions_exam',
      'idx_answers_question',
      'idx_flashcard_user_review',
      'idx_test_history_user_date',
    };
    expect(indexNames.containsAll(expectedIndexes), isTrue);

    // Record valid flashcard_progress and study_history before restart
    final firstVocabRow = (await db.query('vocabularies', limit: 1)).first;
    final validVocabId = firstVocabRow['id'] as String;
    await LocalDatabaseService.instance.upsertFlashcardProgress(
      FlashcardProgress(
        userId: 'guest',
        vocabId: validVocabId,
        interval: 3,
        easeFactor: 2.6,
        repetition: 2,
        nextReview: DateTime.now().add(const Duration(days: 3)),
        correctCount: 2,
        wrongCount: 0,
        lastReviewed: DateTime.now(),
      ),
    );

    final historyProvider = StudyHistoryProvider();
    await historyProvider.init(userId: 'guest');
    await historyProvider.addHistory(
      StudyHistory(
        id: 'hist_valid_001',
        userId: 'guest',
        testId: 'vocab_quiz_n5',
        title: 'Quiz Từ vựng N5',
        jlptLevel: 'N5',
        totalQuestions: 10,
        correctAnswers: 9,
        wrongAnswers: 1,
        scorePercent: 90.0,
        timeTakenSeconds: 45,
        completedAt: DateTime.now(),
      ),
    );

    // Simulate closing and restarting the app
    await LocalDatabaseService.instance.closeDatabaseSafely();

    final restartReset = await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    expect(restartReset.executed, isFalse);

    final restartImport = await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
    expect(restartImport.executed, isFalse);

    // Verify all learning tables AND user progress/history tables are preserved after restart
    final postRestart = await LocalDatabaseService.instance.inspectDatabase();
    expect(postRestart.version, equals(LocalDatabaseService.databaseVersion));
    expect(postRestart.foreignKeysEnabled, isTrue);
    expect(postRestart.foreignKeyViolations, isEmpty);
    expect(postRestart.tableRowCounts['licenses'], equals(3));
    expect(postRestart.tableRowCounts['data_sources'], equals(3));
    expect(postRestart.tableRowCounts['vocabularies'], equals(7811));
    expect(postRestart.tableRowCounts['kanji_entries'], equals(2383));
    expect(postRestart.tableRowCounts['grammar_points'], equals(1164));
    expect(postRestart.tableRowCounts['example_sentences'], equals(16691));
    expect(postRestart.tableRowCounts['reading_materials'], equals(40));
    expect(postRestart.tableRowCounts['vocabulary_cache'], equals(7811));
    expect(postRestart.tableRowCounts['flashcard_progress'], equals(1));
    expect(postRestart.tableRowCounts['test_history'], equals(1));

    final restoredProgress = await LocalDatabaseService.instance.getAllFlashcardProgress(userId: 'guest');
    expect(restoredProgress[validVocabId]?.interval, equals(3));

    final restoredHistory = await LocalDatabaseService.instance.getStudyHistories(userId: 'guest');
    expect(restoredHistory.length, equals(1));
    expect(restoredHistory.first.id, equals('hist_valid_001'));
  });

  testWidgets('11. [Prompt 5] Learning screens (Quiz & Word Matching) work with verified dataset and handle empty dataset safely without crash', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    final settingsProvider = SettingsProvider();
    final vocabProvider = VocabularyProvider();
    final progressProvider = ProgressProvider();

    await tester.runAsync(() async {
      await LocalDatabaseService.instance.performOneTimeDevResetIfNeeded();
    });
    VocabularyData.setLoadedWords(const []);

    final sampleWords = <VocabularyWord>[
      VocabularyWord(
        id: 'vocab_oj_test_1',
        japanese: '猫',
        hiragana: 'ねこ',
        romaji: 'neko',
        vietnamese: '',
        english: 'cat',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
      VocabularyWord(
        id: 'vocab_oj_test_2',
        japanese: '犬',
        hiragana: 'いぬ',
        romaji: 'inu',
        vietnamese: '',
        english: 'dog',
        jlptLevel: 'N5',
        category: 'nouns',
      ),
    ];

    // 11a. VocabularyQuizScreen renders English fallback when vietnamese is empty
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
        ],
        child: MaterialApp(
          home: VocabularyQuizScreen(level: 'N5', words: sampleWords),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('cat'), findsOneWidget);
    expect(find.text('dog'), findsOneWidget);

    // 11b. WordMatchingScreen with empty dataset does not crash (no division by zero)
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
        ],
        child: const MaterialApp(
          home: WordMatchingScreen(level: 'N5', words: []),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Không có từ vựng'), findsOneWidget);
  });

  test('12. [Prompt 6 - SQLite 10.2] Non-destructive import preserves all existing data, enforces FKs, is idempotent, filters N5-N1, and excludes metadata_only & uncertain JLPT items', () async {
    SharedPreferences.setMockInitialValues({});
    // First import Prompt 4 base datasets and create user progress
    await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
    final db = await LocalDatabaseService.instance.database;

    final firstVocabId = (await db.query('vocabularies', limit: 1)).first['id'] as String;
    await LocalDatabaseService.instance.upsertFlashcardProgress(
      FlashcardProgress(
        userId: 'guest',
        vocabId: firstVocabId,
        interval: 5,
        easeFactor: 2.5,
        repetition: 3,
        nextReview: DateTime.now().add(const Duration(days: 5)),
        correctCount: 4,
        wrongCount: 1,
        lastReviewed: DateTime.now(),
      ),
    );
    final historyProvider = StudyHistoryProvider();
    await historyProvider.init(userId: 'guest');
    await historyProvider.addHistory(
      StudyHistory(
        id: 'hist_pre_p6',
        userId: 'guest',
        testId: 'vocab_n5',
        title: 'Pre-Prompt 6 History',
        jlptLevel: 'N5',
        totalQuestions: 10,
        correctAnswers: 8,
        wrongAnswers: 2,
        scorePercent: 80.0,
        timeTakenSeconds: 30,
        completedAt: DateTime.now(),
      ),
    );

    final preInspection = await LocalDatabaseService.instance.inspectDatabase();
    expect(preInspection.tableRowCounts['vocabularies'], equals(7811));
    expect(preInspection.tableRowCounts['kanji_entries'], equals(2383));
    expect(preInspection.tableRowCounts['grammar_points'], equals(1164));
    expect(preInspection.tableRowCounts['example_sentences'], equals(16691));
    expect(preInspection.tableRowCounts['reading_materials'], equals(40));
    expect(preInspection.tableRowCounts['vocabulary_cache'], equals(7811));
    expect(preInspection.tableRowCounts['flashcard_progress'], equals(1));
    expect(preInspection.tableRowCounts['test_history'], equals(1));

    // Execute Prompt 6 non-destructive import
    final p6Report = await LocalDatabaseService.instance
        .ensureListeningAndJlptDatasetsImportedAndLoaded();
    expect(p6Report.executed, isTrue);
    expect(p6Report.success, isTrue);
    expect(p6Report.orphanRecordCount, equals(0));
    expect(p6Report.duplicateIdCount, equals(0));

    // Item 8 & 9: Verify existing data is 100% preserved and new tables/rows are populated with 0 FK violations
    final postInspection = p6Report.postImportInspection;
    expect(postInspection.isHealthy, isTrue);
    expect(postInspection.foreignKeysEnabled, isTrue);
    expect(postInspection.foreignKeyViolations, isEmpty);
    expect(postInspection.tableRowCounts['vocabularies'], equals(7811));
    expect(postInspection.tableRowCounts['kanji_entries'], equals(2383));
    expect(postInspection.tableRowCounts['grammar_points'], equals(1164));
    expect(postInspection.tableRowCounts['example_sentences'], equals(16691));
    expect(postInspection.tableRowCounts['reading_materials'], equals(40));
    expect(postInspection.tableRowCounts['vocabulary_cache'], equals(7811));
    expect(postInspection.tableRowCounts['flashcard_progress'], equals(1));
    expect(postInspection.tableRowCounts['test_history'], equals(1));

    expect(postInspection.tableRowCounts['licenses'], equals(5));
    expect(postInspection.tableRowCounts['data_sources'], equals(5));
    expect(postInspection.tableRowCounts['listening_materials'], equals(308));
    expect(postInspection.tableRowCounts['transcripts'], equals(308));
    expect(postInspection.tableRowCounts['exams'], equals(5));
    expect(postInspection.tableRowCounts['questions'], equals(176)); // 146 JLPT + 30 Listening
    expect(postInspection.tableRowCounts['answers'], equals(704));

    // Item 10: Re-running import is 100% idempotent (updates in-place without duplicates or FK errors)
    final secondRunSkip =
        await LocalDatabaseService.instance.importListeningAndJlptDatasets();
    expect(secondRunSkip.executed, isFalse);

    final forcedRerun = await LocalDatabaseService.instance
        .importListeningAndJlptDatasets(forceReimport: true);
    expect(forcedRerun.executed, isTrue);
    expect(forcedRerun.success, isTrue);
    expect(forcedRerun.orphanRecordCount, equals(0));
    expect(forcedRerun.tableResults['listening_materials']!.insertedCount, equals(0));
    expect(forcedRerun.tableResults['listening_materials']!.updatedCount, equals(308));
    expect(forcedRerun.tableResults['questions']!.insertedCount, equals(0));
    expect(forcedRerun.tableResults['questions']!.updatedCount, equals(176));
    expect(forcedRerun.postImportInspection.tableRowCounts['listening_materials'], equals(308));
    expect(forcedRerun.postImportInspection.tableRowCounts['questions'], equals(176));

    // Item 11 & 12: Querying by N5-N1 returns exact playable items and excludes all 278 metadata_only items
    final totalListeningInDb =
        await LocalDatabaseService.instance.getTotalListeningMaterialCount();
    expect(totalListeningInDb, equals(308));

    final playableListeningCount =
        await LocalDatabaseService.instance.getListeningMaterialCount(playableOnly: true);
    expect(playableListeningCount, equals(30));

    final allPlayable =
        await LocalDatabaseService.instance.getPlayableListeningItems();
    expect(allPlayable.length, equals(30));
    expect(allPlayable.every((item) => item.audioStatus == 'available'), isTrue);
    expect(allPlayable.any((item) => item.audioStatus == 'metadata_only'), isFalse);

    for (final lvl in ['N5', 'N4', 'N3', 'N2', 'N1']) {
      final lvlItems =
          await LocalDatabaseService.instance.getPlayableListeningItems(level: lvl);
      expect(lvlItems.length, equals(6), reason: 'Expected 6 playable items for $lvl');
      expect(lvlItems.every((it) => it.estimatedLevel == lvl), isTrue);
      expect(lvlItems.every((it) => it.levelSource == 'estimated'), isTrue);
      expect(lvlItems.every((it) => it.options.length == 4), isTrue);
    }

    // Item 13: Verify JLPT exams by level N5-N1 and ensure 0 missing-answer or OCR-corrupted questions are in quiz
    const expectedJlptCounts = <String, int>{
      'N5': 15,
      'N4': 36,
      'N3': 34,
      'N2': 42,
      'N1': 19,
    };
    final allTests = JLPTTestData.getAllTests();
    expect(allTests.length, equals(5));
    for (final entry in expectedJlptCounts.entries) {
      final lvlTests = JLPTTestData.getTestsByLevel(entry.key);
      expect(lvlTests.length, equals(1));
      expect(lvlTests.first.questions.length, equals(entry.value));
      for (final q in lvlTests.first.questions) {
        expect(q.options.length, equals(4));
        expect(q.correctIndex, inInclusiveRange(0, 3));
        expect(q.question, contains('official_exam'));
      }
    }

    final badQuestionsInDb = Sqflite.firstIntValue(
      await db.rawQuery(
        "SELECT COUNT(*) FROM questions WHERE id LIKE 'jlpt_audit_%' OR id LIKE 'jlpt_script_%'",
      ),
    );
    expect(badQuestionsInDb, equals(0));
  });

  testWidgets('13. [Prompt 6 - Flutter 10.3 Listening] ListeningPracticeScreen renders SQLite items, filters N5-N1, plays/pauses/replays audio via mock controller, toggles transcript/reading, and grades answers', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.runAsync(() async {
      await LocalDatabaseService.instance
          .ensureListeningAndJlptDatasetsImportedAndLoaded();
    });

    final mockAudioController = MockListeningAudioController();
    final n5PlayableItems =
        LocalDatabaseService.getLoadedListeningItemsByLevel('N5');
    expect(n5PlayableItems.length, equals(6));

    final settingsProvider = SettingsProvider();
    final vocabProvider = VocabularyProvider();
    final progressProvider = ProgressProvider();
    final authProvider = AuthProvider();
    final historyProvider = StudyHistoryProvider();

    await tester.binding.setSurfaceSize(const Size(1080, 1920));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
        ],
        child: MaterialApp(
          home: ListeningPracticeScreen(
            level: 'N5',
            audioController: mockAudioController,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Item 14: Displays N5 playable items from SQLite with estimated badge
    expect(find.textContaining('Câu 1/6'), findsOneWidget);
    expect(find.textContaining('Độ khó ước lượng: N5 (estimated)'), findsOneWidget);
    expect(find.text('Phát audio'), findsOneWidget);
    expect(find.text('Tạm dừng'), findsOneWidget);
    expect(find.text('Nghe lại'), findsOneWidget);
    expect(find.text('Hiện transcript'), findsOneWidget);

    // Item 16: Tap play, pause & replay via mock controller and verify exact audio_path & metadata_only guard
    await tester.tap(find.text('Phát audio'));
    await tester.pump();
    expect(mockAudioController.playCount, equals(1));
    expect(mockAudioController.playedAudioPaths.first, equals(n5PlayableItems.first.audioPath));

    await tester.tap(find.text('Tạm dừng'));
    await tester.pump();
    expect(mockAudioController.pauseCount, equals(1));

    await tester.tap(find.text('Nghe lại'));
    await tester.pump();
    expect(mockAudioController.replayCount, equals(1));
    expect(mockAudioController.playedAudioPaths.last, equals(n5PlayableItems.first.audioPath));

    // Verify metadata_only record is strictly rejected by both Mock and Default audio controllers
    const metadataOnlyItem = ListeningPracticeItem(
      id: 'kokoro_meta_only_test',
      sourceId: 'src_kokoro_tiny',
      externalClipId: 'gongitsune_0001',
      title: 'Metadata Only Clip',
      audioPath: '',
      audioStatus: 'metadata_only',
      durationMs: 4200,
      sampleRate: 22050,
      speakerName: 'ekzemplaro',
      estimatedLevel: 'N5',
      levelSource: 'estimated',
      difficultyScore: 0.12,
      transcriptNormalized: 'ごんぎつね',
      transcriptOriginal: 'ごんぎつね',
      reading: 'ごんぎつね',
      questionId: 'q_meta_only',
      promptVi: 'Test',
      promptJp: 'ごんぎつね',
      options: ['A', 'B', 'C', 'D'],
      correctIndex: 0,
      explanation: 'Test',
    );
    expect(metadataOnlyItem.isPlayable, isFalse);
    final mockMetaPlay = await mockAudioController.playItem(metadataOnlyItem);
    expect(mockMetaPlay, isFalse);
    expect(mockAudioController.blockedMetadataOnlyCalls, equals(1));
    expect(mockAudioController.playCount, equals(1)); // Unchanged!

    final defaultController = DefaultListeningAudioController();
    final defaultMetaPlay = await defaultController.playItem(metadataOnlyItem);
    expect(defaultMetaPlay, isFalse);
    defaultController.dispose();

    // Item 17: Show / hide transcript and reading
    expect(find.textContaining('Transcript:'), findsNothing);
    await tester.tap(find.text('Hiện transcript'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Transcript:'), findsOneWidget);
    expect(find.text('Ẩn transcript'), findsOneWidget);

    await tester.tap(find.text('Ẩn transcript'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Transcript:'), findsNothing);

    await tester.tap(find.text('Hiện cách đọc'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Cách đọc (Hiragana):'), findsOneWidget);

    // Select option A and check answer
    await tester.tap(find.text('A'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Kiểm tra đáp án ✔'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Đáp án đúng:'), findsOneWidget);
    expect(find.text('Câu tiếp theo →'), findsOneWidget);

    // Item 15: Filter by 'Tất cả' (30 playable items) and 'N3' (6 playable items)
    await tester.tap(find.widgetWithText(ChoiceChip, 'Tất cả'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Câu 1/30'), findsOneWidget);

    await tester.tap(find.widgetWithText(ChoiceChip, 'N3'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Câu 1/6'), findsOneWidget);
    expect(find.textContaining('Độ khó ước lượng: N3 (estimated)'), findsOneWidget);
  });

  testWidgets('14. [Prompt 6 - Flutter 10.3 JLPT] JLPTScreen renders N5-N1 exams, filters sections with Empty State for unsupported sections, grades answers, and shows explanations', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.runAsync(() async {
      await LocalDatabaseService.instance
          .ensureListeningAndJlptDatasetsImportedAndLoaded();
    });

    final settingsProvider = SettingsProvider();
    final progressProvider = ProgressProvider();
    final authProvider = AuthProvider();
    final historyProvider = StudyHistoryProvider();

    await tester.binding.setSurfaceSize(const Size(1080, 1920));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
        ],
        child: const MaterialApp(
          home: JLPTScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Item 18: Displays N5 exam with official_exam badge
    expect(find.text('N5 • 1 đề'), findsOneWidget);
    expect(find.text('15 câu hỏi'), findsOneWidget);
    expect(find.text('Nguồn độ khó: Đề thi thật (official_exam)'), findsOneWidget);

    // Item 20: Filtering by 'Nghe hiểu' or 'Đọc hiểu' shows Empty State because jlpt-freq has script_only / OCR reading
    await tester.tap(find.widgetWithText(ChoiceChip, 'Nghe hiểu'));
    await tester.pumpAndSettle();
    expect(find.text('Chưa có dữ liệu luyện thi.'), findsOneWidget);
    expect(find.text('Bắt đầu làm bài'), findsNothing);

    // Filter by 'Ngữ pháp' -> shows verified N5 grammar questions
    final n5GrammarCount = JLPTTestData.getTestsByLevel('N5')
        .first
        .questions
        .where((q) => q.type == QuestionType.grammar)
        .length;
    expect(n5GrammarCount, greaterThan(0));

    await tester.tap(find.widgetWithText(ChoiceChip, 'Ngữ pháp'));
    await tester.pumpAndSettle();
    expect(find.text('$n5GrammarCount câu hỏi'), findsOneWidget);
    expect(find.text('Bắt đầu làm bài'), findsOneWidget);

    // Item 19: Start exam, select answer, grade, and view explanation
    await tester.tap(find.text('Bắt đầu làm bài'));
    await tester.pumpAndSettle();

    expect(find.textContaining('Câu 1/$n5GrammarCount'), findsOneWidget);
    expect(find.textContaining('Cấp độ chính thức: N5 (official_exam)'), findsOneWidget);

    await tester.tap(find.text('A'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Kiểm tra đáp án'));
    await tester.pumpAndSettle();

    expect(find.text('Giải thích'), findsOneWidget);
    expect(find.text('Câu tiếp theo'), findsOneWidget);
  });

  testWidgets('15. [Admin Dev Mode] Admin sample account signs in, unlocks all 5 JLPT worlds & levels, provides 999999 virtual Coins/Gems without polluting raw persisted balances, and renders AdminToolsScreen', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    final authProvider = AuthProvider();
    final progressProvider = ProgressProvider();
    final vocabProvider = VocabularyProvider();

    await tester.runAsync(() async {
      await progressProvider.init();
      final signedIn = await authProvider.signIn(
        email: AuthService.adminEmail,
        password: AuthService.adminPassword,
      );
      expect(signedIn, isTrue);
      await progressProvider.reloadForCurrentUser(
        preferRemote: false,
        isAdmin: authProvider.isAdmin,
      );
    });

    expect(authProvider.isAdmin, isTrue);
    expect(authProvider.currentUser?.displayName, equals('Admin NihonGo'));
    expect(progressProvider.isAdminAccount, isTrue);
    expect(progressProvider.isAdminMode, isTrue);
    expect(progressProvider.progress.coins, equals(999999));
    expect(progressProvider.progress.gems, equals(999999));
    expect(progressProvider.progress.rawCoins, equals(0));
    expect(progressProvider.progress.rawGems, equals(0));
    expect(progressProvider.isWorldUnlocked(false), isTrue);
    expect(
      progressProvider.isMapLevelUnlocked(index: 9, previousLevelKey: 'vocab:N1:9'),
      isTrue,
    );

    await tester.binding.setSurfaceSize(const Size(1080, 1920));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: AdminToolsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Bảng điều khiển Admin (Dev)'), findsOneWidget);
    expect(find.text('Truy cập nhanh 5 Thế giới (N5 → N1)'), findsOneWidget);

    await tester.tap(find.byType(Switch));
    await tester.pumpAndSettle();
    expect(progressProvider.isAdminMode, isFalse);
    expect(progressProvider.progress.coins, equals(0));

    // Verify WorldGateScreen unlocks all 5 worlds (N5, N4, N3, N2, N1)
    for (final world in JlptWorld.all) {
      expect(world.isBuilt, isTrue);
    }

    // Re-enable Unlimited Mode and verify WorldRoadmapScreen for all 5 worlds (N5 -> N1)
    progressProvider.setAdminUnlimitedOverride(true);
    await tester.runAsync(() async {
      await LocalDatabaseService.instance.ensureVerifiedDatasetImportedAndLoaded();
      await vocabProvider.init();
    });

    // 1. N5 Ocean World
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: MaterialApp(
          home: WorldRoadmapScreen(world: JlptWorld.all[0]),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));

    expect(find.text('N5 · Đại dương huyền bí'), findsOneWidget);
    expect(find.byType(UnderwaterBubblesOverlay), findsOneWidget);
    expect(find.byKey(const ValueKey('map-cat-submarine')), findsOneWidget);
    for (var i = 1; i <= 10; i++) {
      expect(find.byKey(ValueKey('map-node-$i')), findsOneWidget);
    }

    // 2. N4 Tech World
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: MaterialApp(
          home: WorldRoadmapScreen(world: JlptWorld.all[1]),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));

    expect(find.text('N4 · Thành phố công nghệ'), findsOneWidget);
    expect(find.byType(HoloTechParticlesOverlay), findsOneWidget);
    expect(find.byKey(const ValueKey('map-cat-hovercar')), findsOneWidget);
    for (var i = 1; i <= 10; i++) {
      expect(find.byKey(ValueKey('map-node-$i')), findsOneWidget);
    }

    // 3. N3 Travel World
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: MaterialApp(
          home: WorldRoadmapScreen(world: JlptWorld.all[2]),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));

    expect(find.text('N3 · Du hành thế giới'), findsOneWidget);
    expect(find.byType(DriftingSakuraPetalsOverlay), findsOneWidget);
    expect(find.byKey(const ValueKey('map-cat-biplane')), findsOneWidget);
    for (var i = 1; i <= 10; i++) {
      expect(find.byKey(ValueKey('map-node-$i')), findsOneWidget);
    }

    // 4. N2 Space World
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: MaterialApp(
          home: WorldRoadmapScreen(world: JlptWorld.all[3]),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));

    expect(find.text('N2 · Vũ trụ vô tận'), findsOneWidget);
    expect(find.byType(CosmicStardustOverlay), findsOneWidget);
    expect(find.byKey(const ValueKey('map-cat-ufo')), findsOneWidget);
    for (var i = 1; i <= 10; i++) {
      expect(find.byKey(ValueKey('map-node-$i')), findsOneWidget);
    }

    // 5. N1 Fairyland World
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: MaterialApp(
          home: WorldRoadmapScreen(world: JlptWorld.all[4]),
        ),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));

    expect(find.text('N1 · Vương quốc thần tiên'), findsOneWidget);
    expect(find.byType(FairyDustSparklesOverlay), findsOneWidget);
    expect(find.byKey(const ValueKey('map-cat-cloudboat')), findsOneWidget);
    for (var i = 1; i <= 10; i++) {
      expect(find.byKey(ValueKey('map-node-$i')), findsOneWidget);
    }
  });

  testWidgets('16. [Phase 2D & Phase 3 Pruned Catalog] Cozy Cat Room Drag-Snap, 5s Auto-Dismiss Speech Bubble, 5 Cats Shop & Selector, 10 Foods & 5 Outfits', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({'wallet_coins': 800, 'wallet_gems': 150});
    final progressProvider = ProgressProvider();
    await tester.runAsync(() async {
      await progressProvider.init();
    });

    // Verify 10 representative foods (4 fruits, 3 dishes, 3 seafood), 5 outfits, 5 cats & 10 room spots
    expect(CatCatalog.foods.length, equals(10));
    expect(
      CatCatalog.foods.where((f) => f.category == CatFoodCategory.fruits).length,
      equals(4),
    );
    expect(
      CatCatalog.foods.where((f) => f.category == CatFoodCategory.dishes).length,
      equals(3),
    );
    expect(
      CatCatalog.foods.where((f) => f.category == CatFoodCategory.seafood).length,
      equals(3),
    );
    expect(CatCatalog.outfits.length, equals(5));
    expect(CatCatalog.characters.length, equals(5));
    expect(CatCatalog.characters.where((c) => c.isFree).length, equals(1));
    expect(CatCatalog.characters.where((c) => !c.isFree && !c.isGemItem).length, equals(3));
    expect(CatCatalog.characters.where((c) => c.isGemItem).length, equals(1));
    expect(CatCatalog.roomSpots.length, equals(10));

    // Initial cat vitals, starter inventory & default cat (img_6883 - Chiến Thần Hào Quang)
    expect(progressProvider.progress.catHunger, equals(75));
    expect(progressProvider.progress.catEnergy, equals(80));
    expect(progressProvider.progress.catMood, equals(85));
    expect(progressProvider.foodCountFor(AppFoods.fruitApple), equals(2));
    expect(progressProvider.progress.selectedCatId, equals('img_6883'));
    expect(progressProvider.isCatOwned('img_6883'), isTrue);

    await tester.binding.setSurfaceSize(const Size(480, 960));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      ChangeNotifierProvider<ProgressProvider>.value(
        value: progressProvider,
        child: const MaterialApp(
          home: GuardianCatScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // 0a. Speech bubble is initially hidden until interaction; tapping cat shows "Trẫm — Con sen" & auto-hides after 5s
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsNothing);
    await tester.tap(find.byKey(const ValueKey('cat-room-avatar')));
    await tester.pump();
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsOneWidget);
    await tester.pump(const Duration(seconds: 5));
    await tester.pump();
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsNothing);

    // 0b. Drag-and-drop cat across room.png -> snaps to furniture spot & shows "Chỗ này view đẹp, trẫm chuẩn tấu ngự tại đây!" for 5s
    await tester.drag(find.byKey(const ValueKey('cat-room-avatar')), const Offset(-90, -70));
    await tester.pump();
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsOneWidget);
    expect(find.text('Chỗ này view đẹp, trẫm chuẩn tấu ngự tại đây!'), findsOneWidget);
    await tester.pump(const Duration(seconds: 5));
    await tester.pump();
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsNothing);

    // 1. Switch to Sub-tab 2: Shop -> Buy 1 'Táo Đỏ Aomori' (5 Xu)
    await tester.tap(find.byKey(const ValueKey('cat-subtab-shop')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('buy-food-${AppFoods.fruitApple}')));
    await tester.pumpAndSettle();
    expect(progressProvider.foodCountFor(AppFoods.fruitApple), equals(3));
    expect(progressProvider.progress.coins, equals(795));

    // 2. Switch to Shop Trang phục (32 bộ) -> Buy Outfit #1 (100 Xu)
    await tester.tap(find.byKey(const ValueKey('shop-tab-outfits')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('buy-outfit-0')));
    await tester.pumpAndSettle();
    expect(progressProvider.isOutfitOwned(AppAssets.outfits[0]), isTrue);
    expect(progressProvider.progress.coins, equals(695));
    expect(find.text('Đã sở hữu'), findsOneWidget);

    // 2b. Switch to Shop Linh Thú (24 mèo) -> Buy 'Hắc Miêu Mắt Lờ Đờ' (img_6831_2, 200 Xu)
    await tester.tap(find.byKey(const ValueKey('shop-tab-cats')));
    await tester.pumpAndSettle();
    expect(progressProvider.isCatOwned('img_6831_2'), isFalse);
    await tester.ensureVisible(find.byKey(const ValueKey('buy-cat-img_6831_2')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('buy-cat-img_6831_2')));
    await tester.pumpAndSettle();
    expect(progressProvider.isCatOwned('img_6831_2'), isTrue);
    expect(progressProvider.progress.coins, equals(495));

    // 3. Switch back to Sub-tab 1: Phòng Mèo -> Open Túi đồ -> Feed cat
    await tester.tap(find.byKey(const ValueKey('cat-subtab-room')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('cat-action-feed')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('sheet-feed-${AppFoods.fruitApple}')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));

    expect(progressProvider.foodCountFor(AppFoods.fruitApple), equals(2));
    expect(progressProvider.progress.catHunger, equals(90)); // 75 + 15
    expect(progressProvider.progress.catMood, equals(90)); // 85 + 5
    expect(find.byKey(const ValueKey('cat-room-speech-bubble')), findsOneWidget);

    // 4. Open Tủ đồ -> Equip Outfit #1
    await tester.tap(find.byKey(const ValueKey('cat-action-wardrobe')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('equip-outfit-0')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
    expect(progressProvider.progress.equippedOutfit, equals(AppAssets.outfits[0]));

    // 5. Switch to Shop Chủ đề (6) -> Buy 'Cyber Midnight' (300 Xu)
    await tester.tap(find.byKey(const ValueKey('cat-subtab-shop')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('shop-tab-themes')));
    await tester.pumpAndSettle();

    expect(progressProvider.isThemeUnlocked('cyber_midnight'), isFalse);
    await tester.ensureVisible(find.byKey(const ValueKey('buy-theme-cyber_midnight')));
    await tester.tap(find.byKey(const ValueKey('buy-theme-cyber_midnight')));
    await tester.pumpAndSettle();
    expect(progressProvider.isThemeUnlocked('cyber_midnight'), isTrue);
    expect(progressProvider.progress.coins, equals(195)); // 495 - 300

    // 6. Switch to Sub-tab 3: Cài đặt Mèo -> Toggle companion switch, Select 'Hắc Miêu Mắt Lờ Đờ' & 'Cyber Midnight' theme
    await tester.tap(find.byKey(const ValueKey('cat-subtab-settings')));
    await tester.pumpAndSettle();
    expect(progressProvider.progress.catCompanionEnabled, isTrue);

    await tester.tap(find.byKey(const ValueKey('cat-companion-switch')));
    await tester.pumpAndSettle();
    expect(progressProvider.progress.catCompanionEnabled, isFalse);

    await tester.ensureVisible(find.byKey(const ValueKey('select-cat-img_6831_2')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('select-cat-img_6831_2')));
    await tester.pumpAndSettle();
    expect(progressProvider.progress.selectedCatId, equals('img_6831_2'));

    await tester.ensureVisible(find.byKey(const ValueKey('select-theme-cyber_midnight')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('select-theme-cyber_midnight')));
    await tester.pumpAndSettle();
    expect(progressProvider.progress.selectedThemeId, equals('cyber_midnight'));

    // Let the 5-second speech & mood revert timers complete cleanly
    await tester.pump(const Duration(seconds: 6));
  });

  testWidgets(
      '17. [Phase 2E] 32 Outfit Metadata offsets, Dual Leaderboard (Streak & PK MR with 8 Ranks), PK Lobby, and 4x4 16-card 3D Battle with Shield Defuse',
      (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    final progressProvider = ProgressProvider();
    await tester.runAsync(() async {
      await progressProvider.init();
    });
    final authProvider = AuthProvider();

    // 1. Verify all 5 representative outfits have calibrated offsets in outfits_metadata.json & 3 Xu / 2 Gem split
    final metadataFile = File('assets/study/outfits/outfits_metadata.json');
    expect(metadataFile.existsSync(), isTrue);
    expect(AppAssets.outfits.length, equals(5));
    for (final outfitPath in AppAssets.outfits) {
      final meta = CatOutfitMetadataRegistry.forPath(outfitPath);
      expect(meta.assetPath, equals(outfitPath));
      expect(meta.scale, inInclusiveRange(0.85, 1.15));
      expect(meta.displayOffsetY, lessThan(0.0));
    }
    final coinOutfits = CatCatalog.outfits.where((o) => !o.isGemItem).toList();
    final gemOutfits = CatCatalog.outfits.where((o) => o.isGemItem).toList();
    expect(coinOutfits.length, equals(3));
    expect(gemOutfits.length, equals(2));
    for (final o in coinOutfits) {
      expect(o.coinPrice, inInclusiveRange(100, 500));
    }
    for (final o in gemOutfits) {
      expect(o.gemPrice, inInclusiveRange(30, 80));
    }

    // Verify all 10 sliced PK badges exist in assets/images/pk/
    final requiredPkBadges = <String>[
      AppAssets.badgeShieldCat,
      AppAssets.badgeTrophyCat,
      AppAssets.badgeDefeatGhost,
      ...AppAssets.pkRankBadges,
    ];
    expect(requiredPkBadges.length, equals(10));
    for (final badgePath in requiredPkBadges) {
      expect(File(badgePath).existsSync(), isTrue, reason: 'Missing $badgePath');
    }

    // Verify 8 Academic Cat Ranks mapped to rank_01 -> rank_07 badges
    expect(PkRankSystem.tiers.length, equals(8));
    expect(PkRankSystem.tierForMr(0).iconAsset, equals(AppAssets.rank01Bronze));
    expect(PkRankSystem.tierForMr(250).iconAsset, equals(AppAssets.rank02Silver));
    expect(PkRankSystem.tierForMr(500).iconAsset, equals(AppAssets.rank03Gold));
    expect(PkRankSystem.tierForMr(720).iconAsset, equals(AppAssets.rank04Purple));
    expect(PkRankSystem.tierForMr(1000).iconAsset, equals(AppAssets.rank05Diamond));
    expect(PkRankSystem.tierForMr(1400).iconAsset, equals(AppAssets.rank06Master));
    expect(PkRankSystem.tierForMr(1800).iconAsset, equals(AppAssets.rank06Master));
    expect(PkRankSystem.tierForMr(2200).iconAsset, equals(AppAssets.rank07Mythic));

    await tester.binding.setSurfaceSize(const Size(480, 1080));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<ProgressProvider>.value(
            value: progressProvider,
          ),
          ChangeNotifierProvider<AuthProvider>.value(
            value: authProvider,
          ),
        ],
        child: const MaterialApp(
          home: LeaderboardScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // 2. Verify Dual Leaderboard (Tab 1: Streak & Tab 2: PK MR + Hero Banner + Pinned Bar)
    expect(
      find.byKey(const ValueKey('leaderboard_pk_hero_banner')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('leaderboard_personal_pinned_bar')),
      findsOneWidget,
    );
    expect(find.text('Bục Vinh Danh Top 3 Streak Học Tập'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('leaderboard_tab_pk')));
    await tester.pumpAndSettle();
    expect(find.text('8 Bậc Rank Mèo Học Thuật (MR)'), findsOneWidget);
    expect(find.textContaining('Thần Mèo Đại Chiến'), findsWidgets);

    // 3. Tap Hero Banner to navigate to PKLobbyScreen
    await tester.tap(find.byKey(const ValueKey('leaderboard_pk_hero_banner')));
    await tester.pumpAndSettle();

    expect(find.text('Sảnh Đấu Mèo Nổ PK'), findsOneWidget);
    expect(find.text('16 Lá'), findsOneWidget);
    expect(find.text('2 Mèo Nổ'), findsOneWidget);
    expect(find.text('15s/Câu'), findsOneWidget);
    expect(find.text('Max 1 Khiên'), findsOneWidget);

    // 4. Tap Solo AI Mode Card to start a 4x4 16-card match
    await tester.ensureVisible(find.byKey(const ValueKey('pk_mode_solo_card')));
    await tester.tap(find.byKey(const ValueKey('pk_mode_solo_card')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));

    // Turn 1: Answer question right -> Receive 1/1 Shield
    expect(find.text('Khiên 🛡️ 0/1'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('pk_option_correct')));
    await tester.pump();
    expect(find.text('Khiên 🛡️ 1/1'), findsOneWidget);

    // Flip Card #1 (Safe Cat at slot 0) -> Survive & pass turn to Bot AI
    await tester.tap(find.byKey(const ValueKey('pk_card_slot_0')));
    for (var i = 0; i < 7; i++) {
      await tester.pump(const Duration(milliseconds: 500));
    }

    // Turn 2: Answer question right -> Keep 1/1 Shield
    await tester.tap(find.byKey(const ValueKey('pk_option_correct')));
    await tester.pump();
    expect(find.text('Khiên 🛡️ 1/1'), findsOneWidget);

    // Flip Card #2 (Exploding Cat at slot 1) while holding Shield 1/1 -> Shield blocks explosion & reshuffles!
    await tester.tap(find.byKey(const ValueKey('pk_card_slot_1')));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('Khiên 🛡️ 0/1'), findsOneWidget);
    expect(
      find.textContaining('KHIÊN BẢO HỘ ĐỠ ĐÒN!'),
      findsOneWidget,
    );

    // Let Shield defuse animation & Bot Turn 2 (where Bot hits Exploding Cat without Shield) complete
    for (var i = 0; i < 8; i++) {
      await tester.pump(const Duration(milliseconds: 500));
    }
    await tester.pumpAndSettle();

    // 5. Verify PKResultScreen shows Victory Trophy Cat Badge, +20 MR & Match Statistics
    expect(find.text('Kết Quả Trận Đấu PK'), findsOneWidget);
    expect(find.text('CHIẾN THẮNG! 🏆'), findsOneWidget);
    expect(find.byKey(const ValueKey('pk_result_badge_trophy_cat')), findsOneWidget);
    expect(find.text('+20 MR'), findsWidgets);
    expect(find.text('1 lần đỡ nổ'), findsOneWidget);
    expect(find.byKey(const ValueKey('pk_result_play_again_btn')), findsOneWidget);
    expect(find.byKey(const ValueKey('pk_result_back_lobby_btn')), findsOneWidget);
  });

  testWidgets(
      '18. [Phase 2F & Anti-Cheat] Sliced PK Banners, Pomodoro Anti-Cheat (-50 Xu & State Lock), Energy Drain, Admin God-Mode Full Inventory, Global Theme Persistence & JLPT 3 Modes',
      (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({
      'wallet_coins': 200,
      'wallet_gems': 50,
      'sound_enabled': false,
      'notifications': false,
    });

    // 1. Verify sliced PK Banners exist on disk
    expect(File(AppAssets.pkVictoryBanner).existsSync(), isTrue);
    expect(File(AppAssets.pkDefeatBanner).existsSync(), isTrue);

    // 2. Verify Pomodoro Anti-Cheat (-50 Xu penalty on AppLifecycleState.paused & State Lock)
    final progressProvider = ProgressProvider();
    final pomodoroProvider = PomodoroProvider();
    final themeProvider = ThemeProvider();
    final settingsProvider = SettingsProvider();
    await tester.runAsync(() async {
      await settingsProvider.init();
      await themeProvider.init();
      await progressProvider.init();
      await pomodoroProvider.init(progressProvider: progressProvider);
    });

    expect(progressProvider.progress.coins, equals(200));
    pomodoroProvider.selectDurationMinutes(15);
    expect(pomodoroProvider.selectedMinutes, equals(15));
    await tester.runAsync(() async {
      await pomodoroProvider.startTimer();
    });
    expect(pomodoroProvider.isRunning, isTrue);
    expect(pomodoroProvider.isStudyLocked, isTrue);

    // Simulate AppLifecycleState.paused -> cancels session & deducts 50 Xu
    pomodoroProvider.didChangeAppLifecycleState(AppLifecycleState.paused);
    await tester.runAsync(() async {
      await Future<void>.delayed(const Duration(milliseconds: 50));
    });
    await tester.pump(const Duration(milliseconds: 50));
    expect(pomodoroProvider.isRunning, isFalse);
    expect(progressProvider.progress.coins, equals(150));
    expect(pomodoroProvider.lastPenaltyMessage, isNotNull);

    // 3. Verify Energy Drain (-1 on vocab learned, -5 on test result, exhausted speech < 20%)
    final initialEnergy = progressProvider.progress.catEnergy; // 80
    progressProvider.markVocabLearned('vocab_test_1');
    expect(progressProvider.progress.catEnergy, equals(initialEnergy - 1)); // 79

    progressProvider.recordTestResult('N5', 8, 10);
    expect(progressProvider.progress.catEnergy, equals(initialEnergy - 6)); // 74

    await tester.runAsync(() async {
      await progressProvider.drainCatEnergy(60); // 74 - 60 = 14 (< 20%)
    });
    expect(progressProvider.progress.catEnergy, equals(14));
    expect(progressProvider.isCatExhausted, isTrue);
    expect(
      CatDialogueService.instance.exhaustedLine(),
      equals('Trẫm kiệt sức rồi! Con sen đi mua cá hồi nạp năng lượng ngay!'),
    );

    // 4. Verify Global Theme Persistence across guest state & LoginScreen
    await tester.runAsync(() async {
      await themeProvider.setTheme('ocean_blue');
      await progressProvider.buyAppTheme(themeId: 'ocean_blue', coinCost: 0);
      await progressProvider.selectAppTheme('ocean_blue');
      await progressProvider.useGuestState();
    });
    expect(themeProvider.selectedThemeId, equals('ocean_blue'));
    expect(progressProvider.progress.selectedThemeId, equals('ocean_blue'));

    final authProvider = AuthProvider();
    await tester.binding.setSurfaceSize(const Size(1080, 1920));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
        ],
        child: const MaterialApp(
          home: LoginScreen(),
        ),
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));
    expect(find.byType(LoginScreen), findsOneWidget);

    // 5. Verify Admin God-Mode unlocks all 24 cats, 32 outfits, 6 themes, and 36 foods (x99 each)
    await tester.runAsync(() async {
      final signedIn = await authProvider.signIn(
        email: AuthService.adminEmail,
        password: AuthService.adminPassword,
      );
      expect(signedIn, isTrue);
      await progressProvider.reloadForCurrentUser(
        preferRemote: false,
        isAdmin: authProvider.isAdmin,
      );
    });

    expect(progressProvider.isAdminMode, isTrue);
    expect(progressProvider.progress.ownedCatIds.length, equals(5));
    expect(progressProvider.progress.ownedOutfits.length, equals(5));
    expect(progressProvider.progress.unlockedThemeIds.length, equals(6));
    expect(progressProvider.progress.foodInventory.length, equals(10));
    for (final food in CatCatalog.foods) {
      expect(progressProvider.foodCountFor(food.assetPath), equals(99));
    }

    // 6. Verify Tab 2 JLPTScreen 3 Mode Tabs (Full Test, Mini Test, Skill Test)
    await tester.runAsync(() async {
      await LocalDatabaseService.instance
          .ensureListeningAndJlptDatasetsImportedAndLoaded();
    });
    final historyProvider = StudyHistoryProvider();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
        ],
        child: const MaterialApp(
          home: JLPTScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('jlpt-mode-full')), findsOneWidget);
    expect(find.byKey(const ValueKey('jlpt-mode-mini')), findsOneWidget);
    expect(find.byKey(const ValueKey('jlpt-mode-skill')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('jlpt-mode-mini')));
    await tester.pumpAndSettle();
    expect(find.textContaining('(Mini)'), findsOneWidget);
    expect(find.text('5 câu hỏi'), findsOneWidget);

    CatDialogueService.instance.dismiss();
    await tester.pump(const Duration(seconds: 6));
  });

  testWidgets(
      '19. [Phase 2G] CozyPalette HTML Hex Sync, Cat Drag & Snap Across Tabs 1-3 & Room Clip on Tab 4, and Unified 2-Tab ProfileScreen with Mocked 1:1 <500KB Avatar Upload',
      (WidgetTester tester) async {
    // 1. Verify exact HTML hex codes in CozyPalette & AppTheme default
    expect(CozyPalette.dustyRose.background, equals(const Color(0xFFFAF7F5)));
    expect(CozyPalette.dustyRose.surface, equals(const Color(0xFFFFFFFF)));
    expect(CozyPalette.dustyRose.primary, equals(const Color(0xFFB5838D)));
    expect(CozyPalette.dustyRose.primaryMuted, equals(const Color(0xFFE5989B)));
    expect(CozyPalette.dustyRose.textPrimary, equals(const Color(0xFF3D3135)));
    expect(CozyPalette.dustyRose.textSecondary, equals(const Color(0xFF8D7B82)));
    expect(CozyPalette.dustyRose.success, equals(const Color(0xFF8FA89B)));

    AppTheme.setActiveTheme('dusty_rose');
    expect(AppTheme.background, equals(CozyPalette.dustyRose.background));
    expect(AppTheme.surface, equals(CozyPalette.dustyRose.surface));
    expect(AppTheme.primary, equals(CozyPalette.dustyRose.primary));
    expect(AppTheme.primaryMuted, equals(CozyPalette.dustyRose.primaryMuted));
    expect(AppTheme.textPrimary, equals(CozyPalette.dustyRose.textPrimary));
    expect(AppTheme.textSecondary, equals(CozyPalette.dustyRose.textSecondary));
    expect(AppTheme.success, equals(CozyPalette.dustyRose.success));

    // 2. Mock ImagePicker via AvatarUploadService.mockPickBytes
    final samplePngBytes = File(AppIcons.coin).readAsBytesSync();
    AvatarUploadService.mockPickBytes = (_) async => samplePngBytes;
    addTearDown(() => AvatarUploadService.mockPickBytes = null);

    SharedPreferences.setMockInitialValues({
      'wallet_coins': 500,
      'wallet_gems': 100,
      'sound_enabled': false,
      'notifications': false,
    });

    final settingsProvider = SettingsProvider();
    final progressProvider = ProgressProvider();
    final authProvider = AuthProvider();
    final themeProvider = ThemeProvider();
    final pomodoroProvider = PomodoroProvider();
    final historyProvider = StudyHistoryProvider();
    final vocabProvider = VocabularyProvider();

    await tester.runAsync(() async {
      await settingsProvider.init();
      await themeProvider.init();
      await progressProvider.init();
      await pomodoroProvider.init(progressProvider: progressProvider);
      await authProvider.register(
        email: 'sakura@nihongo.jp',
        password: 'Password123',
        displayName: 'Sakura Chan',
      );
    });

    await tester.binding.setSurfaceSize(const Size(480, 1800));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    // 3. Test Unified 2-Sub-tab ProfileScreen (Profile & Privacy + System Settings)
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: ProfileScreen(initialTabIndex: 0),
        ),
      ),
    );
    await tester.pumpAndSettle();

    // Verify Sub-tab 1: Live Preview + Avatar Upload (1:1 crop & <= 500KB)
    expect(find.byKey(const ValueKey('profile-live-preview-card')), findsOneWidget);
    expect(find.byKey(const ValueKey('live-preview-vip-badge')), findsOneWidget);
    expect(find.byKey(const ValueKey('live-preview-streak-badge')), findsOneWidget);
    expect(find.byKey(const ValueKey('live-preview-bio-box')), findsOneWidget);

    await tester.runAsync(() async {
      final uploadRes = await AvatarUploadService.instance.cropAndCompressBytes(samplePngBytes);
      expect(uploadRes.width, equals(uploadRes.height)); // Strictly 1:1 square
      expect(uploadRes.sizeInBytes, lessThanOrEqualTo(AvatarUploadService.maxAvatarBytes)); // <= 500KB
    });

    await tester.tap(find.byKey(const ValueKey('avatar-upload-gallery-btn')));
    await tester.pumpAndSettle();

    final savedAvatarUri = progressProvider.progress.avatarBase64;
    expect(savedAvatarUri, isNotNull);
    expect(savedAvatarUri!.startsWith('data:image/'), isTrue);
    final decodedAvatar = AvatarUploadService.decodeDataUri(savedAvatarUri);
    expect(decodedAvatar, isNotNull);
    expect(decodedAvatar!.lengthInBytes, lessThanOrEqualTo(AvatarUploadService.maxAvatarBytes));

    // Update Bio & toggle Privacy Switches -> verify real-time Live Preview reaction
    await tester.enterText(
      find.byKey(const ValueKey('profile-bio-input')),
      'Chiến thần N2 bất bại!',
    );
    await tester.pump();
    expect(find.text('“Chiến thần N2 bất bại!”'), findsOneWidget);

    await tester.ensureVisible(find.byKey(const ValueKey('privacy-switch-bio')));
    await tester.tap(find.byKey(const ValueKey('privacy-switch-bio')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('live-preview-bio-box')), findsNothing);
    expect(progressProvider.progress.showBio, isFalse);

    // Switch to Sub-tab 2: System Settings
    await tester.tap(find.byKey(const ValueKey('profile-subtab-settings')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('settings-theme-option-dusty_rose')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-theme-option-ocean_blue')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-theme-option-sky_butter')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-theme-option-white_sage')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-switch-ui-guide')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-slider-cat-scale')), findsOneWidget);
    expect(find.byKey(const ValueKey('settings-logout-button')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('settings-switch-ui-guide')));
    await tester.pumpAndSettle();
    expect(settingsProvider.uiGuideEnabled, isFalse);

    // 4. Verify MainShell Cat Companion visibility on Tabs 1-3 vs hidden on Tab 4 (where room.png clip stage is active)
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ],
        child: const MaterialApp(
          home: MainShell(initialIndex: 0),
        ),
      ),
    );
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.byKey(const ValueKey('companion-cat')), findsOneWidget);

    // Switch to Tab 3 (Xếp hạng) -> companion cat remains active & can snap to cards
    await tester.tap(find.text('Xếp hạng'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.byKey(const ValueKey('companion-cat')), findsOneWidget);

    // Switch to Tab 4 (Trợ lý AI & Không gian) -> bottom-bar companion cat is hidden, and room.png stage clip is active
    await tester.tap(find.text('Trợ lý AI & Không gian'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.byKey(const ValueKey('companion-cat')), findsNothing);
    expect(find.byKey(const ValueKey('cat-room-stage-clip')), findsOneWidget);
    expect(find.byKey(const ValueKey('cat-room-avatar')), findsOneWidget);

    CatDialogueService.instance.dismiss();
    await tester.pump(const Duration(seconds: 6));
  });

  testWidgets(
      '20. [Phase 3 Gemini RAG Engine & Strict Badge Integrity] Real AI Exam Generation (is_ai_generated=1, src_gemini_rag) vs Offline SQLite Fallback (is_ai_generated=0, src_sqlite_backup)',
      (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({
      'wallet_coins': 200,
      'wallet_gems': 50,
      'sound_enabled': false,
      'notifications': false,
    });

    await tester.runAsync(() async {
      await LocalDatabaseService.instance
          .ensureListeningAndJlptDatasetsImportedAndLoaded();
    });

    final settingsProvider = SettingsProvider();
    final progressProvider = ProgressProvider();
    final authProvider = AuthProvider();
    final historyProvider = StudyHistoryProvider();
    final pomodoroProvider = PomodoroProvider();
    final themeProvider = ThemeProvider();

    await tester.runAsync(() async {
      await settingsProvider.init();
      await themeProvider.init();
      await progressProvider.init();
      await pomodoroProvider.init(progressProvider: progressProvider);
    });

    addTearDown(() {
      GeminiExamService.instance.configureForTesting(
        httpPostOverride: null,
        apiKeyOverride: null,
        proxyUrlOverride: null,
      );
    });

    // CASE A: Mocked Gemini Flash HTTP 200 Response -> Real AI Exam (is_ai_generated = 1, src_gemini_rag)
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'test_runtime_key_not_hardcoded',
      httpPostOverride: (uri, headers, body) async {
        final mockPayload = <String, Object?>{
          'candidates': <Map<String, Object?>>[
            <String, Object?>{
              'content': <String, Object?>{
                'parts': <Map<String, Object?>>[
                  <String, Object?>{
                    'text': jsonEncode(<String, Object?>{
                      'title': 'Đề thi AI RAG JLPT N5 - Đọc hiểu & Ngữ cảnh',
                      'reading_passage':
                          '私は毎日家族と一緒に朝ご飯を食べます。それから電車で学校へ行きます。',
                      'questions': List<Map<String, Object?>>.generate(
                        5,
                        (idx) => <String, Object?>{
                          'question_jp': '問題${idx + 1}: 「家族」の読み方は何ですか。',
                          'question_vi':
                              'Câu ${idx + 1}: Cách đọc đúng của từ trong đoạn văn là gì?',
                          'options': <String>[
                            'かぞく',
                            'ともだち',
                            'せんせい',
                            'がくせい',
                          ],
                          'correct_index': 0,
                          'explanation':
                              '「家族」（かぞく）nghĩa là gia đình (truy xuất từ kho từ vựng N5).',
                          'type': 'reading',
                        },
                      ),
                    }),
                  },
                ],
              },
            },
          ],
        };
        return GeminiHttpResponse(
          statusCode: 200,
          body: jsonEncode(mockPayload),
        );
      },
    );

    await tester.binding.setSurfaceSize(const Size(800, 1200));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
        ],
        child: const MaterialApp(
          home: JLPTScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final aiBtnFinder = find.byKey(const ValueKey('jlpt-ai-rag-generate-btn-N5'));
    expect(aiBtnFinder, findsOneWidget);

    late GeminiExamGenerationResult aiResult;
    await tester.runAsync(() async {
      aiResult = await GeminiExamService.instance.generateExam(level: 'N5');
    });

    expect(aiResult.isAiGenerated, isTrue);
    expect(aiResult.isFallback, isFalse);
    expect(aiResult.sourceId, equals('src_gemini_rag'));
    expect(aiResult.test.questions.length, equals(5));
    expect(aiResult.ragContext.vocabularies.length, inInclusiveRange(5, 10));
    expect(aiResult.ragContext.grammarPoints.length, inInclusiveRange(2, 3));

    // Verify SQLite persistence for AI exam (is_ai_generated = 1, source_id = 'src_gemini_rag')
    await tester.runAsync(() async {
      final db = await LocalDatabaseService.instance.database;
      final rows = await db.query(
        'exams',
        where: 'id = ?',
        whereArgs: <Object>[aiResult.test.id],
      );
      expect(rows, hasLength(1));
      expect(rows.first['is_ai_generated'], equals(1));
      expect(rows.first['source_id'], equals('src_gemini_rag'));
      expect(await db.rawQuery('PRAGMA foreign_key_check'), isEmpty);
    });

    // Render TestScreen for AI-generated exam -> verify '🤖 AI Generated' badge & NO fallback badge
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
        ],
        child: MaterialApp(
          home: TestScreen(test: aiResult.test),
        ),
      ),
    );
    await tester.pump();

    expect(find.byKey(const ValueKey('exam-badge-ai-generated')), findsOneWidget);
    expect(find.text('🤖 AI Generated'), findsOneWidget);
    expect(find.byKey(const ValueKey('exam-reading-passage-card')), findsOneWidget);
    expect(find.byKey(const ValueKey('exam-badge-sqlite-fallback')), findsNothing);
    expect(find.text('📁 Đề thi mẫu ngoại tuyến (SQLite Fallback)'), findsNothing);

    // CASE B: Quota 429 / Network Failure -> Offline SQLite Fallback (is_ai_generated = 0, src_sqlite_backup)
    GeminiExamService.instance.configureForTesting(
      apiKeyOverride: 'test_runtime_key_not_hardcoded',
      httpPostOverride: (uri, headers, body) async {
        return const GeminiHttpResponse(
          statusCode: 429,
          body: '{"error":{"code":429,"message":"Resource exhausted"}}',
        );
      },
    );

    late GeminiExamGenerationResult fallbackResult;
    await tester.runAsync(() async {
      fallbackResult = await GeminiExamService.instance.generateExam(level: 'N4');
    });

    expect(fallbackResult.isAiGenerated, isFalse);
    expect(fallbackResult.isFallback, isTrue);
    expect(fallbackResult.sourceId, equals('src_sqlite_backup'));
    expect(fallbackResult.test.questions.length, equals(5));

    // Verify SQLite persistence for Fallback exam (is_ai_generated = 0, source_id = 'src_sqlite_backup')
    await tester.runAsync(() async {
      final db = await LocalDatabaseService.instance.database;
      final rows = await db.query(
        'exams',
        where: 'id = ?',
        whereArgs: <Object>[fallbackResult.test.id],
      );
      expect(rows, hasLength(1));
      expect(rows.first['is_ai_generated'], equals(0));
      expect(rows.first['source_id'], equals('src_sqlite_backup'));
      expect(await db.rawQuery('PRAGMA foreign_key_check'), isEmpty);
    });

    // Render TestScreen for Fallback exam -> STRICT UI INTEGRITY: must show SQLite Fallback badge & notice, NEVER '🤖 AI Generated'
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
          ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
          ChangeNotifierProvider<AuthProvider>.value(value: authProvider),
          ChangeNotifierProvider<StudyHistoryProvider>.value(value: historyProvider),
          ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoroProvider),
          ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
        ],
        child: MaterialApp(
          home: TestScreen(test: fallbackResult.test),
        ),
      ),
    );
    await tester.pump();

    expect(find.byKey(const ValueKey('exam-badge-sqlite-fallback')), findsOneWidget);
    expect(find.text('📁 Đề thi mẫu ngoại tuyến (SQLite Fallback)'), findsOneWidget);
    expect(find.byKey(const ValueKey('exam-fallback-notice')), findsOneWidget);
    expect(find.text('Đang sử dụng đề dự phòng do sự cố kết nối AI'), findsOneWidget);
    expect(find.byKey(const ValueKey('exam-badge-ai-generated')), findsNothing);
    expect(find.text('🤖 AI Generated'), findsNothing);
  });
}
