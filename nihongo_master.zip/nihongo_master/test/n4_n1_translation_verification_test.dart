import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/data/grammar_data.dart';
import 'package:nihongo_master/data/kanji_data.dart';
import 'package:nihongo_master/data/reading_material_data.dart';
import 'package:nihongo_master/models/grammar.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/providers/vocabulary_provider.dart';
import 'package:nihongo_master/screens/dictionary/dictionary_screen.dart';
import 'package:nihongo_master/screens/grammar/grammar_screen.dart';
import 'package:nihongo_master/screens/kanji/kanji_screen.dart';
import 'package:nihongo_master/screens/read/read_screen.dart';
import 'package:nihongo_master/screens/vocabulary/vocabulary_screen.dart';
import 'package:nihongo_master/services/local_database_service.dart';
import 'package:nihongo_master/utils/theme.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late String projectDbDir;
  late VocabularyProvider vocabProvider;
  late ProgressProvider progressProvider;
  late SettingsProvider settingsProvider;

  setUpAll(() async {
    SharedPreferences.setMockInitialValues({
      LocalDatabaseService.devResetPrefsKey: true,
    });

    projectDbDir = p.join(
      Directory.current.path,
      '.dart_tool',
      'sqflite_common_ffi',
      'databases_n4_n1',
    );
    Directory(projectDbDir).createSync(recursive: true);
    File(p.join(projectDbDir, LocalDatabaseService.devResetMarkerFileName))
        .writeAsStringSync('done');

    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(projectDbDir);

    // Import & synchronize verified dataset + N5 & N4-N1 Vietnamese translations into project SQLite DB
    await LocalDatabaseService.instance.ensureListeningAndJlptDatasetsImportedAndLoaded();
    await LocalDatabaseService.instance.syncTranslationsFromAssets(force: true);
    await LocalDatabaseService.instance.loadVerifiedDatasetsIntoMemory();

    vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();
    progressProvider = ProgressProvider();
    settingsProvider = SettingsProvider();
  });

  tearDownAll(() async {
    await LocalDatabaseService.instance.closeDatabaseSafely();
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(null);
  });

  Widget wrapWithProviders(Widget child) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
        ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
      ],
      child: MaterialApp(
        theme: AppTheme.lightThemeFor(AppTheme.specFor('dusty_rose')),
        home: child,
      ),
    );
  }

  Future<void> configureViewport(WidgetTester tester) async {
    tester.view.physicalSize = const Size(800, 1400);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
  }

  test('1. SQLite Sync & Counts: N4-N1 and N5 translation counts, vocabulary_cache, and reviewed records', () async {
    final db = await LocalDatabaseService.instance.database;

    expect(await db.getVersion(), 3);
    expect(await db.rawQuery('PRAGMA foreign_key_check'), isEmpty);

    // Total counts per table
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM vocabularies')), 7811);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM kanji_entries')), 2383);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM grammar_points')), 1164);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM reading_materials')), 40);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM example_sentences')), 16691);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM vocabulary_cache')), 7811);

    // Per-level translated counts for N4, N3, N2, N1 (and N5 regression)
    final expectedVocabByLevel = {'N5': 120, 'N4': 50, 'N3': 50, 'N2': 50, 'N1': 50};
    for (final entry in expectedVocabByLevel.entries) {
      final cnt = Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM vocabularies WHERE original_level = ? AND translation_status = 'ai_translated' AND TRIM(COALESCE(meaning_vi, '')) != ''",
          [entry.key],
        ),
      );
      expect(cnt, entry.value, reason: 'vocabularies level ${entry.key}');

      final cacheCnt = Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM vocabulary_cache WHERE jlptLevel = ? AND TRIM(COALESCE(vietnamese, '')) != ''",
          [entry.key],
        ),
      );
      expect(cacheCnt, entry.value, reason: 'vocabulary_cache level ${entry.key}');
    }

    final expectedKanjiByLevel = {'N5': 20, 'N4': 10, 'N3': 10, 'N2': 10, 'N1': 10};
    for (final entry in expectedKanjiByLevel.entries) {
      final cnt = Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM kanji_entries WHERE original_level = ? AND translation_status = 'ai_translated' AND TRIM(COALESCE(meaning_vi, '')) != ''",
          [entry.key],
        ),
      );
      expect(cnt, entry.value, reason: 'kanji_entries level ${entry.key}');
    }

    final expectedGrammarByLevel = {'N5': 10, 'N4': 10, 'N3': 10, 'N2': 10, 'N1': 10};
    for (final entry in expectedGrammarByLevel.entries) {
      final cnt = Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM grammar_points WHERE original_level = ? AND translation_status = 'ai_translated' AND TRIM(COALESCE(title_vi, '')) != '' AND TRIM(COALESCE(explanation_vi, '')) != ''",
          [entry.key],
        ),
      );
      expect(cnt, entry.value, reason: 'grammar_points level ${entry.key}');
    }

    final expectedReadingByLevel = {'N5': 5, 'N4': 8, 'N3': 8, 'N2': 10, 'N1': 0};
    for (final entry in expectedReadingByLevel.entries) {
      final cnt = Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM reading_materials WHERE original_level = ? AND translation_status = 'ai_translated' AND TRIM(COALESCE(title_vi, '')) != '' AND TRIM(COALESCE(translation_vi, '')) != ''",
          [entry.key],
        ),
      );
      expect(cnt, entry.value, reason: 'reading_materials level ${entry.key}');
    }

    // Total example_sentences translated (235 N5 + 468 N4-N1 = 703)
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM example_sentences WHERE translation_status = 'ai_translated' AND TRIM(COALESCE(translation_vi, '')) != ''",
        ),
      ),
      703,
    );

    // Spot-check manually reviewed & refined N4-N1 records in SQLite
    final kYo = (await db.query('kanji_entries', where: 'id = ?', whereArgs: ['kanji_oj_4e0e'])).single;
    expect(kYo['character'], '与');
    expect(kYo['meaning_vi'], 'DỰ: cho, ban cho, trao tặng, tham dự');

    final kBou = (await db.query('kanji_entries', where: 'id = ?', whereArgs: ['kanji_oj_4ea1'])).single;
    expect(kBou['character'], '亡');
    expect(kBou['meaning_vi'], 'VONG: mất, chết, diệt vong');

    final kNami = (await db.query('kanji_entries', where: 'id = ?', whereArgs: ['kanji_oj_4e26'])).single;
    expect(kNami['character'], '並');
    expect(kNami['meaning_vi'], 'TỊNH: xếp hàng, sóng đôi, ngang hàng, bình thường');

    final kOka = (await db.query('kanji_entries', where: 'id = ?', whereArgs: ['kanji_oj_4e18'])).single;
    expect(kOka['character'], '丘');
    expect(kOka['meaning_vi'], 'KHÂU: gò, đồi');

    final rSamurai =
        (await db.query('reading_materials', where: 'id = ?', whereArgs: ['read_hb_jlpt_n2_reading_04'])).single;
    expect(rSamurai['title_vi'], 'Thế tiến thoái lưỡng nan của samurai trong Nhật Bản hiện đại');

    final gBekarazu =
        (await db.query('grammar_points', where: 'id = ?', whereArgs: ['gram_oj_n1_bekarazu-bekarazaru'])).single;
    expect(gBekarazu['title_vi'], 'Không được phép, tuyệt đối cấm (〜べからず / 〜べからざる)');
    expect((gBekarazu['explanation_vi'] as String).contains('「〜べからざる」'), isTrue);
  });

  testWidgets('2. VocabularyScreen: N4, N3, N2, N1 Vietnamese meanings, detail sheet examples, and search',
      (WidgetTester tester) async {
    await configureViewport(tester);

    for (final lvl in ['N4', 'N3', 'N2', 'N1']) {
      final translated =
          vocabProvider.allWords.where((w) => w.jlptLevel == lvl && w.vietnamese.trim().isNotEmpty).toList();
      expect(translated.length, 50, reason: 'VocabularyProvider level $lvl');
    }

    await tester.pumpWidget(wrapWithProviders(const VocabularyScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);
    expect(searchField, findsOneWidget);

    // Select N4 level chip and search N4 vocabulary 乗り換える -> đổi xe; chuyển tàu
    await tester.tap(find.text('N4').first);
    await tester.pumpAndSettle();
    await tester.enterText(searchField, '乗り換える');
    await tester.pumpAndSettle();
    expect(find.text('乗り換える'), findsWidgets);
    expect(find.text('đổi xe; chuyển tàu'), findsOneWidget);

    // Tap to open detail sheet and verify linked N4 Vietnamese example sentence
    await tester.tap(find.text('đổi xe; chuyển tàu'));
    await tester.pumpAndSettle();
    expect(find.text('Hãy đổi tàu ở ga Tokyo.'), findsOneWidget);
    Navigator.of(tester.element(find.byType(VocabularyScreen))).pop();
    await tester.pumpAndSettle();

    // Select N3 level chip and search N3 vocabulary 誇り by Vietnamese
    await tester.tap(find.text('N3').first);
    await tester.pumpAndSettle();
    await tester.enterText(searchField, 'niềm kiêu hãnh');
    await tester.pumpAndSettle();
    expect(find.text('誇り'), findsWidgets);
    expect(find.text('niềm tự hào; niềm kiêu hãnh'), findsOneWidget);

    // Select N2 level chip and search N2 vocabulary せっせと
    await tester.tap(find.text('N2').first);
    await tester.pumpAndSettle();
    await tester.enterText(searchField, 'せっせと');
    await tester.pumpAndSettle();
    expect(find.text('chăm chỉ; siêng năng'), findsOneWidget);

    // Select N1 level chip and search N1 vocabulary 遅くとも and verify detail sheet example
    await tester.tap(find.text('N1').first);
    await tester.pumpAndSettle();
    await tester.enterText(searchField, '遅くとも');
    await tester.pumpAndSettle();
    expect(find.text('muộn nhất là; chậm nhất là'), findsOneWidget);
    await tester.tap(find.text('muộn nhất là; chậm nhất là'));
    await tester.pumpAndSettle();
    expect(find.text('Muộn nhất là đến 12 giờ đêm, tôi sẽ về nhà.'), findsOneWidget);
    Navigator.of(tester.element(find.byType(VocabularyScreen))).pop();
    await tester.pumpAndSettle();

    await tester.enterText(searchField, '');
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('3. KanjiScreen: N4, N3, N2, N1 Kanji Vietnamese meanings, detail sheet, and search',
      (WidgetTester tester) async {
    await configureViewport(tester);

    for (final lvl in ['N4', 'N3', 'N2', 'N1']) {
      final translated =
          KanjiData.getKanjiByLevel(lvl).where((k) => k.vietnamese.trim().isNotEmpty).toList();
      expect(translated.length, 10, reason: 'KanjiData level $lvl');
    }

    await tester.pumpWidget(wrapWithProviders(const KanjiScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);

    // N4 Kanji 不 -> BẤT: không
    await tester.enterText(searchField, '不');
    await tester.pumpAndSettle();
    expect(find.text('BẤT: không'), findsOneWidget);

    // N3 Kanji 与 -> DỰ: cho
    await tester.enterText(searchField, '与');
    await tester.pumpAndSettle();
    expect(find.text('DỰ: cho'), findsOneWidget);
    await tester.tap(find.text('DỰ: cho'));
    await tester.pumpAndSettle();
    expect(find.textContaining('DỰ: cho, ban cho, trao tặng, tham dự'), findsOneWidget);
    Navigator.of(tester.element(find.byType(KanjiScreen))).pop();
    await tester.pumpAndSettle();

    // N2 Kanji 並 -> TỊNH: xếp hàng
    await tester.enterText(searchField, '並');
    await tester.pumpAndSettle();
    expect(find.text('TỊNH: xếp hàng'), findsOneWidget);

    // N1 Kanji 丘 -> KHÂU: gò
    await tester.enterText(searchField, '丘');
    await tester.pumpAndSettle();
    expect(find.text('KHÂU: gò'), findsOneWidget);

    await tester.enterText(searchField, '');
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('4. GrammarScreen & GrammarDetailScreen: N4, N3, N2, N1 Vietnamese titles, explanations, and examples',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final allLessons = GrammarData.getAllLessons();
    expect(allLessons.length, 1164);

    final translatedN4ToN1 = <GrammarLesson>[];
    for (final lvl in ['N4', 'N3', 'N2', 'N1']) {
      final lvlLessons = GrammarData.getLessonsByLevel(lvl)
          .where((g) => (g.titleVi ?? '').trim().isNotEmpty)
          .toList();
      expect(lvlLessons.length, 10, reason: 'GrammarData level $lvl');
      for (final lesson in lvlLessons) {
        expect(lesson.titleVi, isNotEmpty, reason: lesson.id);
        expect(lesson.explanationVi, isNotEmpty, reason: lesson.id);
        expect(lesson.examples, isNotEmpty, reason: lesson.id);
        for (final ex in lesson.examples) {
          expect(ex.vietnamese, isNotEmpty, reason: '${lesson.id}: ${ex.japanese}');
        }
      }
      translatedN4ToN1.addAll(lvlLessons);
    }

    GrammarData.setLoadedLessons(translatedN4ToN1);
    addTearDown(() => GrammarData.setLoadedLessons(allLessons));

    await tester.pumpWidget(wrapWithProviders(const GrammarScreen()));
    await tester.pumpAndSettle();

    // Filter by N4
    await tester.tap(find.text('N4').first);
    await tester.pumpAndSettle();
    expect(find.text('あげる / くれる / もらう'), findsOneWidget);
    expect(find.text('Cho, tặng và nhận (あげる・くれる・もらう)'), findsOneWidget);

    // Filter by N3
    await tester.tap(find.text('N3').first);
    await tester.pumpAndSettle();
    expect(find.text('〜ば〜ほど'), findsOneWidget);
    expect(find.text('Càng... càng... (〜ば〜ほど)'), findsOneWidget);

    // Filter by N2
    await tester.tap(find.text('N2').first);
    await tester.pumpAndSettle();
    expect(find.text('〜あげく'), findsOneWidget);
    expect(find.text('Sau một hồi, cuối cùng thì (〜あげく)'), findsOneWidget);

    // Filter by N1 and open GrammarDetailScreen
    await tester.tap(find.text('N1').first);
    await tester.pumpAndSettle();
    expect(find.text('〜あっての'), findsOneWidget);
    expect(find.text('Chính vì có... mới có... (〜あっての)'), findsOneWidget);

    await tester.tap(find.text('〜あっての'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Dùng để nhấn mạnh rằng một sự việc hoặc kết quả nào đó chỉ có được'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('5. ReadScreen & ReadDetailScreen: N4 (8), N3 (8), N2 (10), N1 (0) readings and full paragraph translations',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final allReadings = ReadingMaterialData.getAllMaterials();
    final n4Readings = allReadings.where((r) => r.originalLevel == 'N4' && (r.translationVi ?? '').isNotEmpty).toList();
    final n3Readings = allReadings.where((r) => r.originalLevel == 'N3' && (r.translationVi ?? '').isNotEmpty).toList();
    final n2Readings = allReadings.where((r) => r.originalLevel == 'N2' && (r.translationVi ?? '').isNotEmpty).toList();
    final n1Readings = allReadings.where((r) => r.originalLevel == 'N1').toList();

    expect(n4Readings.length, 8);
    expect(n3Readings.length, 8);
    expect(n2Readings.length, 10);
    expect(n1Readings.length, 0);

    await tester.pumpWidget(wrapWithProviders(const ReadScreen()));
    await tester.pumpAndSettle();

    // Filter N4 -> verify "Mua sắm cuối tuần"
    await tester.tap(find.text('N4').first);
    await tester.pumpAndSettle();
    expect(find.text('Mua sắm cuối tuần'), findsWidgets);

    // Filter N3 -> verify "Chú mèo đi lạc"
    await tester.tap(find.text('N3').first);
    await tester.pumpAndSettle();
    expect(find.text('Chú mèo đi lạc'), findsWidgets);

    // Filter N2 -> verify "Hậu duệ của samurai" and open ReadDetailScreen
    await tester.tap(find.text('N2').first);
    await tester.pumpAndSettle();
    expect(find.text('Hậu duệ của samurai'), findsWidgets);

    await tester.tap(find.text('Hậu duệ của samurai').first);
    await tester.pumpAndSettle();
    expect(find.text('Bản dịch / Tóm tắt'), findsOneWidget);
    expect(find.textContaining('có một nam sinh trung học tên là Hayato sinh sống'), findsOneWidget);

    Navigator.of(tester.element(find.byType(Scaffold).last)).pop();
    await tester.pumpAndSettle();

    // Filter N1 -> verify empty state renders cleanly without error
    await tester.tap(find.text('N1').first);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('6. DictionaryScreen: searches N4-N1 Vocabulary and Kanji by Japanese and Vietnamese',
      (WidgetTester tester) async {
    await configureViewport(tester);

    await tester.pumpWidget(wrapWithProviders(const DictionaryScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);

    // Search N4 Vocabulary by Vietnamese
    await tester.enterText(searchField, 'chuyển tàu');
    await tester.pumpAndSettle();
    expect(find.text('乗り換える'), findsWidgets);

    // Search N1 Vocabulary by Vietnamese
    await tester.enterText(searchField, 'mụn trứng cá');
    await tester.pumpAndSettle();
    expect(find.text('にきび'), findsWidgets);

    // Switch to Kanji tab and search N3/N2/N1 Kanji by Vietnamese
    await tester.tap(find.textContaining('Kanji').last);
    await tester.pumpAndSettle();

    await tester.enterText(searchField, 'trao tặng, tham dự');
    await tester.pumpAndSettle();
    expect(find.text('与'), findsOneWidget);

    await tester.enterText(searchField, 'donburi');
    await tester.pumpAndSettle();
    expect(find.text('丼'), findsOneWidget);

    expect(tester.takeException(), isNull);
  });
}
