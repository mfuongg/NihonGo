import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/data/grammar_data.dart';
import 'package:nihongo_master/data/kanji_data.dart';
import 'package:nihongo_master/data/reading_material_data.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/providers/vocabulary_provider.dart';
import 'package:nihongo_master/screens/dictionary/dictionary_screen.dart';
import 'package:nihongo_master/screens/grammar/grammar_screen.dart';
import 'package:nihongo_master/screens/kanji/kanji_screen.dart';
import 'package:nihongo_master/screens/read/read_screen.dart';
import 'package:nihongo_master/screens/vocabulary/vocabulary_screen.dart';
import 'package:nihongo_master/services/local_database_service.dart';
import 'package:nihongo_master/utils/theme.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late String projectDbDir;
  late VocabularyProvider vocabProvider;
  late ProgressProvider progressProvider;
  late SettingsProvider settingsProvider;

  setUpAll(() async {
    SharedPreferences.setMockInitialValues({
      LocalDatabaseService.devResetPrefsKey: true,
    });

    projectDbDir = p.join(
      Directory.current.path,
      '.dart_tool',
      'sqflite_common_ffi',
      'databases_n5',
    );
    Directory(projectDbDir).createSync(recursive: true);
    File(p.join(projectDbDir, LocalDatabaseService.devResetMarkerFileName))
        .writeAsStringSync('done');

    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(projectDbDir);

    // Import & sync verified dataset + N5 Vietnamese translations into project SQLite DB
    await LocalDatabaseService.instance.ensureListeningAndJlptDatasetsImportedAndLoaded();

    vocabProvider = VocabularyProvider();
    await vocabProvider.ensureLoaded();
    progressProvider = ProgressProvider();
    settingsProvider = SettingsProvider();
  });

  tearDownAll(() async {
    await LocalDatabaseService.instance.closeDatabaseSafely();
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(null);
  });

  Widget wrapWithProviders(Widget child) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<VocabularyProvider>.value(value: vocabProvider),
        ChangeNotifierProvider<ProgressProvider>.value(value: progressProvider),
        ChangeNotifierProvider<SettingsProvider>.value(value: settingsProvider),
      ],
      child: MaterialApp(
        theme: AppTheme.lightThemeFor(AppTheme.specFor('dusty_rose')),
        home: child,
      ),
    );
  }

  Future<void> configureViewport(WidgetTester tester) async {
    tester.view.physicalSize = const Size(800, 1400);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
  }

  test('1. SQLite Sync & Schema v3: counts, translation_status, vocabulary_cache, and 6 fixed N5 records', () async {
    final db = await LocalDatabaseService.instance.database;

    // 1.1 Schema version = 3 & foreign keys valid
    expect(await db.getVersion(), 3);
    expect(await db.rawQuery('PRAGMA foreign_key_check'), isEmpty);

    // 1.2 Total row counts match main JSON files
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM vocabularies')), 7811);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM kanji_entries')), 2383);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM grammar_points')), 1164);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM reading_materials')), 40);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM example_sentences')), 16691);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM vocabulary_cache')), 7811);

    // 1.3 Exact N5 ai_translated counts in SQLite (preserved across Phase 2 & Phase 3)
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM vocabularies WHERE original_level = 'N5' AND translation_status = 'ai_translated' AND TRIM(COALESCE(meaning_vi, '')) != ''",
        ),
      ),
      120,
    );
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM kanji_entries WHERE original_level = 'N5' AND translation_status = 'ai_translated' AND TRIM(COALESCE(meaning_vi, '')) != ''",
        ),
      ),
      20,
    );
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM grammar_points WHERE original_level = 'N5' AND translation_status = 'ai_translated' AND TRIM(COALESCE(title_vi, '')) != ''",
        ),
      ),
      10,
    );
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM reading_materials WHERE original_level = 'N5' AND translation_status = 'ai_translated' AND TRIM(COALESCE(translation_vi, '')) != ''",
        ),
      ),
      5,
    );

    // 1.4 Verify vocabulary_cache has 120 N5 items with Vietnamese meaning and translated examples
    expect(
      Sqflite.firstIntValue(
        await db.rawQuery(
          "SELECT COUNT(*) FROM vocabulary_cache WHERE jlptLevel = 'N5' AND TRIM(COALESCE(vietnamese, '')) != ''",
        ),
      ),
      120,
    );

    // 1.5 Verify all 6 fixed items in SQLite
    final vKazoku = (await db.query('vocabularies', where: 'id = ?', whereArgs: ['vocab_oj_n5_1c9db63bdc'])).single;
    expect(vKazoku['expression'], '家族');
    expect(vKazoku['meaning_vi'], 'gia đình; người nhà');
    expect(vKazoku['translation_status'], 'ai_translated');

    final vcKazoku =
        (await db.query('vocabulary_cache', where: 'id = ?', whereArgs: ['vocab_oj_n5_1c9db63bdc'])).single;
    expect(vcKazoku['vietnamese'], 'gia đình; người nhà');
    final kazokuExJp = jsonDecode(vcKazoku['exampleSentences'] as String) as List<dynamic>;
    final kazokuExTrans = jsonDecode(vcKazoku['exampleTranslations'] as String) as List<dynamic>;
    expect(kazokuExJp, isNotEmpty);
    expect(kazokuExTrans, ['Tôi có thể hỏi về gia đình bạn được không?']);

    final vNaku = (await db.query('vocabularies', where: 'id = ?', whereArgs: ['vocab_oj_n5_07a4101167'])).single;
    expect(vNaku['expression'], '鳴く');
    expect(vNaku['meaning_vi'], 'kêu, hót (chim, thú, côn trùng)');
    expect(vNaku['translation_status'], 'ai_translated');

    final vHon = (await db.query('vocabularies', where: 'id = ?', whereArgs: ['vocab_oj_n5_0e8f798dbf'])).single;
    expect(vHon['expression'], '本');
    expect(vHon['meaning_vi'], 'sách');
    expect(vHon['translation_status'], 'ai_translated');

    final gDeMeans = (await db.query('grammar_points', where: 'id = ?', whereArgs: ['gram_oj_n5_de-means'])).single;
    expect(gDeMeans['pattern'], '〜で（means）');
    expect(gDeMeans['title_vi'], 'bằng; với (phương tiện, công cụ, cách thức, ngôn ngữ)');
    expect(gDeMeans['translation_status'], 'ai_translated');

    final sDeshita1 =
        (await db.query('example_sentences', where: 'id = ?', whereArgs: ['sent_oj_gram_deshita_1'])).single;
    expect(sDeshita1['sentence_jp'], '子どものころ、野菜がきらいでした。');
    expect(sDeshita1['translation_vi'], 'Hồi còn nhỏ, tôi ghét ăn rau.');
    expect(sDeshita1['translation_status'], 'ai_translated');

    final kJo = (await db.query('kanji_entries', where: 'id = ?', whereArgs: ['kanji_oj_4e08'])).single;
    expect(kJo['character'], '丈');
    expect(kJo['meaning_vi'], 'TRƯỢNG: chiều cao, bề dài; vững vàng (trong 丈夫)');
    expect(kJo['translation_status'], 'ai_translated');

    // 1.6 Verify incremental syncTranslationsFromAssets(force: true) preserves learning progress
    await db.insert(
      'flashcard_progress',
      {'vocabId': 'vocab_oj_n5_1c9db63bdc', 'userId': 'guest', 'repetition': 5},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    final updatedCount = await LocalDatabaseService.instance.syncTranslationsFromAssets(force: true);
    expect(updatedCount, 1164); // 390 (N5) + 774 (N4-N1) = 1164

    final fpAfter = await db.query(
      'flashcard_progress',
      where: 'vocabId = ? AND userId = ?',
      whereArgs: ['vocab_oj_n5_1c9db63bdc', 'guest'],
    );
    expect(fpAfter.single['repetition'], 5);
    await db.delete(
      'flashcard_progress',
      where: 'vocabId = ? AND userId = ?',
      whereArgs: ['vocab_oj_n5_1c9db63bdc', 'guest'],
    );
  });

  testWidgets('2. VocabularyScreen: displays N5 Vietnamese meanings, examples in detail sheet, and search',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final translatedN5Words =
        vocabProvider.allWords.where((w) => w.jlptLevel == 'N5' && w.vietnamese.trim().isNotEmpty).toList();
    expect(translatedN5Words.length, 120);

    await tester.pumpWidget(wrapWithProviders(const VocabularyScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);
    expect(searchField, findsOneWidget);

    // Search for first N5 item 今年 -> năm nay
    await tester.enterText(searchField, '今年');
    await tester.pumpAndSettle();
    expect(find.text('今年'), findsWidgets);
    expect(find.text('năm nay'), findsOneWidget);

    // Search for fixed item 家族 -> gia đình; người nhà
    await tester.enterText(searchField, 'người nhà');
    await tester.pumpAndSettle();
    expect(find.text('家族'), findsOneWidget);
    expect(find.text('gia đình; người nhà'), findsOneWidget);

    // Tap the vocabulary card to open _WordDetailSheet and verify linked Vietnamese examples
    await tester.tap(find.text('gia đình; người nhà'));
    await tester.pumpAndSettle();
    expect(find.text('🇻🇳 Tiếng Việt'), findsOneWidget);
    expect(find.text('Tôi có thể hỏi về gia đình bạn được không?'), findsOneWidget);

    // Close detail sheet
    Navigator.of(tester.element(find.byType(VocabularyScreen))).pop();
    await tester.pumpAndSettle();

    // Search by Vietnamese meaning for fixed item 鳴く
    await tester.enterText(searchField, 'chim, thú, côn trùng');
    await tester.pumpAndSettle();
    expect(find.text('鳴く'), findsOneWidget);
    expect(find.text('kêu, hót (chim, thú, côn trùng)'), findsOneWidget);

    // Reset search
    await tester.enterText(searchField, '');
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('3. KanjiScreen: displays N5 Kanji Vietnamese meanings, detail sheet, and search',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final translatedN5Kanji =
        KanjiData.getKanjiByLevel('N5').where((k) => k.vietnamese.trim().isNotEmpty).toList();
    expect(translatedN5Kanji.length, 20);

    await tester.pumpWidget(wrapWithProviders(const KanjiScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);
    expect(searchField, findsOneWidget);

    // Search for 万 -> card shows text before first comma ("VẠN: vạn")
    await tester.enterText(searchField, '万');
    await tester.pumpAndSettle();
    expect(find.text('VẠN: vạn'), findsOneWidget);

    // Search for fixed Kanji 丈
    await tester.enterText(searchField, '丈');
    await tester.pumpAndSettle();
    // Grid card shows meaning before first comma: "TRƯỢNG: chiều cao"
    expect(find.text('TRƯỢNG: chiều cao'), findsOneWidget);

    // Tap card to open _KanjiDetailSheet and verify full meaning_vi
    await tester.tap(find.text('TRƯỢNG: chiều cao'));
    await tester.pumpAndSettle();
    expect(find.textContaining('TRƯỢNG: chiều cao, bề dài; vững vàng (trong 丈夫)'), findsOneWidget);
    expect(find.text('ジョウ'), findsOneWidget);

    Navigator.of(tester.element(find.byType(KanjiScreen))).pop();
    await tester.pumpAndSettle();
    await tester.enterText(searchField, '');
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('4. GrammarScreen & GrammarDetailScreen: displays all 10 N5 Vietnamese titles, explanations, and examples',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final allLessons = GrammarData.getAllLessons();
    expect(allLessons.length, 1164);
    final n5Lessons = GrammarData.getLessonsByLevel('N5');
    final translatedN5Lessons = n5Lessons.where((g) => (g.titleVi ?? '').trim().isNotEmpty).toList();
    expect(translatedN5Lessons.length, 10);
    for (final lesson in translatedN5Lessons) {
      expect(lesson.titleVi, isNotNull);
      expect(lesson.titleVi!, isNotEmpty, reason: lesson.id);
      expect(lesson.explanationVi, isNotNull);
      expect(lesson.explanationVi!, isNotEmpty, reason: lesson.id);
      expect(lesson.examples.length, 3, reason: lesson.id);
      for (final ex in lesson.examples) {
        expect(ex.vietnamese, isNotEmpty, reason: '${lesson.id}: ${ex.japanese}');
      }
    }

    GrammarData.setLoadedLessons(translatedN5Lessons);
    addTearDown(() => GrammarData.setLoadedLessons(allLessons));

    await tester.pumpWidget(wrapWithProviders(const GrammarScreen()));
    await tester.pumpAndSettle();

    expect(find.text('あまり〜ない'), findsOneWidget);
    expect(find.text('không... lắm; không mấy'), findsOneWidget);
    expect(find.text('〜で（means）'), findsOneWidget);
    expect(find.text('bằng; với (phương tiện, công cụ, cách thức, ngôn ngữ)'), findsOneWidget);

    // Scroll to 〜でした and open GrammarDetailScreen
    final mainScrollable = find.byType(Scrollable).first;
    await tester.scrollUntilVisible(
      find.text('〜でした'),
      200.0,
      scrollable: mainScrollable,
      maxScrolls: 20,
    );
    await tester.pumpAndSettle();
    expect(find.text('〜でした'), findsOneWidget);
    expect(find.text('đã là...; thì đã...'), findsOneWidget);

    await tester.tap(find.text('〜でした'));
    await tester.pumpAndSettle();

    expect(find.text('子どものころ、野菜がきらいでした。'), findsOneWidget);
    expect(find.text('Hồi còn nhỏ, tôi ghét ăn rau.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('5. ReadScreen & ReadDetailScreen: displays 5 N5 Vietnamese titles and 3-paragraph translation',
      (WidgetTester tester) async {
    await configureViewport(tester);

    final translatedN5Readings = ReadingMaterialData.getAllMaterials()
        .where((r) => r.originalLevel == 'N5' && (r.translationVi ?? '').trim().isNotEmpty)
        .toList();
    expect(translatedN5Readings.length, 5);
    for (final r in translatedN5Readings) {
      expect(r.title, isNotEmpty, reason: r.id);
      expect(r.translationVi, isNotNull, reason: r.id);
      expect(r.translationVi!, isNotEmpty, reason: r.id);
      expect(r.translationVi!.split('\n\n').length, 3, reason: r.id);
    }

    await tester.pumpWidget(wrapWithProviders(const ReadScreen()));
    await tester.pumpAndSettle();

    // Select N5 level chip
    await tester.tap(find.text('N5').first);
    await tester.pumpAndSettle();

    expect(find.text('Một ngày của tôi'), findsWidgets);
    expect(find.text('私の一日'), findsWidgets);

    // Open ReadDetailScreen for "Một ngày của tôi"
    await tester.tap(find.text('Một ngày của tôi').first);
    await tester.pumpAndSettle();

    expect(find.text('Một ngày của tôi'), findsWidgets);
    expect(find.text('Bản dịch / Tóm tắt'), findsOneWidget);
    expect(
      find.textContaining('Tôi là Tanaka Yuki. Tôi là học sinh. Mỗi sáng, tôi thức dậy lúc 6 giờ.'),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('6. DictionaryScreen: searches N5 Vocabulary and Kanji by Japanese and Vietnamese',
      (WidgetTester tester) async {
    await configureViewport(tester);

    await tester.pumpWidget(wrapWithProviders(const DictionaryScreen()));
    await tester.pumpAndSettle();

    final searchField = find.byType(TextField);
    expect(searchField, findsOneWidget);

    // Search N5 Vocabulary by Vietnamese substring
    await tester.enterText(searchField, 'người nhà');
    await tester.pumpAndSettle();
    expect(find.text('家族'), findsOneWidget);
    expect(find.text('gia đình; người nhà'), findsOneWidget);

    // Search fixed N5 Vocabulary 鳴く by Vietnamese
    await tester.enterText(searchField, 'chim, thú, côn trùng');
    await tester.pumpAndSettle();
    expect(find.text('鳴く'), findsOneWidget);
    expect(find.text('kêu, hót (chim, thú, côn trùng)'), findsOneWidget);

    // Switch to Kanji tab & search fixed Kanji 丈 by Vietnamese
    await tester.tap(find.textContaining('Kanji').last);
    await tester.pumpAndSettle();
    await tester.enterText(searchField, 'vững vàng');
    await tester.pumpAndSettle();
    expect(find.text('丈'), findsOneWidget);
    expect(find.text('TRƯỢNG: chiều cao, bề dài; vững vàng (trong 丈夫)'), findsOneWidget);

    // Search Kanji 万 by Vietnamese
    await tester.enterText(searchField, 'mười nghìn');
    await tester.pumpAndSettle();
    expect(find.text('万'), findsOneWidget);
    expect(find.text('VẠN: vạn, mười nghìn'), findsOneWidget);

    expect(tester.takeException(), isNull);
  });
}
