import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/models/cat_anim_state.dart';
import 'package:nihongo_master/services/cat_dialogue_service.dart';
import 'package:nihongo_master/services/cat_position_manager.dart';
import 'package:nihongo_master/widgets/line_companion_cat.dart';
import 'package:shared_preferences/shared_preferences.dart';

const double _catW = 120;
double get _catH => CatPositionManager.heightForWidth(_catW);

Widget _harness(CompanionCatController controller, {double cardTop = 300, int energy = 80}) {
  return MaterialApp(
    home: Scaffold(
      body: CompanionCatScope(
        controller: controller,
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: cardTop),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: CompanionLineAnchor(
                    id: 'test_card',
                    child: SizedBox(height: 120),
                  ),
                ),
              ],
            ),
            Positioned.fill(
              child: LineCompanionCat(controller: controller, energy: energy),
            ),
          ],
        ),
      ),
    ),
  );
}

AnimatedPositioned _catPositioned(WidgetTester tester) =>
    tester.widget<AnimatedPositioned>(find.byKey(const ValueKey('companion-cat')));

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    CatDialogueService.instance.setPomodoroCatState(null);
    CatDialogueService.instance.setStudyState(studyLocked: false);
  });

  tearDown(() {
    CatDialogueService.instance.dismiss();
    CatDialogueService.instance.setPomodoroCatState(null);
    CatDialogueService.instance.setStudyState(studyLocked: false);
  });

  testWidgets('Mặc định đứng trên viền thanh điều hướng, chân chạm đúng mép', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final controller = CompanionCatController();
    await tester.pumpWidget(_harness(controller));
    await tester.pump();

    final pos = _catPositioned(tester);
    final footY = pos.top! + _catH * CatPositionManager.footAnchorY;
    expect(footY, closeTo(800, 0.01));
  });

  testWidgets('Kéo lên gần thẻ -> hiện đường dẫn, thả -> chân căn đúng mép trên thẻ & lưu bền', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final controller = CompanionCatController();
    await tester.pumpWidget(_harness(controller));
    await tester.pump();

    final catCenter = tester.getCenter(find.byKey(const ValueKey('companion-cat')));
    final gesture = await tester.startGesture(catCenter);
    await gesture.moveBy(const Offset(0, -20));
    await gesture.moveBy(const Offset(-60, -460));
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-line')), findsOneWidget);
    expect(find.byKey(const ValueKey('companion-cat-anim-drag')), findsOneWidget);
    await gesture.up();
    await tester.pump(const Duration(milliseconds: 300));

    expect(find.byKey(const ValueKey('companion-line')), findsNothing);
    expect(controller.attachedId, 'test_card');
    final pos = _catPositioned(tester);
    final footY = pos.top! + _catH * CatPositionManager.footAnchorY;
    expect(footY, closeTo(300, 0.01), reason: 'Chân mèo phải nằm đúng trên mép trên thẻ');
    // Mèo không tràn khỏi màn hình.
    expect(pos.left!, greaterThanOrEqualTo(0));
    expect(pos.left! + _catW, lessThanOrEqualTo(400.01));

    await tester.pump(const Duration(milliseconds: 50));
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getString(CompanionCatController.prefsSurfaceKey), 'test_card');

    // Khôi phục vị trí sau khi "khởi động lại".
    final restored = CompanionCatController();
    await restored.load();
    expect(restored.attachedId, 'test_card');
    expect(restored.relativeX, closeTo(controller.relativeX, 1e-6));
  });

  testWidgets('Bố cục thay đổi -> mèo bám theo bề mặt mới (responsive)', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final controller = CompanionCatController();
    await tester.pumpWidget(_harness(controller, cardTop: 300));
    await tester.pump();
    // Gắn trực tiếp lên thẻ.
    final key = controller.anchors.first;
    controller.attach(key, 0.5);
    await tester.pump();
    expect(_catPositioned(tester).top! + _catH * CatPositionManager.footAnchorY, closeTo(300, 0.01));

    // Thẻ dịch xuống 120px (ví dụ nội dung phía trên cao hơn).
    await tester.pumpWidget(_harness(controller, cardTop: 420));
    await tester.pump();
    controller.relayout();
    await tester.pump();
    expect(_catPositioned(tester).top! + _catH * CatPositionManager.footAnchorY, closeTo(420, 0.01));

    // Đổi kích thước màn hình: vẫn nằm trong vùng hiển thị.
    tester.view.physicalSize = const Size(320, 800);
    await tester.pump();
    controller.relayout();
    await tester.pump();
    final pos = _catPositioned(tester);
    expect(pos.left! + _catW, lessThanOrEqualTo(320.01));
  });

  testWidgets('Rìa trong suốt của mèo không che nút bên dưới; thân mèo vẫn nhận chạm', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    var backgroundTaps = 0;
    final controller = CompanionCatController();
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: CompanionCatScope(
          controller: controller,
          child: Stack(
            children: [
              Positioned.fill(
                child: GestureDetector(
                  key: const ValueKey('under-button'),
                  behavior: HitTestBehavior.opaque,
                  onTap: () => backgroundTaps++,
                ),
              ),
              Positioned.fill(child: LineCompanionCat(controller: controller)),
            ],
          ),
        ),
      ),
    ));
    await tester.pump();

    final rect = tester.getRect(find.byKey(const ValueKey('companion-cat')));
    // Góc trên-trái (vùng trong suốt) -> xuyên xuống nút.
    await tester.tapAt(rect.topLeft + Offset(rect.width * 0.08, rect.height * 0.06));
    await tester.pump();
    expect(backgroundTaps, 1);

    // Giữa thân mèo -> mèo nhận chạm (hiện bong bóng thoại), nút không nhận.
    await tester.tapAt(rect.center);
    await tester.pump();
    expect(backgroundTaps, 1);
    expect(find.byKey(const ValueKey('companion-bubble')), findsOneWidget);
    await tester.pump(const Duration(seconds: 6));
  });

  testWidgets('Trạng thái Pomodoro điều khiển hoạt ảnh mèo; năng lượng thấp -> sleep', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final controller = CompanionCatController();
    await tester.pumpWidget(_harness(controller));
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-cat-anim-idle')), findsOneWidget);

    CatDialogueService.instance.setPomodoroCatState(CatAnimState.studying);
    CatDialogueService.instance.setStudyState(studyLocked: true);
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-cat-anim-studying')), findsOneWidget);

    CatDialogueService.instance.setStudyState(studyLocked: false);
    CatDialogueService.instance.setPomodoroCatState(CatAnimState.relax);
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-cat-anim-relax')), findsOneWidget);

    CatDialogueService.instance.setPomodoroCatState(CatAnimState.happy);
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-cat-anim-happy')), findsOneWidget);

    CatDialogueService.instance.setPomodoroCatState(null);
    await tester.pumpWidget(_harness(controller, energy: 10));
    await tester.pump();
    expect(find.byKey(const ValueKey('companion-cat-anim-sleep')), findsOneWidget);
  });
}
