import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:nihongo_master/providers/auth_provider.dart';
import 'package:nihongo_master/providers/pomodoro_provider.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/providers/settings_provider.dart';
import 'package:nihongo_master/providers/study_history_provider.dart';
import 'package:nihongo_master/providers/theme_provider.dart';
import 'package:nihongo_master/providers/vocabulary_provider.dart';
import 'package:nihongo_master/screens/home/leaderboard_screen.dart';
import 'package:nihongo_master/screens/jlpt/jlpt_screen.dart';
import 'package:nihongo_master/services/feedback_audio_service.dart';
import 'package:nihongo_master/theme/theme_refresh_scope.dart';
import 'package:nihongo_master/utils/theme.dart';

/// Widget "kiểu cũ": đọc AppTheme.xxx trong build, KHÔNG phụ thuộc Theme.of(context).
class _LegacyBox extends StatelessWidget {
  const _LegacyBox();

  @override
  Widget build(BuildContext context) => Container(
        key: const ValueKey('legacy-box'),
        width: 20,
        height: 20,
        color: AppTheme.primary,
      );
}

class _CozyBox extends StatelessWidget {
  const _CozyBox();

  @override
  Widget build(BuildContext context) => Container(
        key: const ValueKey('cozy-box'),
        width: 20,
        height: 20,
        color: Theme.of(context).extension<CozyPalette>()!.primary,
      );
}

/// Dựng app giống `main.dart`: MaterialApp nhận theme từ ThemeProvider + ThemeRefreshScope.
Widget _app(ThemeProvider themeProvider, Widget home, {List<ChangeNotifierProvider> extra = const []}) {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider<ThemeProvider>.value(value: themeProvider),
      ...extra,
    ],
    child: Consumer<ThemeProvider>(
      builder: (context, tp, _) {
        AppTheme.setActiveTheme(tp.selectedThemeId);
        return MaterialApp(
          theme: AppTheme.themeFor(tp.selectedThemeId),
          home: home,
          builder: (context, child) => ThemeRefreshScope(
            themeId: AppTheme.activeThemeId,
            child: child ?? const SizedBox.shrink(),
          ),
        );
      },
    ),
  );
}

Color? _containerColor(WidgetTester tester, String key) =>
    tester.widget<Container>(find.byKey(ValueKey(key))).color;

/// Gom mọi màu giao diện đang hiển thị (Text, Icon, Container, BoxDecoration, Material).
Set<int> _renderedColors(WidgetTester tester) {
  final out = <int>{};
  void add(Color? c) {
    if (c != null) out.add(c.toARGB32() | 0xFF000000);
  }

  for (final w in tester.allWidgets) {
    if (w is Text) add(w.style?.color);
    if (w is RichText) add(w.text.style?.color);
    if (w is Icon) add(w.color);
    if (w is Material) add(w.color);
    if (w is Container) add(w.color);
    if (w is Container && w.decoration is BoxDecoration) {
      final d = w.decoration! as BoxDecoration;
      add(d.color);
      final b = d.border;
      if (b is Border) add(b.top.color);
    }
    if (w is DecoratedBox && w.decoration is BoxDecoration) {
      add((w.decoration as BoxDecoration).color);
    }
    if (w is AnimatedContainer && w.decoration is BoxDecoration) {
      add((w.decoration! as BoxDecoration).color);
    }
  }
  return out;
}

/// Màu giao diện của Dusty Rose + bảng màu cam đất cũ của Trang 3.
const _oldUiColors = <int>{
  0xFFB5838D, // dusty primary
  0xFF3D3135, // dusty textPrimary
  0xFF8D7B82, // dusty textSecondary
  0xFFF5E6E8, // dusty primarySoft
  0xFFEBE3E6, // dusty borderSubtle
  0xFFE07A5F, // leaderboard terracotta (cũ)
  0xFF4A333B, // leaderboard text (cũ)
  0xFF8C7178, // leaderboard text phụ (cũ)
};

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  GoogleFonts.config.allowRuntimeFetching = false;
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  setUp(() {
    FeedbackAudioService.disabledForTesting = true;
    SharedPreferences.setMockInitialValues({
      'onboarded': true,
      'wallet_coins': 500,
      'wallet_gems': 100,
      'sound_enabled': false,
      'notifications': false,
    });
    AppTheme.setActiveTheme(AppTheme.defaultThemeId);
  });

  group('ThemeData & CozyPalette cho từng theme', () {
    for (final spec in AppTheme.themes) {
      testWidgets(spec.id, (tester) async {
        final theme = AppTheme.themeFor(spec.id);
        final palette = theme.extension<CozyPalette>();
        expect(palette, isNotNull);
        expect(palette!.primary, spec.primary);
        expect(palette.surface, spec.surface);
        expect(palette.background, spec.background);
        expect(palette.textPrimary, spec.textPrimary);
        expect(palette.textSecondary, spec.textSecondary);
        expect(palette.borderSubtle, spec.borderSubtle);
        expect(theme.colorScheme.primary, spec.primary);
        expect(theme.scaffoldBackgroundColor, spec.background);
        expect(theme.dialogTheme.backgroundColor, spec.surface);
        expect(theme.textTheme.titleLarge?.color, spec.textPrimary);
        // Màu chức năng giữ nguyên ở mọi theme.
        expect(palette.success, CozyPalette.successColor);
        expect(palette.error, CozyPalette.errorColor);

        AppTheme.setActiveTheme(spec.id);
        expect(AppTheme.primary, spec.primary);
        expect(AppTheme.surface, spec.surface);
        expect(AppTheme.textPrimary, spec.textPrimary);
        expect(AppTheme.success, CozyPalette.successColor);
      });
    }
  });

  testWidgets('Đổi theme: widget cũ (AppTheme) + mới (CozyPalette) + dialog đang mở cập nhật ngay', (tester) async {
    final themeProvider = ThemeProvider(initialThemeId: 'dusty_rose');
    await tester.pumpWidget(_app(
      themeProvider,
      Scaffold(
        body: Builder(
          builder: (context) => Column(
            children: [
              const _LegacyBox(),
              const _CozyBox(),
              TextButton(
                onPressed: () => showDialog<void>(
                  context: context,
                  builder: (_) => const AlertDialog(content: _LegacyBox()),
                ),
                child: const Text('open'),
              ),
            ],
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    final dusty = AppTheme.specFor('dusty_rose');
    expect(_containerColor(tester, 'legacy-box'), dusty.primary);
    expect(_containerColor(tester, 'cozy-box'), dusty.primary);

    await tester.tap(find.text('open'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('legacy-box')), findsNWidgets(2));

    for (final id in ['ocean_blue', 'sky_butter', 'white_sage', 'cyber_midnight', 'royal_palace', 'dusty_rose']) {
      await tester.runAsync(() => themeProvider.setTheme(id));
      await tester.pumpAndSettle();
      final spec = AppTheme.specFor(id);
      final legacy = tester.widgetList<Container>(find.byKey(const ValueKey('legacy-box'))).map((c) => c.color).toList();
      expect(legacy, everyElement(spec.primary), reason: 'Trang + dialog phải nhận màu $id');
      expect(_containerColor(tester, 'cozy-box'), spec.primary);
      final dialogMaterial = tester.widget<Material>(
        find.descendant(of: find.byType(AlertDialog), matching: find.byType(Material)).first,
      );
      expect(dialogMaterial.color, spec.surface, reason: 'Nền dialog theo theme $id');
    }
  });

  Future<List<ChangeNotifierProvider>> appProviders(WidgetTester tester) async {
    final settings = SettingsProvider();
    final progress = ProgressProvider();
    final auth = AuthProvider();
    final pomodoro = PomodoroProvider();
    final history = StudyHistoryProvider();
    final vocab = VocabularyProvider();
    await tester.runAsync(() async {
      await settings.init();
      await progress.init();
      await pomodoro.init(progressProvider: progress);
    });
    return [
      ChangeNotifierProvider<SettingsProvider>.value(value: settings),
      ChangeNotifierProvider<ProgressProvider>.value(value: progress),
      ChangeNotifierProvider<AuthProvider>.value(value: auth),
      ChangeNotifierProvider<PomodoroProvider>.value(value: pomodoro),
      ChangeNotifierProvider<StudyHistoryProvider>.value(value: history),
      ChangeNotifierProvider<VocabularyProvider>.value(value: vocab),
    ];
  }

  for (final screen in <String, Widget>{
    'Trang 2 - Luyện đề JLPT': const Scaffold(body: JLPTScreen()),
    'Trang 3 - Xếp hạng': const Scaffold(body: LeaderboardScreen()),
  }.entries) {
    testWidgets('${screen.key}: đổi theme -> không còn màu Dusty Rose / cam đất cũ', (tester) async {
      await tester.binding.setSurfaceSize(const Size(480, 1600));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final themeProvider = ThemeProvider(initialThemeId: 'dusty_rose');
      final extra = await appProviders(tester);
      await tester.pumpWidget(_app(themeProvider, screen.value, extra: extra));
      await tester.pump(const Duration(milliseconds: 500));

      final before = _renderedColors(tester);
      expect(before.contains(0xFFB5838D) || before.contains(0xFF3D3135), isTrue,
          reason: 'Ở Dusty Rose phải thấy màu Dusty Rose');

      for (final id in ['ocean_blue', 'sky_butter', 'white_sage']) {
        await tester.runAsync(() => themeProvider.setTheme(id));
        // MaterialApp nội suy theme trong 200ms (AnimatedTheme) -> cần vài frame.
        // AnimatedContainer con nội suy tiếp sau đó -> pump tới khi ổn định.
        for (var f = 0; f < 12; f++) {
          await tester.pump(const Duration(milliseconds: 100));
        }
        final spec = AppTheme.specFor(id);
        final after = _renderedColors(tester);
        final leftovers = after.intersection(_oldUiColors);
        expect(leftovers, isEmpty,
            reason: '${screen.key} [$id] còn màu cũ: ${leftovers.map((c) => c.toRadixString(16)).toList()}');
        expect(after.contains(spec.primary.toARGB32()) || after.contains(spec.textPrimary.toARGB32()), isTrue,
            reason: '${screen.key} [$id] phải hiển thị màu của theme mới');
      }
    });
  }
}
