import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/services/local_database_service.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Dựng một DB đúng cấu trúc v2 (các bảng liên quan) kèm dữ liệu nội dung + tiến trình học.
Future<Database> _openV2Fixture(String path) async {
  return databaseFactory.openDatabase(
    path,
    options: OpenDatabaseOptions(
      version: 2,
      onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, _) async {
        await db.execute('CREATE TABLE licenses (id TEXT PRIMARY KEY, code TEXT NOT NULL, name TEXT NOT NULL)');
        await db.execute(
          'CREATE TABLE data_sources (id TEXT PRIMARY KEY, name TEXT NOT NULL, source_url TEXT NOT NULL, '
          'license_id TEXT NOT NULL, attribution_text TEXT NOT NULL, fetched_at TEXT NOT NULL, '
          'FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT)',
        );
        await db.execute(
          'CREATE TABLE vocabularies (id TEXT PRIMARY KEY, source_id TEXT NOT NULL, license_id TEXT NOT NULL, '
          'expression TEXT NOT NULL, reading_hiragana TEXT NOT NULL, meaning_vi TEXT, meaning_en TEXT NOT NULL, '
          'original_level TEXT, FOREIGN KEY (source_id) REFERENCES data_sources(id) ON DELETE RESTRICT, '
          'FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE RESTRICT)',
        );
        await db.execute(
          'CREATE TABLE kanji_entries (id TEXT PRIMARY KEY, character TEXT NOT NULL UNIQUE, meaning_vi TEXT, meaning_en TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE grammar_points (id TEXT PRIMARY KEY, pattern TEXT NOT NULL, title_vi TEXT, explanation_vi TEXT)',
        );
        await db.execute(
          'CREATE TABLE example_sentences (id TEXT PRIMARY KEY, sentence_jp TEXT NOT NULL, translation_vi TEXT, '
          'linked_vocab_id TEXT, FOREIGN KEY (linked_vocab_id) REFERENCES vocabularies(id) ON DELETE SET NULL)',
        );
        await db.execute(
          'CREATE TABLE reading_materials (id TEXT PRIMARY KEY, title_jp TEXT NOT NULL, title_vi TEXT, translation_vi TEXT)',
        );
        await db.execute('CREATE TABLE vocabulary_cache (id TEXT PRIMARY KEY, japanese TEXT NOT NULL)');
        await db.execute(
          "CREATE TABLE flashcard_progress (vocabId TEXT NOT NULL, userId TEXT NOT NULL DEFAULT 'guest', "
          'repetition INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (userId, vocabId), '
          'FOREIGN KEY (vocabId) REFERENCES vocabulary_cache(id) ON DELETE CASCADE)',
        );
        await db.execute('CREATE TABLE test_history (id INTEGER PRIMARY KEY AUTOINCREMENT, testId TEXT, scorePercent REAL)');

        await db.insert('licenses', {'id': 'cc', 'code': 'CC-BY-SA', 'name': 'CC'});
        await db.insert('data_sources', {
          'id': 'jmdict', 'name': 'JMdict', 'source_url': 'x', 'license_id': 'cc',
          'attribution_text': 'x', 'fetched_at': '2026-01-01',
        });
        for (var i = 0; i < 50; i++) {
          await db.insert('vocabularies', {
            'id': 'v$i', 'source_id': 'jmdict', 'license_id': 'cc', 'expression': '語$i',
            'reading_hiragana': 'ご', 'meaning_en': 'word $i', 'original_level': 'N5',
          });
        }
        await db.insert('example_sentences', {'id': 's1', 'sentence_jp': '日本語を勉強します。', 'linked_vocab_id': 'v1'});
        await db.insert('vocabulary_cache', {'id': 'v1', 'japanese': '語1'});
        await db.insert('flashcard_progress', {'vocabId': 'v1', 'userId': 'guest', 'repetition': 4});
        await db.insert('test_history', {'testId': 'N5_01', 'scorePercent': 80.0});
      },
    ),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Directory tempDir;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    tempDir = await Directory.systemTemp.createTemp('nm_translation_migration_');
  });

  tearDown(() async {
    await LocalDatabaseService.instance.closeDatabaseSafely();
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(null);
    if (tempDir.existsSync()) await tempDir.delete(recursive: true);
  });

  Future<void> expectMigratedAndPreserved(Database db) async {
    for (final table in LocalDatabaseService.translatableTables.keys) {
      final cols = await db.rawQuery('PRAGMA table_info("$table")');
      final col = cols.firstWhere((c) => c['name'] == 'translation_status');
      expect(col['notnull'], 1, reason: table);
      expect(col['dflt_value'], "'source'", reason: table);
    }
    // Dữ liệu cũ còn nguyên và nhận giá trị mặc định.
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM vocabularies')), 50);
    expect(
      Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM vocabularies WHERE translation_status = 'source'")),
      50,
    );
    // Tiến trình học không bị chạm.
    final fp = await db.query('flashcard_progress');
    expect(fp, hasLength(1));
    expect(fp.first['repetition'], 4);
    expect(Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM test_history')), 1);
    // Khoá ngoại vẫn hợp lệ.
    expect(await db.rawQuery('PRAGMA foreign_key_check'), isEmpty);
    // CHECK chặn giá trị không hợp lệ.
    await expectLater(
      db.rawUpdate("UPDATE vocabularies SET translation_status = 'machine' WHERE id = 'v1'"),
      throwsA(isA<DatabaseException>()),
    );
    await db.rawUpdate("UPDATE vocabularies SET translation_status = 'ai_translated' WHERE id = 'v1'");
    await db.rawUpdate("UPDATE vocabularies SET translation_status = 'reviewed' WHERE id = 'v2'");
  }

  test('migrateToV3 (dùng trong onUpgrade): thêm cột an toàn, giữ dữ liệu & tiến trình, idempotent', () async {
    final db = await _openV2Fixture(p.join(tempDir.path, 'v2.db'));
    await LocalDatabaseService.migrateToV3(db);
    await LocalDatabaseService.migrateToV3(db); // chạy lại không lỗi
    await expectMigratedAndPreserved(db);
    final meta = await db.rawQuery("SELECT name FROM sqlite_master WHERE name = 'dataset_meta'");
    expect(meta, hasLength(1));
    await db.close();
  });

  test('File tools/migrations/v3_translation_status.sql hợp lệ trên DB v2', () async {
    final path = p.join(tempDir.path, 'v2_sql.db');
    final db = await _openV2Fixture(path);
    final sqlFile = File(p.join('tools', 'migrations', 'v3_translation_status.sql'));
    final statements = sqlFile
        .readAsLinesSync()
        .where((l) => !l.trimLeft().startsWith('--'))
        .join('\n')
        .split(';')
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty && s != 'BEGIN TRANSACTION' && s != 'COMMIT');
    await db.transaction((txn) async {
      for (final s in statements) {
        await txn.execute(s);
      }
    });
    await expectMigratedAndPreserved(db);
    expect(Sqflite.firstIntValue(await db.rawQuery('PRAGMA user_version')), 3);
    await db.close();
  });

  test('Mở DB v2 qua đường onUpgrade thật (version 2 -> 3)', () async {
    final path = p.join(tempDir.path, 'upgrade.db');
    final v2 = await _openV2Fixture(path);
    await v2.close();
    final db = await databaseFactory.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: LocalDatabaseService.databaseVersion,
        onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
        onUpgrade: (db, oldV, newV) async {
          if (oldV < 3) await LocalDatabaseService.migrateToV3(db);
        },
      ),
    );
    await expectMigratedAndPreserved(db);
    expect(await db.getVersion(), LocalDatabaseService.databaseVersion);
    await db.close();
  });

  test('syncTranslationsFromAssets: cập nhật bản dịch AI, không ghi đè reviewed/source, idempotent', () async {
    LocalDatabaseService.instance.setCustomDatabasesDirPathForTesting(tempDir.path);
    final db = await LocalDatabaseService.instance.database;
    await db.insert('licenses', {'id': 'cc', 'code': 'CC', 'name': 'CC'});
    await db.insert('data_sources', {
      'id': 'jmdict', 'name': 'JMdict', 'source_url': 'x', 'license_id': 'cc',
      'attribution_text': 'x', 'fetched_at': '2026-01-01',
    });
    Map<String, Object?> vocab(String id, {String? vi, String status = 'source'}) => {
          'id': id, 'source_id': 'jmdict', 'license_id': 'cc', 'expression': '語',
          'reading_hiragana': 'ご', 'meaning_en': 'word', 'meaning_vi': vi, 'translation_status': status,
        };
    await db.insert('vocabularies', vocab('empty'));
    await db.insert('vocabularies', vocab('reviewed', vi: 'nghĩa đã duyệt', status: 'reviewed'));
    await db.insert('vocabularies', vocab('human', vi: 'nghĩa gốc', status: 'source'));
    await db.insert('vocabularies', vocab('old_ai', vi: 'bản AI cũ', status: 'ai_translated'));
    await db.insert('example_sentences', {
      'id': 'ex1', 'source_id': 'jmdict', 'license_id': 'cc', 'sentence_jp': '日本語を勉強します。',
      'translation_en': 'I study Japanese.', 'linked_vocab_id': 'empty',
    });
    await db.insert('vocabulary_cache', {
      'id': 'empty', 'japanese': '語', 'hiragana': 'ご', 'vietnamese': '', 'english': 'word',
      'jlptLevel': 'N5', 'category': 'general', 'exampleSentences': '["日本語を勉強します。"]',
      'exampleTranslations': '["I study Japanese."]', 'isLearned': 1, 'correctCount': 7,
    });
    await db.insert('flashcard_progress', {'vocabId': 'empty', 'userId': 'guest', 'repetition': 3});

    final assets = Directory(p.join(tempDir.path, 'assets'))..createSync();
    File(p.join(assets.path, 'vocabularies.json')).writeAsStringSync(jsonEncode([
      {'id': 'empty', 'meaning_vi': 'từ ngữ', 'translation_status': 'ai_translated'},
      {'id': 'reviewed', 'meaning_vi': 'AI muốn ghi đè', 'translation_status': 'ai_translated'},
      {'id': 'human', 'meaning_vi': 'AI muốn ghi đè', 'translation_status': 'ai_translated'},
      {'id': 'old_ai', 'meaning_vi': 'bản AI mới', 'translation_status': 'ai_translated'},
      {'id': 'not_in_db', 'meaning_vi': 'x', 'translation_status': 'ai_translated'},
    ]));
    for (final f in ['kanji_entries.json', 'grammar_points.json', 'reading_materials.json']) {
      File(p.join(assets.path, f)).writeAsStringSync('[]');
    }
    File(p.join(assets.path, 'example_sentences.json')).writeAsStringSync(jsonEncode([
      {'id': 'ex1', 'translation_vi': 'Tôi học tiếng Nhật.', 'translation_status': 'ai_translated'},
    ]));

    final updated = await LocalDatabaseService.instance.syncTranslationsFromAssets(assetsDirPath: assets.path);
    expect(updated, 3);
    Future<Map<String, Object?>> row(String id) async =>
        (await db.query('vocabularies', where: 'id = ?', whereArgs: [id])).first;
    expect((await row('empty'))['meaning_vi'], 'từ ngữ');
    expect((await row('empty'))['translation_status'], 'ai_translated');
    expect((await row('reviewed'))['meaning_vi'], 'nghĩa đã duyệt');
    expect((await row('reviewed'))['translation_status'], 'reviewed');
    expect((await row('human'))['meaning_vi'], 'nghĩa gốc');
    expect((await row('old_ai'))['meaning_vi'], 'bản AI mới');

    // Bản dịch tới được vocabulary_cache (bảng app đọc), cờ học tập giữ nguyên, tiến trình không bị cascade xoá.
    final cache = (await db.query('vocabulary_cache', where: 'id = ?', whereArgs: ['empty'])).first;
    expect(cache['vietnamese'], 'từ ngữ');
    expect(jsonDecode(cache['exampleTranslations'] as String), ['Tôi học tiếng Nhật.']);
    expect(cache['isLearned'], 1);
    expect(cache['correctCount'], 7);
    final progress = await db.query('flashcard_progress');
    expect(progress, hasLength(1));
    expect(progress.first['repetition'], 3);

    // Chạy lại: dấu vân tay không đổi -> không làm gì.
    expect(await LocalDatabaseService.instance.syncTranslationsFromAssets(assetsDirPath: assets.path), 0);
  });
}
