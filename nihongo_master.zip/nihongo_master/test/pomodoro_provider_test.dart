import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_master/models/cat_anim_state.dart';
import 'package:nihongo_master/providers/pomodoro_provider.dart';
import 'package:nihongo_master/providers/progress_provider.dart';
import 'package:nihongo_master/services/cat_dialogue_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Đồng hồ giả để kiểm thử đếm ngược theo wall clock.
class FakeClock {
  DateTime now = DateTime(2026, 11, 8, 9, 0, 0);
  DateTime call() => now;
  void advance(Duration d) => now = now.add(d);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late FakeClock clock;
  late ProgressProvider progress;
  late PomodoroProvider pomo;
  var pomoReady = false;

  Future<void> setUpProviders({Map<String, Object> prefs = const {}}) async {
    SharedPreferences.setMockInitialValues({
      'wallet_coins': 200,
      'sound_enabled': false,
      'notifications': false,
      ...prefs,
    });
    clock = FakeClock();
    progress = ProgressProvider();
    await progress.init();
    pomo = PomodoroProvider(clock: clock.call, observeLifecycle: false);
    pomoReady = true;
    await pomo.init(progressProvider: progress);
  }

  tearDown(() {
    if (pomoReady) pomo.dispose();
    pomoReady = false;
    CatDialogueService.instance.dismiss();
  });

  test('Idle mặc định, mở Pomodoro không chuyển mèo sang Studying', () async {
    await setUpProviders();
    expect(pomo.phase, PomodoroPhase.idle);
    expect(CatDialogueService.instance.pomodoroCatState, isNull);
    expect(CatDialogueService.instance.isStudyLocked, isFalse);
    expect(pomo.hasActiveTicker, isFalse);
  });

  test('Cấu hình tuỳ chỉnh 4 tham số và được lưu bền', () async {
    await setUpProviders();
    pomo.setStudyMinutes(30);
    pomo.setShortBreakMinutes(3);
    pomo.setLongBreakMinutes(20);
    pomo.setSessionsBeforeLongBreak(2);
    expect(pomo.formattedRemaining, '30:00');
    await Future<void>.delayed(Duration.zero);

    final reloaded = PomodoroProvider(clock: clock.call, observeLifecycle: false);
    await reloaded.init(progressProvider: progress);
    expect(reloaded.studyMinutes, 30);
    expect(reloaded.shortBreakMinutes, 3);
    expect(reloaded.longBreakMinutes, 20);
    expect(reloaded.sessionsBeforeLongBreak, 2);
    reloaded.dispose();
  });

  test('Bắt đầu -> đếm ngược theo đồng hồ thực, mèo Studying, một timer duy nhất', () async {
    await setUpProviders();
    pomo.setStudyMinutes(25);
    await pomo.startTimer();
    expect(pomo.phase, PomodoroPhase.studying);
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.studying);
    expect(CatDialogueService.instance.isStudyLocked, isTrue);
    expect(pomo.hasActiveTicker, isTrue);

    // Bắt đầu lần nữa không tạo phiên/timer mới.
    final endsAt = pomo.phaseEndsAt;
    await pomo.startTimer();
    expect(pomo.phaseEndsAt, endsAt);

    // App bị chậm: chỉ 1 tick nhưng đã trôi 90 giây thực -> vẫn đúng.
    clock.advance(const Duration(seconds: 90));
    pomo.tick();
    expect(pomo.remainingSeconds, 25 * 60 - 90);
    expect(pomo.formattedRemaining, '23:30');
  });

  test('Tạm dừng giữ nguyên thời gian; Tiếp tục không cộng thêm / không khởi tạo lại', () async {
    await setUpProviders();
    pomo.setStudyMinutes(25);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 5));
    pomo.pause();
    expect(pomo.phase, PomodoroPhase.paused);
    expect(pomo.hasActiveTicker, isFalse);
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.paused);
    expect(pomo.remainingSeconds, 20 * 60);

    clock.advance(const Duration(minutes: 10)); // thời gian tạm dừng không bị trừ
    expect(pomo.remainingSeconds, 20 * 60);

    pomo.resume();
    expect(pomo.phase, PomodoroPhase.studying);
    expect(pomo.remainingSeconds, 20 * 60);
    expect(pomo.phaseTotalSeconds, 25 * 60);
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.studying);
  });

  test('Hết giờ học -> trừ Energy 1%/phút, thưởng Xu, chuyển nghỉ ngắn (Relax)', () async {
    await setUpProviders();
    final energyBefore = progress.progress.catEnergy;
    final coinsBefore = progress.progress.coins;
    pomo.setStudyMinutes(15);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 15));
    pomo.tick();
    await Future<void>.delayed(const Duration(milliseconds: 20));

    expect(pomo.phase, PomodoroPhase.shortBreak);
    expect(pomo.completedSessionsCount, 1);
    expect(pomo.cycleSessions, 1);
    expect(progress.progress.catEnergy, energyBefore - 15);
    expect(progress.progress.coins, greaterThan(coinsBefore));
    expect(pomo.lastCompletionMessage, contains('Hoàn thành'));
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.relax);
    expect(CatDialogueService.instance.isStudyLocked, isFalse);
    expect(pomo.remainingSeconds, pomo.shortBreakMinutes * 60);
  });

  test('Hết giờ nghỉ -> Completed (Happy), không tự bắt đầu phiên mới', () async {
    await setUpProviders();
    pomo.setStudyMinutes(10);
    pomo.setShortBreakMinutes(5);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 10));
    pomo.tick();
    await Future<void>.delayed(const Duration(milliseconds: 20));
    expect(pomo.phase, PomodoroPhase.shortBreak);

    clock.advance(const Duration(minutes: 5));
    pomo.tick();
    expect(pomo.phase, PomodoroPhase.completed);
    expect(pomo.hasActiveTicker, isFalse);
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.happy);

    clock.advance(const Duration(minutes: 30));
    pomo.tick();
    expect(pomo.phase, PomodoroPhase.completed);

    await pomo.startTimer();
    expect(pomo.phase, PomodoroPhase.studying);
  });

  test('Đủ số phiên -> nghỉ dài (Sleep), sau nghỉ dài reset chu kỳ', () async {
    await setUpProviders();
    pomo.setStudyMinutes(5);
    pomo.setShortBreakMinutes(3);
    pomo.setLongBreakMinutes(15);
    pomo.setSessionsBeforeLongBreak(2);

    for (var i = 0; i < 2; i++) {
      await pomo.startTimer();
      clock.advance(const Duration(minutes: 5));
      pomo.tick();
      await Future<void>.delayed(const Duration(milliseconds: 20));
      if (i == 0) {
        expect(pomo.phase, PomodoroPhase.shortBreak);
        pomo.skipBreak();
        expect(pomo.phase, PomodoroPhase.completed);
      }
    }
    expect(pomo.phase, PomodoroPhase.longBreak);
    expect(CatDialogueService.instance.pomodoroCatState, CatAnimState.sleep);
    expect(pomo.remainingSeconds, 15 * 60);

    clock.advance(const Duration(minutes: 15));
    pomo.tick();
    expect(pomo.phase, PomodoroPhase.completed);
    expect(pomo.cycleSessions, 0);
    expect(pomo.completedSessionsCount, 2);
  });

  test('Anti-Cheat: rời app khi đang học -> -50 Xu, huỷ phiên', () async {
    await setUpProviders();
    final coins = progress.progress.coins;
    await pomo.startTimer();
    pomo.didChangeAppLifecycleState(AppLifecycleState.paused);
    await Future<void>.delayed(const Duration(milliseconds: 20));
    expect(pomo.phase, PomodoroPhase.cancelled);
    expect(progress.progress.coins, coins - 50);
    expect(pomo.lastPenaltyMessage, contains('Phát hiện rời phiên học! Phạt 50 Xu!'));
    expect(pomo.hasActiveTicker, isFalse);
    expect(CatDialogueService.instance.isStudyLocked, isFalse);
  });

  test('Anti-Cheat: bấm Kết thúc sớm (kể cả khi tạm dừng) -> -50 Xu; ví không âm', () async {
    await setUpProviders(prefs: {'wallet_coins': 30});
    await pomo.startTimer();
    pomo.pause();
    await pomo.stop();
    expect(pomo.phase, PomodoroPhase.cancelled);
    expect(progress.progress.coins, 0);
  });

  test('Không phạt khi rời app trong giờ nghỉ; quay lại tính đúng thời gian', () async {
    await setUpProviders();
    pomo.setStudyMinutes(5);
    pomo.setShortBreakMinutes(5);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 5));
    pomo.tick();
    await Future<void>.delayed(const Duration(milliseconds: 20));
    final coins = progress.progress.coins;

    pomo.didChangeAppLifecycleState(AppLifecycleState.paused);
    clock.advance(const Duration(minutes: 2));
    pomo.didChangeAppLifecycleState(AppLifecycleState.resumed);
    expect(pomo.phase, PomodoroPhase.shortBreak);
    expect(pomo.remainingSeconds, 3 * 60);
    expect(progress.progress.coins, coins);
  });

  test('Force Kill khi đang học -> phạt khi mở lại; giờ nghỉ được khôi phục', () async {
    await setUpProviders();
    await pomo.startTimer();
    await Future<void>.delayed(Duration.zero);
    final coins = progress.progress.coins;

    // Mô phỏng app bị kill: tạo provider mới đọc cùng SharedPreferences.
    final reopened = PomodoroProvider(clock: clock.call, observeLifecycle: false);
    await reopened.init(progressProvider: progress);
    expect(reopened.phase, PomodoroPhase.cancelled);
    expect(progress.progress.coins, coins - 50);
    reopened.dispose();

    // Giờ nghỉ đang chạy được khôi phục với thời gian còn lại chính xác.
    pomo.dispose();
    pomo = PomodoroProvider(clock: clock.call, observeLifecycle: false);
    await pomo.init(progressProvider: progress);
    pomo.setStudyMinutes(5);
    pomo.setShortBreakMinutes(5);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 5));
    pomo.tick();
    await Future<void>.delayed(const Duration(milliseconds: 20));
    clock.advance(const Duration(minutes: 1));
    final restored = PomodoroProvider(clock: clock.call, observeLifecycle: false);
    await restored.init(progressProvider: progress);
    expect(restored.phase, PomodoroPhase.shortBreak);
    expect(restored.remainingSeconds, 4 * 60);
    restored.dispose();
  });

  test('Năng lượng < 20% sau phiên học -> mèo ủ rũ + nhắc vào Shop', () async {
    await setUpProviders();
    await progress.drainCatEnergy(progress.progress.catEnergy - 25);
    expect(progress.progress.catEnergy, 25);
    pomo.setStudyMinutes(10);
    await pomo.startTimer();
    clock.advance(const Duration(minutes: 10));
    pomo.tick();
    await Future<void>.delayed(const Duration(milliseconds: 20));
    expect(progress.progress.catEnergy, 15);
    expect(pomo.isPostStudyTired, isTrue);
    expect(CatDialogueService.instance.isPostStudyTired, isTrue);
    expect(pomo.lastCompletionMessage, contains('Shop'));
  });
}
